import path from "path";
import fs from "fs-extra";
import low, { LowdbSync } from "lowdb";
import { DebouncedFileAdapter } from "./debouncedAdapter";
import { GroupMetadata } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { getBotSelfNumber, getOwnerLid } from "../utils/botIdentity";
import { findParticipant } from "../utils/participantMatch";
import { logger } from "../utils/logger";
import { scheduleCloudBackup, fetchCloudBackup } from "./supabaseBackup";

/**
 * 🔧 إصلاح جذري مهم جدًا (سبب أخطاء متفرقة كثيرة: ".نون/.قص" يقول "تم"
 * لكن الرصيد يطلع دايمًا 0، النقاط ما تنحفظ صح، التحذيرات/الكتم أحيانًا
 * "تنسى" شخص...):
 *
 * lowdb v1 يفسّر أي مسار (path) نمرره لـ db.get()/db.set() كنص مفصول
 * بنقاط (dot-path) عبر lodash — يعني `db.get(\`points.${safeKey(groupId)}.${safeKey(userId)}\`)`
 * إذا كان userId رقم واتساب عادي مثل "9647xxxxxxxxx@s.whatsapp.net"،
 * فالنقطتين اللي جوا "s.whatsapp.net" تتفسّر كأجزاء مسار إضافية!
 * فبدل ما يخزن كمفتاح واحد مسطّح، ينكسر لعدة مستويات متداخلة عشوائيًا
 * (points → groupId → "xxxx@s" → "whatsapp" → "net")، وبالتالي أي قراءة
 * لاحقة بنفس الطريقة قد "تلاقي" أو "ما تلاقي" القيمة حسب صيغة الـ JID
 * بالضبط تلك اللحظة (خصوصًا مع اختلاف @lid عن @s.whatsapp.net).
 *
 * الحل: أي JID (أو أي نص ممكن يحتوي نقطة) لازم يُنظَّف بهذي الدالة قبل
 * ما يدخل بأي مسار db.get/db.set. تستبدل كل نقطة بشرطة سفلية فقط —
 * تحافظ على التفرد الكامل للمعرّف دون كسر مسار lodash.
 */
function safeKey(id: string): string {
  return String(id).replace(/\./g, "~");
}

/** يعكس safeKey — يرجّع النقاط الأصلية بعد قراءة مفتاح مخزَّن (يلزم فقط
 * عند إرجاع الـ JID نفسه للمستخدم، مثل مفاتيح كائن points بلوحة الصدارة). */
function unsafeKey(id: string): string {
  return String(id).replace(/~/g, ".");
}

export interface GroupSettings {
  protection: boolean;
  antilink: boolean;
  antispam: boolean;
  // 🆕 (طلب صريح: حماية حذف جهات الاتصال) — معطّلة افتراضيًا لكل مجموعة
  // جديدة (خلاف antilink/antispam المفعّلتين افتراضيًا)، يفعّلها المطور
  // عبر نظام الحماية الموجود أصلًا (.اعدادات).
  antiContact: boolean;
  events: boolean;
  welcome: boolean;
  goodbye: boolean;
  autoReply: boolean;
  salawat: boolean;
  prayerTimes: boolean;
  enabled: boolean; // إيقاف/تشغيل البوت داخل مجموعة محددة (.تشغيل / .ايقاف — للمطور فقط)
  // 🆕 (طلب صريح: "لو 3 بواتات بكروب واحد كتب .ايقاف ما يوقفن 3 بس
  // بوته") — قبل هذا الحقل، "enabled" أعلاه كان يوقف كل البوتات بهذي
  // المجموعة معًا (رئيسي + كل الفرعيين) لأنه فحص واحد مشترك بلا أي تمييز.
  // enabledByBot يخزّن حالة كل بوت براسه (المفتاح = رقم البوت الفعلي عبر
  // getBotScopeId) — .ايقاف/.تشغيل الآن يكتبان هنا فقط لبوتهما هما.
  // بوت بدون أي إدخال هنا: البوت الرئيسي يرجع لقيمة enabled القديمة
  // (توافق خلفي)، وأي بوت فرعي يعتبر مفعّل افتراضيًا. راجع
  // isBotEnabledInGroup/setBotEnabledInGroup بالأسفل.
  enabledByBot?: Record<string, boolean>;
  // 🆕 هل أمر ".استمارة" مفعّل بهذي المجموعة؟ مطفي افتراضيًا لكل مجموعة —
  // لازم الأدمن يفعّله يدويًا عبر ".اعدادات استمارة تشغيل" قبل ما يشتغل
  // الأمر لأي عضو بهذي المجموعة تحديدًا (راجع src/commands/tools/form.ts).
  formEnabled: boolean;
  // 🆕 هل أمر ".تنصيب" مفعّل بهذي المجموعة؟ مطفي افتراضيًا لكل مجموعة —
  // لا يعمل تلقائيًا أبدًا، لازم المطور تحديدًا (owner) يفعّله يدويًا عبر
  // ".تفعيل_تنصيب" قبل ما يشتغل الأمر بهذي المجموعة (طلب صريح — راجع
  // src/commands/install/install.ts و src/commands/owner/enableInstall.ts).
  installEnabled: boolean;
  // 🆕 هل البوتات الفرعية (المنصّبة عبر .تنصيب) مسموح لها بالعمل بهذي
  // المجموعة تحديدًا؟ true افتراضيًا (لا تؤثر على أي بوت فرعي حتى يوقفها
  // أدمن/مطور صراحة عبر ".تعطيل_بوت"). هذا الإعداد منفصل تمامًا عن
  // "enabled" (اللي يوقف البوت الرئيسي) — إيقافه لا يوقف إلا البوتات
  // الفرعية بهذي المجموعة بالذات، والبوت الرئيسي يستمر بالعمل طبيعيًا.
  // راجع src/commands/install/disableSubBots.ts و enableSubBots.ts.
  subBotsEnabled: boolean;
  // 🆕 (طلب صريح: أمر "مضاد الاشراف" من ملف خارجي) — لو مفعّلة، أي مشرف
  // (غير المطور والبوت نفسه) يسحب إشراف مشرف ثاني يُنزَّل تلقائيًا هو
  // نفسه من الإشراف فورًا (حماية من إساءة استخدام الإشراف ضد مشرفين
  // آخرين). false افتراضيًا لكل مجموعة — قرار حساس (طرد فعلي من
  // الإشراف)، لازم الأدمن يفعّله يدويًا. راجع src/events/groupParticipants.ts.
  antiDemoteAbuse: boolean;
}

export interface DbSchema {
  groups: Record<
    string,
    {
      settings: GroupSettings;
      warnings: Record<string, number>;
      blocked: string[]; // أعضاء ممنوعون من استخدام البوت داخل هذه المجموعة
      muted: string[]; // أعضاء مكتومون (تُحذف رسائلهم تلقائيًا)
      virtualAdmins: string[]; // أعضاء أعطاهم المطور صلاحية "أدمن وهمي" عبر .رفع_ادمن (بدون ترقية واتساب حقيقية)
      rules?: string; // 🆕 نص قوانين هذي المجموعة تحديدًا (تُعرض بأمر .القوانين وتُحدَّث بأمر .تغيير_القوانين — كل مجموعة قوانينها الخاصة بها فقط)
    }
  >;
  points: Record<string, Record<string, number>>; // points[groupId][userId] = score
  economy: Record<
    string,
    {
      wallet: number;
      bank: number;
      lastDaily: number;
      lastWeekly: number;
      // 🆕 (طلب صريح: نظام مستويات + متجر نقاط) — حقول جديدة، كلها اختيارية
      // حتى تبقى متوافقة مع سجلات economy القديمة (تُملأ افتراضيًا أول
      // استخدام عبر ensureEconomyLevelFields بالأسفل).
      xp?: number;
      lastXpAt?: number; // آخر مرة استلم فيها XP من نشاط عادي (سقف مرة كل دقيقة لمنع الفلوود)
      ownedTitles?: string[]; // ألقاب اشتراها من المتجر (نص اللقب كما هو)
      equippedTitle?: string; // اللقب المفعّل حاليًا (لازم يكون من ownedTitles)
    }
  >; // economy[userId] — محفظة عامة لكل مستخدم (غير مرتبطة بمجموعة واحدة)
  bot: {
    publicMode: boolean;
    autoReplyMigrated?: boolean;
    // 🆕 أقسام الأوامر الموقوفة حاليًا بأمر المطور (.تعطيل <القسم>) —
    // إيقاف عام على كل البوت (كل المجموعات + الخاص)، مو خاص بمجموعة
    // واحدة زي .ايقاف. تخزّن أسماء الفئات (Command["category"]) كما هي.
    disabledSections?: string[];
    // 🆕 (.رفع_مالك) — أعضاء أعطاهم المطور صلاحية "أدمن" بكل مجموعة
    // يتواجد فيها البوت حاليًا أو مستقبلًا (عكس virtualAdmins اللي محصورة
    // بمجموعة وحدة بس). راجع تعليق grantGlobalVirtualAdmin بالأسفل.
    globalVirtualAdmins?: string[];
  };
  // آخر مرة استخدم فيها كل شخص أمر .سرقه (سرقة نقاط) — سقف مرة كل ساعة لكل شخص
  lastSteal: Record<string, number>;
}

const defaultGroupSettings: GroupSettings = {
  protection: true,
  antilink: true,
  antispam: true,
  antiContact: false,
  events: true,
  welcome: true,
  goodbye: true,
  autoReply: true,
  salawat: false,
  prayerTimes: false,
  enabled: true,
  formEnabled: false,
  installEnabled: false,
  subBotsEnabled: true,
  antiDemoteAbuse: false,
};

const dbDir = path.resolve(process.cwd(), "database");
fs.ensureDirSync(dbDir);
const adapter = new DebouncedFileAdapter<any>(
  path.join(dbDir, "db.json"),
  {},
  1500,
  // 🆕 كل حفظة محلية تترافق مع نسخة احتياطية مؤجّلة على Supabase (لو
  // SUPABASE_URL/SUPABASE_KEY موجودين بـ.env) — راجع database/supabaseBackup.ts للتفاصيل.
  (data) => scheduleCloudBackup(data)
);
export const db = low(adapter as any) as unknown as LowdbSync<DbSchema>;

db.defaults({
  groups: {},
  points: {},
  economy: {},
  lastSteal: {},
  bot: { publicMode: true },
}).write();

// 🆕 استرجاع تلقائي من Supabase لو الملف المحلي طلع فاضي تمامًا (سيرفر جديد
// أو انصفرت بياناته، مثل ما يصير أحيانًا بإعادة نشر على استضافات مؤقتة
// التخزين). لا يلمس أي بيانات محلية موجودة فعلًا — فقط لو كانت كل الأقسام
// الرئيسية فاضية معًا (groups + economy + points).
(async () => {
  const state = db.getState() as any;
  const looksEmpty =
    (!state.groups || Object.keys(state.groups).length === 0) &&
    (!state.economy || Object.keys(state.economy).length === 0) &&
    (!state.points || Object.keys(state.points).length === 0);
  if (!looksEmpty) return;

  const restored = await fetchCloudBackup();
  if (!restored) return;

  db.setState(restored as any);
  db.write();
  logger.info("✅ استرجعنا نسخة البيانات الاحتياطية من Supabase (الملف المحلي كان فاضي عند الإقلاع).");
})();

// ضمان وجود المفتاح حتى لو كانت db.json قديمة (منشأة قبل إضافة نظام البنك)
if (!db.get("economy").value()) db.set("economy", {}).write();
// ضمان وجود مفتاح سرقة النقاط حتى لو كانت db.json أقدم من هذي الميزة
if (!db.get("lastSteal").value()) db.set("lastSteal", {}).write();
// 🆕 (أوامر جانبيه: .مهمة_اضف/.مهامي) — مهام كل شخص، مفتاحها jid كامل
if (!(db as any).get("tasks").value()) db.set("tasks", {}).write();
// ضمان وجود مصفوفة الأقسام الموقوفة حتى لو كانت db.json أقدم من هذي الميزة
if (!db.get("bot.disabledSections").value()) db.set("bot.disabledSections", []).write();
// ضمان وجود مصفوفة "الأدمن الوهمي العام" حتى لو كانت db.json أقدم من هذي الميزة
if (!db.get("bot.globalVirtualAdmins").value()) db.set("bot.globalVirtualAdmins", []).write();

// ترحيل لمرة واحدة: تفعيل الردود التلقائية لكل الكروبات الموجودة مسبقًا
// (كانت مطفية افتراضيًا بلا أي واجهة واضحة لتفعيلها، فتسبب بشكوى "بعض
// الأوامر ما تشتغل" مثل ملل/ميتين/فينكم ورد السلام). لا يكرر التنفيذ بعد
// أول تشغيل بفضل مفتاح bot.autoReplyMigrated.
if (!db.get("bot.autoReplyMigrated").value()) {
  const groups = db.get("groups").value() || {};
  for (const groupId of Object.keys(groups)) {
    db.set(`groups.${safeKey(groupId)}.settings.autoReply`, true).write();
  }
  db.set("bot.autoReplyMigrated", true).write();
}

// 🧹 ترحيل لمرة واحدة (طلب صريح: «احذف كل الردود القديمة»): يمسح كل الردود التلقائية
// اللي أُضيفت سابقًا بـ .اضافة_رد. الردود الجديدة تُضاف بعدها عادي ولا تُمسح.
if (!(db as any).get("bot.customRepliesWipedV1").value()) {
  (db as any).set(["friendGlobal", "autoReplies"], {}).write();
  (db as any).set("bot.customRepliesWipedV1", true).write();
}

/** يضمن وجود إعدادات افتراضية لأي مجموعة عند أول تفاعل معها */
export function ensureGroup(groupId: string) {
  if (!db.get(`groups.${safeKey(groupId)}`).value()) {
    db.set(`groups.${safeKey(groupId)}`, {
      settings: { ...defaultGroupSettings },
      warnings: {},
      blocked: [],
      muted: [],
      virtualAdmins: [],
    }).write();
  }
  // ضمان وجود المصفوفة حتى لو كانت المجموعة منشأة قبل إضافة هذي الميزة
  if (!db.get(`groups.${safeKey(groupId)}.virtualAdmins`).value()) {
    db.set(`groups.${safeKey(groupId)}.virtualAdmins`, []).write();
  }
  return db.get(`groups.${safeKey(groupId)}`).value();
}

// ========================= قوانين المجموعة (.القوانين / .تغيير_القوانين) =========================
// كل مجموعة تخزّن نص قوانينها الخاص بها فقط تحت groups.<groupId>.rules —
// مفصول تمامًا عن أي مجموعة ثانية، فتغيير القوانين بمجموعة معينة ما يؤثر
// إطلاقًا على قوانين أي مجموعة أخرى.

/** يرجع نص قوانين المجموعة، أو null لو ما حددها أحد بعد */
export function getGroupRules(groupId: string): string | null {
  ensureGroup(groupId);
  return db.get(`groups.${safeKey(groupId)}.rules`).value() || null;
}

/** يحفظ/يحدّث نص قوانين المجموعة (خاص بهذي المجموعة فقط) */
export function setGroupRules(groupId: string, rules: string) {
  ensureGroup(groupId);
  db.set(`groups.${safeKey(groupId)}.rules`, rules).write();
}

export function getGroupSettings(groupId: string): GroupSettings {
  ensureGroup(groupId);
  return db.get(`groups.${safeKey(groupId)}.settings`).value();
}

export function setGroupSetting(
  groupId: string,
  key: keyof GroupSettings,
  value: boolean
) {
  ensureGroup(groupId);
  db.set(`groups.${safeKey(groupId)}.settings.${key}`, value).write();
}

/**
 * 🆕 (طلب صريح: "لو 3 بواتات بكروب واحد كتب .ايقاف ما يوقفن 3 بس بوته")
 * راجع تعليق enabledByBot بأعلى الملف للتفصيل الكامل. mainBotId يُحسب
 * داخليًا بدل ما يُمرَّر، حتى تبقى نفس منطق التوافق الخلفي (getBotSelfNumber
 * مضبوطة فقط للبوت الرئيسي) بمكان واحد.
 */
export function isBotEnabledInGroup(groupId: string, botId: string): boolean {
  const settings = getGroupSettings(groupId);
  const map = settings.enabledByBot || {};
  if (Object.prototype.hasOwnProperty.call(map, botId)) return map[botId];
  // ما فيه إدخال خاص بهذا البوت بعد — توافق خلفي: البوت الرئيسي يرجع
  // لقيمة "enabled" القديمة (لأنها كانت مضبوطة له تحديدًا تاريخيًا، بما
  // إن .ايقاف/.تشغيل كانا owner-only ومحجوبين عن الفرعيين قبل هذا
  // التحديث)، وأي بوت فرعي بدون إدخال يعتبر مفعّل افتراضيًا.
  return botId === getBotSelfNumber() ? settings.enabled : true;
}

export function setBotEnabledInGroup(groupId: string, botId: string, value: boolean) {
  ensureGroup(groupId);
  const settings = getGroupSettings(groupId);
  const map = { ...(settings.enabledByBot || {}), [botId]: value };
  db.set(`groups.${safeKey(groupId)}.settings.enabledByBot`, map).write();
  // نحافظ على "enabled" القديمة متزامنة لو هذا هو البوت الرئيسي بالذات،
  // حتى أي كود ثاني لسه يقرأها مباشرة (لو موجود) يبقى صحيحًا.
  if (botId === getBotSelfNumber()) {
    db.set(`groups.${safeKey(groupId)}.settings.enabled`, value).write();
  }
}

// 🆕 (طلب صريح: "المطور يقدر يخلي أمر يكون بس للمشرفين / للمطورين") —
// تجاوز صلاحية أي أمر وقت التشغيل بدون تعديل كود. يُخزَّن بـdb.json
// تحت permissionOverrides (اسم الأمر الأساسي → all | admin | owner).
export type PermissionOverrideLevel = "all" | "admin" | "owner";

export function getPermissionOverride(commandName: string): PermissionOverrideLevel | undefined {
  const v = (db as any).get(`permissionOverrides.${safeKey(commandName)}`).value();
  return v === "all" || v === "admin" || v === "owner" ? v : undefined;
}

export function setPermissionOverride(commandName: string, level: PermissionOverrideLevel | null) {
  if (level === null) {
    (db as any).unset(`permissionOverrides.${safeKey(commandName)}`).write();
  } else {
    (db as any).set(`permissionOverrides.${safeKey(commandName)}`, level).write();
  }
}

export function listPermissionOverrides(): Record<string, PermissionOverrideLevel> {
  return ((db as any).get("permissionOverrides").value() as any) || {};
}

export function addWarning(groupId: string, userId: string): number {
  ensureGroup(groupId);
  const current = db.get(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`).value() || 0;
  const updated = current + 1;
  db.set(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`, updated).write();
  return updated;
}

export function resetWarnings(groupId: string, userId: string) {
  ensureGroup(groupId);
  db.set(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`, 0).write();
}

/**
 * ينقص عدد محدد من نذارات عضو (لا يقل عن 0)، ويرجّع العدد الجديد.
 * يُستخدم بأمر .اعفاء_النذار لإعفاء عضو من نذارات معينة بدل تصفيرها
 * بالكامل (لو المشرف يبي يعفي نذار واحد بس مثلاً من أصل 3).
 */
export function removeWarnings(groupId: string, userId: string, amount: number): number {
  ensureGroup(groupId);
  const current = db.get(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`).value() || 0;
  const updated = Math.max(0, current - amount);
  db.set(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`, updated).write();
  return updated;
}

export function getWarnings(groupId: string, userId: string): number {
  ensureGroup(groupId);
  return db.get(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`).value() || 0;
}

/**
 * 🆕 يضبط عدد نذارات عضو على قيمة محددة مباشرة (بدل الزيادة/التصفير
 * فقط). يُستخدم بزر "😡خليه 2" بتدفق قرار الطرد الجديد (راجع
 * src/handlers/kickDecisionManager.ts) — المشرفين يقدروا "يبقوا" العضو
 * بس يخلوه بـ 2 نذار (مو صفر) عشان يصير أقرب للطرد لو كرر.
 */
export function setWarnings(groupId: string, userId: string, amount: number): number {
  ensureGroup(groupId);
  const updated = Math.max(0, amount);
  db.set(`groups.${safeKey(groupId)}.warnings.${safeKey(userId)}`, updated).write();
  return updated;
}

export function blockUser(groupId: string, userId: string) {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.blocked`).value() || [];
  if (!list.includes(userId)) {
    db.set(`groups.${safeKey(groupId)}.blocked`, [...list, userId]).write();
  }
}

export function unblockUser(groupId: string, userId: string) {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.blocked`).value() || [];
  db.set(
    `groups.${safeKey(groupId)}.blocked`,
    list.filter((id) => id !== userId)
  ).write();
}

export function isBlocked(groupId: string, userId: string): boolean {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.blocked`).value() || [];
  return list.includes(userId);
}

export function muteUser(groupId: string, userId: string) {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.muted`).value() || [];
  if (!list.includes(userId)) {
    db.set(`groups.${safeKey(groupId)}.muted`, [...list, userId]).write();
  }
}

export function unmuteUser(groupId: string, userId: string) {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.muted`).value() || [];
  db.set(
    `groups.${safeKey(groupId)}.muted`,
    list.filter((id) => id !== userId)
  ).write();
}

export function isMuted(groupId: string, userId: string): boolean {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.muted`).value() || [];
  return list.includes(userId);
}

// ==================== نظام "الأدمن الوهمي" (.رفع_ادمن / .تنزيل_ادمن) ====================
// يعطي عضو صلاحية تنفيذ أوامر المشرفين (permission: "admin") داخل مجموعة
// معيّنة دون ترقيته فعليًا بواتساب. المطور فقط من يقدر يمنحها/يسحبها
// (راجع src/commands/owner/grantVirtualAdmin.ts و revokeVirtualAdmin.ts).
// ما تؤثر إطلاقًا على أوامر permission: "owner" ولا على فحوصات isOwner()
// المباشرة (زي رد "انا مطورك") — تلك تبقى محصورة بالمطور الحقيقي فقط.
// 🔧 إصلاح إضافي (حماية إضافية فوق توحيد الـ JID بـ getTargetJid بأوامر
// .رفع_ادمن/.تنزيل_ادمن): بدل مقارنة نصية حرفية (===) بالكامل، نقارن
// بالأرقام فقط (نفس أسلوب digitsOnly المستخدم بكل فحوصات الصلاحية
// الأخرى). هذا يمنع أي فشل مطابقة لو تغيّرت صيغة الـ JID لاحقًا لأي سبب
// (تحديث واتساب، تغيّر بيانات المجموعة المخزنة مؤقتًا...) حتى لو JID
// المخزّن أصلًا مختلف شكليًا عن senderJid وقت الفحص.
function sameJidDigits(a: string, b: string): boolean {
  const digits = (jid: string) => jid.split("@")[0].split(":")[0].replace(/[^0-9]/g, "");
  const da = digits(a);
  const db_ = digits(b);
  return !!da && da === db_;
}

/**
 * 🔧 (عزل البوتات الفرعية — سبب حقيقي: تسريب صلاحيات "الأدمن الوهمي")
 * كانت كل قوائم الأدمن الوهمي (العادي والعام) تُخزَّن كـJID مجرد بدون أي
 * ربط بأي بوت — فأي منح صار عبر البوت الرئيسي كان يُفحص وينجح تلقائيًا
 * حتى لو الأمر جاء من بوت فرعي مختلف كليًا بنفس المجموعة، عكس طلبك
 * الصريح: "صلاحياته مرتبطة بذلك البوت فقط، وليس بكل البوتات". الحل: كل
 * إدخال جديد يُخزَّن كـ"botId|jid" (عبر getBotScopeId(sock))، والفحص
 * يقارن botId + jid معًا.
 *
 * توافق مع البيانات القديمة: أي إدخال قديم بدون الفاصل "|" (مُنح قبل هذا
 * الإصلاح) يبقى يعمل، لكن **فقط على البوت الرئيسي تحديدًا** (نفس رقمه
 * الفعلي الحالي عبر getBotSelfNumber() — البوت الوحيد اللي كان يقدر يمنح
 * هذي الصلاحية أصلًا، لأن أوامر المنح كلها owner-only ومحجوبة عن
 * البوتات الفرعية بالكامل). هذا يحافظ 100% على نفس السلوك القديم بالضبط
 * على البوت الرئيسي، ويمنع فقط تسربها للبوتات الفرعية — وهو بالضبط
 * الإصلاح المطلوب، بدون أي فقدان صلاحيات ممنوحة سابقًا.
 */
function scopedEntry(botId: string, jid: string): string {
  return `${botId}|${jid}`;
}

function entryMatchesBot(entry: string, botId: string, mainBotId: string): { jidPart: string } | null {
  const sep = entry.indexOf("|");
  if (sep === -1) {
    // إدخال قديم بدون بوت محدد — يعمل فقط على البوت الرئيسي.
    return botId === mainBotId ? { jidPart: entry } : null;
  }
  const entryBotId = entry.slice(0, sep);
  return entryBotId === botId ? { jidPart: entry.slice(sep + 1) } : null;
}

export function grantVirtualAdmin(botId: string, groupId: string, userId: string) {
  ensureGroup(groupId);
  const list: string[] = db.get(`groups.${safeKey(groupId)}.virtualAdmins`).value() || [];
  const mainBotId = getBotSelfNumber();
  const already = list.some((entry) => {
    const m = entryMatchesBot(entry, botId, mainBotId);
    return m && sameJidDigits(m.jidPart, userId);
  });
  if (!already) {
    db.set(`groups.${safeKey(groupId)}.virtualAdmins`, [...list, scopedEntry(botId, userId)]).write();
  }
}

export function revokeVirtualAdmin(botId: string, groupId: string, userId: string) {
  ensureGroup(groupId);
  const mainBotId = getBotSelfNumber();
  const list: string[] = db.get(`groups.${safeKey(groupId)}.virtualAdmins`).value() || [];
  db.set(
    `groups.${safeKey(groupId)}.virtualAdmins`,
    list.filter((entry) => {
      const m = entryMatchesBot(entry, botId, mainBotId);
      return !(m && sameJidDigits(m.jidPart, userId));
    })
  ).write();
}

export function isVirtualAdmin(botId: string, groupId: string, userId: string): boolean {
  ensureGroup(groupId);
  const mainBotId = getBotSelfNumber();
  const list: string[] = db.get(`groups.${safeKey(groupId)}.virtualAdmins`).value() || [];
  return list.some((entry) => {
    const m = entryMatchesBot(entry, botId, mainBotId);
    return !!m && sameJidDigits(m.jidPart, userId);
  });
}

// ==================== 🆕 نظام "الأدمن الوهمي العام" (.رفع_مالك / .تنزيل_مالك) ====================
// نفس فكرة "الأدمن الوهمي" أعلاه بالضبط، لكن بدل ما تكون الصلاحية محصورة
// بمجموعة وحدة يحددها المطور وقت المنح، هذي الصلاحية عامة على *كل*
// المجموعات اللي البوت موجود فيها — الحالية والمستقبلية على حد سواء
// (تُخزَّن مرة وحدة بقائمة bot.globalVirtualAdmins، مو تحت أي مجموعة
// محددة). ما تؤثر إطلاقًا على أوامر permission: "owner" ولا فحوصات
// isOwner() المباشرة — تبقى محصورة بالمطور الحقيقي فقط، تمامًا زي
// الأدمن الوهمي العادي.
export function grantGlobalVirtualAdmin(botId: string, userId: string) {
  const mainBotId = getBotSelfNumber();
  const list: string[] = db.get("bot.globalVirtualAdmins").value() || [];
  const already = list.some((entry) => {
    const m = entryMatchesBot(entry, botId, mainBotId);
    return m && sameJidDigits(m.jidPart, userId);
  });
  if (!already) {
    db.set("bot.globalVirtualAdmins", [...list, scopedEntry(botId, userId)]).write();
  }
}

export function revokeGlobalVirtualAdmin(botId: string, userId: string) {
  const mainBotId = getBotSelfNumber();
  const list: string[] = db.get("bot.globalVirtualAdmins").value() || [];
  db.set(
    "bot.globalVirtualAdmins",
    list.filter((entry) => {
      const m = entryMatchesBot(entry, botId, mainBotId);
      return !(m && sameJidDigits(m.jidPart, userId));
    })
  ).write();
}

/**
 * 🆕 إصلاح جوهري (طلب صريح: ".رفع_مالك يقول تم الرفع لكن ما يعطي أي
 * صلاحية") — المشكلة الحقيقية: sameJidDigits وحدها كافية لـ"الأدمن
 * الوهمي" العادي (نفس المجموعة دائمًا، غرانت وفحص بنفس السياق)، لكن
 * غير كافية إطلاقًا لنسخة .رفع_مالك *العامة* (تُمنح بمجموعة، وتُفحص
 * بأي مجموعة ثانية): معرّف "@lid" الخاص بواتساب رقم *مختلف تمامًا* عن
 * رقم الهاتف الحقيقي (مو مجرد صيغة مختلفة لنفس الرقم!) — فلو تم المنح
 * وقت ما كان senderJid بصيغة @lid، ثم لاحقًا بمجموعة ثانية وصل senderJid
 * بصيغة الرقم الحقيقي (أو العكس)، sameJidDigits ترجع false دائمًا رغم
 * إنه نفس الشخص فعليًا — بالضبط نفس مشكلة isOwner/isGroupAdmin الموثقة
 * أعلاه، لكن ما كانت مُطبَّقة هنا.
 *
 * الحل (مطابق تمامًا لأسلوب isOwner): لو تعذرت المطابقة المباشرة
 * بالأرقام، ونحن نعرف بيانات المجموعة الحالية (metadata)، نبحث عن عضو
 * بهذي المجموعة يملك id/phoneNumber/lid يطابق *أي* JID مخزَّن بالقائمة
 * — وبنفس الوقت يطابق senderJid المُراد فحصه. هذا يربط الهويتين ببعض
 * عبر بيانات العضو نفسه بدل الاعتماد على تطابق نصي أعمى.
 */
export function isGlobalVirtualAdmin(botId: string, userId: string, metadata?: GroupMetadata): boolean {
  const mainBotId = getBotSelfNumber();
  const list: string[] = db.get("bot.globalVirtualAdmins").value() || [];
  const scopedJids = list
    .map((entry) => entryMatchesBot(entry, botId, mainBotId))
    .filter((m): m is { jidPart: string } => !!m)
    .map((m) => m.jidPart);

  if (scopedJids.some((jid) => sameJidDigits(jid, userId))) return true;

  if (metadata) {
    // 🔧 (توحيد مركزي) — نفس participantMatch.ts المستخدم بـpermissions.ts
    // وdeveloperIdentity.ts، بدل مطابقة يدوية مكررة هنا.
    const participant = findParticipant(metadata, userId);
    if (participant) {
      const anyP = participant as unknown as { phoneNumber?: string; jid?: string; lid?: string };
      return scopedJids.some(
        (stored) =>
          sameJidDigits(stored, participant.id) ||
          (anyP.phoneNumber && sameJidDigits(stored, anyP.phoneNumber)) ||
          (anyP.jid && sameJidDigits(stored, anyP.jid)) ||
          (anyP.lid && sameJidDigits(stored, anyP.lid))
      );
    }
  }

  return false;
}

// 🆕 (أوامر جانبيه: .مهمة_اضف/.مهامي) — مهام شخصية بسيطة لكل مستخدم
export interface Task {
  id: string;
  text: string;
}

export function addTask(userJid: string, text: string): Task {
  const task: Task = { id: `TASK-${Date.now().toString().slice(-6)}`, text };
  const list: Task[] = (db as any).get(`tasks.${safeKey(userJid)}`).value() || [];
  list.push(task);
  db.set(`tasks.${safeKey(userJid)}`, list).write();
  return task;
}

export function getTasks(userJid: string): Task[] {
  return (db as any).get(`tasks.${safeKey(userJid)}`).value() || [];
}

export function removeTask(userJid: string, taskId: string): boolean {
  const list: Task[] = (db as any).get(`tasks.${safeKey(userJid)}`).value() || [];
  const next = list.filter((t) => t.id !== taskId);
  if (next.length === list.length) return false;
  db.set(`tasks.${safeKey(userJid)}`, next).write();
  return true;
}

export function addPoint(groupId: string, userId: string, amount = 1) {  const current = db.get(`points.${safeKey(groupId)}.${safeKey(userId)}`).value() || 0;
  db.set(`points.${safeKey(groupId)}.${safeKey(userId)}`, current + amount).write();
  // ربط الفعاليات بنظام البنك: كل نقطة فوز = 10 عملات بمحفظة الفائز
  addToWallet(userId, amount * 10);
}

/** يرجع نقاط شخص بمجموعة معينة (0 لو ما عنده شي) — استخدم هذي بدل بناء
 * مسار db.get خام بنفسك (أي JID فيه نقاط "." يكسر مسار lowdb، راجع
 * تعليق safeKey بالأعلى). */
export function getPoints(groupId: string, userId: string): number {
  return db.get(`points.${safeKey(groupId)}.${safeKey(userId)}`).value() || 0;
}

/** يحدد نقاط شخص بمجموعة معينة مباشرة (بدل إضافة/طرح) — لنفس سبب getPoints أعلاه. */
export function setPoints(groupId: string, userId: string, value: number) {
  db.set(`points.${safeKey(groupId)}.${safeKey(userId)}`, Math.max(0, value)).write();
}

// ========================= نظام البنك والنقاط =========================

const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const WEEKLY_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;
const DAILY_REWARD = 200;
const WEEKLY_REWARD = 1000;

function ensureEconomy(userId: string) {
  if (!db.get(`economy.${safeKey(userId)}`).value()) {
    db.set(`economy.${safeKey(userId)}`, {
      wallet: 0,
      bank: 0,
      lastDaily: 0,
      lastWeekly: 0,
    }).write();
  }
  return db.get(`economy.${safeKey(userId)}`).value();
}

export function getEconomy(userId: string) {
  const economy = ensureEconomy(userId);
  // رصيد المطور لا نهائي بكل مكان (محفظة + بنك) — بدون التأثير على بقية المستخدمين
  if (isOwnerEconomyId(userId)) {
    return { ...economy, wallet: INFINITE_BALANCE, bank: INFINITE_BALANCE };
  }
  return economy;
}

// ===== رصيد المطور لا نهائي =====
// نقارن برقم الهاتف فقط (بدون @s.whatsapp.net ولا :device) حتى يشتغل الفحص
// بغض النظر عن صيغة الـ JID (منشن، رقم خام، أو JID كامل).
//
// 🔧 إصلاح (v1.1.4): قبل كذا كانت تقارن فقط مع CONFIG.OWNER_NUMBER — فلو
// وصل userId هذي المرة بصيغة "@lid" (مشكلة الخصوصية المعروفة داخل
// المجموعات، راجع تعليق isOwner بملف permissions.ts)، أو لو رقم البوت نفسه
// مختلف عن OWNER_NUMBER، كانت المقارنة تفشل والمطور يُعامل كمستخدم عادي —
// رصيد 0، بنك ما يشتغل معه. الآن نقارن أيضًا مع رقم البوت نفسه ومع lid
// المالك المكتشف تلقائيًا (getBotSelfNumber/getOwnerLid)، بنفس منطق
// isOwner() تمامًا، فيبقى رصيد المطور لا نهائي دائمًا بغض النظر عن الصيغة.
const INFINITE_BALANCE = 999_999_999;
function isOwnerEconomyId(userId: string): boolean {
  // 🔧 إصلاح: نفس تنظيف الأرقام المطبّق بباقي الملفات (راجع تعليق
  // OWNER_NUMBER بملف config.ts) — نشيل أي رمز غير رقمي بدل الاكتفاء
  // بقص "@..." و ":device" فقط، حتى تتطابق المقارنة دايمًا.
  const phone = userId.split("@")[0].split(":")[0].replace(/[^0-9]/g, "");
  if (!phone) return false;
  const botSelf = getBotSelfNumber();
  const ownerLid = getOwnerLid();
  // 🔧 (توحيد مركزي — كانت هذي الدالة ناسية المطور الثاني بالكامل، نفس
  // مشكلة isDeveloperIdentity المكتشفة والمصلحة بـhelpers.ts) — الآن
  // تشمل CONFIG.OWNER_NUMBER_2 أيضًا، فرصيد المطور الثاني صار لا نهائي
  // بنفس أسلوب المطور الأساسي بالضبط.
  return (
    phone === CONFIG.OWNER_NUMBER ||
    (CONFIG.OWNER_NUMBER_2 !== "" && phone === CONFIG.OWNER_NUMBER_2) ||
    (CONFIG.OWNER_NUMBER_3 !== "" && phone === CONFIG.OWNER_NUMBER_3) ||
    (botSelf !== "" && phone === botSelf) ||
    (ownerLid !== "" && phone === ownerLid)
  );
}

export function addToWallet(userId: string, amount: number) {
  ensureEconomy(userId);
  const current = db.get(`economy.${safeKey(userId)}.wallet`).value() || 0;
  const updated = Math.max(0, current + amount);
  db.set(`economy.${safeKey(userId)}.wallet`, updated).write();
  return updated;
}

export function addToBank(userId: string, amount: number) {
  ensureEconomy(userId);
  const current = db.get(`economy.${safeKey(userId)}.bank`).value() || 0;
  const updated = Math.max(0, current + amount);
  db.set(`economy.${safeKey(userId)}.bank`, updated).write();
  return updated;
}

/** يحوّل مبلغ من محفظة مستخدم إلى محفظة مستخدم آخر. يرجع false لو الرصيد غير كافٍ */
export function transferCoins(
  fromId: string,
  toId: string,
  amount: number
): boolean {
  ensureEconomy(fromId);
  ensureEconomy(toId);
  if (amount <= 0) return false;
  // المطور رصيده لا نهائي، فما نتحقق من كفاية رصيده ولا نخصم من محفظته الفعلية
  if (isOwnerEconomyId(fromId)) {
    addToWallet(toId, amount);
    return true;
  }
  const fromWallet = db.get(`economy.${safeKey(fromId)}.wallet`).value() || 0;
  if (fromWallet < amount) return false;
  addToWallet(fromId, -amount);
  addToWallet(toId, amount);
  return true;
}

/** إيداع من المحفظة إلى البنك */
export function depositToBank(userId: string, amount: number): boolean {
  ensureEconomy(userId);
  if (amount <= 0) return false;
  if (isOwnerEconomyId(userId)) {
    addToBank(userId, amount);
    return true;
  }
  const wallet = db.get(`economy.${safeKey(userId)}.wallet`).value() || 0;
  if (wallet < amount) return false;
  addToWallet(userId, -amount);
  addToBank(userId, amount);
  return true;
}

/** سحب من البنك إلى المحفظة */
export function withdrawFromBank(userId: string, amount: number): boolean {
  ensureEconomy(userId);
  if (amount <= 0) return false;
  if (isOwnerEconomyId(userId)) {
    addToWallet(userId, amount);
    return true;
  }
  const bank = db.get(`economy.${safeKey(userId)}.bank`).value() || 0;
  if (bank < amount) return false;
  addToBank(userId, -amount);
  addToWallet(userId, amount);
  return true;
}

/** يرجع الوقت المتبقي بالميلي ثانية قبل إمكانية استلام الراتب اليومي (0 = يمكن الآن) */
export function dailyCooldownRemaining(userId: string): number {
  const economy = ensureEconomy(userId);
  const remaining = economy.lastDaily + DAILY_COOLDOWN_MS - Date.now();
  return Math.max(0, remaining);
}

export function claimDaily(userId: string): number | null {
  if (dailyCooldownRemaining(userId) > 0) return null;
  db.set(`economy.${safeKey(userId)}.lastDaily`, Date.now()).write();
  addToWallet(userId, DAILY_REWARD);
  return DAILY_REWARD;
}

export function weeklyCooldownRemaining(userId: string): number {
  const economy = ensureEconomy(userId);
  const remaining = economy.lastWeekly + WEEKLY_COOLDOWN_MS - Date.now();
  return Math.max(0, remaining);
}

export function claimWeekly(userId: string): number | null {
  if (weeklyCooldownRemaining(userId) > 0) return null;
  db.set(`economy.${safeKey(userId)}.lastWeekly`, Date.now()).write();
  addToWallet(userId, WEEKLY_REWARD);
  return WEEKLY_REWARD;
}

/** أغنى المستخدمين ضمن قائمة jids معينة (مثلًا أعضاء مجموعة) */
export function getRichest(
  userIds: string[],
  limit = 10
): Array<{ userId: string; total: number }> {
  return userIds
    .map((userId) => {
      const economy = ensureEconomy(userId);
      return { userId, total: economy.wallet + economy.bank };
    })
    .filter((entry) => entry.total > 0)
    .sort((a, b) => b.total - a.total)
    .slice(0, limit);
}

export function getLeaderboard(
  groupId: string,
  limit = 10
): Array<{ userId: string; score: number }> {
  const groupPoints = db.get(`points.${safeKey(groupId)}`).value() || {};
  return Object.entries(groupPoints)
    // 🔧 مفاتيح هذا الكائن هي userId المخزَّن (منظَّف من النقاط عبر
    // safeKey) — لازم نرجّعه لصيغته الأصلية (JID كامل صالح) هنا، وإلا
    // بيوصل ناقص لأمر .الترتيب فيفشل الإشارة (@mention) للفائزين.
    .map(([userId, score]) => ({ userId: unsafeKey(userId), score: score as number }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

// ========================= أمر السرقة (.سرقه) — كولداون ساعة لكل شخص =========================

const STEAL_COOLDOWN_MS = 60 * 60 * 1000; // ساعة واحدة

/** الوقت المتبقي (مللي ثانية) قبل ما يقدر شخص معيّن يستخدم .سرقه مرة ثانية (0 = يقدر الآن) */
export function stealCooldownRemaining(userId: string): number {
  const last = db.get(`lastSteal.${safeKey(userId)}`).value() || 0;
  const remaining = last + STEAL_COOLDOWN_MS - Date.now();
  return Math.max(0, remaining);
}

/** يسجّل وقت آخر استخدام لأمر .سرقه لشخص معيّن */
export function markStealUsed(userId: string) {
  db.set(`lastSteal.${safeKey(userId)}`, Date.now()).write();
}

// ========================= أقسام الأوامر الموقوفة (.تعطيل / .تفعيل) =========================
// إيقاف/تشغيل قسم كامل من الأوامر عبر كل البوت (كل المجموعات + الخاص)،
// مخصص لرقم المطور ورقم البوت نفسه فقط (permission: "owner" بالأمرين).

/** يرجع كل الأقسام الموقوفة حاليًا */
export function getDisabledSections(): string[] {
  return db.get("bot.disabledSections").value() || [];
}

/** يتحقق هل قسم معيّن موقوف حاليًا */
export function isSectionDisabled(category: string): boolean {
  return getDisabledSections().includes(category);
}

/** يوقف/يشغّل قسم معيّن. يرجع false لو كانت الحالة نفسها أصلًا (ما تغيّر شي) */
export function setSectionDisabled(category: string, disabled: boolean): boolean {
  const list = getDisabledSections();
  const alreadyDisabled = list.includes(category);
  if (disabled === alreadyDisabled) return false; // لا تغيير — كانت نفس الحالة أصلًا

  if (disabled) {
    db.set("bot.disabledSections", [...list, category]).write();
  } else {
    db.set(
      "bot.disabledSections",
      list.filter((c) => c !== category)
    ).write();
  }
  return true;
}

// ===== 🆕 نظام المستويات (XP) + المتجر (طلب صريح: "ضيف متجر للنقاط فيه
// ألقاب وغيرها" + "حط لفل") — تخزين فقط هنا؛ منطق حساب المستوى نفسه
// (getLevelFromXp) بملف utils/leveling.ts، وقائمة المتجر بملف
// utils/shopCatalog.ts. صريح ومهم: هذا النظام ما يلمس صلاحيات الأدمن أو
// الطرد إطلاقًا — بيع/شراء الألقاب هنا تجميلي بحت بدون أي أثر على صلاحيات
// المجموعة (بطلب صريح من صاحب البوت).

const XP_COOLDOWN_MS = 60 * 1000; // مرة كل دقيقة كحد أقصى (منع فلود XP)

function ensureEconomyLevelFields(userId: string) {
  const economy = ensureEconomy(userId);
  const key = `economy.${safeKey(userId)}`;
  if (typeof economy.xp !== "number") db.set(`${key}.xp`, 0).write();
  if (!Array.isArray(economy.ownedTitles)) db.set(`${key}.ownedTitles`, []).write();
  return db.get(key).value();
}

/** يرجع XP الحالية للمستخدم (0 لو ما عنده). */
export function getXp(userId: string): number {
  return ensureEconomyLevelFields(userId).xp || 0;
}

/** يضيف XP لو ما طلعت الكولداون (مرة كل دقيقة). يرجع XP الجديدة، أو null لو بالكولداون. */
export function addXpWithCooldown(userId: string, amount: number): number | null {
  const economy = ensureEconomyLevelFields(userId);
  const last = economy.lastXpAt || 0;
  if (Date.now() - last < XP_COOLDOWN_MS) return null;
  const updated = (economy.xp || 0) + amount;
  db.set(`economy.${safeKey(userId)}.xp`, updated).write();
  db.set(`economy.${safeKey(userId)}.lastXpAt`, Date.now()).write();
  return updated;
}

/** يضيف XP بدون أي كولداون (لمكافآت أوامر معيّنة، مثل الفوز بلعبة). */
export function addXp(userId: string, amount: number): number {
  const economy = ensureEconomyLevelFields(userId);
  const updated = (economy.xp || 0) + amount;
  db.set(`economy.${safeKey(userId)}.xp`, updated).write();
  return updated;
}

/** ينقص عملات من محفظة المستخدم لو كافية (لشراء من المتجر). المطور دايمًا "كافي". */
export function spendFromWallet(userId: string, amount: number): boolean {
  ensureEconomy(userId);
  if (amount <= 0) return false;
  if (isOwnerEconomyId(userId)) return true; // ما نخصم من محفظة المطور (رصيده لا نهائي أصلًا)
  const wallet = db.get(`economy.${safeKey(userId)}.wallet`).value() || 0;
  if (wallet < amount) return false;
  addToWallet(userId, -amount);
  return true;
}

export function getOwnedTitles(userId: string): string[] {
  return ensureEconomyLevelFields(userId).ownedTitles || [];
}

/** يضيف لقب لمملوكات المستخدم (بدون تكرار). يرجع false لو كان عنده أصلًا. */
export function addOwnedTitle(userId: string, title: string): boolean {
  const owned = getOwnedTitles(userId);
  if (owned.includes(title)) return false;
  db.set(`economy.${safeKey(userId)}.ownedTitles`, [...owned, title]).write();
  return true;
}

export function hasOwnedTitle(userId: string, title: string): boolean {
  return getOwnedTitles(userId).includes(title);
}

export function getEquippedTitle(userId: string): string | undefined {
  return ensureEconomyLevelFields(userId).equippedTitle;
}

/** يفعّل لقب كـ"لقبه الحالي" — لازم يكون من ألقابه المملوكة، أو "" لإلغاء التفعيل. */
export function setEquippedTitle(userId: string, title: string): boolean {
  if (title !== "" && !hasOwnedTitle(userId, title)) return false;
  db.set(`economy.${safeKey(userId)}.equippedTitle`, title).write();
  return true;
}
