/**
 * 🆕 اتصال Supabase المركزي (بديل MongoDB القديم بالكامل).
 *
 * على عكس Mongo (اتصال TCP دائم يحتاج "ننتظره يجهز")، Supabase عميل REST
 * عادي فوق HTTP — يُنشأ فورًا بدون أي انتظار، وكل طلب (قراءة/كتابة) مستقل
 * بحد ذاته. فلا حاجة هنا لأي "ensureConnection" حقيقي؛ فقط نتأكد إن
 * SUPABASE_URL و SUPABASE_KEY موجودين قبل أي استخدام.
 */
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { CONFIG } from "../config/config";
import { logger } from "../utils/logger";

export function isSupabaseConfigured(): boolean {
  return Boolean(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_KEY);
}

let client: SupabaseClient | null = null;

/** يرجع عميل Supabase جاهز، أو null لو الإعدادات ناقصة بـ.env (بدون أي رمي أخطاء). */
export function getSupabase(): SupabaseClient | null {
  if (!isSupabaseConfigured()) return null;
  if (!client) {
    client = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, {
      auth: { persistSession: false },
    });
    logger.info("✅ عميل Supabase جاهز.");
  }
  return client;
}
