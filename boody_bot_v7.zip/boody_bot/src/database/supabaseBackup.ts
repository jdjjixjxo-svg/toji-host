/**
 * 🆕 نسخة احتياطية سحابية لكامل db.json المحلي — الآن على Supabase بدل
 * MongoDB. القاعدة تبقى كما هي تمامًا (lowdb محلي متزامن، صفر تغيير على
 * أي أمر من الأوامر الحالية) — هذا الملف فقط يضيف طبقة أمان فوقها:
 *
 *  • كل ما يتغيّر شي محليًا، نرسل نسخة كاملة من الحالة إلى جدول
 *    "bot_backup" على Supabase (مؤجّلة ~5 ثواني، بدون ما تزاحم أو تبطئ
 *    الحفظ المحلي أبدًا — أي فشل بالسحابة يُسجَّل ويُتجاهل ولا يوقف البوت).
 *  • عند إقلاع البوت: لو db.json المحلي طلع *فاضي تمامًا* (سيرفر جديد أو
 *    انصفرت بياناته)، نجيب آخر نسخة محفوظة من Supabase ونعيدها محليًا
 *    تلقائيًا قبل أي استخدام فعلي.
 *
 * يحتاج الجدول التالي منشأ مرة واحدة فقط على Supabase (SQL Editor):
 *
 *   create table if not exists bot_backup (
 *     id text primary key,
 *     data jsonb not null,
 *     updated_at timestamptz not null default now()
 *   );
 *
 * ولو تستخدم مفتاح "publishable" (anon) بدل "secret" (service_role)، لازم
 * سياسة RLS تسمح بالقراءة/الكتابة لهذا الجدول تحديدًا (راجع README).
 */
import { getSupabase, isSupabaseConfigured } from "./supabaseClient";
import { logger } from "../utils/logger";

const BACKUP_ROW_ID = "main";

let pushTimer: NodeJS.Timeout | null = null;

/** يرفع نسخة من كامل الداتا لـSupabase (مؤجّل، غير مزاحم للحفظ المحلي). */
export function scheduleCloudBackup(state: unknown): void {
  if (!isSupabaseConfigured()) return;
  if (pushTimer) return;
  pushTimer = setTimeout(async () => {
    pushTimer = null;
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { error } = await supabase
        .from("bot_backup")
        .upsert({ id: BACKUP_ROW_ID, data: state, updated_at: new Date().toISOString() });
      if (error) throw error;
    } catch (err) {
      logger.warn("⚠️ فشلت النسخة الاحتياطية على Supabase (البيانات المحلية سليمة ولم تتأثر):", err);
    }
  }, 5000);
  pushTimer.unref?.();
}

/** لو فيه نسخة محفوظة على Supabase، يرجعها. غير ذلك null (بدون أي رمي أخطاء). */
export async function fetchCloudBackup(): Promise<unknown | null> {
  if (!isSupabaseConfigured()) return null;
  try {
    const supabase = getSupabase();
    if (!supabase) return null;
    const { data, error } = await supabase
      .from("bot_backup")
      .select("data")
      .eq("id", BACKUP_ROW_ID)
      .maybeSingle();
    if (error) throw error;
    return data?.data ?? null;
  } catch (err) {
    logger.warn("⚠️ تعذر جلب النسخة الاحتياطية من Supabase عند الإقلاع:", err);
    return null;
  }
}
