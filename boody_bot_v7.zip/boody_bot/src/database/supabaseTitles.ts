/**
 * 🆕 نظام الألقاب (.تسجيل_لقب / .حجز_لقب / .اللقاب ...) — منقول بالكامل من
 * MongoDB إلى Supabase. مستقل تمامًا عن db.json المحلي (lowdb)، تمامًا مثل
 * الوضع السابق: باقي المشروع يعمل حتى لو Supabase غير مضبوط أصلًا (أي فشل
 * يُسجَّل بدون ما يوقف تشغيل البوت كامل).
 *
 * يحتاج الجدول التالي منشأ مرة واحدة فقط على Supabase (SQL Editor):
 *
 *   create table if not exists titles (
 *     user_id text primary key,
 *     title text not null unique,
 *     updated_at timestamptz not null default now()
 *   );
 *
 * 🔧 (طلب صريح قديم: "ما أبيها تتكرر") — يحافظ عليه هنا عبر قيد unique
 * حقيقي على عمود title بقاعدة البيانات نفسها (نفس فكرة index Mongo القديم).
 *
 * ملاحظة تسمية: أبقينا شكل الواجهة (findOne/findOneAndUpdate/find...) قريب
 * جدًا من TitleModel القديم (Mongoose) عمدًا، حتى لا نحتاج لإعادة كتابة
 * منطق كل ملف أمر من الـ9 ملفات اللي تستخدمها — فقط غيّرنا مصدر الاستيراد
 * والاسمين (ensureMongoConnection → ensureTitlesReady، TitleModel → TitleStore).
 */
import { getSupabase, isSupabaseConfigured } from "./supabaseClient";
import { logger } from "../utils/logger";

export interface TitleDoc {
  userId: string;
  title: string;
  /** يحدّث اللقب لنفس userId على القرص (يستخدمها .تغير_لقب بعد تعديل .title مباشرة). */
  save(): Promise<void>;
}

/** خطأ يحاكي كود Mongo لتكرار المفتاح (11000) حتى تبقى catch blocks الحالية تعمل بدون تعديل. */
class DuplicateTitleError extends Error {
  code = 11000;
  constructor(title: string) {
    super(`duplicate title: ${title}`);
  }
}

function isUniqueViolation(err: any): boolean {
  // 23505 = unique_violation بـ Postgres/Supabase
  return err?.code === "23505";
}

function toDoc(row: { user_id: string; title: string } | null): TitleDoc | null {
  if (!row) return null;
  const doc: TitleDoc = {
    userId: row.user_id,
    title: row.title,
    async save() {
      const { error } = await getSupabase()!
        .from("titles")
        .update({ title: doc.title, updated_at: new Date().toISOString() })
        .eq("user_id", doc.userId);
      if (error) {
        if (isUniqueViolation(error)) throw new DuplicateTitleError(doc.title);
        throw error;
      }
    },
  };
  return doc;
}

/** يتحقق إن Supabase مضبوط وجاهز (استبدال ensureMongoConnection القديمة). */
export async function ensureTitlesReady(): Promise<boolean> {
  return isSupabaseConfigured();
}

export const TitleStore = {
  async findOne(query: { userId?: string; title?: string }): Promise<TitleDoc | null> {
    const supabase = getSupabase();
    if (!supabase) return null;
    let q = supabase.from("titles").select("user_id, title");
    if (query.userId) q = q.eq("user_id", query.userId);
    if (query.title) q = q.eq("title", query.title);
    const { data, error } = await q.maybeSingle();
    if (error) {
      logger.warn("⚠️ خطأ أثناء قراءة لقب من Supabase:", error);
      return null;
    }
    return toDoc(data as any);
  },

  async findOneAndUpdate(
    filter: { userId: string },
    update: { title: string },
    _opts?: { upsert?: boolean }
  ): Promise<TitleDoc | null> {
    const supabase = getSupabase();
    if (!supabase) return null;
    const { data, error } = await supabase
      .from("titles")
      .upsert(
        { user_id: filter.userId, title: update.title, updated_at: new Date().toISOString() },
        { onConflict: "user_id" }
      )
      .select("user_id, title")
      .maybeSingle();
    if (error) {
      if (isUniqueViolation(error)) throw new DuplicateTitleError(update.title);
      throw error;
    }
    return toDoc(data as any);
  },

  async findOneAndDelete(query: { userId?: string; title?: string }): Promise<TitleDoc | null> {
    const supabase = getSupabase();
    if (!supabase) return null;
    let q = supabase.from("titles").delete();
    if (query.userId) q = q.eq("user_id", query.userId);
    if (query.title) q = q.eq("title", query.title);
    const { data, error } = await q.select("user_id, title").maybeSingle();
    if (error) {
      logger.warn("⚠️ خطأ أثناء حذف لقب من Supabase:", error);
      return null;
    }
    return toDoc(data as any);
  },

  async find(_query: Record<string, never> = {}): Promise<TitleDoc[]> {
    const supabase = getSupabase();
    if (!supabase) return [];
    const { data, error } = await supabase.from("titles").select("user_id, title").order("title");
    if (error) {
      logger.warn("⚠️ خطأ أثناء جلب كل الألقاب من Supabase:", error);
      return [];
    }
    return (data || []).map((row) => toDoc(row as any)!).filter(Boolean);
  },

  async deleteMany(_query: Record<string, never> = {}): Promise<{ deletedCount: number }> {
    const supabase = getSupabase();
    if (!supabase) return { deletedCount: 0 };
    // 🔧 Supabase/Postgres تتطلب شرط WHERE صريح حتى لحذف الكل — neq على
    // قيمة مستحيلة عمليًا يحذف كل الصفوف فعليًا دون كسر هذا الشرط.
    const { data, error } = await supabase
      .from("titles")
      .delete()
      .neq("user_id", "__never_matches__")
      .select("user_id");
    if (error) {
      logger.warn("⚠️ خطأ أثناء حذف كل الألقاب من Supabase:", error);
      return { deletedCount: 0 };
    }
    return { deletedCount: data?.length || 0 };
  },
};
