/**
 * 🆕 حزمة "node-webpmux" لا تنشر ملفات تعريف أنواع (types) خاصة فيها، ولا
 * يوجد لها حزمة @types/node-webpmux رسمية على npm — هذا كان سبب الخطأ
 * "Cannot find module 'node-webpmux' or its corresponding type declarations"
 * بملف src/utils/stickerExif.ts. هذا تصريح بسيط (ambient declaration) يكفي
 * فقط لإسكات هذا الخطأ دون التأثير على أي سلوك فعلي وقت التشغيل (runtime) —
 * الاستخدام الفعلي بـ stickerExif.ts (`new webpmux.Image()`, `.load()`,
 * `.exif`, `.save()`) يبقى يعمل بالضبط كما هو، فقط بدون فحص أنواع دقيق له.
 */
declare module "node-webpmux" {
  const webpmux: any;
  export default webpmux;
}
