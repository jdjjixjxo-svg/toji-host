declare module "yt-search";
