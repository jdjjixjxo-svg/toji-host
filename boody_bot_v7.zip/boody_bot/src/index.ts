import "dotenv/config";
import "./utils/globalFetchTimeout";
import path from "path";
import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  Browsers,
  WAMessage,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import NodeCache from "node-cache";
import qrcodeTerminal from "qrcode-terminal";

import { CONFIG } from "./config/config";
import { BOT_START_TIME } from "./utils/uptime"; // 🕒 يُسجَّل وقت الإقلاع فورًا هنا
import { restoreSessionFromEnv } from "./config/session";
import { commandRegistry } from "./handlers/commandRegistry";
import { handleIncomingMessage } from "./handlers/messageHandler";
import { registerGroupParticipantsEvent } from "./events/groupParticipants";
import { registerGroupJoinPtvEvent } from "./events/groupJoinPtv";
import { registerJoinRequestAutoApprove } from "./events/joinRequests";
import { startGameServer } from "./utils/gameServer";
import { getGroupCache, invalidateGroupCache } from "./utils/groupCache";
import { setActiveSocket, startSalawatScheduler, startPrayerTimesScheduler, startDbBackupScheduler } from "./handlers/scheduler";
import { bootAllSubBots } from "./handlers/subBotManager";
import { getWaVersion } from "./utils/helpers";
import { setBotSelfNumber, setOwnerLid } from "./utils/botIdentity";
import { applyNewsletterBranding, resolveChannelJidFromLink } from "./utils/interactive";
import { logger } from "./utils/logger";
import { db } from "./database/db";

// ==============================================================
// 🔇 تصفية ضجيج مكتبة libsignal الداخلي (Bad MAC لرسائل قديمة/بث)
// ==============================================================
// بعض إصدارات libsignal تطبع أخطاء "Failed to decrypt.../Bad MAC" مباشرة
// عبر console بدل الـ logger الممرَّر لها، وهذا معروف وموثّق في مكتبة
// Baileys نفسها (غالبًا رسائل حالة/بث قديمة لا تخص البوت ولا تُسقطه).
// نقوم بتصفيتها من الطرفية فقط لإبقاء السجلات نظيفة، دون التأثير على أي
// معالجة فعلية للرسائل.
const NOISY_PATTERNS = ["Bad MAC", "Failed to decrypt message with any known session"];
const originalConsoleError = console.error.bind(console);
const originalConsoleLog = console.log.bind(console);
const isNoisy = (args: unknown[]) =>
  NOISY_PATTERNS.some((p) => args.some((a) => typeof a === "string" && a.includes(p)));
console.error = (...args: unknown[]) => {
  if (isNoisy(args)) return;
  originalConsoleError(...args);
};
console.log = (...args: unknown[]) => {
  if (isNoisy(args)) return;
  originalConsoleLog(...args);
};

// ==============================================================
// معالجات الأخطاء العامة — تُسجَّل مرة واحدة فقط عند إقلاع التطبيق
// (سابقًا كانت داخل startBot() فتتكرر مع كل إعادة اتصال وتسبب تراكمًا)
// ==============================================================
process.on("uncaughtException", (err) => {
  logger.error("خطأ غير متوقع (Uncaught Exception):", err);
});
process.on("unhandledRejection", (reason) => {
  logger.error("خطأ غير متوقع (Unhandled Rejection):", reason);
});

// كاش لعدّاد إعادة محاولة إرسال الرسائل (يقلّل أخطاء فك التشفير للرسائل المُعاد إرسالها)
const msgRetryCounterCache = new NodeCache();
// كاش بسيط لآخر الرسائل المُرسلة، يُستخدم في getMessage لدعم آلية إعادة الإرسال في Baileys
const recentMessagesCache = new NodeCache({ stdTTL: 60 * 10 });

let isFirstInit = true;

let reconnectAttempts = 0;
const MAX_BACKOFF_MS = 30_000;

async function startBot() {
  // 1) تحميل الأوامر وتسجيل أحداث المجموعة مرة واحدة فقط عند أول إقلاع
  //    (استدعاؤها مع كل إعادة اتصال كان يسبب تكرار المستمعين وتسريب ذاكرة)
  if (isFirstInit) {
    logger.info(`🚀 جاري تشغيل ${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION}...`);
    commandRegistry.loadAll(path.join(__dirname, "commands"));
    await restoreSessionFromEnv();
    isFirstInit = false;

    // 🆕 (ميزة .تنصيب) — يعيد ربط أي بوتات فرعية كانت شغّالة قبل آخر
    // إعادة تشغيل (جلساتها محفوظة على القرص تحت subbots-sessions/).
    // best-effort بالكامل: لا يوقف إقلاع البوت الرئيسي لو فشل شي هنا.
    bootAllSubBots().catch((err) =>
      logger.warn("⚠️ تعذر إعادة ربط بعض/كل البوتات الفرعية عند الإقلاع.", err)
    );
  }

  const sessionDir = path.resolve(process.cwd(), CONFIG.SESSION_DIR);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const version = await getWaVersion();

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      // ✅ تغليف مخزن مفاتيح Signal بذاكرة تخزين مؤقت (Cache) لتقليل قراءات/كتابات
      // الملفات المتزامنة على القرص — أحد أشهر أسباب أخطاء "Bad MAC" العشوائية
      // عند حدوث تضارب أثناء قراءة ملف جلسة يُكتب في نفس اللحظة.
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }) as any),
    },
    logger: pino({ level: "silent" }) as any,
    // 🔧 (طلب صريح: "أول شي يشوف الجلسة session، إذا موجودة يربط تلقائي،
    // إذا ما موجودة يروح للخيار الثاني ويرسل QR") — printQRInTerminal
    // بقيت false عمدًا (خاصية Baileys القديمة لطباعة QR تلقائيًا أصبحت
    // deprecated وقد لا تعمل بإصدارات حديثة)، ونطبع QR يدويًا بأنفسنا
    // أدناه عبر حدث "connection.update" + مكتبة qrcode-terminal — هذا هو
    // الأسلوب الرسمي الموصى به حاليًا بمكتبة Baileys نفسها.
    printQRInTerminal: false,
    browser: Browsers.ubuntu(CONFIG.BOT_NAME),
    // 🔧 ثبات الاتصال وسرعة الرد:
    //  - cachedGroupMetadata: بدونها Baileys يجلب بيانات المجموعة من واتساب مع كل رسالة يرسلها
    //  - إيقاف مزامنة السجل القديم ومعاينة الروابط عالية الجودة (تبطّئ وتستهلك رام)
    //  - مهلات ونبض اتصال صريحة
    cachedGroupMetadata: async (jid) => getGroupCache(jid, 10 * 60_000),
    shouldSyncHistoryMessage: () => false,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    keepAliveIntervalMs: 25_000,
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    retryRequestDelayMs: 350,
    msgRetryCounterCache,
    getMessage: async (key) => {
      const cached = recentMessagesCache.get<WAMessage>(`${key.remoteJid}:${key.id}`);
      return cached?.message || undefined;
    },
  });

  // 🆕 (بند 4 من الطلب) — قبل كذا كان تاغ "معاد توجيهها + اسم القناة"
  // (buildNewsletterForwardContext) يُدمج فقط برسائل الأزرار (sendButtonMessage
  // بـ interactive.ts). المطلوب الآن: *كل* رسائل البوت بدون استثناء —
  // فبدل ما نعدّل كل ملف أمر يستخدم ctx.sock.sendMessage (عشرات الملفات)،
  // نغلّف الدالة نفسها مرة وحدة هنا مباشرة بعد إنشاء sock، فأي استدعاء
  // لاحق لـ sock.sendMessage() بأي مكان بالمشروع يمر من هنا تلقائيًا.
  //
  // 🔧 لو CHANNEL_JID فاضي بالـ.env، buildNewsletterForwardContext() ترجع
  // undefined ولا نغلّف شي إطلاقًا — أي سلوك قديم يبقى بالضبط زي ما هو
  // بدون أي خطر كسر لمن ما يبي هذي الميزة.
  // 🔧 (تعميم) — منطق التغليف نفسه انتقل لدالة مشتركة applyNewsletterBranding
  // بـ utils/interactive.ts، حتى تُستخدم بنفس الطريقة على مقابس البوتات
  // الفرعية بـ subBotManager.ts (كانت قبل كذا تفوتها هذي الميزة بالكامل).
  applyNewsletterBranding(sock);

  // 🆕 (v1.1.4) دفعة مبكرة احتياطية: لو جلسة محفوظة سابقًا خلّت sock.user
  // متوفر فورًا (قبل حدث "open")، نسجّله من الآن حتى لا يبقى فاضيًا لأي
  // فترة انتقالية قصيرة عند إعادة التشغيل.
  setBotSelfNumber(sock.user?.id);

  // ==============================================================
  // 🔧 (طلب صريح) — الأولوية دائمًا لجلسة محفوظة (session/creds.json أو
  // SESSION_ID بالـ.env): لو موجودة، يربط تلقائيًا بصمت بدون أي QR (نفس
  // ما كان يصير قبل كذا بالضبط). لو ما فيه أي جلسة مسجّلة إطلاقًا، بدل ما
  // نوقف الاتصال بالكامل، نكمل عادي ونطبع كود QR بالطرفية (الخيار
  // الثاني) عبر حدث "connection.update" بالأسفل — بالظبط زي أي بوت
  // واتساب عادي يعمل لأول مرة.
  // ==============================================================
  if (!state.creds.registered) {
    logger.warn(
      "📸 لا توجد جلسة مسجّلة بعد (لا session/creds.json ولا SESSION_ID صالح). " +
        "سيظهر كود QR بالأسفل خلال لحظات — امسحه من واتساب (الأجهزة المرتبطة ← ربط جهاز) " +
        "لأول ربط، أو أضف SESSION_ID جاهز (راجع README) لتفادي مسح QR في كل مرة."
    );
  }

  sock.ev.on("creds.update", saveCreds);

  // إبطال كاش المجموعة عند أي تغيير (انضمام/خروج/ترقية/تغيير إعدادات)
  sock.ev.on("group-participants.update", (u) => invalidateGroupCache(u.id));
  sock.ev.on("groups.update", (us) => us.forEach((g) => g.id && invalidateGroupCache(g.id)));

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    // 🆕 (الخيار الثاني: QR) — يصلنا هذا الحقل من Baileys بس لو ما فيه
    // جلسة مسجّلة بعد (نفس حالة !state.creds.registered بالأعلى). نطبعه
    // كـ ASCII بالطرفية مباشرة — يفتح مباشرة بكاميرا واتساب بجهازك.
    // ملاحظة: كل كود QR صالح لمدة قصيرة (~20-60 ثانية) وBaileys يرسل واحد
    // جديد تلقائيًا كل ما تنتهي صلاحية القديم، لحد ما تنجح بمسحه.
    if (qr) {
      logger.warn("📸 امسح كود QR التالي بواتساب (الأجهزة المرتبطة ← ربط جهاز) خلال حوالي 20-60 ثانية:");
      qrcodeTerminal.generate(qr, { small: true });
    }

    if (connection === "close") {
      const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      // 🆕 (طلب صريح: "الجلسة تخرب بسرعة") — تشخيص صريح لسبب كل انقطاع.
      // بدون هذا، ما فيه طريقة نعرف إذا السبب تسجيل خروج فعلي من واتساب
      // (401)، أو استضافتين تشتغلان بنفس الرقم (440)، أو مهلة شبكة عادية
      // (408/428/515) هتنصلح وحدها بإعادة الاتصال. راجع هذا السطر بالسجل
      // أول ما ينقطع البوت عندك عشان نعرف السبب الحقيقي بالضبط.
      const reasonName =
        Object.entries(DisconnectReason).find(([, v]) => v === statusCode)?.[0] || "غير معروف";
      logger.warn(
        `🔌 انقطع اتصال واتساب — statusCode=${statusCode ?? "?"} (${reasonName}). السبب المسجَّل: ${
          (lastDisconnect?.error as Error)?.message || "بدون رسالة"
        }`
      );

      if (statusCode === DisconnectReason.connectionReplaced) {
        logger.error(
          "⚠️ (440) الجلسة مفتوحة بمكان ثاني — غالبًا نسخة أخرى من البوت شغّالة بنفس الرقم (استضافة ثانية/جهازك). أوقف النسخة الثانية. سأنتظر 60 ثانية قبل المحاولة."
        );
        reconnectAttempts = Math.max(reconnectAttempts, 0);
        setTimeout(() => startBot().catch((err) => logger.error("فشل أثناء إعادة الاتصال:", err)), 60_000);
        return;
      }

      if (!shouldReconnect) {
        logger.error(
          "🔒 تم تسجيل خروج الجلسة من واتساب (Logged Out). احذف مجلد session وSESSION_ID وأعد الربط من جديد."
        );
        return; // لا تُعِد المحاولة إطلاقًا — إعادة المحاولة هنا عديمة الفائدة وتُهدر الموارد
      }

      reconnectAttempts++;
      const delay = Math.min(2000 * reconnectAttempts, MAX_BACKOFF_MS);
      logger.warn(
        `❌ انقطع الاتصال. إعادة المحاولة خلال ${Math.round(delay / 1000)} ثانية... (محاولة رقم ${reconnectAttempts})`
      );
      setTimeout(() => {
        startBot().catch((err) => logger.error("فشل أثناء إعادة الاتصال:", err));
      }, delay);
    } else if (connection === "open") {
      reconnectAttempts = 0;
      logger.success(`✅ ${CONFIG.BOT_NAME} متصل الآن وجاهز للعمل!`);
      startGameServer(); // اختياري: لو GAMES_PORT مضبوط

      // 🆕 يحاول يكتشف CHANNEL_JID تلقائيًا من CHANNEL_LINK فور نجاح
      // الاتصال (راجع resolveChannelJidFromLink بـutils/interactive.ts
      // للتفاصيل). best-effort بالكامل — لا يوقف التشغيل لو فشل.
      resolveChannelJidFromLink(sock).catch(() => {});

      // 🆕 (v1.1.4) نحدّث "رقم البوت الحالي" فور كل اتصال ناجح — يُستخدم
      // بمعزل تام عن CONFIG.OWNER_NUMBER حتى يُعتبر مطورًا بكامل الصلاحيات
      // دائمًا، حتى لو رُبط البوت لاحقًا برقم مختلف بدون إعادة تشغيل العملية.
      setBotSelfNumber(sock.user?.id);
      logger.info(`🩺 رقم البوت الحالي (مطور تلقائيًا): ${sock.user?.id?.split(":")[0].split("@")[0] || "غير معروف"}`);

      // 🆕 (إصلاح التعرف على المالك داخل الگروبات مع خصوصية @lid) —
      // نستعلم من واتساب مباشرة عن الـ lid المرتبط برقم المالك، ونخزنه
      // حتى تتعرف isOwner() على المالك بأي گروب حتى لو ظهر بمعرّف lid
      // بدل رقمه الحقيقي. لا يوقف تشغيل البوت أبدًا لو فشل الاستعلام
      // (مثلاً إصدار Baileys لا يدعم حقل lid) — مجرد محاولة إضافية.
      try {
        const results = await sock.onWhatsApp(CONFIG.OWNER_NUMBER);
        const ownerLid = (results?.[0] as unknown as { lid?: string } | undefined)?.lid;
        if (ownerLid) {
          setOwnerLid(ownerLid);
          logger.info(`🩺 lid المالك المكتشف: ${ownerLid.split("@")[0]}`);
        }
      } catch (err) {
        logger.warn("تعذر استعلام lid المالك من واتساب (غير مؤثر على باقي عمل البوت).", err);
      }

      // 🩺 تشخيص إقلاع: يوضح هل بيانات المجموعات (db.json) محفوظة فعليًا
      // بين كل إعادة تشغيل ولا لأ — مفيد جدًا لو أمر .تشغيل/.ايقاف يبدو
      // "يشتغل لفترة محدودة بس" (شكوى شائعة سببها غالبًا أن الاستضافة لا
      // تحفظ ملفات المشروع بشكل دائم بين كل إعادة تشغيل، فترجع كل الإعدادات
      // لقيمتها الافتراضية تلقائيًا عند كل ريستارت). لو العدد صفر رغم إنك
      // متأكد إنك أوقفت كروبات قبل كذا، هذا دليل قوي إن المشكلة من الاستضافة
      // (تخزين غير دائم/Ephemeral) مو من كود البوت.
      try {
        const groups = db.get("groups").value() || {};
        const groupIds = Object.keys(groups);
        const disabledGroups = groupIds.filter((id) => groups[id]?.settings?.enabled === false);
        logger.info(
          `🩺 بيانات محفوظة: ${groupIds.length} مجموعة بقاعدة البيانات، ${disabledGroups.length} منها موقوفة حاليًا (.ايقاف).`
        );
      } catch (err) {
        logger.warn("تعذر قراءة تشخيص قاعدة البيانات عند الإقلاع.", err);
      }

      setActiveSocket(sock);
      startSalawatScheduler();
      startPrayerTimesScheduler();
      startDbBackupScheduler();

      try {
        await sock.sendMessage(CONFIG.OWNER_JID, {
          text:
            `✅ تم تشغيل ${CONFIG.BOT_NAME} بنجاح وهو جاهز للعمل 24/7!\n\n` +
            `👑 المطور: ${CONFIG.OWNER_NAME}\n` +
            `📦 الإصدار: v${CONFIG.BOT_VERSION}\n` +
            `📜 عدد الأوامر: ${commandRegistry.count()}`,
        });
      } catch (err) {
        logger.warn("تعذر إرسال رسالة التأكيد لمالك البوت.", err);
      }
    }
  });

  // ==============================================================
  // 🩺 تشخيص "الأوامر تتنفذ بس ما فيه رد يوصل": sock.sendMessage() قد
  // يرجع بنجاح (Promise تتحلّل بدون خطأ) رغم إن واتساب فشل فعليًا بتوصيل
  // الرسالة للمستلم (مشكلة تشفير/جلسة Signal غالبًا). الطريقة الوحيدة
  // لمعرفة هل الرسالة "وصلت فعلاً" هي مراقبة حدث "messages.update" الذي
  // يحمل حالة كل رسالة صادرة (ERROR / PENDING / SERVER_ACK / DELIVERY_ACK
  // / READ). نطبع أي حالة فيها خطأ صريح هنا بدل ما تختفي بصمت.
  sock.ev.on("messages.update", (updates) => {
    for (const { key, update } of updates) {
      if (!key.fromMe) continue;
      if (update.status === 0 /* ERROR */) {
        logger.error(
          `🩺 فشل تسليم رسالة صادرة فعليًا (status=ERROR) للمستلم ${key.remoteJid} — رغم إن sendMessage لم يرمِ أي خطأ. هذا يؤكد أن المشكلة بجلسة التشفير (Signal session) وليست بكود البوت.`
        );
      }
    }
  });

  // معالجة الرسائل الواردة + تخزين مؤقت للرسائل الصادرة (يدعم getMessage أعلاه)
  sock.ev.on("messages.upsert", ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (msg.key.fromMe && msg.message && msg.key.id) {
        recentMessagesCache.set(`${msg.key.remoteJid}:${msg.key.id}`, msg);
      }
      // 🔧 إصلاح تأخير/عدم استجابة: قبل كذا كنا نعمل await لكل رسالة
      // بالتسلسل (for...await) — يعني لو رسالة وحدة أخذت وقت (تنزيل
      // فيديو، تحويل نص لصوت...)، كل الرسائل الجاية بعدها (حتى بكروبات
      // ثانية) تنتظر دورها وتتأخر أو يبدو إن البوت "ما يرد". الحين كل
      // رسالة تُعالج فورًا وبالتوازي مع البقية (بدون await هنا)، وأي خطأ
      // بمعالجتها يُمسك بمفرده فيسجّل بالـ logger بدون ما يوقف أي رسالة
      // ثانية أو يرمي unhandledRejection.
      handleIncomingMessage(sock, msg).catch((err) => {
        logger.error("خطأ أثناء معالجة رسالة واردة:", err);
      });
    }
  });

  // الترحيب والوداع بالأعضاء — تُسجَّل مرة واحدة فقط لكل مقبس اتصال جديد
  registerGroupParticipantsEvent(sock);
  registerGroupJoinPtvEvent(sock);
  registerJoinRequestAutoApprove(sock);
}

startBot().catch((err) => {
  logger.error("فشل تشغيل البوت عند الإقلاع:", err);
  // لا تُنهِ العملية فورًا — أعطِ فرصة لإعادة المحاولة بدل الدخول في حلقة تعطّل متكررة
  setTimeout(() => {
    startBot().catch((e) => {
      logger.error("فشلت إعادة المحاولة أيضًا، إيقاف العملية:", e);
      process.exit(1);
    });
  }, 5000);
});
