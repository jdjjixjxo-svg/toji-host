import { WASocket, GroupMetadata, proto } from "@whiskeysockets/baileys";
import NodeCache from "node-cache";
import { getGroupSettings, addWarning } from "../database/db";
import { isGroupAdmin, isOwner } from "./permissions";
import { CONFIG } from "../config/config";
import { startKickDecision } from "../handlers/kickDecisionManager";
import { logger } from "../utils/logger";
import { handleLinkMode, handleThreeLinkKick, getFriendCfg } from "../utils/friendUtils";

// 🔧 أزلنا علامة g: مع .test() تحفظ lastIndex بين الرسائل وتفوّت روابط أحيانًا
const LINK_REGEX = /(https?:\/\/|www\.|chat\.whatsapp\.com\/)[^\s]+/i;

// أسماء/أسماء بديلة لأوامر يفترض أنها تحتوي رابط ضمن استخدامها الطبيعي —
// نستثنيها من فلتر منع الروابط، وإلا رسالة أي عضو عادي يستخدم .تحميل تنحذف
// تلقائيًا قبل ما توصل لمعالجة الأمر أصلًا (وهذا كان يبدو تمامًا كأن الأمر
// "ما يشتغل إلا للمطور"، لأن المطور والمشرفين فقط مستثنون من هذا الفلتر).
const LINK_WHITELISTED_COMMANDS = ["تحميل", "تنزيل_فيديو", "download", "دلود"];

function isWhitelistedLinkCommand(text: string): boolean {
  if (!text.startsWith(CONFIG.PREFIX)) return false;
  const cmdName = text.slice(CONFIG.PREFIX.length).trim().split(/\s+/)[0];
  return LINK_WHITELISTED_COMMANDS.includes(cmdName);
}

// كاش لتتبع تكرار الرسائل (لنظام الحماية من السبام)
const spamCache = new NodeCache({ stdTTL: CONFIG.ANTISPAM_WINDOW_MS / 1000 });

/**
 * يفحص رسالة داخل مجموعة ويطبق قواعد الحماية (روابط + سبام).
 * يرجع true إذا تم التعامل مع الرسالة (حذف/تحذير) ولا داعي لمعالجتها كأمر.
 */
export async function runProtection(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  msg: proto.IWebMessageInfo,
  text: string,
  metadata: GroupMetadata
): Promise<boolean> {
  const settings = getGroupSettings(chatId);
  if (!settings.protection) return false;
  if (isOwner(senderJid, metadata, sock) || isGroupAdmin(metadata, senderJid)) return false; // المشرفون مستثنون

  // ===== منع الروابط =====
  if (settings.antilink && LINK_REGEX.test(text) && !isWhitelistedLinkCommand(text)) {
    // 🆕 (طلب صريح: ".3=طرد") — لو المشرف فعّل هذا الوضع، يتحكم بالكامل
    // ويتجاوز نظام linkMode القديم. لو غير مفعّل، يرجع نفس السلوك القديم
    // تمامًا كما كان (handleLinkMode ثم التحذير الافتراضي).
    if (getFriendCfg(chatId).threeLinkKick) return handleThreeLinkKick(sock, chatId, senderJid, msg);
    if (await handleLinkMode(sock, chatId, senderJid, msg)) return true; // 🆕 .منع_الروابط (حذف فقط / طرد)
    await deleteAndWarn(sock, chatId, senderJid, msg, "🚫 ممنوع إرسال الروابط في هذه المجموعة!", metadata);
    return true;
  }

  // 🆕 (طلب صريح: حماية حذف جهات الاتصال — معطّلة افتراضيًا) — نتحقق من
  // نوعي رسالة جهة الاتصال المدعومين بواتساب: جهة واحدة (contactMessage)
  // أو عدة جهات دفعة وحدة (contactsArrayMessage).
  if (settings.antiContact && (msg.message?.contactMessage || msg.message?.contactsArrayMessage)) {
    await deleteAndWarn(sock, chatId, senderJid, msg, "🚫 ممنوع إرسال جهات اتصال في هذه المجموعة!", metadata);
    return true;
  }

  // ===== منع السبام =====
  if (settings.antispam) {
    const key = `${chatId}:${senderJid}`;
    const count = (spamCache.get<number>(key) || 0) + 1;
    spamCache.set(key, count);
    if (count > CONFIG.ANTISPAM_MAX_MSGS) {
      await deleteAndWarn(sock, chatId, senderJid, msg, "🚫 توقف عن إرسال رسائل متكررة بسرعة (سبام)!", metadata);
      return true;
    }
  }

  return false;
}

async function deleteAndWarn(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  msg: proto.IWebMessageInfo,
  reason: string,
  metadata: GroupMetadata
) {
  try {
    await sock.sendMessage(chatId, { delete: msg.key });
  } catch (err) {
    logger.warn("تعذر حذف الرسالة (قد لا يكون البوت مشرفًا).", err);
  }

  const warnings = addWarning(chatId, senderJid);
  const mention = `@${senderJid.split("@")[0]}`;

  // 🔧 (طلب صريح: "لا تخليه يطرد حد تلقائي") — نفس تدفق قرار الطرد
  // الجديد المستخدم بأمر .نذار اليدوي الآن يُستخدم هنا أيضًا لو التحذيرات
  // التلقائية (روابط/سبام) وصلت للعدد الكامل، بدل طرد فوري بلا موافقة
  // المشرفين. راجع src/handlers/kickDecisionManager.ts للتفاصيل الكاملة.
  if (warnings >= CONFIG.MAX_WARNINGS) {
    try {
      const groupMetadata = await sock.groupMetadata(chatId);
      await sock.sendMessage(chatId, { text: reason, mentions: [senderJid] });
      await startKickDecision(sock, chatId, senderJid, groupMetadata);
    } catch (err) {
      logger.warn("تعذر بدء تدفق قرار الطرد بعد اكتمال التحذيرات التلقائية.", err);
    }
  } else {
    await sock.sendMessage(chatId, {
      text: `${reason}\n${mention} ⚠️ تحذير (${warnings}/${CONFIG.MAX_WARNINGS})`,
      mentions: [senderJid],
    });
  }
}
