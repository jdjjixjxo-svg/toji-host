import { WASocket, GroupMetadata } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { digitsOnly, getBotScopeId, notifyOwnerOfError } from "../utils/helpers";
import { isDeveloper } from "../utils/developerIdentity";
import { findParticipant } from "../utils/participantMatch";
import { isVirtualAdmin, isGlobalVirtualAdmin } from "../database/db";

export type PermissionLevel = "all" | "admin" | "owner";

/**
 * يتحقق هل الرقم هو مالك/مطور البوت.
 *
 * 🔧 إصلاح مهم (v1.1.4): "مطور البوت" الآن هويتان مستقلتان تمامًا، وأي
 * منهما تُعطى كامل الصلاحيات دون أي شرط لتطابقهما مع بعض:
 *   1) رقم البوت نفسه (الحساب المربوط فيه البوت حاليًا عبر QR/الكود) —
 *      يُقارَن بـ getBotSelfNumber() المحدَّث تلقائيًا من sock.user.id.
 *   2) CONFIG.OWNER_NUMBER من ملف .env — يبقى "المالك" الرسمي بكامل
 *      الصلاحيات بغض النظر تمامًا عن رقم البوت نفسه.
 * قبل هذا الإصلاح كان الكود بأماكن ثانية (fromMe بـ messageHandler) يفترض
 * ضمنيًا إنهما نفس الرقم دائمًا، فكان "المطور" يُتعرَّف عليه صح فقط لو
 * ربط البوت بنفس رقمه هو، وما يُتعرَّف عليه إطلاقًا لو ربط البوت برقم
 * مختلف. الحل هنا يفصل الهويتين نهائيًا فيشتغلان دائمًا، بغض النظر عن
 * أي الرقمين مربوط فيه البوت فعليًا.
 *
 * ⚠️ نفس مشكلة الـ @lid الموضحة تحت في isGroupAdmin تنطبق هنا بالضبط: داخل
 * الگروبات، قد يصل senderJid بصيغة "xxxx@lid" بدل الرقم الحقيقي حتى لو كان
 * المرسل هو المالك فعليًا، فتفشل المقارنة المباشرة مع OWNER_NUMBER ويظن
 * البوت أنه شخص عادي (وهذا كان يسبب تجاهل صامت لأي أمر، حتى أوامر المالك
 * نفسه، داخل المجموعات). لذلك نمرر بيانات المجموعة (metadata) اختياريًا
 * هنا أيضًا، ونبحث عن العضو المطابق برقمه الحقيقي (phoneNumber) أو lid قبل
 * الحكم بأنه ليس المالك.
 *
 * 🆕 (طلب صريح: "خله يعتبر الرقم المربوط فيه البوت وعامل عليه تنصيب
 * يعتبره مطور، لاكن منعزل لبوته" — يعني: أي بوت فرعي يعامل صاحب رقمه هو
 * بالذات كمطور كامل الصلاحيات، لكن فقط لما التفاعل يمر عبر *نفس ذاك
 * البوت تحديدًا* (مُمرَّر هنا كـsock اختياري). هذا لا يعطي أي صلاحية على
 * بوت آخر إطلاقًا — بوت فرعي ثانٍ بنفس المجموعة لن يعامل نفس الشخص
 * كمطور له هو (لأن sock مختلف = getBotScopeId مختلف)، ولا يعطي صلاحية
 * على البوت الرئيسي (نفس المنطق بالضبط). راجع أيضًا القائمة الصغيرة
 * MAIN_BOT_ONLY_COMMANDS بـmessageHandler.ts للأوامر المشتركة/الخطيرة
 * المستثناة من هذا حتى لو صاحب الرقم كتبها من بوته هو.
 */
export function isOwner(jid: string, metadata?: GroupMetadata, sock?: WASocket): boolean {
  return isDeveloper(jid, metadata, sock);
}

/**
 * يتحقق هل العضو مشرف داخل المجموعة.
 *
 * ⚠️ ملاحظة مهمة (سبب شائع لعطل "أوامر المشرفين لا تعمل"):
 * واتساب بدأ تدريجيًا يستبدل رقم الهاتف الحقيقي لبعض الأعضاء بمعرّف مؤقت
 * بصيغة "xxxx@lid" داخل قوائم أعضاء المجموعة (خاصية خصوصية جديدة). هذا
 * يعني أن `metadata.participants[].id` قد يكون بصيغة @lid بينما
 * `senderJid` القادم من الرسالة نفسها بصيغة @s.whatsapp.net (أو العكس)،
 * فتفشل أي مقارنة نصية مباشرة (`===`) حتى لو كان المستخدم فعليًا مشرفًا.
 * الحل: نقارن بالأرقام فقط (بعد إزالة أي لاحقة @...)، ونتحقق أيضًا من
 * حقلي phoneNumber/lid الإضافيين اللذين توفرهما مكتبة Baileys الحديثة
 * لكل عضو عندما يكون معرّفه الأساسي من النوع الآخر.
 */
export function isGroupAdmin(
  metadata: GroupMetadata,
  userJid: string
): boolean {
  const participant = findParticipant(metadata, userJid);
  return participant?.admin === "admin" || participant?.admin === "superadmin";
}

/** يتحقق هل البوت نفسه مشرف بالمجموعة (مطلوب لتنفيذ الطرد/الكتم...) */
export function isBotAdmin(metadata: GroupMetadata, botJid: string): boolean {
  return isGroupAdmin(metadata, botJid);
}

/**
 * الدالة المركزية للتحقق من الصلاحية قبل تنفيذ أي أمر.
 * ترجع true إذا يُسمح بالتنفيذ، وترسل تنبيهًا تلقائيًا إذا رُفض.
 */
export async function checkPermission(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  level: PermissionLevel,
  metadata?: GroupMetadata,
  // هل الأمر يحتاج فعليًا أن يكون البوت مشرفًا؟ افتراضيًا true (نفس
  // السلوك القديم) — الفعاليات/الإعدادات تمررها false لأنها ما تنفذ أي
  // إجراء إشراف حقيقي بواتساب، فما مبرر لمنعها بسبب حالة البوت.
  requireBotAdmin = true,
  // 🆕 هل "الأدمن الوهمي" مسموح له بهذا الأمر تحديدًا؟ افتراضيًا true.
  // .اعدادات (تشغيل/إيقاف ميزات البوت) تمررها false بناءً على طلب صريح:
  // الأدمن الوهمي يقدر يستخدم كل أوامر الإشراف بدون استثناء، إلا تشغيل/
  // إيقاف ردود البوت ورفع/تنزيل الأدمن الوهمي نفسه (وهذي أصلًا owner-only).
  allowVirtualAdmin = true
): Promise<boolean> {
  if (level === "all") return true;

  if (level === "owner") {
    if (isOwner(senderJid, metadata, sock)) return true;
    try {
      void notifyOwnerOfError(
        sock,
        "فحص صلاحية مطور (رفض)",
        `senderJid: ${senderJid} (digits: ${digitsOnly(senderJid)})\nهوية هذا البوت (getBotScopeId): ${getBotScopeId(sock)}\nOWNER_NUMBER: ${CONFIG.OWNER_NUMBER} | OWNER_NUMBER_2: ${CONFIG.OWNER_NUMBER_2 || "—"}`,
        { chatId, senderJid }
      );
    } catch {
      /* تشخيص إضافي فقط */
    }
    await sock.sendMessage(chatId, {
      text: "👑 هذا الأمر مخصص لمطور البوت فقط!",
    });
    return false;
  }

  if (level === "admin") {
    if (isOwner(senderJid, metadata, sock)) return true; // المطور يتجاوز أي قيد

    // 🆕 أدمن وهمي: عضو منحه المطور صلاحية عبر .رفع_ادمن — يتجاوز فحص
    // isGroupAdmin الحقيقي بواتساب فقط لهذي المجموعة بالذات، ولكل أوامر
    // الإشراف ما عدا اللي تحدد allowVirtualAdmin: false صراحة.
    // 🔧 (عزل البوتات الفرعية) — الفحص صار مرتبطًا بهوية البوت الحالي
    // (getBotScopeId(sock)) حتى لا تسري صلاحية مُنحت عبر بوت على بوت آخر.
    const botId = getBotScopeId(sock);
    if (allowVirtualAdmin && isVirtualAdmin(botId, chatId, senderJid)) return true;

    // 🆕 (.رفع_مالك) أدمن وهمي عام: نفس فكرة الأدمن الوهمي أعلاه، لكن
    // بدون التقيّد بمجموعة واحدة — يشتغل بأي مجموعة البوت موجود فيها.
    if (allowVirtualAdmin && isGlobalVirtualAdmin(botId, senderJid, metadata)) return true;

    // ١) نتحقق من صلاحية الشخص نفسه أول شي — لو مو مشرف، هذا سبب الرفض
    // (بغض النظر عن حالة البوت)، فيه رسالة الرفض العادية زي ما كانت دائمًا.
    if (!metadata || !isGroupAdmin(metadata, senderJid)) {
      // 🆕 تشخيص فعلي (بدل التخمين المستمر): لو صار رفض "مخصص للمشرفين"،
      // نبعت للمطور على الخاص تلقائيًا بيانات المطابقة الحقيقية لهذا
      // العضو بالذات (id/phoneNumber/lid المخزّنة بمتادata مقابل الرقم
      // اللي وصل بالرسالة) — عشان نشوف بالضبط وين الاختلاف بدل تخمينات
      // جديدة بدون أي دليل حقيقي.
      try {
        const target = digitsOnly(senderJid);
        const participant = metadata ? findParticipant(metadata, senderJid) : undefined;
        const anyP = participant as unknown as { phoneNumber?: string; jid?: string; lid?: string } | undefined;
        const diag =
          `senderJid: ${senderJid} (digits: ${target})\n` +
          `تم إيجاد مشارك مطابق: ${participant ? "نعم" : "لا"}\n` +
          (participant
            ? `id: ${participant.id} | phoneNumber: ${anyP?.phoneNumber || "—"} | jid: ${anyP?.jid || "—"} | lid: ${anyP?.lid || "—"} | admin: ${participant.admin || "لا"}`
            : "");
        void notifyOwnerOfError(sock, "فحص صلاحية مشرف (رفض)", diag, { chatId, senderJid });
      } catch {
        /* التشخيص إضافي فقط، ما يمنع الرد العادي بأي حال */
      }

      await sock.sendMessage(chatId, {
        text: "⚠️ هذا الأمر مخصص لمشرفي المجموعة فقط!",
      });
      return false;
    }

    // ٢) الشخص فعليًا مشرف. قبل كذا كان فيه فحص محلي إضافي "هل البوت
    // نفسه مشرف؟" (بمقارنة أرقام/lid) يمنع تنفيذ الأمر مسبقًا لو رجّع
    // "لا". لكن هذا الفحص غير موثوق بالكامل بسبب طريقة واتساب الجديدة
    // بتمثيل بعض الأعضاء بمعرّف "@lid" داخلي بدل رقم الهاتف الحقيقي —
    // حتى مع إعادة جلب بيانات المجموعة مباشرة، ما نضمن مطابقة صحيحة
    // 100% دائمًا، وهذا كان يسبب رفض الأمر ورسالة "عليك جعل البوت مشرفا
    // اولا" حتى لو البوت مشرف فعليًا بالمجموعة.
    //
    // الحل الأدق: ما نمنع الأمر مسبقًا بناءً على تخمين محلي. نتركه ينفذ
    // فعليًا، وواتساب نفسه هو من يقرر (السيرفر يملك الحقيقة الكاملة عن
    // صلاحيات البوت، لا حاجة نخمنها من جهتنا). كل أمر إشراف حقيقي
    // (طرد/كتم/قفل/فتح/حذف/تغيير الوصف والصورة...) يستدعي API يرفضه
    // واتساب بخطأ واضح لو البوت فعلاً مو مشرف، وكل هذه الأوامر تمسك ذلك
    // الخطأ برسالة "تأكد أن البوت مشرف" الخاصة فيها — فمافي داعي لفحص
    // مسبق قد يخطئ ويمنع أمر كان بيشتغل فعليًا.
    void requireBotAdmin; // محتفظ فيه بالتوقيع لعدم كسر الاستدعاءات القديمة

    return true;
  }

  return false;
}
