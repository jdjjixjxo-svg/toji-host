/**
 * 🆕 لعبة "Dino Runner" (.dino) — محاكاة لعبة الديناصور الشهيرة، بس
 * بشكل يناسب واتساب فعليًا: كل ضغطة زر = "خطوة" وحدة باللعبة، ونرسم
 * مشهد جديد (SVG → صورة) بعد كل خطوة. راجع الشرح اللي بعثته قبل هذا
 * الكود لتفاصيل ليش هذا هو الحد الأقصى الواقعي لأي بوت واتساب (بدون
 * بث فيديو حي أو محرك رسوميات فعلي).
 */
import { WASocket } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { addPoint } from "../database/db";
import { CONFIG } from "../config/config";

interface Game {
  playerJid: string;
  score: number;
  obstacleDistance: number; // 0 = بجنب الديناصور تمامًا
  jumping: boolean;
}

const sessions = new Map<string, Game>();

function key(sock: WASocket, chatId: string, senderJid: string): string {
  return `${getBotScopeId(sock)}:${chatId}:${senderJid}`;
}

export function isRunning(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.has(key(sock, chatId, senderJid));
}

const TRACK_WIDTH = 500;
const LANES = 6; // مواقع ممكنة بالمضمار

function renderScene(game: Game): Promise<Buffer> {
  const dinoX = 60;
  const groundY = 200;
  const obstacleX = dinoX + (game.obstacleDistance / LANES) * (TRACK_WIDTH - dinoX - 40) + 40;

  const dinoY = game.jumping ? groundY - 60 : groundY - 30;
  const dinoEmoji = game.jumping ? "🦘" : "🦖";

  const svg = `<svg width="${TRACK_WIDTH}" height="260" xmlns="http://www.w3.org/2000/svg">
    <rect width="${TRACK_WIDTH}" height="260" fill="#fef9e7"/>
    <line x1="0" y1="${groundY}" x2="${TRACK_WIDTH}" y2="${groundY}" stroke="#7f8c8d" stroke-width="4"/>
    <text x="${dinoX}" y="${dinoY}" font-size="50">${dinoEmoji}</text>
    ${game.obstacleDistance <= LANES ? `<text x="${obstacleX}" y="${groundY - 5}" font-size="42">🌵</text>` : ""}
    <text x="20" y="30" font-size="22" font-family="sans-serif" fill="#2c3e50" font-weight="bold">🏆 النقاط: ${game.score}</text>
  </svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendScene(sock: WASocket, chatId: string, game: Game, message: string): Promise<void> {
  const image = await renderScene(game);
  await sendButtonMessage(sock, chatId, {
    text: `🦖 *Dino Runner* — ${jidToMention(game.playerJid)}\n\n${message}`,
    mentions: [game.playerJid],
    image,
    extraButtons: [buildSingleSelectButton("🦘 اقفز!", "الحركة", [{ command: "dino_jump", label: "🦘 اقفز فوق الصبار" }])],
  });
}

export async function start(sock: WASocket, chatId: string, senderJid: string): Promise<void> {
  const k = key(sock, chatId, senderJid);
  const game: Game = { playerJid: senderJid, score: 0, obstacleDistance: LANES, jumping: false };
  sessions.set(k, game);
  await sendScene(sock, chatId, game, "اضغط \"اقفز\" بالضبط لما الصبار يوصل جنبك، أو استعد عادي أي وقت ثاني.");
}

/**
 * كل رسالة (زر أو نص "قفز") تُعتبر "خطوة" باللعبة — سواء قفز فعلي أو
 * انتظار. يرجع true لو تعامل مع الرسالة.
 *
 * 🔧 (نفس درس أزرار الراوي): لما تُضغط قائمة "اختار"، matchButtonTrigger
 * بـmessageHandler.ts يحوّل النص تلقائيًا لـ"${PREFIX}dino_jump" (يضيف
 * البادئة). لازم نشيلها قبل أي مقارنة.
 */
export async function handleStep(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId, senderJid);
  const game = sessions.get(k);
  if (!game) return false;

  const trimmed = text.trim();
  const withoutPrefix = trimmed.startsWith(CONFIG.PREFIX) ? trimmed.slice(CONFIG.PREFIX.length) : trimmed;
  const isJump = withoutPrefix === "dino_jump" || withoutPrefix === "قفز" || withoutPrefix.includes("اقفز");
  // لو مو قفزة ولا رسالة عادية بالمحادثة نفسها (نتجاهل غير المرتبط)
  if (!isJump && withoutPrefix.length > 20) return false;

  game.jumping = isJump;

  // تصادم؟ الصبار بجنب الديناصور بالضبط (distance == 0) وما قفز
  if (game.obstacleDistance === 0) {
    if (!isJump) {
      sessions.delete(k);
      addPoint(chatId, senderJid, Math.floor(game.score / 3));
      await sendButtonMessage(sock, chatId, {
        text: `💥 *اصطدمت بالصبار!* انتهت اللعبة.\n🏆 نقاطك النهائية: ${game.score}`,
        mentions: [senderJid],
      });
      return true;
    }
    // قفز بنجاح فوق العائق
    game.score++;
    game.obstacleDistance = LANES; // عائق جديد من البداية
    await sendScene(sock, chatId, game, "🎉 قفزة ناجحة! استعد للصبار الجاي.");
    return true;
  }

  // ما فيه تصادم هالخطوة — نقرّب العائق خطوة
  game.obstacleDistance--;
  await sendScene(sock, chatId, game, game.obstacleDistance <= 1 ? "⚠️ الصبار قرّب! جهّز نفسك." : "🏃 مستمر...");
  return true;
}

export function end(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.delete(key(sock, chatId, senderJid));
}
