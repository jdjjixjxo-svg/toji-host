import fs from "fs";
import path from "path";
import { Command } from "./types";
import { logger } from "../utils/logger";
import { normalizeArabicCommand } from "../utils/arabicNormalize";

/**
 * 🆕 أسماء بديلة مطابقة لقائمة أوامر بوت الصديق — تُضاف فوق الأوامر الموجودة
 * (المفتاح = الاسم الأساسي للأمر عندنا، القيمة = الأسماء الإضافية).
 * لا تُغيّر أي أمر أصلي؛ فقط تجعل نفس الاختصارات تعمل.
 */
const EXTRA_ALIASES: Record<string, string[]> = {
  "حجر_ورقة_مقص": ["حجر"],
  "إكس_أو": ["اكس"],
  "اعلام": ["علم"],
  "سؤال_شخصي": ["اسألني"],
  "مثل": ["اكمل_المثل"],
  "زوجه": ["زوجني"],
  "تحليل_الشخصية": ["شخصية"],
  "dino": ["لعبة"],
  "قول": ["تكلم"],
  "سوال": ["gemini", "كلود", "claude", "chatgpt", "جيمناي"],
  "صور": ["بنترست", "pinterest"],
  "رتب": ["فك_الطلاسم", "فكك"],
  "تغيير_الصورة": ["تغيير_صورة_المجموعة"],
  "تنصيب": ["install"],
  "سبوتيفاي": ["ساوند", "soundcloud"],
  "ستيكر": [],
};

class CommandRegistry {
  private commands: Map<string, Command> = new Map();
  private aliasMap: Map<string, string> = new Map();

  register(command: Command) {
    const key = normalizeArabicCommand(command.name);
    this.commands.set(key, command);
    command.aliases?.forEach((alias) =>
      this.aliasMap.set(normalizeArabicCommand(alias), key)
    );
  }

  get(nameOrAlias: string): Command | undefined {
    const norm = normalizeArabicCommand(nameOrAlias);
    const realName = this.aliasMap.get(norm) || norm;
    return this.commands.get(realName);
  }

  getAll(): Command[] {
    return Array.from(this.commands.values());
  }

  clear() {
    this.commands.clear();
    this.aliasMap.clear();
  }

  count(): number {
    return this.commands.size;
  }

  /** يحمّل كل ملفات الأوامر (.ts/.js) من مجلد commands وكل المجلدات الفرعية تلقائيًا */
  loadAll(baseDir: string) {
    const walk = (dir: string) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walk(fullPath);
        } else if (entry.name.endsWith(".ts") || entry.name.endsWith(".js")) {
          if (entry.name.endsWith(".d.ts")) continue;
          try {
            delete require.cache[require.resolve(fullPath)];
            // eslint-disable-next-line @typescript-eslint/no-var-requires
            const imported = require(fullPath);
            const command: Command | undefined = imported.default || imported.command;
            if (command && command.name) {
              this.register(command);
            }
          } catch (err) {
            logger.error(`فشل تحميل الأمر من الملف: ${fullPath}`, err);
          }
        }
      }
    };
    walk(baseDir);
    for (const [target, extras] of Object.entries(EXTRA_ALIASES)) {
      const cmd = this.get(target);
      if (!cmd) continue;
      for (const a of extras) {
        const key = normalizeArabicCommand(a);
        if (!this.commands.has(key) && !this.aliasMap.has(key)) this.aliasMap.set(key, normalizeArabicCommand(cmd.name));
      }
    }
    logger.success(`تم تحميل ${this.count()} أمر بنجاح.`);
  }
}

export const commandRegistry = new CommandRegistry();
