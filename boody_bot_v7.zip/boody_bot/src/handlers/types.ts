import { WASocket, GroupMetadata, proto } from "@whiskeysockets/baileys";
import { PermissionLevel } from "../middlewares/permissions";

export interface CommandContext {
  sock: WASocket;
  chatId: string;
  senderJid: string;
  isGroup: boolean;
  metadata: GroupMetadata | null;
  msg: proto.IWebMessageInfo;
  args: string[];
  text: string; // النص كامل بعد الأمر
  quoted: proto.IMessage | null | undefined;
  // 🆕 true فقط لو الأمر تنفّذ عبر بوت فرعي (raw sock من ميزة .تنصيب)،
  // وليس البوت الرئيسي. راجع MessageHandlerOptions.subBot بالأسفل ودالة
  // handleIncomingMessage بملف messageHandler.ts — نفس المصدر بالضبط.
  isSubBot: boolean;
}

export interface Command {
  name: string; // الاسم الأساسي بدون البادئة، مثال: "menu"
  aliases?: string[]; // أسماء بديلة، مثال: ["اوامر", "help", "بوت"]
  category:
    | "بوت"
    | "مشرفين"
    | "حماية"
    | "ترفيه" // يضم كل الألعاب والفعاليات وأوامر المرح بقسم واحد
    | "ادوات"
    | "اعدادات"
    | "السنة" // محتوى إسلامي: أذكار، أركان الصلاة، حديث، آية، سورة
    | "المطور"
    | "IA" // قسم الذكاء الاصطناعي (.رسم / .سوال)
    | "تحليل" // 🆕 قسم جديد (تحليل الشخصية / تحليل المزاج) — بطاقات عشوائية للترفيه
    | "العاب2D" // 🆕 قسم جديد: ألعاب على شبكة نصية ثنائية الأبعاد (2D) — راجع commands/games2d/
    | "تنصيب" // 🆕 قسم جديد: ربط رقم المستخدم كـ"جهاز مرتبط" ليشتغل عنده بوت فرعي — راجع commands/install/
    | "الراوي" // 🆕 (طلب صريح) قسم مستقل خاص بلعبة .قصة فقط — زر مباشر بالقائمة الرئيسية، لا قائمة فرعية له
    | "اوامر_جانبيه" // 🆕 (طلب صريح) أوامر مستوردة من ملف خارجي، أُعيدت كتابتها بالكامل لتشتغل بمعمارية هذا المشروع
    | "تعديل_الصور"; // 🆕 (طلب صريح) قسم جديد: كل أدوات تعديل الصور — فلاتر Jimp + تعديل بالذكاء (.نانو) + قص
  description: string;
  permission: PermissionLevel; // "all" | "admin" | "owner"
  groupOnly?: boolean; // هل الأمر يعمل داخل المجموعات فقط
  // هل هذا الأمر يتطلب أن يكون البوت نفسه مشرفًا بالمجموعة؟ (مطلوب فقط
  // للأوامر اللي فعليًا تحتاج صلاحية إشراف واتساب حقيقية زي الطرد/الكتم/
  // الحذف/القفل...). افتراضيًا true للحفاظ على نفس السلوك القديم لأي أمر
  // "admin" ما يحدد هذا الحقل صراحة. الفعاليات/الإعدادات لا تحتاج هذا
  // (ما تنفذ أي إجراء إشرافي فعلي بواتساب)، فتحدده false صراحة.
  requireBotAdmin?: boolean;
  // 🆕 هل "الأدمن الوهمي" (.رفع_ادمن) يقدر ينفذ هذا الأمر؟ افتراضيًا
  // true لكل أوامر permission: "admin" (نفس طلب المالك: الأدمن الوهمي
  // يقدر يستخدم كل الأوامر بدون استثناء). حدّدها false صراحة فقط للأوامر
  // المستثناة تحديدًا (تشغيل/إيقاف ميزات البوت عبر .اعدادات) — تبقى
  // لمشرفي واتساب الحقيقيين/المطور فقط.
  allowVirtualAdmin?: boolean;
  execute: (ctx: CommandContext) => Promise<void>;
}

/**
 * 🆕 خيارات إضافية لمعالجة الرسائل (راجع handlers/messageHandler.ts).
 * subBot: true تعني أن sock الممرَّر هو مقبس بوت فرعي (تم إنشاؤه عبر
 * ميزة .تنصيب — راجع handlers/subBotManager.ts)، وليس البوت الرئيسي.
 * تُستخدم لمنع تنفيذ أي أمر بفئة "المطور" أو صلاحية "owner" على أي بوت
 * فرعي إطلاقًا، بغض النظر عن هوية المرسل (حتى لو كان هو نفسه صاحب الرقم
 * المرتبط) — طلب صريح من صاحب المشروع.
 */
export interface MessageHandlerOptions {
  subBot?: boolean;
}