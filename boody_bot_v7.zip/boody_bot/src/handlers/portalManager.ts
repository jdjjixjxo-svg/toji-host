/**
 * ============================================================================
 * 🆕 لعبة "بوابة" (.بوابه) — قصة قصيرة ثابتة متفرعة (بدون ذكاء اصطناعي،
 * على عكس .قصة اللي تولّد نص جديد كل مرة). شخصية لكل شخص لحاله (مو
 * مشتركة بالشات زي .قصة)، فأكثر من شخص بنفس الكروب يقدر يلعب قصته
 * الخاصة بنفس الوقت بدون تعارض.
 * ============================================================================
 * 🔧 الأصل كان يعتمد على صور محلية (media/red.jpg...) غير موجودة أصلًا
 * بالمشروع ولا حتى مُستخدمة فعليًا بمنطق اللعبة (كود ميت) — حذفناها.
 * وكان مسجّل بدالة "continueGame" منفصلة يستدعيها المطور يدويًا من مكان
 * غير موجود بمشروعنا — دمجناها بنفس آلية hasActiveStory/handleStoryChoice.
 * ============================================================================
 */
type Stage = "start" | "chooseDoor" | "red_path" | "blue_path" | "black_path";

const sessions = new Map<string, Stage>();
const key = (chatId: string, senderJid: string) => `${chatId}:${senderJid}`;

export function hasActivePortal(chatId: string, senderJid: string): boolean {
  return sessions.has(key(chatId, senderJid));
}

export function startPortal(): { text: string; stage: Stage } {
  return { text: "🌀 *تم فتح بوابة غامضة...*\nهل ترغب بالدخول؟\nاكتب *نعم* للمتابعة أو *لا* للخروج.", stage: "start" };
}

/** يرجع نص الرد لو تعامل مع الرسالة، أو null لو النص ما يطابق أي خيار متوقع بهذي المرحلة */
export function handlePortalChoice(chatId: string, senderJid: string, rawText: string): string | null {
  const k = key(chatId, senderJid);
  const stage = sessions.get(k);
  if (!stage) return null;

  const text = rawText.trim().toLowerCase();

  if (stage === "start") {
    if (text === "نعم") {
      sessions.set(k, "chooseDoor");
      return "🎴 أمامك ثلاث بوابات:\n1️⃣ الأحمر\n2️⃣ الأزرق\n3️⃣ الأسود\n\nاكتب رقم الباب أو اسمه لاختيارك.";
    }
    sessions.delete(k);
    return "🚪 تم إغلاق البوابة... إلى اللقاء!";
  }

  if (stage === "chooseDoor") {
    if (["1", "الأحمر", "احمر", "red", "🔴"].some((v) => text.includes(v))) {
      sessions.set(k, "red_path");
      return "🔴 دخلت عالم الرجل المقنع، هل تريد الاقتراب (اكتب 1) أم الهروب (اكتب 2)؟";
    }
    if (["2", "الأزرق", "ازرق", "blue", "🔵"].some((v) => text.includes(v))) {
      sessions.set(k, "blue_path");
      return "🔵 وقفت أمام الشجرة البيضاء، هل تسمع الهمسات (1) أم تتجاهلها (2)؟";
    }
    if (["3", "الأسود", "اسود", "black", "⚫"].some((v) => text.includes(v))) {
      sessions.set(k, "black_path");
      return "⚫ دخلت عالم الظلال، هل تبحث عن المراقب (1) أم تختبئ (2)؟";
    }
    return "❌ اختيار غير معروف. اكتب رقم الباب أو اسمه (1، 2، 3).";
  }

  if (stage === "red_path") {
    if (text === "1") {
      sessions.delete(k);
      return "👤 اقتربت من الرجل المقنع... النهاية: دخلت في صراع نفسي عميق.";
    }
    if (text === "2") {
      sessions.delete(k);
      return "🏃‍♂️ هربت من الرجل المقنع، ولكن البوابة أغلقت. النهاية.";
    }
    return "❌ اكتب 1 أو 2 فقط.";
  }

  if (stage === "blue_path") {
    if (text === "1") {
      sessions.delete(k);
      return "🌳 سمعت الهمسات وتعلمت أسرار الماضي. النهاية: الحكمة.";
    }
    if (text === "2") {
      sessions.delete(k);
      return "❄️ تجاهلت الهمسات وبقيت وحيداً في الغابة. النهاية.";
    }
    return "❌ اكتب 1 أو 2 فقط.";
  }

  // black_path
  if (text === "1") {
    sessions.delete(k);
    return "🔦 وجدت أن المراقب هو نفسك من المستقبل. النهاية: رحلة عبر الزمن.";
  }
  if (text === "2") {
    sessions.delete(k);
    return "🌫️ اختبأت في الظلال وابتلعتك النهاية.";
  }
  return "❌ اكتب 1 أو 2 فقط.";
}

export function beginPortalSession(chatId: string, senderJid: string): void {
  sessions.set(key(chatId, senderJid), "start");
}

/** ينهي جلسة بوابة جارية لهذا الشخص يدويًا (يُستدعى من .استسلم). */
export function endPortal(chatId: string, senderJid: string): boolean {
  return sessions.delete(key(chatId, senderJid));
}
