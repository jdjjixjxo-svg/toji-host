import { WASocket } from "@whiskeysockets/baileys";
import path from "path";
import fs from "fs-extra";
import { db, getGroupSettings } from "../database/db";
import { logger } from "../utils/logger";
import { CONFIG } from "../config/config";
import { sendWithSalawatFallback } from "../utils/media";
import { getTodayMeccaPrayerTimes, currentMeccaTimeHHMM, PrayerTimes } from "../utils/prayerTimes";

// رسائل متنوعة حتى ما تصير نفس الرسالة كل ساعة وتصير مملة
const SALAWAT_MESSAGES = [
  "🌹 حيّ على الصلاة على سيدنا محمد ﷺ.. اللهم صل وسلم عليه 💫",
  "✨ تذكير حلو: صلّوا على الحبيب محمد ﷺ ولو مرة وحدة الحين 🤍",
  "🕌 اللهم صل وسلم وبارك على نبينا محمد ﷺ عدد ما ذكره الذاكرون وغفل عن ذكره الغافلون",
  "💫 دقيقة وحدة بس.. صلّ على النبي ﷺ وربح أجرها 🌙",
  "🌙 اللهم صل على محمد وعلى آل محمد ﷺ.. لا تنسوها 🌹",
  "🤍 من أحلى الأذكار: الصلاة على الحبيب ﷺ.. صلوا عليه الحين 💫",
];

let activeSock: WASocket | null = null;

/** يحدّث مرجع الاتصال النشط الحالي (يُستدعى مع كل اتصال ناجح جديد بعد إعادة الاتصال) */
export function setActiveSocket(sock: WASocket) {
  activeSock = sock;
}

let schedulerStarted = false;

/**
 * يبدأ مؤقت تذكير الصلاة على النبي ﷺ كل ساعة، لأي مجموعة مفعّل فيها إعداد
 * "صلاة" (عبر: .اعدادات صلاة تشغيل). يُستدعى مرة واحدة فقط طوال عمر العملية
 * (حماية داخلية عبر schedulerStarted) حتى لو تكرر الاتصال أكثر من مرة.
 */
export function startSalawatScheduler() {
  if (schedulerStarted) return;
  schedulerStarted = true;

  setInterval(async () => {
    if (!activeSock) return;
    const groups: Record<string, unknown> = db.get("groups").value() || {};

    for (const groupId of Object.keys(groups)) {
      try {
        const settings = getGroupSettings(groupId);
        // 🔧 إصلاح: تذكير الصلاة كان يستمر حتى بمجموعة موقوفة بـ .ايقاف
        if (settings.enabled === false) continue;
        if (!settings.salawat) continue;
        const text = SALAWAT_MESSAGES[Math.floor(Math.random() * SALAWAT_MESSAGES.length)];
        await sendWithSalawatFallback(activeSock, groupId, text);
      } catch (err) {
        logger.warn(`تعذر إرسال تذكير الصلاة على النبي ﷺ لمجموعة ${groupId}.`, err);
      }
    }
  }, 60 * 60 * 1000); // كل ساعة

  logger.info("🕌 تم تفعيل مؤقت تذكير الصلاة على النبي ﷺ (كل ساعة للمجموعات المفعّلة).");
}

const PRAYER_LABELS: { key: keyof PrayerTimes; label: string }[] = [
  { key: "fajr", label: "الفجر" },
  { key: "dhuhr", label: "الظهر" },
  { key: "asr", label: "العصر" },
  { key: "maghrib", label: "المغرب" },
  { key: "isha", label: "العشاء" },
];

let prayerSchedulerStarted = false;
// نمنع تكرار إرسال نفس الصلاة أكثر من مرة بنفس الدقيقة (Set تتصفر كل يوم جديد)
let lastSentKey: string | null = null;

/**
 * يبدأ مؤقت تذكير أوقات الصلاة (فجر/ظهر/عصر/مغرب/عشاء) بتوقيت مكة المكرمة،
 * لأي مجموعة مفعّل فيها إعداد "مواقيت" (عبر: .اعدادات مواقيت تشغيل).
 * بدون أي منشن جماعي للكل — رسالة عامة بس، كما طُلب صراحة.
 */
export function startPrayerTimesScheduler() {
  if (prayerSchedulerStarted) return;
  prayerSchedulerStarted = true;

  setInterval(async () => {
    if (!activeSock) return;

    const times = await getTodayMeccaPrayerTimes();
    if (!times) return;

    const nowHHMM = currentMeccaTimeHHMM();
    const match = PRAYER_LABELS.find((p) => times[p.key] === nowHHMM);
    if (!match) return;

    const dedupeKey = `${nowHHMM}-${match.key}`;
    if (lastSentKey === dedupeKey) return; // تم إرسالها بالفعل بهذي الدقيقة بالضبط
    lastSentKey = dedupeKey;

    const groups: Record<string, unknown> = db.get("groups").value() || {};
    const text =
      `🕌 حان الآن وقت صلاة *${match.label}* (بتوقيت مكة المكرمة)\n` +
      `لا تنسَ حق الله 🤍`;

    for (const groupId of Object.keys(groups)) {
      try {
        const settings = getGroupSettings(groupId);
        // 🔧 إصلاح: نفس مشكلة تذكير الصلاة أعلاه — يحترم .ايقاف الآن
        if (settings.enabled === false) continue;
        if (!settings.prayerTimes) continue;
        await activeSock.sendMessage(groupId, { text });
      } catch (err) {
        logger.warn(`تعذر إرسال تذكير صلاة ${match.label} لمجموعة ${groupId}.`, err);
      }
    }
  }, 30 * 1000); // كل نصف دقيقة (كفاية لالتقاط دقيقة الأذان بالضبط بدون تأخير محسوس)

  logger.info("🕌 تم تفعيل مؤقت تذكير مواقيت الصلاة (توقيت مكة المكرمة، للمجموعات المفعّلة).");
}

// ========================= 📦 نسخة احتياطية تلقائية كل 5 ساعات =========================
// يُرسل ملف db.json لمحادثة المطور الخاصة كل 5 ساعات من لحظة تشغيل البوت.
// نفس أسلوب باقي المجدولات تمامًا: singleton guard + setActiveSocket.

const DB_BACKUP_INTERVAL_MS = 5 * 60 * 60 * 1000; // 5 ساعات

let dbBackupStarted = false;

/**
 * يبدأ مجدول الإرسال التلقائي لنسخة احتياطية من قاعدة البيانات (db.json)
 * لمحادثة المطور الخاصة كل 5 ساعات. يُستدعى مرة واحدة فقط بعد كل اتصال
 * ناجح (نفس startSalawatScheduler / startPrayerTimesScheduler).
 */
export function startDbBackupScheduler() {
  if (dbBackupStarted) return;
  dbBackupStarted = true;

  setInterval(async () => {
    if (!activeSock) return;

    try {
      const dbPath = path.resolve(process.cwd(), "database", "db.json");
      if (!(await fs.pathExists(dbPath))) {
        logger.warn("📦 النسخة الاحتياطية التلقائية: ملف db.json غير موجود، تم التخطي.");
        return;
      }

      const buffer = await fs.readFile(dbPath);
      const fileName = `db-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.txt`;

      await activeSock.sendMessage(CONFIG.OWNER_JID, {
        document: buffer,
        mimetype: "text/plain",
        fileName,
        caption: `📦 *نسخة احتياطية تلقائية*\n🕐 ${new Date().toLocaleString("ar-SA")}\n📁 ${fileName}`,
      });

      logger.info(`📦 تم إرسال النسخة الاحتياطية التلقائية بنجاح: ${fileName}`);
    } catch (err) {
      logger.warn("📦 تعذر إرسال النسخة الاحتياطية التلقائية للمطور.", err);
    }
  }, DB_BACKUP_INTERVAL_MS);

  logger.info("📦 تم تفعيل مجدول النسخة الاحتياطية التلقائية (كل 5 ساعات للمطور).");
}
