/**
 * 🆕 لعبة "Speed Rival" (.race) — سباق سيارات بـ3 مسارات، بادل بين
 * المسارات عشان تتفادى العوائق. نفس أسلوب Dino/FPS: كل زر = خطوة،
 * نرسم مشهد جديد بعدها.
 */
import { WASocket } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { addPoint } from "../database/db";
import { CONFIG } from "../config/config";

const LANES = 3; // 0=يسار، 1=وسط، 2=يمين

interface Game {
  playerJid: string;
  lane: number;
  distance: number;
  obstacleLane: number;
  obstacleAhead: number; // 0 = بجنب السيارة بالضبط
  crashed: boolean;
}

const sessions = new Map<string, Game>();

function key(sock: WASocket, chatId: string, senderJid: string): string {
  return `${getBotScopeId(sock)}:${chatId}:${senderJid}`;
}

export function isRunning(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.has(key(sock, chatId, senderJid));
}

function newObstacle(): { lane: number; ahead: number } {
  return { lane: Math.floor(Math.random() * LANES), ahead: 4 };
}

function renderScene(game: Game): Promise<Buffer> {
  const laneWidth = 500 / LANES;
  const carY = 300;
  const carX = game.lane * laneWidth + laneWidth / 2;

  const obstacleY = 60 + (4 - game.obstacleAhead) * 55;
  const obstacleX = game.obstacleLane * laneWidth + laneWidth / 2;

  const laneLines = Array.from({ length: LANES - 1 }, (_, i) => {
    const x = (i + 1) * laneWidth;
    return `<line x1="${x}" y1="0" x2="${x}" y2="380" stroke="#f1c40f" stroke-width="3" stroke-dasharray="15,15"/>`;
  }).join("");

  const svg = `<svg width="500" height="380" xmlns="http://www.w3.org/2000/svg">
    <rect width="500" height="380" fill="#2c3e50"/>
    ${laneLines}
    ${game.obstacleAhead <= 4 && game.obstacleAhead >= 0 ? `<text x="${obstacleX}" y="${obstacleY}" font-size="48" text-anchor="middle">🚧</text>` : ""}
    <text x="${carX}" y="${carY}" font-size="55" text-anchor="middle">🏎️</text>
    <text x="20" y="30" font-size="22" font-family="monospace" fill="#ecf0f1" font-weight="bold">🏁 المسافة: ${game.distance}م</text>
  </svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendScene(sock: WASocket, chatId: string, game: Game, message: string): Promise<void> {
  const image = await renderScene(game);
  const rows = [
    { command: "race_left", label: "⬅️ يسار" },
    { command: "race_right", label: "➡️ يمين" },
    { command: "race_stay", label: "⏺️ استمر بنفس المسار" },
  ];
  await sendButtonMessage(sock, chatId, {
    text: `🏎️ *Speed Rival* — ${jidToMention(game.playerJid)}\n\n${message}`,
    mentions: [game.playerJid],
    image,
    extraButtons: [buildSingleSelectButton("🕹️ تحكّم", "اختر اتجاهك", rows)],
  });
}

export async function start(sock: WASocket, chatId: string, senderJid: string): Promise<void> {
  const k = key(sock, chatId, senderJid);
  const obstacle = newObstacle();
  const game: Game = {
    playerJid: senderJid,
    lane: 1,
    distance: 0,
    obstacleLane: obstacle.lane,
    obstacleAhead: obstacle.ahead,
    crashed: false,
  };
  sessions.set(k, game);
  await sendScene(sock, chatId, game, "🏁 بدأ السباق! بادل بين المسارات عشان تتفادى العوائق.");
}

async function gameOver(sock: WASocket, chatId: string, senderJid: string, game: Game): Promise<void> {
  sessions.delete(key(sock, chatId, senderJid));
  addPoint(chatId, senderJid, Math.max(1, Math.floor(game.distance / 20)));
  await sock.sendMessage(chatId, {
    text: `💥 *تصادمت!* انتهى السباق.\n🏁 المسافة النهائية: ${game.distance}م`,
  });
}

export async function handleMove(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId, senderJid);
  const game = sessions.get(k);
  if (!game) return false;

  const trimmed = text.trim();
  const withoutPrefix = trimmed.startsWith(CONFIG.PREFIX) ? trimmed.slice(CONFIG.PREFIX.length) : trimmed;

  let move: -1 | 0 | 1 | null = null;
  if (withoutPrefix === "race_left" || withoutPrefix === "يسار") move = -1;
  else if (withoutPrefix === "race_right" || withoutPrefix === "يمين") move = 1;
  else if (withoutPrefix === "race_stay" || withoutPrefix === "استمر") move = 0;
  else return false;

  game.lane = Math.min(LANES - 1, Math.max(0, game.lane + move));

  // نقرّب العائق خطوة
  game.obstacleAhead--;

  if (game.obstacleAhead === 0 && game.obstacleLane === game.lane) {
    await gameOver(sock, chatId, senderJid, game);
    return true;
  }

  if (game.obstacleAhead < 0) {
    // تجاوزنا العائق بأمان — عائق جديد
    game.distance += 20;
    const next = newObstacle();
    game.obstacleLane = next.lane;
    game.obstacleAhead = next.ahead;
    await sendScene(sock, chatId, game, "✅ تجاوزت العائق بسلام!");
    return true;
  }

  game.distance += 5;
  await sendScene(sock, chatId, game, game.obstacleAhead <= 1 ? "⚠️ عائق قريب! غيّر مسارك لو محتاج." : "🏎️ مستمر بالسباق...");
  return true;
}

export function end(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.delete(key(sock, chatId, senderJid));
}
