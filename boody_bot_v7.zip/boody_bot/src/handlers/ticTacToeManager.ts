import { WASocket } from "@whiskeysockets/baileys";
import { jidToMention, digitsOnly, toEnglishDigits, getBotScopeId } from "../utils/helpers";
import { renderTicTacToeImage } from "../utils/ticTacToeRenderer";
import { logger } from "../utils/logger";

interface XOGame {
  board: string[]; // 9 خانات: "1".."9" أو "❌"/"⭕"
  players: [string, string]; // [x, o]
  turn: 0 | 1;
}

const symbols = ["❌", "⭕"];

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

class TicTacToeManager {
  private games: Map<string, XOGame> = new Map();

  // 🔧 (عزل البوتات الفرعية) — مفتاح "botId:chatId" بدل "chatId" فقط،
  // بنفس فكرة eventManager بالضبط: راجع تعليقه للتفصيل الكامل.
  private key(sock: WASocket, chatId: string): string {
    return `${getBotScopeId(sock)}:${chatId}`;
  }

  isRunning(sock: WASocket, chatId: string) {
    return this.games.has(this.key(sock, chatId));
  }

  start(sock: WASocket, chatId: string, playerX: string, playerO: string) {
    this.games.set(this.key(sock, chatId), {
      board: Array.from({ length: 9 }, (_, i) => String(i + 1)),
      players: [playerX, playerO],
      turn: 0,
    });
  }

  renderBoard(board: string[]) {
    return [0, 3, 6]
      .map((r) => board.slice(r, r + 3).join(" | "))
      .join("\n---------\n");
  }

  /**
   * 🆕 يرسل لوحة اللعبة الحالية كصورة 2D واضحة (بدل النص القديم)، مع
   * رجوع تلقائي للنص لو فشل توليد الصورة لأي سبب — حتى لا تنكسر اللعبة.
   */
  private async sendBoard(
    sock: WASocket,
    chatId: string,
    board: string[],
    caption: string,
    mentions: string[]
  ) {
    try {
      const image = await renderTicTacToeImage(board);
      await sock.sendMessage(chatId, { image, caption, mentions });
    } catch (err) {
      logger.warn("⚠️ تعذر توليد صورة لوحة إكس_أو أثناء اللعب، تم الرجوع للنص.", err);
      await sock.sendMessage(chatId, {
        text: `${caption}\n\n${this.renderBoard(board)}`,
        mentions,
      });
    }
  }

  async handleMove(sock: WASocket, chatId: string, senderJid: string, text: string) {
    const key = this.key(sock, chatId);
    const game = this.games.get(key);
    if (!game) return false;

    // 🔧 إصلاح (سبب "لو جا دور صاحب البوت (رقم البوت نفسه) وكتب رقم
    // الخانة، ما يرد إطلاقًا"): كنا نقارن senderJid بـ currentPlayer
    // بمطابقة نصية حرفية (===). لكن senderJid لرسائل "fromMe" (لما
    // صاحب رقم البوت نفسه يكتب) يُبنى من sock.user.id، وقد يوصل بصيغة
    // مختلفة شكليًا (لاحقة جهاز :xx، أو @lid بدل @s.whatsapp.net، أو
    // العكس) عن الصيغة اللي انخزن فيها هذا اللاعب أصلًا بمصفوفة
    // players وقت بدء اللعبة (عبر getTargetJid/ctx.senderJid) — حتى لو
    // الرقم الحقيقي نفسه بالضبط. أي فرق شكلي بسيط يفشّل المقارنة
    // الحرفية بالكامل فيبدو "البوت ما يرد". الحل: نقارن بالأرقام فقط
    // (digitsOnly) بدل المطابقة الحرفية، بنفس الأسلوب المستخدم بكل
    // فحوصات الصلاحية بالمشروع (isOwner/isGroupAdmin/resolveGroupJid).
    const senderDigits = digitsOnly(senderJid);
    const isPlayer = game.players.some((p) => digitsOnly(p) === senderDigits);
    if (!isPlayer) return false; // مو أحد لاعبي هذي اللعبة، تجاهل بصمت (قد تكون رسالة عادية)

    // 🔧 إصلاح إضافي: نحوّل أي أرقام هندية عربية (١٢٣) لأرقام إنجليزية
    // قبل التحقق، حتى لا يفشل التعرف على رقم الخانة لو المستخدم كتبه
    // بلوحة مفاتيح عربية.
    const cell = Number(toEnglishDigits(text.trim()));
    if (!Number.isInteger(cell) || cell < 1 || cell > 9) return false;

    const currentPlayer = game.players[game.turn];
    if (digitsOnly(currentPlayer) !== senderDigits) {
      // 🆕 قبل كذا كنا نتجاهل بصمت — يبدو تمامًا كأن "البوت ما يرد".
      // الحين نوضح للاعب إنه مو دوره حاليًا بدل الصمت.
      await sock.sendMessage(chatId, {
        text: `⏳ ${jidToMention(senderJid)} مو دورك الحين، انتظر دور خصمك 🙂`,
        mentions: [senderJid],
      });
      return true;
    }
    if (!/^[1-9]$/.test(game.board[cell - 1])) {
      await sock.sendMessage(chatId, {
        text: "⚠️ هذي الخانة محجوزة، اختر رقم خانة فاضية.",
      });
      return true;
    }

    game.board[cell - 1] = symbols[game.turn];

    const winner = this.checkWinner(game.board);
    if (winner) {
      await this.sendBoard(
        sock,
        chatId,
        game.board,
        `🏆 مبروك ${jidToMention(currentPlayer)} فزت باللعبة!`,
        [currentPlayer]
      );
      this.games.delete(key);
      return true;
    }

    if (!game.board.some((c) => /^[1-9]$/.test(c))) {
      await this.sendBoard(sock, chatId, game.board, "🤝 تعادل! انتهت اللعبة.", []);
      this.games.delete(key);
      return true;
    }

    game.turn = game.turn === 0 ? 1 : 0;
    const nextPlayer = game.players[game.turn];
    await this.sendBoard(
      sock,
      chatId,
      game.board,
      `🎯 دور ${jidToMention(nextPlayer)} (${symbols[game.turn]})`,
      [nextPlayer]
    );
    return true;
  }

  private checkWinner(board: string[]): boolean {
    return WIN_LINES.some(
      ([a, b, c]) => board[a] === board[b] && board[b] === board[c] && (board[a] === "❌" || board[a] === "⭕")
    );
  }

  stop(sock: WASocket, chatId: string) {
    return this.games.delete(this.key(sock, chatId));
  }
}

export const ticTacToeManager = new TicTacToeManager();
