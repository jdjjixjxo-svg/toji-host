/**
 * 🆕 لعبة "من الأسرع" (.من_الاسرع) — البوت يقول "استعدوا"، وبعد تأخير
 * عشوائي يرسل إشارة البدء. أول شخص يكتب أي شي بعد الإشارة يفوز. لو
 * حد كتب قبل الإشارة، يخسر فورًا (نفس روح ألعاب رد الفعل الحقيقية).
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { addPoint } from "../database/db";

interface Game {
  started: boolean; // هل صدرت إشارة "الآن" فعلًا؟
  startedAt: number;
  timer: NodeJS.Timeout;
}

const games = new Map<string, Game>();

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

export async function start(sock: WASocket, chatId: string): Promise<void> {
  const k = key(sock, chatId);
  if (games.has(k)) {
    await sock.sendMessage(chatId, { text: "🔁 فيه جولة جارية بالفعل!" });
    return;
  }

  // 🔧 نسجّل الجولة فورًا (قبل أي await) لمنع نافذة زمنية صغيرة يقدر
  // فيها حد يبدأ جولة ثانية بنفس اللحظة قبل ما نسجّل هذي.
  const game: Game = { started: false, startedAt: 0, timer: setTimeout(() => {}, 0) };
  games.set(k, game);

  await sock.sendMessage(chatId, { text: "⚡ *استعدوا...* لا تكتبوا شي لسه!" });

  const delay = 2000 + Math.random() * 4000; // 2-6 ثواني عشوائي
  game.timer = setTimeout(async () => {
    if (!games.has(k)) return;
    game.started = true;
    game.startedAt = Date.now();
    await sock.sendMessage(chatId, { text: "🟢 *الآن!* أول شخص يكتب يفوز!" });
    // مهلة أمان 15 ثانية لو محد كتب
    setTimeout(() => {
      if (games.has(k)) {
        games.delete(k);
        sock.sendMessage(chatId, { text: "⌛ ما رد حد. انتهت الجولة." }).catch(() => {});
      }
    }, 15_000);
  }, delay);
}

export async function handleMessage(sock: WASocket, chatId: string, senderJid: string): Promise<boolean> {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;

  if (!game.started) {
    // كتب قبل الإشارة — يخسر فورًا
    clearTimeout(game.timer);
    games.delete(k);
    await sock.sendMessage(chatId, {
      text: `🚫 ${jidToMention(senderJid)} كتب بدري! خسر الجولة 😂`,
      mentions: [senderJid],
    });
    return true;
  }

  const ms = Date.now() - game.startedAt;
  games.delete(k);
  addPoint(chatId, senderJid, 1);
  await sock.sendMessage(chatId, {
    text: `⚡ *${jidToMention(senderJid)} كان الأسرع!* (${ms} مللي ثانية) +1 نقطة`,
    mentions: [senderJid],
  });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;
  clearTimeout(game.timer);
  games.delete(k);
  return true;
}
