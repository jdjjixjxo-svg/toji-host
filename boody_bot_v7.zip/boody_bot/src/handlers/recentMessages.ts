import { WAMessage, WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId } from "../utils/helpers";

/**
 * 🆕 (أمر .محي <رقم>) — واتساب/Baileys ما فيه طريقة تطلب فيها "احذف آخر
 * N رسالة" جاهزة؛ الحذف يحتاج مفتاح كل رسالة (id + participant + fromMe)
 * بالتحديد، والبوت ما يقدر يكتشف مفاتيح رسائل ما شافها بنفسه. فنسجّل هنا
 * مفتاح كل رسالة توصل (نص أو وسائط أو ملصق، أي نوع) بذاكرة مؤقتة —
 * سعة محدودة لكل مجموعة، تُنسى تلقائيًا (الأقدم يطيح أول).
 *
 * 🔧 (عزل البوتات الفرعية) — نفس فكرة كل مدراء الحالة بالمحادثة: المفتاح
 * "botId:chatId"، لأن كل بوت (رئيسي/فرعي) يشوف نفس الرسائل الحقيقية عبر
 * اتصاله المستقل هو، فيسجّلها بذاكرته هو فقط — حذف عبر بوت معيّن يعمل
 * على الرسائل اللي هو نفسه شافها، بدون أي تعارض بين البوتات.
 */
const MAX_PER_GROUP = 300;

interface RecordedKey {
  id: string;
  participant?: string;
  fromMe: boolean;
}

const buffers = new Map<string, RecordedKey[]>();

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

/** يُستدعى من messageHandler.ts لكل رسالة جماعية توصل (أي نوع). */
export function recordMessageKey(sock: WASocket, chatId: string, msg: WAMessage) {
  const id = msg.key.id;
  if (!id) return;
  const list = buffers.get(key(sock, chatId)) || [];
  list.push({ id, participant: msg.key.participant || undefined, fromMe: !!msg.key.fromMe });
  if (list.length > MAX_PER_GROUP) list.splice(0, list.length - MAX_PER_GROUP);
  buffers.set(key(sock, chatId), list);
}

/** يرجع آخر N مفتاح مسجّل بهذي المجموعة لهذا البوت بالذات (الأحدث أخيرًا)، وينسّاها فورًا. */
export function takeRecentMessageKeys(sock: WASocket, chatId: string, count: number): RecordedKey[] {
  const k = key(sock, chatId);
  const list = buffers.get(k) || [];
  const taken = list.slice(-count);
  buffers.set(k, list.slice(0, Math.max(0, list.length - count)));
  return taken;
}
