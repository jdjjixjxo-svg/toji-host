import path from "path";
import fs from "fs-extra";
import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  Browsers,
  WAMessage,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import { CONFIG } from "../config/config";
import { logger } from "../utils/logger";
import { getWaVersion, numberToJid, digitsOnly } from "../utils/helpers";
import { exportSessionToBase64 } from "../config/session";
import { handleIncomingMessage } from "./messageHandler";
import { getGroupCache } from "../utils/groupCache";
import { registerGroupParticipantsEvent } from "../events/groupParticipants";
import { registerJoinRequestAutoApprove } from "../events/joinRequests";
import { applyNewsletterBranding, resolveChannelJidFromLink } from "../utils/interactive";

/**
 * ============================================================================
 * 🕸 مدير "البوتات الفرعية" (ميزة .تنصيب)
 * ============================================================================
 * كل رقم يربط نفسه عبر ".تنصيب" يحصل على مقبس Baileys مستقل خاص فيه، بجلسة
 * (session) منفصلة تمامًا عن جلسة البوت الرئيسي وعن أي بوت فرعي آخر — كل
 * واحد بمجلده الخاص تحت subbots-sessions/<رقمه>/.
 *
 * ⚠️ نقطة أمان مهمة جدًا: هذا الملف *لا* يستدعي أبدًا setBotSelfNumber()
 * ولا setOwnerLid() (المستوردتان فقط داخل index.ts للبوت الرئيسي). هاتان
 * الدالتان تُحدّثان متغيّرًا عامًا واحدًا مشتركًا تعتمد عليه isOwner() لتحديد
 * "صاحب الصلاحيات الكاملة" — لو ناديناهما هنا لأي بوت فرعي، كان بيصير كل
 * رقم يربط بوت فرعي يكتسب صلاحيات "مطور" على *كل* أرقام البوتات الأخرى
 * (بما فيها البوت الرئيسي!) بمجرد إنه أصبح "رقم البوت الحالي" بنظر isOwner().
 * لذلك نتعمّد تجاهلهما كليًا هنا، ونعتمد فقط على القيد الصريح المضاف في
 * handleIncomingMessage (options.subBot) لمنع أي أمر فئة "المطور" أو صلاحية
 * "owner" على أي بوت فرعي، بغض النظر عمّن يرسله.
 * ============================================================================
 */

const SUBBOTS_ROOT = path.resolve(process.cwd(), "subbots-sessions");
fs.ensureDirSync(SUBBOTS_ROOT);

/**
 * 🆕 (طلب صريح: "هذي الأرقام هي أرقام عامله تنصيب للبوت فلازم يعتبرها
 * مطور") — يرجع كل أرقام البوتات الفرعية المنصّبة حاليًا (حتى الموقوفة
 * مؤقتًا لو ما انحذف مجلدها)، بقراءة أسماء مجلدات SUBBOTS_ROOT مباشرة
 * (كل مجلد اسمه رقم الهاتف). تُستخدم بـdeveloperIdentity.ts لاعتبار أي
 * رقم نصّب بوت فرعي "مطورًا" بكل مكان بالمشروع — مو بس على بوته هو —
 * بخلاف الوضع الافتراضي القديم (معزول لكل بوت لحاله، راجع تعليق isOwner).
 */
export function getInstalledSubBotNumbers(): string[] {
  try {
    return fs.readdirSync(SUBBOTS_ROOT).filter((name) => /^\d+$/.test(name));
  } catch {
    return [];
  }
}

interface ActiveSubBot {
  sock: ReturnType<typeof makeWASocket>;
  phone: string;
}

/** كل البوتات الفرعية المتصلة فعليًا حاليًا بهذي العملية، مفتاحها رقم الهاتف (أرقام فقط) */
const activeSubBots = new Map<string, ActiveSubBot>();
/** جلسات بانتظار إدخال الكود حاليًا (طلب صدر، ما زال ينتظر نجاح/فشل الربط) */
const pendingPairing = new Set<string>();
/** آخر مرة طلب فيها كل رقم كود — لمنع تكرار الطلب بسرعة (يقلّل خطر حظر الرقم) */
const lastRequestAt = new Map<string, number>();

const COOLDOWN_MS = 3 * 60 * 1000; // 3 دقائق بين كل طلب كود وآخر لنفس الرقم
const RECONNECT_ATTEMPTS_LIMIT = 5;

export function isInstallCooldownActive(phone: string): number {
  const last = lastRequestAt.get(phone);
  if (!last) return 0;
  const remaining = COOLDOWN_MS - (Date.now() - last);
  return remaining > 0 ? remaining : 0;
}

/**
 * 🆕 (.الغاء_تنصيب) يوقف البوت الفرعي لرقم معيّن ويحذف جلسته نهائيًا.
 * يرجع true لو كان فيه بوت/جلسة فعلًا.
 */
export async function uninstallSubBot(phone: string): Promise<boolean> {
  const bot = activeSubBots.get(phone);
  const dir = path.join(SUBBOTS_ROOT, phone);
  const existed = !!bot || fs.existsSync(dir) || pendingPairing.has(phone);
  if (bot) {
    try {
      await bot.sock.logout();
    } catch {
      try { bot.sock.end(undefined); } catch { /* تجاهل */ }
    }
    activeSubBots.delete(phone);
  }
  pendingPairing.delete(phone);
  await fs.remove(dir).catch(() => undefined);
  return existed;
}

export function isPendingOrActive(phone: string): "pending" | "active" | null {
  if (pendingPairing.has(phone)) return "pending";
  if (activeSubBots.has(phone)) return "active";
  return null;
}

/** يقسم الكود لمجموعتين بفاصلة (مثال: ABCD1234 → ABCD-1234) لسهولة القراءة، لو ما كان مقسّمًا أصلًا */
function formatCode(code: string): string {
  const clean = code.replace(/-/g, "");
  if (clean.length === 8) return `${clean.slice(0, 4)}-${clean.slice(4)}`;
  return code;
}

interface RequestResult {
  code: string;
}

/**
 * يطلب كود اقتران جديد لرقم معيّن. يرمي خطأ برسالة عربية واضحة لو كان
 * الرقم بحالة تمنع الطلب (تبريد/جلسة قائمة أصلًا/بوت فرعي شغّال أصلًا).
 */
export async function requestInstallCode(rawPhone: string): Promise<RequestResult> {
  const phone = digitsOnly(rawPhone);
  if (!phone) throw new Error("تعذّر التعرف على رقم هاتف صالح.");

  if (activeSubBots.has(phone)) {
    throw new Error("ALREADY_ACTIVE");
  }
  if (pendingPairing.has(phone)) {
    throw new Error("ALREADY_PENDING");
  }
  const cooldown = isInstallCooldownActive(phone);
  if (cooldown > 0) {
    throw new Error(`COOLDOWN:${Math.ceil(cooldown / 1000)}`);
  }

  const sessionDir = path.join(SUBBOTS_ROOT, phone);
  await fs.ensureDir(sessionDir);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  if (state.creds.registered) {
    // جلسة سابقة مسجّلة فعلًا لهذا الرقم — بدل ما نطلب كود جديد (Baileys
    // يرفضه أصلًا)، نحاول نعيد وصلها مباشرة بدون كود.
    await startSubBotSocket(phone, sessionDir, false);
    throw new Error("ALREADY_ACTIVE");
  }

  pendingPairing.add(phone);
  lastRequestAt.set(phone, Date.now());

  try {
    const version = await getWaVersion();
    const sock = makeWASocket({
      version,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }) as any),
      },
      logger: pino({ level: "silent" }) as any,
      cachedGroupMetadata: async (jid: string) => getGroupCache(jid, 10 * 60_000),
      shouldSyncHistoryMessage: () => false,
      syncFullHistory: false,
      keepAliveIntervalMs: 25_000,
      printQRInTerminal: false,
      browser: Browsers.ubuntu("Chrome"),
      generateHighQualityLinkPreview: false,
    });

    // 🆕 نفس تاغ "معاد توجيهها" المفعّل على البوت الرئيسي، الآن على كل
    // بوت فرعي أيضًا (راجع applyNewsletterBranding بـ utils/interactive.ts).
    applyNewsletterBranding(sock);

    sock.ev.on("creds.update", saveCreds);

    // 🔧 إصلاح جذري لسبب "الكود يظهر لكن الربط يفشل عند إدخاله":
    // كان الكود يُطلب فورًا بعد إنشاء المقبس مباشرة (sock.requestPairingCode)
    // دون انتظار اكتمال المصافحة الأولى (handshake) مع سيرفرات واتساب. عمليًا
    // Baileys يحتاج أولًا يفتح الاتصال (ws open) ثم يرسل عقدة التسجيل
    // (registration node) ثم ينتظر سيرفر واتساب يرد بطلب "pair-device" (وهو
    // نفس الحدث اللي يصدر منه qr بالتدفق العادي) — وهذا يأخذ جولة شبكة
    // كاملة (round-trip)، مش لحظي. طلب الكود قبل اكتمال هذي الخطوة إما يفشل
    // فورًا بخطأ "Connection Closed" (لو المقبس لسا ما فتح)، أو ينجح بالصدفة
    // بتوقيت غير مضمون لكن الجلسة على سيرفر واتساب ما تكون جاهزة فعليًا
    // لإتمام الاقتران — فيظهر الكود للمستخدم لكن إدخاله بالهاتف يفشل. هذا هو
    // نفس النمط الموثّق رسميًا بمكتبة Baileys (مثال "Pairing Code Flow" بالتوثيق
    // الرسمي: ينتظرون حدث "qr" بـconnection.update *قبل* طلب requestPairingCode).
    // الحل: ننتظر أول connection.update يحمل qr فعليًا (دليل إن السيرفر رد
    // وجاهز) قبل ما نطلب الكود.
    await waitForPairReadyState(sock);

    const code = await sock.requestPairingCode(phone);

    wireSubBotEvents(sock, phone, sessionDir, saveCreds);

    return { code: formatCode(code) };
  } catch (err) {
    pendingPairing.delete(phone);
    throw err;
  }
}

const PAIR_READY_TIMEOUT_MS = 20_000;

/**
 * ينتظر أول connection.update يحمل "qr" فعليًا (أو إغلاق الاتصال) — هذا
 * الحدث لا يصدر إلا بعد رد سيرفر واتساب فعليًا على عقدة التسجيل الأولى
 * (pair-device)، أي ضمان حقيقي إن الاتصال جاهز فعليًا لطلب كود اقتران
 * سيُكمل الربط بنجاح، بدل استدعاء requestPairingCode فورًا بتوقيت عشوائي.
 * راجع الشرح الكامل بموقع الاستدعاء بالأعلى.
 */
function waitForPairReadyState(sock: ReturnType<typeof makeWASocket>): Promise<void> {
  return new Promise((resolve, reject) => {
    let settled = false;

    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      sock.ev.off("connection.update", onUpdate);
      reject(new Error("انتهت مهلة انتظار جاهزية الاتصال قبل طلب كود التنصيب."));
    }, PAIR_READY_TIMEOUT_MS);

    const onUpdate = (update: { qr?: string; connection?: string; lastDisconnect?: { error?: Error } }) => {
      if (settled) return;
      if (update.qr) {
        settled = true;
        clearTimeout(timeout);
        sock.ev.off("connection.update", onUpdate);
        resolve();
      } else if (update.connection === "close") {
        settled = true;
        clearTimeout(timeout);
        sock.ev.off("connection.update", onUpdate);
        reject(update.lastDisconnect?.error || new Error("أُغلق الاتصال قبل جاهزيته لطلب كود التنصيب."));
      }
    };

    sock.ev.on("connection.update", onUpdate);
  });
}

/** يعيد إنشاء مقبس لجلسة مسجّلة أصلًا (بدون طلب كود) — يُستخدم عند إعادة الربط أو الإقلاع */
async function startSubBotSocket(
  phone: string,
  sessionDir: string,
  isReconnect: boolean
): Promise<void> {
  if (activeSubBots.has(phone)) return;
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const version = await getWaVersion();
  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }) as any),
    },
    logger: pino({ level: "silent" }) as any,
    printQRInTerminal: false,
    browser: Browsers.ubuntu("Chrome"),
    generateHighQualityLinkPreview: false,
  });
  applyNewsletterBranding(sock);
  sock.ev.on("creds.update", saveCreds);
  wireSubBotEvents(sock, phone, sessionDir, saveCreds, isReconnect);
}

function wireSubBotEvents(
  sock: ReturnType<typeof makeWASocket>,
  phone: string,
  sessionDir: string,
  saveCreds: () => Promise<void>,
  isReconnect = false
) {
  let reconnectAttempts = 0;

  // 🔧 إصلاح جذري (سبب "رسائل الترحيب لا تعمل ببعض البوتات"): كان
  // registerGroupParticipantsEvent() يُستدعى فقط بـ index.ts على مقبس
  // البوت الرئيسي — أي بوت فرعي (مقبسه منفصل تمامًا، راجع تعليق أعلى
  // الملف) ما كان يسجّل هذا الحدث إطلاقًا، فيبقى صامتًا تمامًا عند أي
  // انضمام/مغادرة/ترقية عضو (ترحيب/وداع/تعليق ترقية) رغم أن نفس هذا
  // البوت الفرعي يستجيب للأوامر العادية بشكل طبيعي تمامًا (لأن تلك تمر
  // بـhandleIncomingMessage المستدعاة يدويًا بالأسفل بـmessages.upsert،
  // وهذا حدث مختلف كليًا لا علاقة له بذاك المسار). الحل: نسجّله هنا أيضًا
  // مرة واحدة لكل مقبس بوت فرعي جديد — بنفس دالة البوت الرئيسي بالضبط
  // (لا تكرار منطق)، مع تمرير subBot: true لاحترام .تعطيل_بوت.
  registerGroupParticipantsEvent(sock, { subBot: true });
  registerJoinRequestAutoApprove(sock);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      pendingPairing.delete(phone);
      reconnectAttempts = 0;
      activeSubBots.set(phone, { sock, phone });
      logger.success(`🕸 بوت فرعي مرتبط الآن (تنصيب): ${phone}`);

      // 🆕 نفس اكتشاف CHANNEL_JID التلقائي المستخدم بالبوت الرئيسي —
      // القيمة تُخزَّن مشتركة (module-level) فأول بوت يتصل (رئيسي أو
      // فرعي) يحلّها للجميع، وباقي المقابس لا تعيد المحاولة.
      resolveChannelJidFromLink(sock).catch(() => {});

      if (!isReconnect) {
        await notifyOwnerOfNewInstall(sock, phone, sessionDir).catch((err) =>
          logger.warn("⚠️ تعذر إرسال رسائل تفعيل البوت الفرعي على الخاص.", err)
        );
      }
    } else if (connection === "close") {
      activeSubBots.delete(phone);
      const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;

      if (statusCode === DisconnectReason.loggedOut) {
        pendingPairing.delete(phone);
        logger.warn(`🕸 تم تسجيل خروج بوت فرعي (${phone}) — حذف جلسته.`);
        await fs.remove(sessionDir).catch(() => undefined);
        return;
      }

      // 🔧 إصلاح (سبب إضافي محتمل لفشل الربط رغم ظهور الكود): كانت هذي
      // الحالة "تعيد المحاولة" تلقائيًا بمجرد إغلاق الاتصال أثناء انتظار
      // إدخال الكود، عبر startSubBotSocket() — لكن تلك الدالة تقرأ الجلسة
      // من القرص وتفتح مقبسًا عاديًا (تسجيل دخول)، لا تطلب كودًا جديدًا.
      // المشكلة: requestPairingCode() أعلاه يضبط creds.me *فورًا* عند طلب
      // الكود (قبل ما يكتمل الاقتران فعليًا على سيرفر واتساب) ويُخزَّن على
      // القرص عبر creds.update. فلو انقطع الاتصال قبل ما يدخل المستخدم
      // الكود، وأعدنا الاتصال بنفس هذي الجلسة، Baileys يرى creds.me موجود
      // ويرسل عقدة "تسجيل دخول" (login) بدل عقدة "تسجيل/اقتران" — وسيرفر
      // واتساب يرفضها لأن الجهاز لم يُربط فعليًا بعد. النتيجة: المستخدم يشوف
      // كود ظاهر أمامه لكن أي محاولة لإدخاله تفشل ("تعذر الربط") لأن الاتصال
      // اللي كان بانتظاره تحوّل بصمت لمحاولة تسجيل دخول فاشلة بدل انتظار الكود.
      // الحل الآمن: ما نعيد الاتصال إطلاقًا بهذي الحالة — نعتبر محاولة
      // الاقتران هذي منتهية ونحذف الجلسة الملوّثة (creds.me/pairingCode)
      // حتى ما تُفسد أي محاولة تالية، ونترك المستخدم يطلب كودًا جديدًا
      // (بعد التبريد الطبيعي 3 دقائق) بدل محاولة إنعاش جلسة غير قابلة للإنعاش.
      if (pendingPairing.has(phone)) {
        // 🔧 إصلاح (السبب الحقيقي لـ"الجهاز يظهر مربوطًا لكن البوت لا يكمل"):
        // بعد أن يُدخل المستخدم الكود بنجاح على هاتفه، سيرفر واتساب *يقفل*
        // هذا الاتصال عمدًا برمز DisconnectReason.restartRequired (515) —
        // هذه ليست حالة فشل، بل إشارة قياسية موثّقة رسميًا بمكتبة Baileys
        // تعني "التسجيل تم واعتُمد على الخادم، أعد فتح الاتصال بنفس بيانات
        // الجلسة (creds) المحفوظة لإكمال المصافحة والحصول على connection=open".
        // creds.update يكون بهذه اللحظة قد حفظ registered:true فعلًا على
        // القرص. كان الكود القديم يعامل *أي* إغلاق هنا كفشل نهائي ويحذف هذي
        // الجلسة المسجَّلة حديثًا فورًا — فتُفقد قبل أن تُستكمل، ويبقى الـ
        // sub-bot متوقفًا، وتنتهي المهلة من جهة واتساب فتظهر "تعذر الربط"
        // رغم أن الجهاز أُدرج مؤقتًا في الأجهزة المرتبطة.
        // الحل: لو كان سبب الإغلاق هو restartRequired تحديدًا، لا نحذف شيئًا
        // ولا نعتبر المحاولة منتهية — بل نعيد فتح مقبس جديد بنفس sessionDir
        // فورًا (بدون طلب كود جديد)، ونُبقي phone ضمن pendingPairing إلى أن
        // يصل connection === "open" فعليًا (وهو من يحذفه ويشغّل إشعار التفعيل).
        if (statusCode === DisconnectReason.restartRequired) {
          logger.info(
            `🕸 بوت فرعي (${phone}): تم قبول كود التنصيب، إعادة فتح الاتصال لإكمال المصافحة (restartRequired)…`
          );
          startSubBotSocket(phone, sessionDir, false).catch((err) => {
            pendingPairing.delete(phone);
            logger.error(`فشل إكمال اتصال بوت فرعي بعد قبول الكود (${phone}):`, err);
          });
          return;
        }

        pendingPairing.delete(phone);
        logger.warn(
          `🕸 انقطع اتصال بوت فرعي (${phone}) أثناء انتظار إدخال كود التنصيب — يُعتبر الكود منتهي الصلاحية، يلزم طلب كود جديد.`
        );
        await fs.remove(sessionDir).catch(() => undefined);
        return;
      }

      if (reconnectAttempts >= RECONNECT_ATTEMPTS_LIMIT) {
        pendingPairing.delete(phone);
        logger.error(`🕸 توقف بوت فرعي (${phone}) نهائيًا بعد ${RECONNECT_ATTEMPTS_LIMIT} محاولات إعادة اتصال فاشلة.`);
        return;
      }

      reconnectAttempts++;
      const delay = Math.min(2000 * reconnectAttempts, 30_000);
      setTimeout(() => {
        startSubBotSocket(phone, sessionDir, true).catch((err) =>
          logger.error(`فشل إعادة اتصال بوت فرعي (${phone}):`, err)
        );
      }, delay);
    }
  });

  sock.ev.on("messages.upsert", ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      handleIncomingMessage(sock, msg as WAMessage, { subBot: true }).catch((err) => {
        logger.error(`خطأ أثناء معالجة رسالة ببوت فرعي (${phone}):`, err);
      });
    }
  });
}

/** يرسل على الخاص (شات "راسل نفسك") نسخة احتياطية من الجلسة + رسالة تأكيد التفعيل */
async function notifyOwnerOfNewInstall(
  sock: ReturnType<typeof makeWASocket>,
  phone: string,
  sessionDir: string
): Promise<void> {
  const selfJid = numberToJid(phone);

  await sock.sendMessage(selfJid, {
    text:
      `✅ *تم تشغيل ${CONFIG.BOT_NAME} بنجاح على رقمك!*\n\n` +
      `رقمك الآن جهاز مرتبط ويعمل عليه نسخة كاملة من البوت بكل أوامره\n` +
      `(ما عدا أوامر المطور الخاصة بالبوت الأساسي).\n\n` +
      `🔐 *ليش تبقى بيانات الدخول محفوظة؟*\n` +
      `حفظنا حالة هذا الربط محليًا وبأمان، فما تحتاج تعيد كتابة كود اقتران من جديد كل مرة يعاد فيها تشغيل البوت أو ينقطع الاتصال مؤقتًا — يرجع يتصل تلقائيًا بنفس الجلسة.\n\n` +
      `⚠️ لا تشارك أي كود اقتران أو رسالة "جلسة" توصلك على هذا الشات مع *أي شخص* — من يحصل عليها يتحكم بحساب واتساب هذا بالكامل.`,
  });

  try {
    const backup = await exportSessionToBase64(sessionDir);
    await sock.sendMessage(selfJid, {
      text:
        `🔐 *نسخة احتياطية من جلستك (SESSION):*\n\n` +
        `${backup}\n\n` +
        `⚠️ هذه القيمة تعطي تحكمًا كاملًا بحساب واتساب هذا — احتفظ فيها لنفسك ولا ترسلها لأي أحد.`,
    });
  } catch (err) {
    logger.warn(`تعذر إرسال نسخة احتياطية من جلسة البوت الفرعي (${phone}) على الخاص.`, err);
  }
}

/** يعيد ربط كل الجلسات المسجّلة سابقًا (من تشغيل سابق) عند إقلاع العملية */
export async function bootAllSubBots(): Promise<void> {
  let entries: string[] = [];
  try {
    entries = await fs.readdir(SUBBOTS_ROOT);
  } catch {
    return;
  }
  for (const phone of entries) {
    const sessionDir = path.join(SUBBOTS_ROOT, phone);
    try {
      const credsPath = path.join(sessionDir, "creds.json");
      if (!(await fs.pathExists(credsPath))) continue;
      await startSubBotSocket(phone, sessionDir, true);
    } catch (err) {
      logger.warn(`تعذر إعادة ربط بوت فرعي محفوظ سابقًا (${phone}) عند الإقلاع.`, err);
    }
  }
}
