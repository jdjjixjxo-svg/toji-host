/**
 * ============================================================================
 * 🆕 لعبة "قلوب" — كل لاعب يبدأ بـ5 قلوب، صاحب اللعبة يقلل قلوب اللاعبين،
 * آخر لاعب معه قلوب يفوز.
 * ============================================================================
 * 🔧 إصلاح جوهري: الأصل كان يخزّن حالة اللعبة بمتغيّر عام واحد (module-level)
 * بدون أي ربط بالمحادثة — يعني لعبة واحدة بس ممكن تشتغل بكل البوت كله
 * بكل مجموعاته بنفس الوقت! أي كروب ثاني يكتب .قلوب كان يتعارض مع أي
 * لعبة جارية بكروب مختلف كليًا. الحين كل كروب له لعبته الخاصة (Map
 * بمفتاح chatId، ومعزولة بين البوتات الفرعية زي بقية مدراء الألعاب).
 * ============================================================================
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, digitsOnly } from "../utils/helpers";
import { addPoint } from "../database/db";

const HEART_ICONS = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎"];
const START_HEARTS = 5;

interface HeartsGame {
  starterJid: string;
  players: Record<string, { hearts: number; icon: string }>; // مفتاح: jid كامل
}

const games = new Map<string, HeartsGame>();

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

export function start(sock: WASocket, chatId: string, starterJid: string): boolean {
  const k = key(sock, chatId);
  if (games.has(k)) return false;
  games.set(k, { starterJid, players: {} });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  return games.delete(key(sock, chatId));
}

export function join(sock: WASocket, chatId: string, jid: string): { ok: boolean; already: boolean; icon?: string } {
  const game = games.get(key(sock, chatId));
  if (!game) return { ok: false, already: false };
  if (game.players[jid]) return { ok: true, already: true };
  const icon = HEART_ICONS[Object.keys(game.players).length % HEART_ICONS.length];
  game.players[jid] = { hearts: START_HEARTS, icon };
  return { ok: true, already: false, icon };
}

/** ينقص قلب من اللاعب. يرجع null لو ما فيه لعبة، أو اللاعب مو مشارك أصلًا. */
export function decrease(
  sock: WASocket,
  chatId: string,
  requesterJid: string,
  targetJid: string
): { allowed: boolean; eliminated?: boolean; heartsLeft?: number; icon?: string; winner?: string } | null {
  const game = games.get(key(sock, chatId));
  if (!game) return null;

  if (digitsOnly(requesterJid) !== digitsOnly(game.starterJid)) {
    return { allowed: false };
  }

  const playerEntry = Object.entries(game.players).find(([jid]) => digitsOnly(jid) === digitsOnly(targetJid));
  if (!playerEntry) return { allowed: true, eliminated: undefined };

  const [jid, player] = playerEntry;
  player.hearts--;

  if (player.hearts <= 0) {
    delete game.players[jid];
    const remaining = Object.keys(game.players);
    if (remaining.length === 1) {
      const winner = remaining[0];
      addPoint(chatId, winner, 1);
      games.delete(key(sock, chatId));
      return { allowed: true, eliminated: true, winner };
    }
    return { allowed: true, eliminated: true };
  }

  return { allowed: true, eliminated: false, heartsLeft: player.hearts, icon: player.icon };
}

export function getResults(sock: WASocket, chatId: string): { alive: string[]; eliminatedCount: number } | null {
  const game = games.get(key(sock, chatId));
  if (!game) return null;
  const alive = Object.entries(game.players)
    .filter(([, p]) => p.hearts > 0)
    .map(([jid, p]) => `${jid} - قلوب: ${p.icon.repeat(p.hearts)}`);
  return { alive, eliminatedCount: 0 };
}
