/**
 * 🆕 مدير لعبة الثعبان (Snake) — أول لعبة بقسم "ألعاب 2D" الجديد.
 *
 * ملاحظة تصميم مهمة: بعد المشكلة اللي واجهناها بالتحميل الصوتي (ffmpeg
 * ما يتحمّل صح على استضافات مقيّدة مثل Katabump لأنه يحتاج تحميل ملف
 * تنفيذي native وقت التثبيت)، تعمدنا هنا نتجنب أي مكتبة رسم صور
 * (canvas/napi-rs/sharp إضافي) تحتاج بناء native. اللعبة بالكامل نصية:
 * الشبكة ثنائية الأبعاد (2D) تُرسم بإيموجي كنص عادي — يشتغل %100 على أي
 * استضافة بدون أي اعتماديات إضافية.
 *
 * ملاحظة تصميم ثانية: كل حركة تُرسل كأمر كامل (.ثعبان فوق) بدل رسالة
 * حرة بدون بادئة — تفاديًا لنفس فئة المشاكل اللي واجهناها بلعبة
 * إكس_أو (مطابقة JID لرسائل غير أوامر). هذا يخليها أبسط وأوثق.
 */

import { getBotScopeId } from "../utils/helpers";

export type Direction = "up" | "down" | "left" | "right";

interface Point {
  x: number;
  y: number;
}

export interface SnakeGame {
  size: number;
  snake: Point[]; // العنصر [0] = الرأس
  direction: Direction;
  food: Point;
  score: number;
  over: boolean;
}

const DIR_VECTORS: Record<Direction, Point> = {
  up: { x: 0, y: -1 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
  right: { x: 1, y: 0 },
};

const OPPOSITE: Record<Direction, Direction> = {
  up: "down",
  down: "up",
  left: "right",
  right: "left",
};

class SnakeManager {
  private games = new Map<string, SnakeGame>();

  // 🔧 (عزل البوتات الفرعية) — نفس فكرة بقية المدراء بالضبط.
  private key(sock: { user?: { id?: string } }, chatId: string): string {
    return `${getBotScopeId(sock)}:${chatId}`;
  }

  isRunning(sock: { user?: { id?: string } }, chatId: string): boolean {
    return this.games.has(this.key(sock, chatId));
  }

  get(sock: { user?: { id?: string } }, chatId: string): SnakeGame | undefined {
    return this.games.get(this.key(sock, chatId));
  }

  end(sock: { user?: { id?: string } }, chatId: string) {
    this.games.delete(this.key(sock, chatId));
  }

  start(sock: { user?: { id?: string } }, chatId: string, size = 6): SnakeGame {
    const mid = Math.floor(size / 2);
    const startSnake: Point[] = [{ x: mid, y: mid }];
    const game: SnakeGame = {
      size,
      snake: startSnake,
      direction: "right",
      food: this.randomFood(size, startSnake),
      score: 0,
      over: false,
    };
    this.games.set(this.key(sock, chatId), game);
    return game;
  }

  private randomFood(size: number, occupied: Point[]): Point {
    // الشبكة صغيرة (6×6 = 36 خانة)، فحلقة عشوائية بسيطة تكفي بدون أي
    // تعقيد إضافي (حتى لو الثعبان طويل جدًا، احتمال التصادم يبقى معقول)
    let food: Point;
    let attempts = 0;
    do {
      food = { x: Math.floor(Math.random() * size), y: Math.floor(Math.random() * size) };
      attempts++;
    } while (occupied.some((p) => p.x === food.x && p.y === food.y) && attempts < 200);
    return food;
  }

  move(sock: { user?: { id?: string } }, chatId: string, dir: Direction): SnakeGame | undefined {
    const game = this.games.get(this.key(sock, chatId));
    if (!game || game.over) return game;

    // ما نسمح بالرجوع المباشر بعكس اتجاه الحركة الحالي (قاعدة سنيك
    // الكلاسيكية — وإلا الرأس يصطدم بالجسم فورًا بشكل غير منطقي للاعب)
    if (game.snake.length > 1 && dir === OPPOSITE[game.direction]) {
      dir = game.direction;
    }
    game.direction = dir;

    const head = game.snake[0];
    const vec = DIR_VECTORS[dir];
    const newHead: Point = { x: head.x + vec.x, y: head.y + vec.y };

    if (newHead.x < 0 || newHead.x >= game.size || newHead.y < 0 || newHead.y >= game.size) {
      game.over = true;
      return game;
    }
    if (game.snake.some((p) => p.x === newHead.x && p.y === newHead.y)) {
      game.over = true;
      return game;
    }

    game.snake.unshift(newHead);

    if (newHead.x === game.food.x && newHead.y === game.food.y) {
      game.score += 1;
      if (game.snake.length >= game.size * game.size) {
        game.over = true; // فوز كامل: الثعبان ملأ الشبكة كلها
      } else {
        game.food = this.randomFood(game.size, game.snake);
      }
    } else {
      game.snake.pop();
    }

    return game;
  }

  render(game: SnakeGame): string {
    const grid: string[][] = Array.from({ length: game.size }, () => Array(game.size).fill("⬛"));
    grid[game.food.y][game.food.x] = "🍎";
    game.snake.forEach((p, i) => {
      if (p.y >= 0 && p.y < game.size && p.x >= 0 && p.x < game.size) {
        grid[p.y][p.x] = i === 0 ? "🟢" : "🟩";
      }
    });
    return grid.map((row) => row.join("")).join("\n");
  }
}

export const snakeManager = new SnakeManager();
