/**
 * 🆕 لعبة "FPS War Zone" (.fps) — نفس فكرة الصورة اللي بعثها صاحب
 * البوت، بس بأزرار حقيقية شغالة (quick_reply/single_select) بدل
 * الأزرار القديمة المهجورة من واتساب. كل ضغطة = خطوة وحدة (إطلاق نار/
 * إعادة تلقيم/تصويب مركّز)، ونرسم مشهد جديد بعدها.
 */
import { WASocket } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { addPoint } from "../database/db";
import { CONFIG } from "../config/config";

interface Game {
  playerJid: string;
  hp: number;
  ammo: number;
  score: number;
  enemyHp: number;
  scoped: boolean; // تصويب مركّز يزيد فرصة الإصابة بالطلقة الجاية
}

const MAX_HP = 100;
const MAX_AMMO = 30;
const ENEMY_MAX_HP = 40;

const sessions = new Map<string, Game>();

function key(sock: WASocket, chatId: string, senderJid: string): string {
  return `${getBotScopeId(sock)}:${chatId}:${senderJid}`;
}

export function isRunning(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.has(key(sock, chatId, senderJid));
}

function renderScene(game: Game): Promise<Buffer> {
  const enemyBarWidth = Math.max(0, (game.enemyHp / ENEMY_MAX_HP) * 150);
  const hpColor = game.hp > 50 ? "#27ae60" : game.hp > 20 ? "#f39c12" : "#e74c3c";

  const svg = `<svg width="500" height="380" xmlns="http://www.w3.org/2000/svg">
    <rect width="500" height="380" fill="#1c1c1c"/>
    <polygon points="0,380 150,180 350,180 500,380" fill="#3a2e1f"/>
    <rect x="0" y="0" width="500" height="180" fill="#0d0d0d"/>
    ${game.enemyHp > 0 ? `<text x="250" y="230" font-size="70" text-anchor="middle">🧍</text>` : ""}
    ${game.scoped ? `<circle cx="250" cy="215" r="40" stroke="#e74c3c" stroke-width="3" fill="none"/>` : ""}

    <text x="20" y="30" font-size="20" fill="${hpColor}" font-family="monospace" font-weight="bold">HP: ${game.hp}</text>
    <text x="200" y="30" font-size="20" fill="#f1c40f" font-family="monospace" font-weight="bold">AMMO: ${game.ammo}/${MAX_AMMO}</text>
    <text x="380" y="30" font-size="20" fill="#ecf0f1" font-family="monospace" font-weight="bold">SCORE: ${game.score}</text>

    <rect x="175" y="255" width="150" height="12" fill="#333"/>
    <rect x="175" y="255" width="${enemyBarWidth}" height="12" fill="#e74c3c"/>
    <text x="250" y="280" font-size="14" fill="#fff" text-anchor="middle" font-family="sans-serif">عدو</text>
  </svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendScene(sock: WASocket, chatId: string, game: Game, message: string): Promise<void> {
  const image = await renderScene(game);
  const rows = [
    { command: "fps_fire", label: `🔥 إطلاق نار${game.scoped ? " (تصويب مركّز)" : ""}` },
    { command: "fps_reload", label: "🔄 إعادة تلقيم" },
    { command: "fps_scope", label: "🎯 تصويب مركّز" },
  ];
  await sendButtonMessage(sock, chatId, {
    text: `🪖 *WAR ZONE 3D* — ${jidToMention(game.playerJid)}\n\n${message}`,
    mentions: [game.playerJid],
    image,
    extraButtons: [buildSingleSelectButton("⚔️ تحرّك", "اختر حركتك", rows)],
  });
}

export async function start(sock: WASocket, chatId: string, senderJid: string): Promise<void> {
  const k = key(sock, chatId, senderJid);
  const game: Game = { playerJid: senderJid, hp: MAX_HP, ammo: MAX_AMMO, score: 0, enemyHp: ENEMY_MAX_HP, scoped: false };
  sessions.set(k, game);
  await sendScene(sock, chatId, game, "دخلت منطقة الحرب! صفّي العدو قبل ما تخلص صحتك.");
}

async function gameOver(sock: WASocket, chatId: string, senderJid: string, game: Game, won: boolean): Promise<void> {
  sessions.delete(key(sock, chatId, senderJid));
  if (won) addPoint(chatId, senderJid, Math.max(1, Math.floor(game.score / 10)));
  await sock.sendMessage(chatId, {
    text: won
      ? `🏆 *فزت!* صفّيت العدو.\n📊 النقاط النهائية: ${game.score}`
      : `☠️ *انتهت اللعبة.* خسرت كل صحتك.\n📊 النقاط النهائية: ${game.score}`,
  });
}

export async function handleAction(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId, senderJid);
  const game = sessions.get(k);
  if (!game) return false;

  const trimmed = text.trim();
  const withoutPrefix = trimmed.startsWith(CONFIG.PREFIX) ? trimmed.slice(CONFIG.PREFIX.length) : trimmed;

  let action: "fire" | "reload" | "scope" | null = null;
  if (withoutPrefix === "fps_fire" || withoutPrefix === "اطلاق" || withoutPrefix === "نار") action = "fire";
  else if (withoutPrefix === "fps_reload" || withoutPrefix === "تلقيم") action = "reload";
  else if (withoutPrefix === "fps_scope" || withoutPrefix === "تصويب") action = "scope";
  else return false;

  if (action === "scope") {
    game.scoped = true;
    await sendScene(sock, chatId, game, "🎯 صوّبت بتركيز — الطلقة الجاية فرصتها أعلى.");
    return true;
  }

  if (action === "reload") {
    game.ammo = MAX_AMMO;
    game.scoped = false;
    // العدو ياخذ فرصة مجانية أثناء إعادة التلقيم
    if (Math.random() < 0.5) {
      game.hp -= 10;
      if (game.hp <= 0) {
        await gameOver(sock, chatId, senderJid, game, false);
        return true;
      }
    }
    await sendScene(sock, chatId, game, "🔄 أعدت تلقيم السلاح.");
    return true;
  }

  // action === "fire"
  if (game.ammo <= 0) {
    await sendScene(sock, chatId, game, "⚠️ ما عندك طلقات! أعد التلقيم أول.");
    return true;
  }
  game.ammo--;
  const hitChance = game.scoped ? 0.85 : 0.55;
  game.scoped = false;
  const hit = Math.random() < hitChance;
  let message: string;

  if (hit) {
    const damage = 10 + Math.floor(Math.random() * 10);
    game.enemyHp -= damage;
    message = `🎯 إصابة! -${damage} من صحة العدو.`;
    if (game.enemyHp <= 0) {
      game.score += 10;
      game.enemyHp = ENEMY_MAX_HP; // عدو جديد
      message = `💀 صفّيت العدو! +10 نقاط. عدو جديد ظهر.`;
    }
  } else {
    message = "💨 طلقة طايشة!";
  }

  // العدو يرد النار باحتمال معين
  if (Math.random() < 0.35) {
    const dmg = 5 + Math.floor(Math.random() * 10);
    game.hp -= dmg;
    message += `\n🩸 العدو أصابك! -${dmg} صحة.`;
    if (game.hp <= 0) {
      await gameOver(sock, chatId, senderJid, game, false);
      return true;
    }
  }

  await sendScene(sock, chatId, game, message);
  return true;
}

export function end(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.delete(key(sock, chatId, senderJid));
}
