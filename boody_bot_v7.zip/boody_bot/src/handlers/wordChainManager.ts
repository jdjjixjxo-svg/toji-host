/**
 * 🆕 لعبة "سلسلة" (.سلسلة) — لعبة جماعية مستمرة: كل كلمة لازم تبدأ
 * بآخر حرف من الكلمة اللي قبلها، وممنوع تكرار كلمة استُخدمت قبل.
 * لعبة جماعية بلا "فائز واحد" — كل كلمة صحيحة = نقطة لصاحبها، ولعبة
 * مستمرة إلى إن تُنهى بـ.استسلم.
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId } from "../utils/helpers";
import { addPoint } from "../database/db";

interface Game {
  lastWord: string;
  used: Set<string>;
}

const games = new Map<string, Game>();

// توحيد آخر حرف عشان اختلافات الهمزة/التاء المربوطة ما تكسر اللعبة
function normalizeLetter(ch: string): string {
  const map: Record<string, string> = { ة: "ه", أ: "ا", إ: "ا", آ: "ا", ى: "ي", ئ: "ي", ؤ: "و" };
  return map[ch] || ch;
}

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

export async function start(sock: WASocket, chatId: string): Promise<void> {
  const k = key(sock, chatId);
  if (games.has(k)) {
    await sock.sendMessage(chatId, { text: "🔁 فيه سلسلة جارية بالفعل! اكتب .استسلم لإنهائها." });
    return;
  }

  const starter = "مدرسة";
  games.set(k, { lastWord: starter, used: new Set([starter]) });

  await sock.sendMessage(chatId, {
    text:
      `🔗 *لعبة السلسلة بدأت!*\n\nكل شخص يكتب كلمة تبدأ بآخر حرف من الكلمة اللي قبلها. ممنوع التكرار.\n\n` +
      `🔤 أول كلمة: *${starter}*\nاكتبوا كلمة تبدأ بحرف "${normalizeLetter([...starter].pop()!)}"\n\n` +
      `كل كلمة صحيحة = نقطة. اكتبوا .استسلم لإنهاء اللعبة.`,
  });
}

/** يرجع true لو تعامل مع الرسالة كمحاولة بالسلسلة (صح أو غلط). */
export async function handleWord(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;

  const word = text.trim();
  // نقبل بس كلمة عربية وحدة بلا مسافات (تجنّب اعتراض رسائل عادية بالجروب)
  if (!/^[\u0600-\u06FF]{2,}$/.test(word)) return false;

  const requiredLetter = normalizeLetter([...game.lastWord].pop()!);
  const firstLetter = normalizeLetter([...word][0]);

  if (game.used.has(word)) {
    await sock.sendMessage(chatId, { text: `❌ كلمة "${word}" مستخدمة قبل! جرّب غيرها.` });
    return true;
  }

  if (firstLetter !== requiredLetter) {
    // مو محاولة سلسلة فعلية (رسالة عادية بالجروب) — نتجاهلها بصمت
    return false;
  }

  game.used.add(word);
  game.lastWord = word;
  addPoint(chatId, senderJid, 1);

  const nextLetter = normalizeLetter([...word].pop()!);
  await sock.sendMessage(chatId, {
    text: `✅ *${word}* (+1 نقطة) — الحرف الجاي: "${nextLetter}"`,
  });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  return games.delete(key(sock, chatId));
}
