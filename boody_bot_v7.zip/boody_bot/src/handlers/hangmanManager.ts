/**
 * 🆕 (طلب صريح ضمن قائمة أوامر صاحبك) لعبة "المشنقة" (.المشنقة) —
 * تخمين كلمة حرف بحرف، عدد محاولات خاطئة محدود.
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { addPoint } from "../database/db";

const WORDS = [
  "برمجة", "واتساب", "مغامرة", "احترافي", "صداقة", "سعادة",
  "رحلة", "مكتبة", "شمس", "قمر", "بحر", "جبل", "غابة", "نجمة",
  "حديقة", "مدرسة", "طائرة", "سيارة", "حاسوب", "انترنت",
];
const MAX_WRONG = 6;

interface HangmanGame {
  word: string;
  guessed: Set<string>;
  wrong: number;
}

const games = new Map<string, HangmanGame>();

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

function renderWord(game: HangmanGame): string {
  return [...game.word].map((ch) => (game.guessed.has(ch) ? ch : "_")).join(" ");
}

function renderGallows(wrong: number): string {
  const stages = [
    "🙂", "😐", "😟", "😨", "😰", "😱", "💀",
  ];
  return stages[Math.min(wrong, stages.length - 1)];
}

export async function start(sock: WASocket, chatId: string): Promise<void> {
  const k = key(sock, chatId);
  if (games.has(k)) {
    await sock.sendMessage(chatId, { text: "🔁 فيه جولة مشنقة جارية بالفعل!" });
    return;
  }
  const word = WORDS[Math.floor(Math.random() * WORDS.length)];
  games.set(k, { word, guessed: new Set(), wrong: 0 });

  await sock.sendMessage(chatId, {
    text:
      `🪢 *لعبة المشنقة بدأت!*\n\n${renderWord({ word, guessed: new Set(), wrong: 0 })}\n\n` +
      `${renderGallows(0)} محاولات خاطئة متبقية: ${MAX_WRONG}\n\n` +
      `اكتب حرف واحد بأي رسالة للتخمين. اكتب .استسلم للإنهاء.`,
  });
}

/** يرجع true لو تعامل مع الرسالة كتخمين حرف. */
export async function handleGuess(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;

  const letter = text.trim();
  // نقبل بس حرف عربي واحد (تجنّب اعتراض أي رسالة عادية بالجروب)
  if (![...letter].every((c) => /[\u0600-\u06FF]/.test(c)) || letter.length !== 1) return false;

  if (game.guessed.has(letter)) {
    await sock.sendMessage(chatId, { text: `⚠️ جرّبت هذا الحرف قبل: "${letter}"` });
    return true;
  }
  game.guessed.add(letter);

  if (!game.word.includes(letter)) {
    game.wrong++;
  }

  const won = [...game.word].every((ch) => game.guessed.has(ch));
  const lost = game.wrong >= MAX_WRONG;

  if (won) {
    addPoint(chatId, senderJid, 1);
    await sock.sendMessage(chatId, {
      text: `🎉 *فزتوا!* الكلمة كانت: *${game.word}*\n🏆 آخر تخمين صحيح من: ${jidToMention(senderJid)} (+1 نقطة)`,
      mentions: [senderJid],
    });
    games.delete(k);
    return true;
  }

  if (lost) {
    await sock.sendMessage(chatId, { text: `💀 *خسرتوا!* الكلمة كانت: *${game.word}*` });
    games.delete(k);
    return true;
  }

  await sock.sendMessage(chatId, {
    text: `${renderWord(game)}\n\n${renderGallows(game.wrong)} محاولات خاطئة متبقية: ${MAX_WRONG - game.wrong}`,
  });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  return games.delete(key(sock, chatId));
}
