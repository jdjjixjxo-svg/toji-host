import { WASocket, GroupMetadata } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { isGroupAdmin, isOwner } from "../middlewares/permissions";
import { resetWarnings, setWarnings, unmuteUser, muteUser } from "../database/db";
import { jidToMention, getBotScopeId } from "../utils/helpers";
import { sendButtonMessage, QuickButton } from "../utils/interactive";
import { downloadImageBuffer } from "../utils/imageSearch";
import { logger } from "../utils/logger";

/**
 * 🆕 (طلب صريح: "امر طرد لا تخليه يطرد حد تلقائي، بس يصير 3 نذارات
 * يكتمه ويرسل رسالة فيها منشن مخفي للمشرفين... معها 3 أزرار") — يستبدل
 * الطرد التلقائي القديم عند اكتمال 3 نذارات (كان بملف admin/warn.ts)
 * بتدفق قرار جماعي: العضو يُكتم لحين ما يقرر المشرفون عبر 3 أزرار.
 *
 * ⚠️ قيد صراحة (بسبب طريقة عمل الأزرار التفاعلية بواتساب — راجع تعليق
 * utils/interactive.ts): واتساب يرسل *نص الزر نفسه* عند الضغط، مو أي
 * معرّف مخفي مرتبط بالعضو المستهدف. لذلك هذا النظام يدعم *قرار واحد
 * معلّق بكل مجموعة بنفس اللحظة* (Map بمفتاح chatId فقط) — لو وصل عضوين
 * لـ 3 نذارات بنفس الوقت بنفس المجموعة، القرار الثاني يستبدل الأول.
 * هذا احتمال نادر عمليًا (المشرفون يتوقع يردوا خلال ثواني/دقائق).
 */

interface PendingKickDecision {
  target: string;
  /** أول ضغطة زر بس تُنفَّذ — أي ضغطة بعدها تُتجاهل بصمت */
  handled: boolean;
}

const pending = new Map<string, PendingKickDecision>(); // key: "botId:chatId"

/** 🔧 (عزل البوتات الفرعية) — نفس فكرة بقية مدراء الحالة بالذاكرة بالضبط. */
function pendingKey(sock: { user?: { id?: string } }, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export const KICK_BUTTON_YES = "💀فنشه";
export const KICK_BUTTON_NO = "🥺لا";
export const KICK_BUTTON_KEEP_2 = "😡خليه 2";

const DECISION_BUTTON_TEXTS = [KICK_BUTTON_YES, KICK_BUTTON_NO, KICK_BUTTON_KEEP_2];

/**
 * 🆕 (طلب صريح: "الزرار لا تعمل") — أزرار واتساب التفاعلية غير الرسمية
 * (native_flow عبر Baileys) هي "best-effort" أصلًا وموثّق بوضوح بملف
 * utils/interactive.ts إنها قد لا تظهر إطلاقًا على حسابات فردية (غير
 * أعمال) — هذا قيد من واتساب نفسه، مو خطأ نقدر "نصلحه" بالكود. الحل
 * العملي: نقبل أيضًا نفس القرار كنص عادي مكتوب يدويًا (بدون أي زر) حتى
 * لو الزر ما ظهر إطلاقًا عند المشرف — يكتب الكلمة بس وتشتغل بنفس القوة.
 */
const TEXT_ALIASES: Record<string, string> = {
  فنشه: KICK_BUTTON_YES,
  اطرده: KICK_BUTTON_YES,
  طرده: KICK_BUTTON_YES,
  نعم: KICK_BUTTON_YES,
  لا: KICK_BUTTON_NO,
  سيبه: KICK_BUTTON_NO,
  اعفيه: KICK_BUTTON_NO,
  "خليه 2": KICK_BUTTON_KEEP_2,
  خليه2: KICK_BUTTON_KEEP_2,
  "2": KICK_BUTTON_KEEP_2,
};

/**
 * 🔧 إصلاح جذري مهم جدًا (السبب الحقيقي الأرجح وراء "الأزرار/الكتابة
 * اليدوية ما تشتغل أبدًا"): resolveDecisionText كانت تقارن النص بمطابقة
 * *حرفية تامة* — لو المستخدم كتب/لصق "فنشه💀" (الإيموجي بعد الكلمة) بدل
 * "💀فنشه" (الإيموجي قبلها، الصيغة المخزّنة بـKICK_BUTTON_YES)، أو حتى
 * "فنشه 💀" (بمسافة)، المطابقة تفشل تمامًا مع كلا الطرفين (لا تساوي نص
 * الزر الكامل، ولا تساوي الكلمة المجردة بـTEXT_ALIASES لأن فيها إيموجي
 * إضافي). نشيل الآن كل الإيموجي والمسافات الزايدة من المدخل *قبل*
 * المقارنة، فتشتغل الكلمة بأي شكل يكتبها فيه المستخدم.
 */
const EMOJI_REGEX = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{2B00}-\u{2BFF}]/gu;

function stripEmojiAndSpaces(text: string): string {
  return text.replace(EMOJI_REGEX, "").replace(/\s+/g, " ").trim();
}

// جدول مطابقة إضافي بعد تنظيف الإيموجي من كل الصيغ المعروفة (أزرار +
// أسماء بديلة) — مبني تلقائيًا عشان ما نكرر نفس القيم يدويًا مرتين.
const CLEANED_LOOKUP: Record<string, string> = {};
for (const full of DECISION_BUTTON_TEXTS) {
  CLEANED_LOOKUP[stripEmojiAndSpaces(full)] = full;
}
for (const [alias, target] of Object.entries(TEXT_ALIASES)) {
  CLEANED_LOOKUP[stripEmojiAndSpaces(alias)] = target;
}

/** يوحّد أي صيغة وصلت (نص زر حقيقي أو كلمة مكتوبة يدويًا، بأي ترتيب/وجود إيموجي) لاسم القرار القياسي */
function resolveDecisionText(trimmed: string): string | undefined {
  if (DECISION_BUTTON_TEXTS.includes(trimmed)) return trimmed;
  if (TEXT_ALIASES[trimmed]) return TEXT_ALIASES[trimmed];
  return CLEANED_LOOKUP[stripEmojiAndSpaces(trimmed)];
}

/**
 * يبدأ تدفق القرار: يكتم العضو، ويرسل رسالة (بصورة بروفايله لو توفرت)
 * فيها منشن ظاهر للعضو المكتوم + منشن *مخفي* (بدون ظهور @ بالنص) لكل
 * مشرفي المجموعة، مع 3 أزرار قرار.
 */
export async function startKickDecision(
  sock: WASocket,
  chatId: string,
  target: string,
  metadata: GroupMetadata
): Promise<void> {
  muteUser(chatId, target);
  pending.set(pendingKey(sock, chatId), { target, handled: false });

  const mention = jidToMention(target);
  const adminJids = metadata.participants.filter((p) => isGroupAdmin(metadata, p.id)).map((p) => p.id);

  const text =
    `*❌تم كتم ${mention} لانهُ تلقا 3 انذارات هل تسمحون لي بطرده ام لا*\n` +
    `*🕥الوقت مهم*\n` +
    `ـــــــــــــــــــــــــــــــــ༺⚜️༻ـــــــــــــــــــــــــــــــ\n\n` +
    `*🕸ملاحظه*\n` +
    `> ⚜️اذا قلتم لا سيتم اعفاىه ⚜️من جميع الانذارات او ⚜️يمكنكم جلعه انذارين فقط \n\n\n` +
    `⚠️ لو الأزرار تحت ما ظهرت، اكتبوا بس: فنشه / لا / خليه 2\n\n` +
    `*${CONFIG.BOT_NAME}*`;

  // منشن ظاهر للعضو (داخل النص نفسه عبر jidToMention) + منشن مخفي
  // للمشرفين (نفس أسلوب .منشن بملف tagall.ts — JID بحقل mentions بدون
  // كتابة @رقمه داخل النص) حتى توصلهم إشعارات فعلية بدون تلويث الرسالة.
  const allMentions = [target, ...adminJids];

  // 🔧 إصلاح الجذر الحقيقي لـ"الأزرار ما تشتغل أبدًا" (لقيته أخيرًا،
  // بمقارنة مباشرة مع sectionButton() الشغّالة بـinteractive.ts): واتساب
  // يرجّع حقل "id" (مو النص المعروض) عند الضغط على أي زر. هذا الكود كان
  // يحط id="kick_yes"/"kick_no"/"kick_keep2" (معرّفات داخلية عشوائية)
  // بينما resolveDecisionText() يقارن بنص العرض الفعلي (KICK_BUTTON_YES
  // وغيرها) — فمهما ضغط المشرف، القيمة الراجعة ("kick_yes") ما تتطابق
  // أبدًا مع أي شي بجدول القرارات. يعني الأزرار الحقيقية معطّلة *بالكامل*
  // منذ البداية، وأي نجاح سابق كان فقط عبر الكتابة اليدوية. الحل: نفس id
  // = نص الزر نفسه (بالضبط زي sectionButton الشغّالة).
  const buttons: QuickButton[] = [
    { id: KICK_BUTTON_YES, text: KICK_BUTTON_YES },
    { id: KICK_BUTTON_NO, text: KICK_BUTTON_NO },
    { id: KICK_BUTTON_KEEP_2, text: KICK_BUTTON_KEEP_2 },
  ];

  // 🖼️ صورة بروفايل العضو المكتوم كرأس الرسالة (مطلوب صراحة). best-effort:
  // لو ما عنده صورة بروفايل أو تعذر تحميلها، ترسل الرسالة نص فقط بدون كسر شي.
  let profileImage: Buffer | undefined;
  try {
    const url = await sock.profilePictureUrl(target, "image");
    if (url) profileImage = await downloadImageBuffer(url);
  } catch {
    profileImage = undefined;
  }

  try {
    await sendButtonMessage(sock, chatId, {
      text,
      mentions: allMentions,
      quickButtons: buttons,
      image: profileImage,
      excludeUtilityButtons: true,
    });
  } catch (err) {
    logger.error("فشل إرسال رسالة قرار الطرد (3 نذارات):", err);
  }
}

/** يرجع true لو النص المستلم أحد أزرار القرار الثلاثة أو مرادفها النصي اليدوي */
export function isKickDecisionButtonText(text: string): boolean {
  return !!resolveDecisionText(text.trim());
}

export function hasPendingKickDecision(sock: { user?: { id?: string } }, chatId: string): boolean {
  const p = pending.get(pendingKey(sock, chatId));
  return !!p && !p.handled;
}

/**
 * يعالج ضغطة أحد الأزرار الثلاثة. يرجع true لو تم التعامل مع الرسالة
 * (بغض النظر عن نجاح التنفيذ الفعلي) حتى لا تكمل messageHandler معالجتها
 * كأمر/رد عادي.
 */
export async function handleKickDecisionButton(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  text: string,
  metadata?: GroupMetadata
): Promise<boolean> {
  const trimmed = text.trim();
  const resolved = resolveDecisionText(trimmed);
  if (!resolved) return false;

  const decision = pending.get(pendingKey(sock, chatId));
  if (!decision || decision.handled) return false; // ما فيه قرار معلّق أصلًا، أو انضغط زر قبل كذا

  // 🔧 إصلاح جذري مهم جدًا (سبب محتمل قوي لـ"الأزرار ما تستجيب أبدًا
  // للمشرفين"): "metadata" الممرَّرة هنا تجي من الكاش العام
  // (messageHandler.ts) وقد تكون بلحظة أقدم من آخر تغيير إشراف حقيقي —
  // فتفشل isGroupAdmin() بصمت تام (ترجع false → الدالة كلها ترجع false
  // → الضاغط ما يشوف أي رد إطلاقًا، يحس إن الزر "ميت"). نجلب نسخة حيّة
  // الآن مباشرة قبل اتخاذ القرار، بدل الاعتماد على أي نسخة مخزَّنة.
  let freshMetadata = metadata;
  try {
    freshMetadata = await sock.groupMetadata(chatId);
  } catch {
    /* لو فشل الجلب الحي لأي سبب، نكمل بالنسخة المتوفرة بدل ما نفشل كليًا */
  }

  // فقط مشرفي واتساب الحقيقيين أو المطور يقدروا يقرروا — أي شخص ثاني
  // يضغط الزر (أو يكتب الكلمة يدويًا) تُتجاهل رسالته بصمت (ترجع false
  // حتى تكمل المعالجة العادية له، بما إنها مو رسالة قرار فعلية بالنسبة له).
  if (!freshMetadata || (!isGroupAdmin(freshMetadata, senderJid) && !isOwner(senderJid, freshMetadata, sock))) {
    return false;
  }

  decision.handled = true; // 🔒 قفل فوري — أي ضغطة/كتابة بعدها (حتى لو من مشرف ثاني) تُتجاهل
  pending.delete(pendingKey(sock, chatId));

  const target = decision.target;
  const mention = jidToMention(target);

  try {
    if (resolved === KICK_BUTTON_YES) {
      // 🔧 إصلاح (طلب صريح: "رسالة الطرد مو تظهر، تظهر رسالة الوداع
      // بس" + "لا تجعل فشل إرسال الرسالة يؤدي لانهيار نظام الإنذارات
      // كله") — قبل كذا كانت رسالة الطرد وتنفيذ الطرد بنفس try واحد:
      // لو فشل إرسال الرسالة (لأي سبب: مشكلة شبكة مؤقتة، طول النص...)
      // كان يوقف كل شي هنا (catch الخارجي يفكّ الكتم ويوضح خطأ عام) ولا
      // يوصل أبدًا لسطر الطرد الفعلي — فيبدو للمشرف "ولا شي صار"، بينما
      // فعليًا العضو يضل بالمجموعة (مكتوم بس). فصلنا الآن الخطوتين
      // تمامًا: فشل الرسالة يُسجَّل ويُتجاوز، والطرد الفعلي ينفّذ دائمًا.
      try {
        await sock.sendMessage(chatId, {
          text:
            `> *${CONFIG.BOT_NAME}*\n\n` +
            `✒️التفاعل كان نازل بسسبك\n` +
            ` يا عديم الفائده \n` +
            `)ــــــــــــــــــــــــــــــʚعاهةɞـــــــــــــــــــــــــــــــــ(\n` +
            `دلوقتي ${mention} طلعت بره الجروب ونضفته منك يا عاهة الجروبات ✨`,
          mentions: [target],
        });
      } catch (msgErr) {
        logger.error("فشل إرسال رسالة الطرد (سيتم تنفيذ الطرد فعليًا رغم ذلك):", msgErr);
      }

      // 🔧 نفس الإصلاح السابق: أزلنا الفحص المحلي غير الموثوق (isBotAdmin)
      // قبل محاولة الطرد — نحاول الطرد مباشرة، وواتساب نفسه يقرر.
      await sock.groupParticipantsUpdate(chatId, [target], "remove");
      resetWarnings(chatId, target);
      unmuteUser(chatId, target); // احتياط: لو تعذر الطرد لأي سبب لاحق، ما يبقى مكتوم للأبد
    } else if (resolved === KICK_BUTTON_NO) {
      resetWarnings(chatId, target);
      unmuteUser(chatId, target);
      await sock.sendMessage(chatId, { text: "هجيبك يعني هجيبك 💔" });
    } else if (resolved === KICK_BUTTON_KEEP_2) {
      setWarnings(chatId, target, 2);
      unmuteUser(chatId, target);
      await sock.sendMessage(chatId, { text: `واضح الواصطه ${mention}`, mentions: [target] });
    }
  } catch (err) {
    logger.error("فشل تنفيذ قرار المشرفين بعد 3 نذارات:", err);
    // نفك الكتم بأي الأحوال حتى ما يبقى العضو مكتوم للأبد بسبب خطأ تنفيذ
    unmuteUser(chatId, target);
    await sock.sendMessage(chatId, {
      text: "❌ صار خطأ أثناء تنفيذ القرار. تأكد إني مشرف بالمجموعة.",
    });
  }

  return true;
}
