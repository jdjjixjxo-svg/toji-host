/**
 * 🆕 مدير لعبة "٢٠٤٨" — ثاني لعبة بقسم "ألعاب 2D" (بعد لعبة الثعبان).
 * نفس فلسفة snakeManager بالضبط: حالة اللعبة تُخزّن بالذاكرة لكل شات
 * (Map)، والحركة عبر 4 اتجاهات بنفس أزرار الثعبان (فوق/تحت/يمين/يسار).
 */

import { getBotScopeId } from "../utils/helpers";

export type Direction2048 = "up" | "down" | "left" | "right";

export interface Game2048 {
  size: number;
  grid: number[][]; // 0 = خانة فارغة
  score: number;
  over: boolean; // ما فيه أي حركة ممكنة بعد
  won: boolean; // وصل لبلاطة 2048 (تُعرض مرة وحدة، اللعب يستمر بعدها)
  wonAnnounced: boolean;
}

function emptyGrid(size: number): number[][] {
  return Array.from({ length: size }, () => Array(size).fill(0));
}

function cloneGrid(grid: number[][]): number[][] {
  return grid.map((row) => [...row]);
}

function transpose(grid: number[][]): number[][] {
  const size = grid.length;
  const result = emptyGrid(size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      result[x][y] = grid[y][x];
    }
  }
  return result;
}

function reverseRows(grid: number[][]): number[][] {
  return grid.map((row) => [...row].reverse());
}

/** يدمج صف واحد نحو اليسار (القاعدة الكلاسيكية للعبة 2048) */
function slideRowLeft(row: number[]): { row: number[]; gained: number } {
  const nonZero = row.filter((v) => v !== 0);
  const merged: number[] = [];
  let gained = 0;
  for (let i = 0; i < nonZero.length; i++) {
    if (i < nonZero.length - 1 && nonZero[i] === nonZero[i + 1]) {
      const value = nonZero[i] * 2;
      merged.push(value);
      gained += value;
      i++; // تجاوز العنصر التالي لأنه اندمج بالفعل
    } else {
      merged.push(nonZero[i]);
    }
  }
  while (merged.length < row.length) merged.push(0);
  return { row: merged, gained };
}

class Game2048Manager {
  private games = new Map<string, Game2048>();

  // 🔧 (عزل البوتات الفرعية) — نفس فكرة eventManager/ticTacToeManager
  // بالضبط: مفتاح "botId:chatId" بدل "chatId" فقط.
  private key(sock: { user?: { id?: string } }, chatId: string): string {
    return `${getBotScopeId(sock)}:${chatId}`;
  }

  isRunning(sock: { user?: { id?: string } }, chatId: string): boolean {
    return this.games.has(this.key(sock, chatId));
  }

  get(sock: { user?: { id?: string } }, chatId: string): Game2048 | undefined {
    return this.games.get(this.key(sock, chatId));
  }

  end(sock: { user?: { id?: string } }, chatId: string) {
    this.games.delete(this.key(sock, chatId));
  }

  start(sock: { user?: { id?: string } }, chatId: string, size = 4): Game2048 {
    const game: Game2048 = {
      size,
      grid: emptyGrid(size),
      score: 0,
      over: false,
      won: false,
      wonAnnounced: false,
    };
    this.addRandomTile(game);
    this.addRandomTile(game);
    this.games.set(this.key(sock, chatId), game);
    return game;
  }

  private addRandomTile(game: Game2048) {
    const empties: { x: number; y: number }[] = [];
    for (let y = 0; y < game.size; y++) {
      for (let x = 0; x < game.size; x++) {
        if (game.grid[y][x] === 0) empties.push({ x, y });
      }
    }
    if (!empties.length) return;
    const cell = empties[Math.floor(Math.random() * empties.length)];
    game.grid[cell.y][cell.x] = Math.random() < 0.9 ? 2 : 4;
  }

  /** هل فيه أي حركة ممكنة (خانة فارغة أو دمج متاح أفقيًا/عموديًا)؟ */
  private hasMoves(grid: number[][]): boolean {
    const size = grid.length;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        if (grid[y][x] === 0) return true;
        if (x < size - 1 && grid[y][x] === grid[y][x + 1]) return true;
        if (y < size - 1 && grid[y][x] === grid[y + 1][x]) return true;
      }
    }
    return false;
  }

  move(sock: { user?: { id?: string } }, chatId: string, dir: Direction2048): Game2048 | undefined {
    const game = this.games.get(this.key(sock, chatId));
    if (!game || game.over) return game;

    let grid = cloneGrid(game.grid);
    // نحوّل الشبكة دائمًا لصيغة "الدمج نحو اليسار" بغض النظر عن الاتجاه
    // الفعلي، فنحتاج دالة دمج واحدة فقط بدل 4 نسخ منفصلة.
    if (dir === "up") grid = transpose(grid);
    else if (dir === "down") grid = reverseRows(transpose(grid));
    else if (dir === "right") grid = reverseRows(grid);

    let gained = 0;
    const merged = grid.map((row) => {
      const result = slideRowLeft(row);
      gained += result.gained;
      return result.row;
    });

    let finalGrid = merged;
    if (dir === "up") finalGrid = transpose(merged);
    else if (dir === "down") finalGrid = transpose(reverseRows(merged));
    else if (dir === "right") finalGrid = reverseRows(merged);

    const moved = finalGrid.some((row, y) => row.some((v, x) => v !== game.grid[y][x]));
    if (!moved) return game; // حركة غير فعالة (لم تغيّر أي شيء) — لا نضيف بلاطة جديدة

    game.grid = finalGrid;
    game.score += gained;

    if (!game.won && finalGrid.some((row) => row.some((v) => v >= 2048))) {
      game.won = true;
    }

    this.addRandomTile(game);

    if (!this.hasMoves(game.grid)) {
      game.over = true;
    }

    return game;
  }
}

export const game2048Manager = new Game2048Manager();
