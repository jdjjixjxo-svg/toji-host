/**
 * 🆕 لعبة "رقم سري" (.رقم_سري) — البوت يختار رقم من 1 إلى 100، الكل
 * يحاول يخمن، والبوت يقول "أعلى"/"أقل" لكل محاولة غلط.
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { addPoint } from "../database/db";

interface Game {
  number: number;
  attempts: number;
  timer: NodeJS.Timeout;
}

const games = new Map<string, Game>();
const ROUND_MS = 90_000;

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

export async function start(sock: WASocket, chatId: string): Promise<void> {
  const k = key(sock, chatId);
  if (games.has(k)) {
    await sock.sendMessage(chatId, { text: "🔁 فيه جولة رقم سري جارية بالفعل!" });
    return;
  }

  const number = Math.floor(Math.random() * 100) + 1;
  const timer = setTimeout(() => {
    games.delete(k);
    sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الرقم السري كان: *${number}*` }).catch(() => {});
  }, ROUND_MS);

  games.set(k, { number, attempts: 0, timer });

  await sock.sendMessage(chatId, {
    text: `🔢 *اخترت رقم سري بين 1 و100!*\n\nاكتب تخميناتك بالأرقام. عندكم 90 ثانية.\nاكتب .استسلم لكشف الرقم وإنهاء الجولة.`,
  });
}

export async function handleGuess(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;

  const trimmed = text.trim();
  if (!/^\d+$/.test(trimmed)) return false;

  const guess = Number(trimmed);
  if (guess < 1 || guess > 100) return false; // خارج النطاق، غالبًا رسالة عادية

  game.attempts++;

  if (guess === game.number) {
    clearTimeout(game.timer);
    games.delete(k);
    addPoint(chatId, senderJid, 1);
    await sock.sendMessage(chatId, {
      text: `🎉 *صح!* الرقم كان *${game.number}*\n🏆 الفائز: ${jidToMention(senderJid)} (بعد ${game.attempts} محاولة) +1 نقطة`,
      mentions: [senderJid],
    });
    return true;
  }

  await sock.sendMessage(chatId, {
    text: guess < game.number ? "⬆️ أعلى من هيك!" : "⬇️ أقل من هيك!",
  });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;
  clearTimeout(game.timer);
  games.delete(k);
  return true;
}
