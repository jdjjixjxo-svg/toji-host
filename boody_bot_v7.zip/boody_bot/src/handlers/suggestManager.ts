import fs from "fs";
import path from "path";
import { WASocket } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { getBotScopeId, digitsOnly } from "../utils/helpers";
import { logger } from "../utils/logger";

/**
 * 💡 اقتراح أمر — المستخدم يكتب فكرته، والبوت يرسلها للمطور على الخاص.
 *  - «.اقتراح <فكرتك>» يرسل مباشرة.
 *  - زر «💡 اقتراح أمر» (أو «.اقتراح» بدون نص): البوت يقول «اكتب اقتراحك الآن» وأول
 *    رسالة عادية من نفس الشخص بنفس المحادثة خلال دقيقتين تُرسل كاقتراح.
 *  - حماية من الإزعاج: 5 اقتراحات/ساعة لكل شخص، طول أدنى 6 أحرف وأقصى 800.
 */
const PENDING_MS = 2 * 60 * 1000;
const MAX_PER_HOUR = 5;
const MIN_LEN = 6;
const MAX_LEN = 800;

const pending = new Map<string, number>(); // key -> expiresAt
const history = new Map<string, number[]>(); // sender -> timestamps

const pkey = (sock: WASocket, chatId: string, sender: string) => `${getBotScopeId(sock)}:${chatId}:${digitsOnly(sender)}`;

export function expectSuggestion(sock: WASocket, chatId: string, sender: string) {
  pending.set(pkey(sock, chatId, sender), Date.now() + PENDING_MS);
}
export function isSuggestionPending(sock: WASocket, chatId: string, sender: string): boolean {
  const k = pkey(sock, chatId, sender);
  const exp = pending.get(k);
  if (!exp) return false;
  if (Date.now() > exp) {
    pending.delete(k);
    return false;
  }
  return true;
}
export function cancelSuggestion(sock: WASocket, chatId: string, sender: string) {
  pending.delete(pkey(sock, chatId, sender));
}

function recipients(sock: WASocket, isSubBot: boolean): string[] {
  const out = new Set<string>([CONFIG.OWNER_JID]);
  if (CONFIG.OWNER_NUMBER_2) out.add(`${CONFIG.OWNER_NUMBER_2}@s.whatsapp.net`);
  if (CONFIG.OWNER_NUMBER_3) out.add(`${CONFIG.OWNER_NUMBER_3}@s.whatsapp.net`);
  if (isSubBot && sock.user?.id) out.add(`${digitsOnly(sock.user.id)}@s.whatsapp.net`); // صاحب البوت الفرعي
  return [...out];
}

export type SuggestResult = { ok: true } | { ok: false; reason: string };

export async function submitSuggestion(
  sock: WASocket,
  info: { chatId: string; sender: string; pushName?: string; groupName?: string; isSubBot?: boolean },
  rawText: string
): Promise<SuggestResult> {
  const text = rawText.trim().replace(/\s+\n/g, "\n");
  if (text.length < MIN_LEN) return { ok: false, reason: "الاقتراح قصير جدًا — اشرح فكرتك بجملة كاملة على الأقل." };
  if (text.length > MAX_LEN) return { ok: false, reason: `الاقتراح طويل (الحد ${MAX_LEN} حرف). اختصره وأعد الإرسال.` };

  const now = Date.now();
  const list = (history.get(info.sender) || []).filter((t) => now - t < 3600_000);
  if (list.length >= MAX_PER_HOUR) return { ok: false, reason: "وصلت الحد (5 اقتراحات بالساعة). جرّب بعد شوي 🙏" };

  const num = digitsOnly(info.sender);
  const body =
    `💡 *اقتراح أمر جديد*\n━━━━━━━━━━━━\n` +
    `👤 من: ${info.pushName || "بدون اسم"}\n` +
    `📞 wa.me/${num}\n` +
    `📍 المكان: ${info.groupName ? `مجموعة «${info.groupName}»` : "محادثة خاصة"}\n` +
    `🤖 البوت: ${CONFIG.BOT_NAME}\n━━━━━━━━━━━━\n${text}`;

  let delivered = 0;
  for (const jid of recipients(sock, !!info.isSubBot)) {
    try {
      await sock.sendMessage(jid, { text: body });
      delivered++;
    } catch (err) {
      logger.warn(`تعذر إرسال الاقتراح إلى ${jid}:`, err);
    }
  }

  try {
    const dir = path.resolve(process.cwd(), "database");
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, "suggestions.jsonl"), JSON.stringify({ at: new Date().toISOString(), from: num, name: info.pushName, group: info.groupName, text }) + "\n");
  } catch {
    /* نسخة احتياطية فقط */
  }

  if (!delivered) return { ok: false, reason: "تعذر إيصال الاقتراح للمطور الآن. حاول بعد شوي." };
  list.push(now);
  history.set(info.sender, list);
  return { ok: true };
}
