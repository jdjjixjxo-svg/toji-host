/**
 * ============================================================================
 * 🆕 فعالية فردية تفاعلية عن طريق الذكاء الاصطناعي — أمر .قصة
 * ============================================================================
 * 🔧 (طلب صريح: "خلي اللعبة لشخص واحد، ما تكون أكثر من لعبة بنفس الوقت")
 * قبل كذا كانت الجلسة مفتاحها "chatId:senderJid" — يعني كل شخص بنفس
 * المجموعة يقدر يبدأ قصته الخاصة، وأكثر من قصة تشتغل بنفس الوقت بنفس
 * الشات. الحين المفتاح صار "chatId" فقط: قصة وحدة فعّالة بكل شات، وأي
 * شخص ثاني يحاول يبدأ وحدة جديدة وفيه وحدة جارية يُرفض بوضوح (نذكر مين
 * اللاعب الحالي). واختيارات الأرقام كمان تُقبل فقط من نفس اللاعب اللي بدأ
 * القصة — رسائل أي شخص ثاني بنفس الشات تمر عادي بدون أي تأثير عليها.
 * ============================================================================
 */
import { WASocket } from "@whiskeysockets/baileys";
import { GoogleGenAI } from "@google/genai";
import { CONFIG } from "../config/config";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { jidToMention } from "../utils/helpers";
import { logger } from "../utils/logger";

const GEMINI_MODEL = "gemini-3.1-flash-lite";
const MAX_TURNS = 8; // بعدها تنتهي القصة تلقائيًا بختام مناسب

interface StorySession {
  playerJid: string; // 🆕 صاحب القصة الوحيد المسموح له يختار (بقية أعضاء الشات لا يتأثرون)
  history: string; // ملخص القصة لحد الآن (يُمرر كسياق بكل طلب جديد)
  options: string[]; // آخر 3 خيارات عُرضت (لمطابقة ضغطة الزر)
  turn: number;
}

const sessions = new Map<string, StorySession>(); // 🔧 المفتاح الآن chatId فقط

function ai() {
  return new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
}

/** يفكك رد الذكاء الاصطناعي لنص المشهد + 3 خيارات، بشكل متسامح مع اختلافات الصياغة */
function parseStoryReply(raw: string): { scene: string; options: string[] } {
  const lines = raw
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const options: string[] = [];
  const sceneLines: string[] = [];
  for (const line of lines) {
    const m = line.match(/^(?:[1-3]|[١-٣])[).\-:]\s*(.+)$/);
    if (m && options.length < 3) {
      options.push(m[1].trim());
    } else if (!options.length) {
      sceneLines.push(line);
    }
  }

  // احتياط: لو الذكاء الاصطناعي ما التزم بالتنسيق ورجع أقل من 3 خيارات
  while (options.length < 3) {
    options.push(["تابع بحذر", "جرّب طريقًا آخر", "ارجع للخلف"][options.length] || `خيار ${options.length + 1}`);
  }

  return { scene: sceneLines.join("\n") || raw.trim(), options: options.slice(0, 3) };
}

async function generateSegment(history: string, choice: string | null, isFinal: boolean): Promise<{ scene: string; options: string[] }> {
  const instruction = isFinal
    ? "أنت راوي قصص عربي لبوت واتساب. اكتب خاتمة قصيرة ومناسبة (3-4 جمل) تختم بها المغامرة التالية بشكل مُرضٍ، بدون أي خيارات بعدها."
    : "أنت راوي قصص عربي تفاعلي لبوت واتساب (نمط 'اختر مغامرتك'). اكتب مقطع قصة قصير ومشوّق (2-4 جمل) عربي فصيح بسيط، ثم اعرض بالضبط 3 خيارات مرقّمة (1، 2، 3) كل واحد بسطر منفصل، بدون أي نص إضافي بعد الخيارات.";

  const prompt = choice
    ? `${history}\n\nاختار اللاعب: ${choice}\nكمّل القصة من هذي النقطة.`
    : history || "ابدأ قصة مغامرة عربية قصيرة وجديدة ومثيرة.";

  const response = await ai().models.generateContent({
    model: GEMINI_MODEL,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: { systemInstruction: instruction, maxOutputTokens: 400 },
  });

  const text = response.text?.trim();
  if (!text) throw new Error("رد فارغ من الذكاء الاصطناعي (قصة)");

  if (isFinal) return { scene: text, options: [] };
  return parseStoryReply(text);
}

async function sendSegment(
  sock: WASocket,
  chatId: string,
  playerJid: string,
  scene: string,
  options: string[],
  turn: number
): Promise<void> {
  // 🔧 (طلب صريح: "خلي أزرار الرواية زر واحد زي المنيو") — قبل كذا كانت
  // 3 أزرار quick_reply منفصلة (نص كل واحد يُقص أحيانًا). الحين زر واحد
  // اسمه "اختار" (نفس آلية القائمة المستخدمة بـ.فعالية والمنيو الرئيسي)
  // يفتح قائمة فيها الخيارات الثلاثة بنصها الكامل بدون أي قص.
  //
  // 🔧 تفصيل تقني مهم: هذي الآلية (buildSingleSelectButton) تسجّل كل خيار
  // كـ"أمر" حقيقي بالبادئة (matchButtonTrigger يحوّل الاختيار المضغوط لنص
  // "${PREFIX}${command}" تلقائيًا) — فاستخدمنا "قصة1"/"قصة2"/"قصة3" كأسماء
  // أوامر (مو أرقام مجردة زي "1" بس) لتفادي أي تصادم لو حد كتب رقم مجرد
  // بسياق ثاني بأي مكان بالبوت (لعبة إكس_أو مثلًا). handleStoryChoice
  // بالأسفل يتعرف على الشكلين: "قصة1" (من الزر) أو رقم مجرد "1" (لو كتبه
  // يدوي بدون ما يضغط الزر).
  const rows = options.map((opt, i) => ({
    command: `قصة${i + 1}`,
    label: `${i + 1}️⃣ ${opt}`,
  }));

  // 🆕 (طلب صريح: "خلي نص الخيارات بالرسالة نفسها، لأن نص الزر لا يظهر
  // كامل أحيانًا") — نطبع الخيارات كاملة بنص الرسالة (1. / 2. / 3.) كنسخة
  // احتياطية مضمونة القراءة دائمًا، بغض النظر عن أي قص يصير بعرض الزر.
  const optionsText = options.length
    ? `\n\n*الخيارات:*\n${options.map((opt, i) => `${i + 1}. ${opt}`).join("\n")}`
    : "";

  const footer = options.length
    ? `\n\n👇 اضغط زر "اختار" تحت، أو اكتب رقم الخيار مباشرة (مقطع ${turn}/${MAX_TURNS})`
    : `\n\n🏁 *انتهت القصة.* اكتب ${CONFIG.PREFIX}قصة لبدء مغامرة جديدة.`;

  // 🆕 (طلب صريح: "خلي منشن تمام منشن المستخدم") — منشن حقيقي للاعب
  // بنص الرسالة نفسها (مو بس contextInfo صامت)، فيوصله تنبيه فعلي ويبين
  // بوضوح مين صاحب القصة الجارية بهذا الشات.
  await sendButtonMessage(sock, chatId, {
    text: `📖 *مغامرة تفاعلية* — ${jidToMention(playerJid)}\n\n${scene}${optionsText}${footer}`,
    mentions: [playerJid],
    extraButtons: options.length ? [buildSingleSelectButton("اختار", "خيارات القصة", rows)] : [],
  });
}

/** يبدأ قصة جديدة بهذا الشات. يرفض لو فيه قصة جارية لشخص ثاني بنفس الشات. */
export async function startStory(sock: WASocket, chatId: string, senderJid: string, seed?: string): Promise<void> {
  if (!CONFIG.GEMINI_API_KEY) {
    await sock.sendMessage(chatId, {
      text: "❌ *أمر .قصة غير مفعّل حاليًا.* يحتاج نفس مفتاح Gemini المستخدم بأمر .سوال (GEMINI_API_KEY بملف .env).",
    });
    return;
  }

  // 🆕 (طلب صريح: "ما تكون لعبة أكثر من لعبة جاري بنفس الوقت") — لو فيه
  // قصة جارية فعلًا بهذا الشات لشخص غير اللي كاتب الأمر الحين، نرفض
  // ونوضح مين اللاعب الحالي بدل ما نبدأ قصة ثانية موازية تلخبط الأزرار.
  const existing = sessions.get(chatId);
  if (existing && existing.playerJid !== senderJid) {
    await sock.sendMessage(chatId, {
      text: `⚠️ فيه قصة جارية حاليًا لـ ${jidToMention(existing.playerJid)} بهذا الشات. خلّها تخلص أول (أو تنتهي) قبل ما تبدأ وحدة جديدة.`,
      mentions: [existing.playerJid],
    });
    return;
  }

  try {
    const { scene, options } = await generateSegment(seed || "", null, false);
    sessions.set(chatId, { playerJid: senderJid, history: scene, options, turn: 1 });
    await sendSegment(sock, chatId, senderJid, scene, options, 1);
  } catch (err) {
    logger.error("فشل بدء أمر .قصة:", err);
    await sock.sendMessage(chatId, { text: "❌ تعذر توليد القصة حاليًا. حاول مرة ثانية بعد شوي." });
  }
}

/** هل فيه قصة جارية بهذا الشات (لأي شخص)؟ */
export function hasActiveStory(chatId: string): boolean {
  return sessions.has(chatId);
}

/**
 * يفحص هل النص الوارد يطابق أحد الخيارات الثلاثة المعروضة حاليًا. يرجع
 * true لو تعامل مع الرسالة (سواء كمّل القصة أو رفضها بصمت)، و false لو
 * ما فيه قصة جارية أصلًا *أو* الكاتب مو صاحب القصة الجارية (تمر رسالته
 * عادي للمعالجة الطبيعية بدون أي تأثير على قصة غيره).
 */
export async function handleStoryChoice(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  text: string
): Promise<boolean> {
  const session = sessions.get(chatId);
  if (!session) return false;
  // 🆕 شخص ثاني غير صاحب القصة كتب أي شي بهذا الشات أثناء قصة جارية —
  // نتجاهله هنا كليًا (نرجع false) عشان رسالته تكمل مسارها الطبيعي
  // كأن ما فيه قصة أصلًا، بدل ما تُقرأ خطأً كاختيار لقصة مو له.
  if (session.playerJid !== senderJid) return false;

  const trimmed = text.trim();
  let choiceIndex = -1;

  // 🔧 لما تُضغط قائمة "اختار" (single_select)، matchButtonTrigger بملف
  // messageHandler.ts يحوّل الاختيار تلقائيًا لنص "${PREFIX}قصة1" (مثلًا)
  // — نشيل البادئة لو موجودة قبل أي فحص، حتى تتطابق الحالتين (زر أو كتابة
  // يدوية) بنفس المنطق.
  const withoutPrefix = trimmed.startsWith(CONFIG.PREFIX) ? trimmed.slice(CONFIG.PREFIX.length) : trimmed;

  // مطابقة شكل الزر: "قصة1"/"قصة2"/"قصة3"
  const buttonMatch = withoutPrefix.match(/^قصة([1-3])$/);
  if (buttonMatch) {
    choiceIndex = Number(buttonMatch[1]) - 1;
  } else {
    // مطابقة رقم مباشر مكتوب يدويًا (1/2/3 أو ١/٢/٣ أو مسبوق بإيموجي رقم)
    const digitMatch = withoutPrefix.match(/^[1-3١-٣]/);
    if (digitMatch) {
      const map: Record<string, number> = { "1": 0, "2": 1, "3": 2, "١": 0, "٢": 1, "٣": 2 };
      choiceIndex = map[digitMatch[0]] ?? -1;
    } else {
      choiceIndex = session.options.findIndex((opt) => trimmed.includes(opt) || opt.includes(trimmed));
    }
  }

  if (choiceIndex < 0 || choiceIndex >= session.options.length) return false;

  const chosenText = session.options[choiceIndex];
  const nextTurn = session.turn + 1;
  const isFinal = nextTurn > MAX_TURNS;

  try {
    const { scene, options } = await generateSegment(session.history, chosenText, isFinal);
    if (isFinal) {
      sessions.delete(chatId);
    } else {
      sessions.set(chatId, { playerJid: senderJid, history: `${session.history}\n${scene}`, options, turn: nextTurn });
    }
    await sendSegment(sock, chatId, senderJid, scene, options, nextTurn);
  } catch (err) {
    // 🔧 (طلب صريح: "أحيانًا العبة توقف بنص القصة") — قبل كذا أي خطأ مؤقت
    // (تعطل مؤقت بخدمة Gemini، بطء شبكة...) كان يحذف الجلسة كاملة فورًا،
    // فتضيع القصة والتقدّم كله ولازم يبدأ من الصفر. الحين الجلسة تبقى
    // محفوظة زي ما هي، ونطلب منه يعيد نفس اختياره — لو الخطأ كان مؤقت
    // فعلًا، المحاولة الثانية غالبًا تنجح بدون ما يخسر أي تقدّم بالقصة.
    logger.error("فشل استكمال أمر .قصة (الجلسة محفوظة، يقدر يعيد المحاولة):", err);
    await sock.sendMessage(chatId, {
      text: "⚠️ صار خطأ مؤقت أثناء توليد الرد. جرّب تختار نفس رقمك مرة ثانية (قصتك محفوظة ولن تضيع).",
    });
  }

  return true;
}

/**
 * 🆕 (طلب صريح: "خل اللعبة تتوقف بأمر — نهاء موجود بالفعل") — ينهي القصة
 * الجارية بهذا الشات يدويًا (يُستدعى من أمر .استسلم الموجود أصلًا، بدل
 * ما نضيف أمر منفصل جديد له نفس الغرض). يرجع true لو كان فيه قصة فعلًا
 * وتم إنهاؤها، و false لو ما فيه قصة جارية أصلًا.
 */
export function endStory(chatId: string): boolean {
  return sessions.delete(chatId);
}
