/**
 * 🆕 لعبة "كلمة السر" (.كلمة_السر) — البوت يعطي تلميح، وبعد 15 ثانية
 * بدون حل يعطي تلميح أقوى، وهكذا لغاية 3 تلميحات أو الحل.
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { addPoint } from "../database/db";

interface Entry {
  word: string;
  hints: string[]; // من الأضعف للأقوى
}

const BANK: Entry[] = [
  { word: "شمس", hints: ["نجم قريب منا", "تشرق كل صباح", "مصدر الضوء والحرارة بالنهار"] },
  { word: "قلم", hints: ["أداة كتابة", "تحتاجه بالمدرسة", "فيه حبر أو رصاص"] },
  { word: "مفتاح", hints: ["أداة معدنية صغيرة", "تفتح فيها باب أو سيارة", "بدونه ما تدخل بيتك"] },
  { word: "ساعة", hints: ["تخبرك بشي مهم", "على معصمك أو الحائط", "تعرف منها الوقت"] },
  { word: "مظلة", hints: ["تحميك من شي", "تفتحها بالسماء", "تستخدمها وقت المطر"] },
  { word: "جسر", hints: ["إنشاء كبير", "يربط بين مكانين", "تعبره فوق نهر أو وادي"] },
];

interface Game {
  entry: Entry;
  hintLevel: number;
  timer: NodeJS.Timeout;
}

const games = new Map<string, Game>();
const HINT_INTERVAL_MS = 15_000;

function key(sock: WASocket, chatId: string): string {
  return `${getBotScopeId(sock)}:${chatId}`;
}

export function isRunning(sock: WASocket, chatId: string): boolean {
  return games.has(key(sock, chatId));
}

function scheduleNextHint(sock: WASocket, chatId: string, k: string): NodeJS.Timeout {
  return setTimeout(async () => {
    const game = games.get(k);
    if (!game) return;
    if (game.hintLevel >= game.entry.hints.length - 1) {
      games.delete(k);
      await sock.sendMessage(chatId, { text: `⌛ انتهت المحاولات! الكلمة كانت: *${game.entry.word}*` });
      return;
    }
    game.hintLevel++;
    await sock.sendMessage(chatId, { text: `💡 تلميح أقوى: ${game.entry.hints[game.hintLevel]}` });
    game.timer = scheduleNextHint(sock, chatId, k);
  }, HINT_INTERVAL_MS);
}

export async function start(sock: WASocket, chatId: string): Promise<void> {
  const k = key(sock, chatId);
  if (games.has(k)) {
    await sock.sendMessage(chatId, { text: "🔁 فيه جولة كلمة السر جارية بالفعل!" });
    return;
  }

  const entry = BANK[Math.floor(Math.random() * BANK.length)];
  const timer = scheduleNextHint(sock, chatId, k);
  games.set(k, { entry, hintLevel: 0, timer });

  await sock.sendMessage(chatId, {
    text: `🕵️ *لعبة كلمة السر!*\n\n💡 التلميح: ${entry.hints[0]}\n\nخمّن الكلمة! تلميح أقوى كل 15 ثانية.`,
  });
}

export async function handleGuess(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;

  if (text.trim() !== game.entry.word) return false;

  clearTimeout(game.timer);
  games.delete(k);
  addPoint(chatId, senderJid, 1);
  await sock.sendMessage(chatId, {
    text: `🎉 *صح!* الكلمة كانت *${game.entry.word}*\n🏆 ${jidToMention(senderJid)} +1 نقطة`,
    mentions: [senderJid],
  });
  return true;
}

export function end(sock: WASocket, chatId: string): boolean {
  const k = key(sock, chatId);
  const game = games.get(k);
  if (!game) return false;
  clearTimeout(game.timer);
  games.delete(k);
  return true;
}
