/**
 * ============================================================================
 * 🆕 لعبة "القنبلة" (.قنبلة) — نفس فكرة الكود اللي بعثه صاحب البوت، لكن
 * أعدت بناءها لتشتغل صح بمعمارية هذا المشروع تحديدًا:
 * ============================================================================
 * 🔧 الكود الأصلي كان يسجّل مستمع "sock.ev.on('messages.upsert', ...)" خاص
 * فيه بكل مرة تُلعب أول جولة بمجموعة جديدة — بوتنا أصلًا عنده مستمع مركزي
 * وحيد لكل الرسائل (index.ts → handleIncomingMessage)، فتسجيل مستمع ثاني
 * منفصل لكل مجموعة يعالج كل رسالة بالبوت مرتين، ومع الوقت (مجموعات كثيرة
 * لعبت مرة واحدة) يتراكم عشرات المستمعين اللي ما ينحذفون أبدًا (تسريب
 * ذاكرة حقيقي + كل رسالة تُعالج عدة مرات). الحل: أدمج اللعبة بنفس النظام
 * المركزي (بالضبط متل ticTacToeManager/eventManager)، فما فيه أي مستمع
 * إضافي إطلاقًا، وتُعزل حالة كل بوت فرعي عن الثاني بنفس مفتاح "botId:chatId".
 *
 * 🔧 إصلاح ثاني حقيقي: الكود الأصلي كان يقفل المجموعة (announcement) ثم
 * يرسل رسالة الانفجار ثم يفتحها — لو فشل إرسال أي رسالة بالمنتصف لأي سبب
 * (خطأ شبكة مثلًا)، المجموعة تضل مقفولة للأبد بلا أي طريقة لفتحها غير
 * تدخل يدوي. الحين ملفوفة بـtry/finally فتنفتح المجموعة دائمًا مهما صار.
 *
 * 🔧 إصلاح ثالث حقيقي (طلب صريح: "ما قدرت أمرر القنبلة، منشنته، رديت
 * عليه، ما ضبط") — سببان حقيقيان:
 * 1) الرد (reply/quoted) بدون منشن @ ما كان يُفحص إطلاقًا — بس المنشن
 *    المباشر. الحين نقبل الاثنين: منشن @ فعلي، أو رد على رسالة الشخص.
 * 2) الأهم: مقارنة الـJIDs كانت بالتطابق الحرفي المباشر (===/.includes)،
 *    وواتساب أحيانًا يرجّع نفس الشخص بصيغة @lid بدل @s.whatsapp.net (أو
 *    العكس) باختلاف السياق — فنفس الشخص بالضبط يفشل بمطابقة نفسه! الحين
 *    كل مقارنة هوية بهذي اللعبة تمر عبر digitsOnly() (نفس الحل المستخدم
 *    بباقي البوت لمشكلة LID، راجع helpers.ts) بدل المقارنة الحرفية.
 * ============================================================================
 */
import { WASocket } from "@whiskeysockets/baileys";
import { jidToMention, getBotScopeId, digitsOnly, getMentionedJids, getQuotedParticipant } from "../utils/helpers";
import { addPoint } from "../database/db";
import { logger } from "../utils/logger";

interface BombGame {
  started: boolean;
  players: string[];
  activePlayers: string[];
  currentHolder: string | null;
  roundTimer: NodeJS.Timeout | null;
  roundTime: number;
}

const ROUND_MS = 30 * 1000;

class BombManager {
  private games: Map<string, BombGame> = new Map();

  private key(sock: WASocket, chatId: string): string {
    return `${getBotScopeId(sock)}:${chatId}`;
  }

  isRunning(sock: WASocket, chatId: string): boolean {
    return this.games.has(this.key(sock, chatId));
  }

  /**
   * 🆕 (طلب صريح: "خل اللعبة تتوقف بأمر") — ينهي جولة قنبلة جارية يدويًا
   * (يُستدعى من أمر .استسلم الموجود أصلًا). يرجع true لو كان فيه جولة
   * فعلًا وتم إنهاؤها.
   */
  end(sock: WASocket, chatId: string): boolean {
    const key = this.key(sock, chatId);
    const game = this.games.get(key);
    if (!game) return false;
    if (game.roundTimer) clearTimeout(game.roundTimer);
    this.games.delete(key);
    return true;
  }

  async start(sock: WASocket, chatId: string, msg: any): Promise<void> {
    const key = this.key(sock, chatId);
    if (this.games.has(key)) {
      await sock.sendMessage(chatId, { text: "🔁 *جولة قنبلة قيد التشغيل بالفعل!*" }, { quoted: msg });
      return;
    }

    this.games.set(key, {
      started: false,
      players: [],
      activePlayers: [],
      currentHolder: null,
      roundTimer: null,
      roundTime: ROUND_MS,
    });

    const instructions =
      `╭━━━❰💣 *لعبة القنبلة* 💣❱━━━╮\n` +
      `│\n` +
      `│ 🔥 *الهدف:* لا تقع القنبلة عندك!\n` +
      `│\n` +
      `│ 📜 *التعليمات:*\n` +
      `│ 1️⃣ اكتب *شارك* للانضمام\n` +
      `│ 2️⃣ بعد اكتمال اللاعبين (عضوين على الأقل)، اكتب *بدا*\n` +
      `│ 3️⃣ القنبلة تنتقل بمنشن لاعب ثاني نشط، أو بالرد (reply) على رسالته\n` +
      `│ 4️⃣ عند انفجارها يُقفل القروب لحظيًا (المشرفون فقط)\n` +
      `│ 5️⃣ سيتم منشن الناجين بعد كل جولة\n` +
      `│ 6️⃣ آخر لاعب يبقى هو الفائز (+نقطة)!\n` +
      `│\n` +
      `│ ⚡ *جاهز؟* اكتب *شارك* الآن!\n` +
      `╰━━━━━━━━━━━━━━━━━╯`;

    await sock.sendMessage(chatId, { text: instructions }, { quoted: msg });
  }

  /**
   * يعالج رسائل نصية عادية (بدون بادئة) أثناء لعبة جارية: "شارك"، "بدا"،
   * وتمرير القنبلة بمنشن. يرجع true لو تعامل مع الرسالة، و false لو ما
   * فيه علاقة بالقنبلة (تمر عادي للمعالجة الطبيعية).
   */
  async handleMessage(sock: WASocket, chatId: string, senderJid: string, text: string, msg: any): Promise<boolean> {
    const key = this.key(sock, chatId);
    const game = this.games.get(key);
    if (!game) return false;

    const trimmed = text.trim();

    if (trimmed === "شارك") {
      if (game.started) return false; // خلص وقت الانضمام، خليها تمر عادي
      if (game.players.some((p) => digitsOnly(p) === digitsOnly(senderJid))) {
        await sock.sendMessage(chatId, { text: "❌ أنت مسجل بالفعل!" }, { quoted: msg });
      } else {
        game.players.push(senderJid);
        await sock.sendMessage(chatId, {
          text: `✅ *انضم:* ${jidToMention(senderJid)}`,
          mentions: [senderJid],
        });
      }
      return true;
    }

    if (trimmed === "بدا") {
      if (game.started) return false;
      // 🔧 تحسين حقيقي عن الأصل: لعبة "تمرير قنبلة" بشخص وحيد تنتهي فورًا
      // بلا أي تمرير فعلي — نطلب عضوين على الأقل لمعنى حقيقي للعبة.
      if (game.players.length < 2) {
        await sock.sendMessage(
          chatId,
          { text: "⚠️ تحتاج لاعبين اثنين على الأقل قبل البدء. اكتب *شارك* للانضمام." },
          { quoted: msg }
        );
        return true;
      }

      game.started = true;
      game.activePlayers = [...game.players];

      const mentionsText = game.activePlayers.map((p) => `❖ ${jidToMention(p)}`).join("\n");
      await sock.sendMessage(chatId, {
        text: `🎮 *بدأت اللعبة!*\n\n👥 *المشاركون:*\n${mentionsText}`,
        mentions: game.activePlayers,
      });

      this.nextRound(sock, chatId, key, game);
      return true;
    }

    // تمرير القنبلة: حامل القنبلة الحالي يمنشن لاعب نشط ثاني، أو يرد على
    // رسالته (reply)، بأي رسالة.
    if (game.started && game.currentHolder && digitsOnly(senderJid) === digitsOnly(game.currentHolder)) {
      const mentioned = getMentionedJids(msg);
      const repliedTo = getQuotedParticipant(msg);
      const candidates = repliedTo ? [...mentioned, repliedTo] : mentioned;

      const targetDigits = candidates
        .map(digitsOnly)
        .find((d) => d && d !== digitsOnly(game.currentHolder!) && game.activePlayers.some((p) => digitsOnly(p) === d));

      const target = targetDigits ? game.activePlayers.find((p) => digitsOnly(p) === targetDigits) : undefined;

      if (target) {
        game.currentHolder = target;
        await sock.sendMessage(chatId, {
          text: `🔄 *القنبلة انتقلت إلى:* ${jidToMention(target)}!`,
          mentions: [target],
        });
        return true;
      }
    }

    return false;
  }

  private nextRound(sock: WASocket, chatId: string, key: string, game: BombGame) {
    if (game.activePlayers.length <= 1) {
      const winner = game.activePlayers[0];
      if (winner) {
        addPoint(chatId, winner, 1);
        sock
          .sendMessage(chatId, {
            text: `🏆 *فائز القنبلة:* ${jidToMention(winner)}! 🎉 (+1 نقطة)`,
            mentions: [winner],
          })
          .catch((err) => logger.warn("فشل إرسال رسالة فوز القنبلة:", err));
      }
      this.games.delete(key);
      return;
    }

    const holder = game.activePlayers[Math.floor(Math.random() * game.activePlayers.length)];
    game.currentHolder = holder;

    sock
      .sendMessage(chatId, {
        text: `💣 *القنبلة الآن عند:* ${jidToMention(holder)}!\n⏳ منشن لاعب ثاني نشط أو رد على رسالته عشان تمررها له (30 ثانية).`,
        mentions: [holder],
      })
      .catch((err) => logger.warn("فشل إرسال دور القنبلة:", err));

    if (game.roundTimer) clearTimeout(game.roundTimer);
    game.roundTimer = setTimeout(() => this.explode(sock, chatId, key, game), game.roundTime);
  }

  private async explode(sock: WASocket, chatId: string, key: string, game: BombGame) {
    if (!game.currentHolder) return;
    const exploded = game.currentHolder;

    let locked = false;
    try {
      try {
        await sock.groupSettingUpdate(chatId, "announcement");
        locked = true;
      } catch (err) {
        logger.warn("⚠️ تعذر قفل المجموعة أثناء انفجار القنبلة (تأكد أن البوت مشرف):", err);
      }

      await sock.sendMessage(chatId, {
        text: `💥 *بـــــوووم!* 💥\nالقنبلة انفجرت عند: ${jidToMention(exploded)}`,
        mentions: [exploded],
      });

      game.activePlayers = game.activePlayers.filter((p) => digitsOnly(p) !== digitsOnly(exploded));
      game.currentHolder = null;

      if (game.activePlayers.length > 0) {
        const remainingText = game.activePlayers.map((p) => `┃ ✦ ${jidToMention(p)}`).join("\n");
        await sock.sendMessage(chatId, {
          text: `👥 *الناجون حتى الآن:*\n${remainingText}`,
          mentions: game.activePlayers,
        });
      }
    } catch (err) {
      logger.error("خطأ أثناء معالجة انفجار القنبلة:", err);
    } finally {
      // 🔧 (إصلاح فعلي: منع بقاء المجموعة مقفولة للأبد) — finally تضمن فتح
      // المجموعة دايمًا حتى لو صار خطأ بإرسال أي رسالة أعلاه.
      if (locked) {
        try {
          await sock.groupSettingUpdate(chatId, "not_announcement");
        } catch (err) {
          logger.warn("⚠️ تعذر فتح المجموعة بعد انفجار القنبلة (تأكد أن البوت مشرف):", err);
        }
      }
    }

    this.nextRound(sock, chatId, key, game);
  }
}

export const bombManager = new BombManager();
