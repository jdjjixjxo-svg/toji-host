/**
 * 🆕 لعبة "KURO SLASH" (.kuro) — قتال خفيف بالأزرار، هجوم/هجوم قوي/دفاع.
 */
import { WASocket } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { addPoint } from "../database/db";
import { CONFIG } from "../config/config";

const MAX_HP = 100;

interface Game {
  playerJid: string;
  hp: number;
  enemyHp: number;
  blocking: boolean;
  round: number;
}

const sessions = new Map<string, Game>();

function key(sock: WASocket, chatId: string, senderJid: string): string {
  return `${getBotScopeId(sock)}:${chatId}:${senderJid}`;
}

export function isRunning(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.has(key(sock, chatId, senderJid));
}

function renderScene(game: Game): Promise<Buffer> {
  const playerBar = Math.max(0, (game.hp / MAX_HP) * 180);
  const enemyBar = Math.max(0, (game.enemyHp / MAX_HP) * 180);

  const svg = `<svg width="500" height="300" xmlns="http://www.w3.org/2000/svg">
    <rect width="500" height="300" fill="#1a1a2e"/>
    <text x="100" y="180" font-size="70" text-anchor="middle">🥷</text>
    <text x="400" y="180" font-size="70" text-anchor="middle">${game.blocking ? "😤" : "👹"}</text>
    ${game.blocking ? `<text x="100" y="120" font-size="30" text-anchor="middle">🛡️</text>` : ""}

    <text x="100" y="220" font-size="14" fill="#fff" text-anchor="middle" font-family="sans-serif">أنت</text>
    <rect x="20" y="230" width="160" height="14" fill="#333"/>
    <rect x="20" y="230" width="${playerBar}" height="14" fill="#2ecc71"/>

    <text x="400" y="220" font-size="14" fill="#fff" text-anchor="middle" font-family="sans-serif">الخصم</text>
    <rect x="320" y="230" width="160" height="14" fill="#333"/>
    <rect x="320" y="230" width="${enemyBar}" height="14" fill="#e74c3c"/>

    <text x="20" y="30" font-size="18" fill="#f1c40f" font-family="monospace" font-weight="bold">جولة: ${game.round}</text>
  </svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendScene(sock: WASocket, chatId: string, game: Game, message: string): Promise<void> {
  const image = await renderScene(game);
  const rows = [
    { command: "kuro_attack", label: "⚔️ هجوم عادي" },
    { command: "kuro_heavy", label: "💥 هجوم قوي" },
    { command: "kuro_block", label: "🛡️ دفاع" },
  ];
  await sendButtonMessage(sock, chatId, {
    text: `🥷 *KURO SLASH* — ${jidToMention(game.playerJid)}\n\n${message}`,
    mentions: [game.playerJid],
    image,
    extraButtons: [buildSingleSelectButton("⚔️ هجومك", "اختر حركتك", rows)],
  });
}

export async function start(sock: WASocket, chatId: string, senderJid: string): Promise<void> {
  const k = key(sock, chatId, senderJid);
  const game: Game = { playerJid: senderJid, hp: MAX_HP, enemyHp: MAX_HP, blocking: false, round: 1 };
  sessions.set(k, game);
  await sendScene(sock, chatId, game, "⚔️ بدأت المبارزة! اختر حركتك.");
}

async function gameOver(sock: WASocket, chatId: string, senderJid: string, game: Game, won: boolean): Promise<void> {
  sessions.delete(key(sock, chatId, senderJid));
  if (won) addPoint(chatId, senderJid, 2);
  await sock.sendMessage(chatId, {
    text: won ? `🏆 *فزت بالمبارزة!* بعد ${game.round} جولة (+2 نقطة)` : `💀 *خسرت المبارزة.* بعد ${game.round} جولة`,
  });
}

export async function handleMove(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId, senderJid);
  const game = sessions.get(k);
  if (!game) return false;

  const trimmed = text.trim();
  const withoutPrefix = trimmed.startsWith(CONFIG.PREFIX) ? trimmed.slice(CONFIG.PREFIX.length) : trimmed;

  let move: "attack" | "heavy" | "block" | null = null;
  if (withoutPrefix === "kuro_attack" || withoutPrefix === "هجوم") move = "attack";
  else if (withoutPrefix === "kuro_heavy" || withoutPrefix === "هجوم_قوي") move = "heavy";
  else if (withoutPrefix === "kuro_block" || withoutPrefix === "دفاع") move = "block";
  else return false;

  let message = "";
  game.round++;
  game.blocking = false;

  if (move === "block") {
    game.blocking = true;
    message = "🛡️ رفعت دفاعك — الضربة الجاية عليك أضعف.";
  } else {
    const isHeavy = move === "heavy";
    const hitChance = isHeavy ? 0.55 : 0.8;
    if (Math.random() < hitChance) {
      const dmg = isHeavy ? 20 + Math.floor(Math.random() * 15) : 8 + Math.floor(Math.random() * 8);
      game.enemyHp -= dmg;
      message = `${isHeavy ? "💥 هجوم قوي أصاب!" : "⚔️ ضربة موفّقة!"} -${dmg} من صحة الخصم.`;
    } else {
      message = isHeavy ? "😤 الهجوم القوي أخطأ!" : "💨 الضربة أخطأت.";
    }
  }

  if (game.enemyHp <= 0) {
    await gameOver(sock, chatId, senderJid, game, true);
    return true;
  }

  // رد الخصم
  const enemyHeavy = Math.random() < 0.25;
  const enemyHit = Math.random() < (enemyHeavy ? 0.5 : 0.75);
  if (enemyHit) {
    let dmg = enemyHeavy ? 18 + Math.floor(Math.random() * 12) : 6 + Math.floor(Math.random() * 8);
    if (game.blocking) dmg = Math.floor(dmg * 0.35);
    game.hp -= dmg;
    message += `\n${enemyHeavy ? "👹 الخصم هاجم بقوة!" : "👹 رد الخصم!"} -${dmg} من صحتك.`;
  } else {
    message += "\n👻 هجوم الخصم أخطأ!";
  }

  if (game.hp <= 0) {
    await gameOver(sock, chatId, senderJid, game, false);
    return true;
  }

  await sendScene(sock, chatId, game, message);
  return true;
}

export function end(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.delete(key(sock, chatId, senderJid));
}
