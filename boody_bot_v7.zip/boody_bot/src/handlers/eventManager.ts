import { WASocket, WAMessage } from "@whiskeysockets/baileys";
import { addPoint } from "../database/db";
import { jidToMention, getBotScopeId } from "../utils/helpers";
import { normalizeAnswerText } from "../utils/arabicNormalize";

interface ActiveEvent {
  alts: string[]; // 🆕 إجابات بديلة مقبولة (بعد normalizeAnswerText)
  answer: string; // الإجابة الصحيحة بعد التسامح بالمطابقة (normalizeAnswerText) — تُستخدم للمقارنة فقط
  rawAnswer: string; // الإجابة الأصلية كما هي (بشكلها الصحيح المقروء) — تُستخدم للعرض فقط
  title: string; // اسم الفعالية للعرض
  startedAt: number;
  timeoutMs: number;
  timer: NodeJS.Timeout;
}

/**
 * يدير كل الفعاليات الجارية حاليًا في كل المجموعات (Map: "botId:chatId" -> ActiveEvent)
 * تصميم بسيط وقابل لإعادة الاستخدام من أي فعالية (خمن الدولة، الشخصية، الحيوان...).
 *
 * 🔧 (عزل البوتات الفرعية) — المفتاح كان "chatId" فقط، فلو أكثر من بوت
 * (رئيسي + فرعي/فرعيين) بنفس المجموعة، فعالية بدأها بوت واحد كانت تُعتبر
 * "جارية" لكل البوتات الأخرى بنفس المجموعة (وتُحل بإجابة توصل لأي واحد
 * منهم) بدل أن يكون لكل بوت فعاليته المستقلة تمامًا. الحل: المفتاح صار
 * `${botId}:${chatId}` عبر getBotScopeId(sock) — راجع helpers.ts.
 */
class EventManager {
  private active: Map<string, ActiveEvent> = new Map();

  private key(sock: WASocket, chatId: string): string {
    return `${getBotScopeId(sock)}:${chatId}`;
  }

  isRunning(sock: WASocket, chatId: string): boolean {
    return this.active.has(this.key(sock, chatId));
  }

  /** يبدأ فعالية جديدة في مجموعة معينة (خاصة بهذا البوت فقط) */
  start(
    sock: WASocket,
    chatId: string,
    title: string,
    answer: string,
    timeoutMs = 60_000,
    alternates: string[] = []
  ) {
    const key = this.key(sock, chatId);
    if (this.active.has(key)) return false;

    const timer = setTimeout(async () => {
      if (this.active.get(key)) {
        await sock.sendMessage(chatId, {
          text: `⌛ انتهى وقت فعالية *${title}*!\nالإجابة الصحيحة كانت: *${answer}*`,
        });
        this.active.delete(key);
      }
    }, timeoutMs);

    this.active.set(key, {
      alts: alternates.map((a) => normalizeAnswerText(a)).filter(Boolean),
      answer: normalizeAnswerText(answer),
      rawAnswer: answer.trim(),
      title,
      startedAt: Date.now(),
      timeoutMs,
      timer,
    });
    return true;
  }

  /** يفحص إن كانت رسالة معينة تطابق إجابة فعالية جارية بهذا البوت بالذات، ويكافئ الفائز تلقائيًا */
  async checkAnswer(
    sock: WASocket,
    chatId: string,
    senderJid: string,
    text: string,
    // 🆕 (طلب صريح: "خلي أي رد من البوت للفعاليات يكون رد فعلي على
    // الرسالة، مو رسالة عائمة محد يعرف مين بعتها") — نمرر رسالة الإجابة
    // نفسها هنا لو متوفرة، حتى يظهر تأكيد الفوز كـ"رد" فعلي عليها.
    quotedMsg?: WAMessage
  ): Promise<boolean> {
    const key = this.key(sock, chatId);
    const event = this.active.get(key);
    if (!event) return false;

    const normalized = normalizeAnswerText(text);
    if (!normalized || (normalized !== event.answer && !event.alts.includes(normalized))) return false;

    clearTimeout(event.timer);
    this.active.delete(key);
    addPoint(chatId, senderJid, 1);

    await sock.sendMessage(
      chatId,
      {
        text: `🎉 إجابة صحيحة!\n🏆 الفائز: ${jidToMention(senderJid)}\n✨ تم إضافة نقطة له في فعالية *${event.title}*`,
        mentions: [senderJid],
      },
      quotedMsg ? { quoted: quotedMsg } : undefined
    );
    return true;
  }

  stop(sock: WASocket, chatId: string): boolean {
    const key = this.key(sock, chatId);
    const event = this.active.get(key);
    if (!event) return false;
    clearTimeout(event.timer);
    this.active.delete(key);
    return true;
  }

  /** يوقف الفعالية الجارية بهذا البوت ويرجع عنوانها وإجابتها الصحيحة (يُستخدم بأمر .استسلم) */
  revealAndStop(sock: WASocket, chatId: string): { title: string; answer: string } | null {
    const key = this.key(sock, chatId);
    const event = this.active.get(key);
    if (!event) return null;
    clearTimeout(event.timer);
    this.active.delete(key);
    return { title: event.title, answer: event.rawAnswer };
  }
}

export const eventManager = new EventManager();
