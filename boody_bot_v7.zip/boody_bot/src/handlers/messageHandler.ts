import { WASocket, WAMessage, GroupMetadata } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { commandRegistry } from "./commandRegistry";
import { checkPermission, isOwner, isGroupAdmin } from "../middlewares/permissions";
import { runProtection } from "../middlewares/protection";
import { runFriendHooks, tryGlobalAutoReply, getFriendCfg } from "../utils/friendUtils";
import { eventManager } from "./eventManager";
import { ticTacToeManager } from "./ticTacToeManager";
import { hasActiveStory, handleStoryChoice } from "./storyManager";
import { bombManager } from "./bombManager";
import { isRunning as isHangmanRunning, handleGuess as handleHangmanGuess } from "./hangmanManager";
import { isRunning as isSecretNumberRunning, handleGuess as handleSecretNumberGuess } from "./secretNumberManager";
import { isRunning as isSpeedRunning, handleMessage as handleSpeedMessage } from "./speedReactionManager";
import { isRunning as isWordChainRunning, handleWord as handleWordChain } from "./wordChainManager";
import { isRunning as isPasswordRunning, handleGuess as handlePasswordGuess } from "./passwordGameManager";
import { isRunning as isDinoRunning, handleStep as handleDinoStep } from "./dinoManager";
import { isRunning as isFpsRunning, handleAction as handleFpsAction } from "./fpsManager";
import { isRunning as isMazeRunning, handleAction as handleMazeAction } from "./mazeManager";
import { isSuggestionPending, cancelSuggestion, submitSuggestion } from "./suggestManager";
import { isRunning as isRaceRunning, handleMove as handleRaceMove } from "./raceManager";
import { isRunning as isKuroRunning, handleMove as handleKuroMove } from "./kuroManager";
import { hasActivePortal, handlePortalChoice } from "./portalManager";
import { isBlocked, isMuted, db, getGroupSettings, isSectionDisabled, isBotEnabledInGroup, addXpWithCooldown, getPermissionOverride } from "../database/db";
import { extractMessageText, getQuotedMessage, containsWordStartingWith, isGreeting, isSalawatTrigger, resolveGroupJid, getBotScopeId, digitsOnly, stripDiacritics } from "../utils/helpers";
import { FUN_REPLIES, pickRandomReply, SALAWAT_REPLIES, HOW_ARE_YOU_REPLY, isHowAreYouTrigger, DISABLED_INSULT_REPLY, isDisabledInsultTrigger, isGenericInsultTrigger, GENERIC_INSULT_ROASTS } from "../utils/funReplies";
import { matchQuickReply, matchMentionQuickReply, matchAhatCounter } from "../utils/quickReplies";
import { matchButtonTrigger, createBrandedSock } from "../utils/interactive";
import { handleKickDecisionButton } from "./kickDecisionManager";
import { getMenuVideoBuffer } from "../utils/media";
import { msgContextStore } from "../utils/msgContext";
import { logger } from "../utils/logger";
import { CommandContext, MessageHandlerOptions } from "./types";
import { recordMessageKey } from "./recentMessages";
import { checkCommandNag } from "../utils/commandNagger";
import { getGroupCache, setGroupCache } from "../utils/groupCache";

const CACHE_TTL = 60_000;

// ===== 🛡️ تحكم بالحمل (استضافة 308MB): فاصل بين أوامر نفس الشخص + حد أقصى لعدد الأوامر المتزامنة =====
const COMMAND_COOLDOWN_MS = 800;
const lastCommandAt = new Map<string, number>();
const MAX_CONCURRENT_COMMANDS = 8;
// أي أمر يتجاوز هذي المدة يُفرج عن مكانه فورًا حتى لا يعلّق باقي الأوامر (السبب الأشيع لـ"البوت ما يرد")
const COMMAND_TIMEOUT_MS = 120_000;
let runningCommands = 0;
const waitingCommands: Array<() => void> = [];
async function runLimited<T>(fn: () => Promise<T>): Promise<T> {
  if (runningCommands >= MAX_CONCURRENT_COMMANDS) {
    await new Promise<void>((resolve) => waitingCommands.push(resolve));
  }
  runningCommands++;
  try {
    return await fn();
  } finally {
    runningCommands--;
    waitingCommands.shift()?.();
  }
}

// إيموجيات تفاعل تأكيد تنفيذ الأمر — يُختار واحد عشوائيًا في كل مرة
const REACTION_EMOJIS = ["🌸", "👑", "🔥", "🇮🇶", "🌑"];

// 🔧 إصلاح جذري (سبب رئيسي لشكوى "أي أمر ياخذ دقيقة أو أكثر"): كل رسالة
// بمجموعة تمر من هنا أولًا لجلب بيانات المجموعة قبل أي معالجة ثانية.
// قبل هذا الإصلاح كان أي انتهاء صلاحية للكاش (CACHE_TTL = دقيقة) يعمل
// `await sock.groupMetadata(chatId)` مباشرة بدون أي مهلة خاصة — وBaileys
// مضبوط بـdefaultQueryTimeoutMs=60000 (دقيقة كاملة) بملف index.ts، فلو
// تأخر رد واتساب لهذا الطلب تحديدًا (شائع على استضافات محدودة الموارد أو
// اتصال غير مستقر)، الرسالة *كلها* — قبل ما تُطبع أي سطر لوق للأمر نفسه —
// تنتظر لين دقيقة كاملة أو حتى ترمي خطأ. المشكلة تتضاعف لو وصلت عدة رسائل
// بنفس اللحظة بنفس المجموعة (نادرًا ما تُعالج بالتوازي الآن): كل وحدة كانت
// ترسل طلب شبكة منفصل لنفس المجموعة بدل ما تتشارك طلب واحد.
//
// الحل: (1) طلبات متزامنة لنفس المجموعة تتشارك نفس الـPromise بدل تكرارها،
// و(2) مهلة قصيرة (8 ثواني) بدل انتظار الدقيقة الكاملة — لو انتهت، نرجع
// أي نسخة قديمة مخزّنة مؤقتًا (حتى لو منتهية الصلاحية) بدل التجميد.
const inflightGroupMetadata = new Map<string, Promise<GroupMetadata>>();
const GROUP_METADATA_FETCH_TIMEOUT_MS = 8_000;

async function fetchGroupMetadataSafe(sock: WASocket, chatId: string): Promise<GroupMetadata> {
  let promise = inflightGroupMetadata.get(chatId);
  if (!promise) {
    promise = sock.groupMetadata(chatId);
    inflightGroupMetadata.set(chatId, promise);
    promise.finally(() => inflightGroupMetadata.delete(chatId));
  }

  try {
    const data = await Promise.race([
      promise,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("group metadata fetch timeout (8s)")), GROUP_METADATA_FETCH_TIMEOUT_MS)
      ),
    ]);
    setGroupCache(chatId, data);
    return data;
  } catch (err) {
    // أي نسخة قديمة أفضل من التجميد لدقيقة كاملة — نتجاهل TTL هنا عمدًا
    const stale = getGroupCache(chatId, Number.POSITIVE_INFINITY);
    if (stale) return stale;
    throw err;
  }
}

async function getGroupMetadataCached(sock: WASocket, chatId: string) {
  const cached = getGroupCache(chatId, CACHE_TTL);
  if (cached) return cached;
  return fetchGroupMetadataSafe(sock, chatId);
}

export async function handleIncomingMessage(
  sock: WASocket,
  msg: WAMessage,
  // 🆕 (ميزة .تنصيب) — options.subBot === true تعني أن sock هنا هو مقبس
  // بوت فرعي (raw، مو الرئيسي)، راجع handlers/subBotManager.ts. اختياري
  // بالكامل ولا يغيّر أي سلوك قديم إطلاقًا لو ما مرّرناه (البوت الرئيسي
  // بـ index.ts يستدعي هذي الدالة بدون هذا الوسيط تمامًا كما كان).
  options?: MessageHandlerOptions
) {
  try {
    if (!msg.message) return;

    const chatId = msg.key.remoteJid;
    if (!chatId) return;

    const isGroup = chatId.endsWith("@g.us");

    // 🆕 (أمر .محي <رقم>) — نسجّل مفتاح كل رسالة جماعية توصل (أي نوع:
    // نص/وسائط/ملصق) بذاكرة مؤقتة قبل أي فحص/بوابة ثانية، حتى لو الرسالة
    // نفسها لن تُعالج لاحقًا (بوت متوقف بهذي المجموعة مثلًا) — بما إن
    // الحذف نفسه إجراء واتساب حقيقي منفصل تمامًا عن معالجة الأوامر.
    if (isGroup) recordMessageKey(sock, chatId, msg);

    // 🔧 إصلاح (سبب "امر كتم يحذف بس النصوص، مو الستيكرات/الفيديوهات..."):
    // قبل كذا كان فيه "if (!rawText) return;" هنا مباشرة — أي إن أي رسالة
    // بدون نص قابل للاستخراج (ستيكر، فيديو/صورة بدون كابشن، صوت، ملف...)
    // كانت تخرج من الدالة *قبل* ما توصل أصلًا لفحص "هل المرسل مكتوم؟"
    // بالأسفل، فتنجو من الحذف التلقائي رغم إن صاحبها مكتوم. الحل: نأجّل
    // هذا الفحص لبعد فحص الكتم مباشرة (تحت)، حتى تنحذف رسائل المكتوم
    // بكل أنواعها، وتبقى بقية المعالجة (الأوامر/الردود التلقائية...) اللي
    // فعليًا تحتاج نص متجاهلة لهذي الرسائل الخالية من النص متل ما كانت.
    const rawText = extractMessageText(msg);

    // ===== ضغطة زر قسم (من المنيو): واتساب يرسل نص الزر نفسه لا أي
    // معرّف داخلي، فنطابقه بجدول الأزرار المسجّلة ونحوّله لأمر حقيقي
    // بالبادئة تمامًا كأن المستخدم كتبه يدويًا. غير موجود؟ يبقى النص كما هو.
    const buttonCommand = matchButtonTrigger(rawText);
    const text = buttonCommand ? `${CONFIG.PREFIX}${buttonCommand}` : rawText;

    // تشخيص: لو الرسالة وصلت فعليًا كضغطة زر تفاعلي (interactiveResponseMessage)
    // ولم نطابقها بأي أمر، نسجّل ذلك بالـ logger — يساعد لاحقًا لمعرفة سبب
    // عدم استجابة زر معيّن بدل ما يضيع بصمت.
    if (!buttonCommand && msg.message?.interactiveResponseMessage) {
      logger.warn(`ضغطة زر لم تُطابَق بأي أمر. النص المستلم: "${rawText}"`);
    }

    // ===== الرسائل الصادرة من رقم البوت نفسه (fromMe) =====
    // تحدث عندما يكتب المالك رسالة من نفس الجوال المرتبط بالبوت. نسمح بمعالجتها
    // كأوامر ذاتية (SELF_COMMANDS) حتى يستطيع المالك اختبار/استخدام البوت من
    // رقمه نفسه دون الحاجة لرقم ثانٍ. غير الأوامر بالبادئة، نسمح كمان بمرور
    // كلمات التفعيل التلقائي (بوتي/ملل/سلام...) — قبل كذا كانت محصورة
    // بالبادئة بس، فهذي الكلمات ما كانت تشتغل أبدًا من رقم البوت نفسه.
    let senderJid: string;
    if (msg.key.fromMe) {
      if (!CONFIG.SELF_COMMANDS) return;
      const isCommandText = text.startsWith(CONFIG.PREFIX);
      // 🔧 إصلاح: رد "انا مطورك" ما كان يوصل أبدًا لو المطور نفسه جربه من
      // رقم البوت (fromMe) — لأن هذا الفلتر كان يوقف أي رسالة مو أمر ومو
      // ردود الفرفشة المعتادة قبل ما توصل لمعالج "انا مطورك" لاحقًا بالكود.
      const isDeveloperClaim = /^انا\s*مطورك(\s*يا\s*حمار)?/.test(text.trim());
      const isFunTrigger =
        isGreeting(text) ||
        isSalawatTrigger(text) ||
        isHowAreYouTrigger(text) ||
        isDeveloperClaim ||
        Object.keys(FUN_REPLIES).some((prefix) => containsWordStartingWith(text, prefix));
      // 🔧 إصلاح مهم (سبب "المطور ما يقدر يلعب بالفعاليات لو البوت مربوط
      // برقمه هو نفسه"): كان هذا الفلتر يرفض أي رسالة مو أمر (تبدأ بالبادئة)
      // ومو ضمن ردود الفرفشة المعروفة — فإجابة على سؤال فعالية جارية (مثل
      // كتابة "مصر" ردًا على .فعالية دول) أو رقم خانة بلعبة .إكس_أو كانت
      // تُرفض هنا وتُحذف بصمت *قبل* ما توصل أصلًا لفحص الفعالية/اللعبة
      // الجارية بالأسفل — فيبدو إن المطور "ما يقدر يلعب" رغم إن كل شي
      // مفعّل صح. نتحقق هنا أيضًا: لو فيه فعالية أو لعبة إكس أو جارية
      // فعليًا بهذا الشات، نسمح للرسالة تمر بغض النظر عن شكلها.
      const hasRunningGame =
        isGroup && (eventManager.isRunning(sock, chatId) || ticTacToeManager.isRunning(sock, chatId) || bombManager.isRunning(sock, chatId) || isHangmanRunning(sock, chatId) || isSecretNumberRunning(sock, chatId) || isSpeedRunning(sock, chatId) || isWordChainRunning(sock, chatId) || isPasswordRunning(sock, chatId));
      if (!isCommandText && !isFunTrigger && !hasRunningGame) return;
      // 🔧 إصلاح (v1.1.4): قبل كذا كانت تُنسب دائمًا لـ CONFIG.OWNER_JID
      // (رقم المالك بالـ.env) حتى لو رقم البوت المتصل فعليًا مختلف تمامًا
      // عنه — فكان "المطور" ما يُتعرَّف عليه صح إلا لو ربط البوت بنفس
      // رقمه. الصح: senderJid لرسالة fromMe هو رقم البوت *الفعلي* نفسه
      // (sock.user.id)، و isOwner() الآن تتعرف على رقم البوت هذا تلقائيًا
      // كمطور بشكل مستقل تمامًا عن CONFIG.OWNER_NUMBER (راجع botIdentity.ts).
      senderJid = sock.user?.id || CONFIG.OWNER_JID;
    } else {
      senderJid = isGroup ? msg.key.participant || "" : chatId;
    }
    if (!senderJid) return;

    // 🔧 (سبب شكوى "الأوامر اللي تبدأ بنقطة ما تطلع أي شي بالكونسول") —
    // قبل هذا السطر، أول لوق يُطبع لأي أمر كان logger.command() بالأسفل
    // (بعد عشرات الفحوصات: جلب بيانات المجموعة، الحماية، الفعاليات...).
    // لو أي خطوة من هذي علّقت أو رجعت مبكرًا بصمت (بوت موقوف بالمجموعة،
    // خطأ بجلب بيانات المجموعة قبل الإصلاح أعلاه...)، ما كان يطبع أي شي
    // إطلاقًا فيبدو تمامًا كأن الرسالة "ما وصلت" للبوت. الآن نطبع فورًا
    // بمجرد ما نتعرف إن الرسالة تبدأ بالبادئة، قبل أي خطوة يمكن تتأخر.
    if (text.startsWith(CONFIG.PREFIX) && text.trim().length > CONFIG.PREFIX.length) {
      logger.info(`📥 استلمنا رسالة أمر محتملة: "${text.trim()}" من ${senderJid}${isGroup ? ` بمجموعة ${chatId}` : ""}`);
    }

    let metadata: GroupMetadata | null = null;
    if (isGroup) {
      try {
        metadata = await getGroupMetadataCached(sock, chatId);
      } catch (err) {
        logger.warn("تعذر جلب بيانات المجموعة.", err);
      }
    }

    // 🔧 إصلاح: نوحّد senderJid فورًا (رقم حقيقي بدل @lid المؤقت لو توفر)
    // حتى تتطابق أي عملية تخزين لاحقة تعتمد عليه (نقاط الفعاليات، صلاحية
    // المشرف/المطور...) مع نفس المفتاح دايمًا بغض النظر عن الصيغة اللي
    // وصلت فيها هذي الرسالة بالذات — راجع تعليق resolveGroupJid بالتفصيل.
    if (isGroup && metadata) {
      senderJid = resolveGroupJid(senderJid, metadata);
    }

    // ===== الوضع الخاص: البوت يستجيب للمالك فقط =====
    const publicMode = db.get("bot.publicMode").value();
    if (!publicMode && !isOwner(senderJid, metadata || undefined)) return;

    // ===== إيقاف/تشغيل البوت داخل مجموعة محددة (.ايقاف / .تشغيل) =====
    // 🔧 (طلب صريح: "لو 3 بواتات بكروب واحد كتب .ايقاف ما يوقفن 3 بس
    // بوته") — الفحص صار مرتبطًا بهوية البوت الحالي (isBotEnabledInGroup)
    // بدل حقل "enabled" المشترك القديم، فإيقاف بوت معيّن لا يؤثر على
    // البوت الرئيسي ولا على بقية البوتات الفرعية بنفس المجموعة إطلاقًا.
    // لو المجموعة موقوفة لهذا البوت بالذات، نتجاهل كل شي تمامًا
    // (حماية/فعاليات/أوامر/ردود تلقائية) إلا أمر ".تشغيل" نفسه، وفقط لو
    // كاتبه المطور الحقيقي أو صاحب رقم هذا البوت بالذات (راجع isOwner
    // بـpermissions.ts للتفصيل الكامل لمفهوم "مطور هذا البوت").
    if (isGroup) {
      const botId = getBotScopeId(sock);
      if (!isBotEnabledInGroup(chatId, botId)) {
        const cmdWord = text.startsWith(CONFIG.PREFIX)
          ? text.slice(CONFIG.PREFIX.length).trim().split(/\s+/)[0]
          : "";
        const isUnlockCommand = commandRegistry.get(cmdWord)?.name === "تشغيل";
        if (!isUnlockCommand || !isOwner(senderJid, metadata || undefined, sock)) return;
      }
    }

    // ===== 🆕 تعطيل خاص بالبوتات الفرعية فقط داخل مجموعة معيّنة =====
    // (.تعطيل_بوت / .تفعيل_بوت — راجع src/commands/install/disableSubBots.ts)
    // منفصل تمامًا عن فحص "enabled" أعلاه: هذا يوقف فقط الرسائل الجايّة من
    // مقبس بوت فرعي (options.subBot) بهذي المجموعة بالذات، ولا يؤثر إطلاقًا
    // على البوت الرئيسي (اللي يستمر يشتغل طبيعيًا بنفس المجموعة)، ولا على
    // أي بوت فرعي بأي مجموعة أخرى (كل مجموعة بمفتاح subBotsEnabled خاص فيها).
    if (isGroup && options?.subBot) {
      const subBotGroupSettings = getGroupSettings(chatId);
      if (subBotGroupSettings.subBotsEnabled === false) return;
    }

    // ===== المستخدمون المكتومون: تُحذف رسائلهم مباشرة =====
    if (isGroup && isMuted(chatId, senderJid)) {
      try {
        await sock.sendMessage(chatId, { delete: msg.key });
      } catch (err) {
        // 🔧 قبل كذا كان الخطأ هنا يُبتلع بصمت تمامًا (بدون أي تسجيل)، فلو
        // فشل الحذف لأي سبب (البوت مو مشرف، الرسالة قديمة...) ما فيه أي
        // أثر يوضح السبب — يبدو تمامًا كأن ".كتم" "ما يشتغل" بدون تفسير.
        logger.warn("فشل حذف رسالة عضو مكتوم (تأكد أن البوت مشرف):", err);
      }
      return;
    }

    // ===== لا يوجد نص قابل للاستخراج (ستيكر/وسائط بدون كابشن...) =====
    // ولم يكن المرسل مكتومًا (وإلا كانت انحذفت أعلاه) — بقية المعالجة
    // بالأسفل (أوامر/حماية روابط/فعاليات/ردود تلقائية) كلها تعتمد على
    // نص فعلي، فما فيه داعي نكمّل من دونه.
    // ===== 🆕 حماية/غياب/نشاط إضافي (منع ميديا/ملصقات/كلمات/بوتات، .مود، .منع_بوت، .اختفاء) =====
    if (isGroup && metadata) {
      const friendHandled = await runFriendHooks(sock, chatId, senderJid, msg, rawText, metadata);
      if (friendHandled) return;
    }

    if (!rawText) return;

    // ===== 🆕 ضغطة أحد أزرار "قرار الطرد" (بعد 3 نذارات) =====
    // نتحقق منها هنا مباشرة (قبل الحماية/الأوامر/أي شي ثاني) لأنها قرار
    // مشرف حساس بالوقت ولازم تُعالج فورًا، وحتى لا تمر بفلاتر الحماية أو
    // تُفسَّر كأمر عادي. لو مو ضغطة زر قرار (أو ما فيه قرار معلّق أصلًا)
    // ترجع false وتكمل بقية المعالجة العادية بدون أي تأثير.
    if (isGroup && metadata) {
      const decisionHandled = await handleKickDecisionButton(sock, chatId, senderJid, text, metadata);
      if (decisionHandled) return;
    }

    // ===== نظام الحماية (روابط/سبام) — يعمل فقط داخل المجموعات =====
    if (isGroup && metadata) {
      const handled = await runProtection(sock, chatId, senderJid, msg, text, metadata);
      if (handled) return;
    }

    // ===== فحص إجابات الفعاليات الجارية =====
    if (isGroup && eventManager.isRunning(sock, chatId)) {
      const wasAnswer = await eventManager.checkAnswer(sock, chatId, senderJid, text, msg);
      if (wasAnswer) return;
    }

    // ===== فحص حركات لعبة إكس أو الجارية =====
    if (isGroup && ticTacToeManager.isRunning(sock, chatId)) {
      const wasMove = await ticTacToeManager.handleMove(sock, chatId, senderJid, text);
      if (wasMove) return;
    }

    // ===== 🆕 فحص رسائل لعبة القنبلة الجارية (شارك/بدا/تمرير القنبلة) =====
    if (isGroup && bombManager.isRunning(sock, chatId)) {
      const wasBombMsg = await bombManager.handleMessage(sock, chatId, senderJid, text, msg);
      if (wasBombMsg) return;
    }

    // ===== 🆕 فحص تخمين حرف بلعبة المشنقة الجارية =====
    if (isGroup && isHangmanRunning(sock, chatId)) {
      const wasGuess = await handleHangmanGuess(sock, chatId, senderJid, text);
      if (wasGuess) return;
    }

    // ===== 🆕 فحص تخمين رقم بلعبة الرقم السري الجارية =====
    if (isGroup && isSecretNumberRunning(sock, chatId)) {
      const wasGuess = await handleSecretNumberGuess(sock, chatId, senderJid, text);
      if (wasGuess) return;
    }

    // ===== 🆕 فحص رسالة بلعبة "من الأسرع" الجارية =====
    if (isGroup && isSpeedRunning(sock, chatId)) {
      const wasHandled = await handleSpeedMessage(sock, chatId, senderJid);
      if (wasHandled) return;
    }

    // ===== 🆕 فحص محاولة بلعبة السلسلة الجارية =====
    if (isGroup && isWordChainRunning(sock, chatId)) {
      const wasWord = await handleWordChain(sock, chatId, senderJid, text);
      if (wasWord) return;
    }

    // ===== 🆕 فحص تخمين بلعبة كلمة السر الجارية =====
    if (isGroup && isPasswordRunning(sock, chatId)) {
      const wasGuess = await handlePasswordGuess(sock, chatId, senderJid, text);
      if (wasGuess) return;
    }

    // ===== 🆕 فحص اختيار مغامرة .قصة الجارية (لعبة واحدة فقط بكل شات) =====
    if (hasActiveStory(chatId)) {
      const wasChoice = await handleStoryChoice(sock, chatId, senderJid, text);
      if (wasChoice) return;
    }

    // ===== 🆕 فحص اختيار لعبة .بوابه الجارية (شخصية لكل شخص لحاله) =====
    if (hasActivePortal(chatId, senderJid)) {
      const reply = handlePortalChoice(chatId, senderJid, text);
      if (reply) {
        await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
        return;
      }
    }

    // ===== 🆕 فحص خطوة بلعبة Dino الجارية (شخصية لكل شخص لحاله) =====
    if (isDinoRunning(sock, chatId, senderJid)) {
      const wasStep = await handleDinoStep(sock, chatId, senderJid, text);
      if (wasStep) return;
    }

    // ===== 🆕 فحص حركة بلعبة FPS الجارية (شخصية لكل شخص لحاله) =====
    if (isFpsRunning(sock, chatId, senderJid)) {
      const wasAction = await handleFpsAction(sock, chatId, senderJid, text);
      if (wasAction) return;
    }

    // ===== 🧊 فحص حركة بلعبة متاهة 3D الجارية =====
    if (isMazeRunning(sock, chatId, senderJid)) {
      const wasMove = await handleMazeAction(sock, chatId, senderJid, text);
      if (wasMove) return;
    }

    // ===== 🆕 فحص حركة بلعبة السباق الجارية (شخصية لكل شخص لحاله) =====
    if (isRaceRunning(sock, chatId, senderJid)) {
      const wasMove = await handleRaceMove(sock, chatId, senderJid, text);
      if (wasMove) return;
    }

    // ===== 🆕 فحص حركة بلعبة KURO الجارية (شخصية لكل شخص لحاله) =====
    if (isKuroRunning(sock, chatId, senderJid)) {
      const wasMove = await handleKuroMove(sock, chatId, senderJid, text);
      if (wasMove) return;
    }

    // ===== ♟️ نقلة شطرنج مكتوبة مباشرة بدون نقطة (e2e4 / Nf3) أثناء لعبة جارية =====
    if (isGroup && !text.startsWith(CONFIG.PREFIX)) {
    }

    // ===== 💡 استقبال اقتراح أمر (بعد ضغط زر «اقتراح أمر»): أول رسالة عادية من نفس الشخص =====
    if (!text.startsWith(CONFIG.PREFIX) && text.trim() && isSuggestionPending(sock, chatId, senderJid)) {
      cancelSuggestion(sock, chatId, senderJid);
      const res = await submitSuggestion(
        sock,
        { chatId, sender: senderJid, pushName: msg.pushName || undefined, groupName: isGroup ? metadata?.subject : undefined, isSubBot: !!options?.subBot },
        text
      );
      await sock.sendMessage(
        chatId,
        { text: res.ok ? "✅ وصل اقتراحك للمطور. شكرًا لك، هالأفكار هي اللي تكبّر البوت 🚀" : `⚠️ ${res.reason}` },
        { quoted: msg }
      );
      return;
    }

    // ===== رد تلقائي: تحية "سلام" → "وعليكم السلام" =====
    // بالكروب مربوط بإعداد "الردود_التلقائية" (كان موجود بقاعدة البيانات
    // بدون أي كود يستخدمه فعليًا) حتى يتحكم المشرف فيه، وبالخاص شغّال دايمًا.
    if (!text.startsWith(CONFIG.PREFIX) && isGreeting(text)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      if (!isGroup || settings?.autoReply) {
        try {
          await sock.sendMessage(
            chatId,
            { text: "وعليكم السلام ورحمة الله وبركاته 🌹" },
            { quoted: msg }
          );
        } catch (err) {
          logger.error("فشل إرسال رد السلام:", err);
        }
        return;
      }
    }

    // ===== رد تلقائي: طلب "صلوا على النبي" ﷺ =====
    if (!text.startsWith(CONFIG.PREFIX) && isSalawatTrigger(text)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      if (!isGroup || settings?.autoReply) {
        try {
          const reply = SALAWAT_REPLIES[Math.floor(Math.random() * SALAWAT_REPLIES.length)];
          await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
        } catch (err) {
          logger.error("فشل إرسال رد الصلاة على النبي ﷺ:", err);
        }
        return;
      }
    }

    // ===== رد تلقائي: "كيف حالكم" / "كيف الحال" =====
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX) && isHowAreYouTrigger(text)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      if (!isGroup || settings?.autoReply) {
        try {
          await sock.sendMessage(chatId, { text: HOW_ARE_YOU_REPLY }, { quoted: msg });
        } catch (err) {
          logger.error("فشل إرسال رد كيف الحال:", err);
        }
        return;
      }
    }

    // ===== رد تلقائي: "بوت معاق" / "بوت معوق" (وأي ترتيب مشابه) =====
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX) && isDisabledInsultTrigger(text)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      if (!isGroup || settings?.autoReply) {
        try {
          await sock.sendMessage(chatId, { text: DISABLED_INSULT_REPLY }, { quoted: msg });
        } catch (err) {
          logger.error("فشل إرسال رد (بوت معاق/معوق):", err);
        }
        return;
      }
    }

    // 🆕 (طلب صريح: "خليه يرد على الكلام الساخر") — رد ساخر لأي شتيمة عامة
    // للبوت (غبي/تافه/خرا بوت...) — كلام فقط، بدون أي طرد/كتم حقيقي.
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX) && isGenericInsultTrigger(text)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      if (!isGroup || settings?.autoReply) {
        try {
          const roast = GENERIC_INSULT_ROASTS[Math.floor(Math.random() * GENERIC_INSULT_ROASTS.length)];
          await sock.sendMessage(chatId, { text: roast }, { quoted: msg });
        } catch (err) {
          logger.error("فشل إرسال رد الشتيمة العامة:", err);
        }
        return;
      }
    }

    // 🆕 (طلب صريح: "شي غريب حتى لو ما له داعي") — أمر سرّي مخفي كليًا،
    // غير موجود بأي قائمة أو أمر ظاهر، يشتغل فقط لو كتب أحد العبارة
    // بالضبط. لا فائدة عملية له، مجرد "بيضة فصح" (Easter Egg).
    if (CONFIG.LEGACY_REPLIES && text.trim() === "افتح يا سمسم") {
      try {
        await sock.sendMessage(
          chatId,
          { text: "🗝️ *تم فتح الكنز السري...*\nما فيه شي بصراحة، بس مبروك اكتشفت الأمر السري 🐪✨" },
          { quoted: msg }
        );
      } catch (err) {
        logger.error("فشل إرسال رد الأمر السري:", err);
      }
      return;
    }

    // ===== رد خاص: "انا مطورك" / "انا مطورك يا حمار" =====
    // يشتغل دايمًا (مش مربوط بإعداد الردود_التلقائية) لأنه رد حماية لهوية
    // المطور الحقيقي، مو مجرد فرفشة عابرة. نتأكد فعليًا من رقم المرسل عبر
    // isOwner بدل ما نصدّق أي شخص يدّعي إنه المطور.
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX)) {
      const cleaned = text.trim();
      const claimMatch = /^انا\s*مطورك(\s*يا\s*حمار)?/.test(cleaned);

      if (claimMatch) {
        const hasInsult = /يا\s*حمار/.test(cleaned);
        try {
          if (!isOwner(senderJid, metadata || undefined)) {
            await sock.sendMessage(
              chatId,
              { text: "*تحسبني غبي زيك ما يعرف حبيب قلبه(مطوري)*\n*اذلف🫥*" },
              { quoted: msg }
            );
          } else if (hasInsult) {
            await sock.sendMessage(chatId, { text: "*اسف ما كنت اقصد😭🥺*" }, { quoted: msg });
          } else {
            await sock.sendMessage(
              chatId,
              { text: "*دا انا امون عليك ياض لاتزعلش🌹 🙄*" },
              { quoted: msg }
            );
          }
        } catch (err) {
          logger.error("فشل إرسال رد (انا مطورك):", err);
        }
        return;
      }
    }

    // ===== ردود تلقائية مرحة: بوتي / ملل / فينكم / ميتين وغيرها =====
    // يشتغل بس على الرسائل العادية (مش أوامر)، وبنفس إعداد الردود
    // التلقائية اللي يتحكم فيه المشرف (.اعدادات الردود_التلقائية).
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      const autoReplyOn = !isGroup || settings?.autoReply;

      if (autoReplyOn) {
        const matchedPrefix = Object.keys(FUN_REPLIES).find((prefix) => {
          // 🆕 مفاتيح تحتوي مسافة (عبارة من أكثر من كلمة، مثل "كول هوا")
          // ما تقدر تتطابق أبدًا عبر containsWordStartingWith (تفحص كل
          // كلمة براسها) — نتحقق منها كعبارة كاملة داخل النص بدلًا من ذلك.
          const matches = prefix.includes(" ")
            ? stripDiacritics(text).includes(prefix)
            : containsWordStartingWith(text, prefix);
          if (!matches) return false;
          // "بوتي" مخصص للمطور فقط — أي شخص ثاني يكتبها ما يستحق رد تلقائي
          if (prefix === "بوتي" && !isOwner(senderJid, metadata || undefined)) return false;
          return true;
        });

        if (matchedPrefix) {
          const reply = pickRandomReply(matchedPrefix);
          if (reply) {
            try {
              // "ملل" فقط يرفق فيديو/GIF (لو موجود) لأنه الرد الأكثر استخدامًا أصلًا
              if (matchedPrefix === "ملل") {
                const videoBuffer = getMenuVideoBuffer();
                if (videoBuffer) {
                  await sock.sendMessage(
                    chatId,
                    {
                      video: videoBuffer,
                      gifPlayback: true,
                      caption: reply,
                      mentions: isGroup ? [senderJid] : undefined,
                    },
                    { quoted: msg }
                  );
                  return;
                }
              }
              await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
            } catch (err) {
              logger.error("فشل إرسال رد تلقائي مرح:", err);
            }
            return;
          }
        }
      }
    }

    // ===== 🆕 بنك ردود إضافي (جيت/هاي/بربك/حار/العراق/مليت وغيرها، وردود
    // حول موضوع المطور) — نفس شرط إعداد الردود_التلقائية أعلاه بالضبط.
    if (CONFIG.LEGACY_REPLIES && !text.startsWith(CONFIG.PREFIX)) {
      const settings = isGroup ? getGroupSettings(chatId) : null;
      const autoReplyOn = !isGroup || settings?.autoReply;

      if (autoReplyOn) {
        // 🆕 ("N احات" → رد ديناميكي N+1) — نتحقق منه أول شي لأنه نمط
        // محدد جدًا (رقم/كلمة + "احات")، قبل الردود العامة.
        const ahatReply = matchAhatCounter(text);
        if (ahatReply) {
          try {
            await sock.sendMessage(chatId, { text: ahatReply }, { quoted: msg });
          } catch (err) {
            logger.error("فشل إرسال رد عداد الاحات:", err);
          }
          return;
        }

        // أولًا: الردود اللي تحتاج منشن فعلي لرقم المطور (أدق من الردود
        // العادية، نتحقق منها أول شي حتى ما يسبقها رد نصي عام مشابه).
        const mentionMatch = matchMentionQuickReply(text);
        if (mentionMatch) {
          const { text: replyText, mentions } = mentionMatch.build();
          try {
            await sock.sendMessage(chatId, { text: replyText, mentions }, { quoted: msg });
          } catch (err) {
            logger.error("فشل إرسال رد سريع بمنشن:", err);
          }
          return;
        }

        const quickReply = matchQuickReply(text, senderJid);
        if (quickReply) {
          try {
            await sock.sendMessage(chatId, { text: quickReply }, { quoted: msg });
          } catch (err) {
            logger.error("فشل إرسال رد سريع:", err);
          }
          return;
        }
      }
    }

    // ===== تنفيذ الأوامر (يجب أن تبدأ بالبادئة فقط) =====
    if (!text.startsWith(CONFIG.PREFIX)) {
      // 🆕 (.اضافة_رد) ردود تلقائية عالمية على كلمات/جمل محددة
      if (await tryGlobalAutoReply(sock, msg, chatId, text)) return;
      return;
    }

    let withoutPrefix = text.slice(CONFIG.PREFIX.length).trim();
    if (!withoutPrefix) return;

    // 🆕 أوامر من كلمتين تُكتب بمسافة (مثل ".تسجيل لقب @شخص X" أو ".منع كلمات") —
    // نوصلها بشرطة سفلية لتطابق اسم الأمر المسجّل.
    withoutPrefix = withoutPrefix
      .replace(/^(?:حذف|مسح|ازالة|إزالة)\s+(?:كل\s+)?(?:الردود|ردود)(?=\s|$)/, "حذف_الردود")
      .replace(/^(?:حذف|مسح|ازالة|إزالة)\s+رد(?=\s|$)/, "حذف_رد")
      .replace(/^(تنزيل|رفع)\s+(?:ادمن|أدمن|مشرف)(?=\s|$)/, (_m, a) => `${a}_ادمن`);
    withoutPrefix = withoutPrefix.replace(
      /^(تسجيل|تغير|تغيير|حذف|حجز)\s+(لقب|الالقاب|الألقاب)(?=\s|$)/,
      (_m, a, b) => `${a}_${b}`
    ).replace(
      /^(منع\s+(?:كلمات|الميديا|الروابط|بطاقه|بطاقة|ملصقات|بوت)|قفل\s+(?:امر|الأمر|الامر|تنصيب)|فتح\s+(?:امر|الأمر|الامر)|تغيير\s+(?:الاسم|الوصف|صورة\s+المجموعة)|عيد\s+تحذير|احصائيات\s+المجموعة)(?=\s|$)/,
      (m) => m.trim().replace(/\s+/g, "_")
    );

    let [cmdName, ...args] = withoutPrefix.split(/\s+/);
    let joinedRest: string | null = null;
    // 🆕 أي أمر من كلمتين/ثلاث يُكتب بمسافة (مثل «.رفع ادمن @شخص» أو «.تنزيل ادمن» أو
    // «.خمن العمر») — لو الكلمة الأولى وحدها مو أمر معروف، نجرّب نوصلها بالكلمة
    // اللي بعدها بشرطة سفلية (وبعدها بثلاث كلمات) قبل ما نتجاهل الرسالة.
    if (!commandRegistry.get(cmdName) && args.length) {
      for (const n of [2, 1]) {
        if (args.length < n) continue;
        const joined = [cmdName, ...args.slice(0, n)].join("_");
        if (commandRegistry.get(joined)) {
          joinedRest = withoutPrefix.replace(new RegExp(`^(?:\\S+\\s+){${n}}\\S+`), "").trim();
          cmdName = joined;
          args = args.slice(n);
          break;
        }
      }
    }
    const command = commandRegistry.get(cmdName);
    if (!command) return;

    // 🆕 (.قفل_امر) أمر مقفول بهذي المجموعة للأعضاء العاديين
    if (isGroup && metadata && getFriendCfg(chatId).lockedCmds.includes(command.name)) {
      if (!isOwner(senderJid, metadata, sock) && !isGroupAdmin(metadata, senderJid)) {
        await sock.sendMessage(chatId, { text: "🔒 هذا الأمر مقفول بهذي المجموعة من قِبل المشرفين." }, { quoted: msg });
        return;
      }
    }

    if (command.groupOnly && !isGroup) {
      await sock.sendMessage(chatId, { text: "⚠️ هذا الأمر يعمل داخل المجموعات فقط." });
      return;
    }

    // ===== 🆕 قيد على أوامر خطيرة/مشتركة على مستوى العملية كلها =====
    // 🔧 تراجع عن قيد سابق أوسع (كان يحجب كل فئة "المطور" + كل
    // permission:"owner" بالكامل عن أي بوت فرعي بلا استثناء — طلب صريح
    // جديد يُلغي هذا: "خله يسمح بكل شي مثل البوت الرئيسي، بس منعزل").
    // الحل الجديد: البوت الفرعي يعامل صاحب رقمه هو بالذات كـ"مطور" لبوته
    // فقط (راجع isOwner بـpermissions.ts) — تقدر تشغّل أي أمر owner عادي
    // (.ايقاف/.تشغيل، .رفع_ادمن، .تفعيل_تنصيب...) وتأثيره ينحصر ببوتك أنت
    // فقط (بفضل كل إصلاحات العزل السابقة: enabledByBot، virtualAdmins
    // المرتبطة بالبوت...).
    // الاستثناء الوحيد المتبقي: قائمة صغيرة من الأوامر لسه خطيرة فعلًا
    // لأنها تتحكم بموارد/بيانات مشتركة للعملية *كلها* (كل البوتات معًا)
    // ولا علاقة لها ببوت واحد بالذات — هذي تبقى للمطور الحقيقي (رقم
    // .env) حصرًا مهما كان صاحب الرقم المرسل:
    //   .اعادة_تشغيل  → يقفل العملية كلها (كل البوتات تنقطع سوا)
    //   .نسخ_احتياطي  → يصدّر db.json كاملة (بيانات كل المجموعات/البوتات)
    //   .اذاعة        → إذاعة لكل مجموعات البوت الرئيسي
    //   .تشخيص        → معلومات السيرفر المستضيف نفسه
    //   .تحديث        → يعيد تحميل سجل الأوامر المشترك لكل البوتات
    //   .تفعيل/.تعطيل → يوقف قسم أوامر كامل على *كل* البوتات معًا
    //   .تفعيل_تنصيب/.تعطيل_تنصيب → يتحكم بإمكانية تنصيب بوتات جديدة أصلًا
    //   .فحص_مالك     → يعرض قائمة تشمل منح كل البوتات (تسريب خصوصية بين البوتات)
    //   .وضع_خاص/.وضع_عام → bot.publicMode علم عام واحد يتحكم باستجابة *كل* البوتات
    const MAIN_BOT_ONLY_COMMANDS = new Set([
      "اعادة_تشغيل",
      "نسخ_احتياطي",
      "اذاعة",
      "تشخيص",
      "تحديث",
      "تفعيل",
      "تعطيل",
      "تفعيل_تنصيب",
      "تعطيل_تنصيب",
      "فحص_مالك",
      "وضع_خاص",
      "وضع_عام",
    ]);
    if (options?.subBot && MAIN_BOT_ONLY_COMMANDS.has(command.name)) {
      await sock.sendMessage(
        chatId,
        { text: "🚫 هذا الأمر خاص بالبوت الرئيسي فقط، غير متاح هنا." },
        { quoted: msg }
      );
      return;
    }

    // ===== 🆕 قسم معطّل بأمر .تعطيل =====
    // يمنع تنفيذ أي أمر من قسم موقوفه المطور — بما فيه فتح قائمة القسم
    // نفسها (menu لكل قسم مسجّل بنفس فئة أوامره، فيُحجب تلقائيًا هنا
    // كمان). المطور/رقم البوت نفسه معفيّان دائمًا حتى يقدرا يجربا القسم
    // ويعيدا تفعيله بـ .تفعيل بأي وقت.
    if (isSectionDisabled(command.category) && !isOwner(senderJid, metadata || undefined)) {
      await sock.sendMessage(
        chatId,
        { text: `🚫 هذا القسم موقّف حاليًا بأمر من المطور.` },
        { quoted: msg }
      );
      return;
    }

    // ===== الأعضاء المحظورون من استخدام البوت =====
    if (isGroup && isBlocked(chatId, senderJid) && !isOwner(senderJid, metadata || undefined)) return;

    // 🔧 إصلاح مهم (سبب محتمل لـ "عضو عادي يقدر ينفذ أمر مشرفين أحيانًا"،
    // أو "أمر يرفض شخص هو فعليًا مشرف"): كنا نستخدم بيانات المجموعة
    // (metadata) نفسها المخزّنة مؤقتًا لمدة دقيقة كاملة (CACHE_TTL) حتى
    // لأوامر تتحقق من صلاحية الإشراف. لو أحد تمت ترقيته/تنزيله من الإشراف
    // بالضبط بهالدقيقة، أو كانت أول مرة تُجلب فيها بيانات المجموعة قبل ما
    // تكتمل مزامنة حقول lid/phoneNumber من واتساب، القرار يصير مبني على
    // معلومة قديمة/ناقصة. الآن أي أمر يتطلب صلاحية أعلى من "الجميع" يجلب
    // نسخة حيّة من بيانات المجموعة مباشرة قبل اتخاذ قرار السماح/الرفض
    // (ويحدّث الكاش بها بعدين لأي استخدام عادي آخر)، فيصير القرار مبني على
    // أحدث حالة فعلية دايمًا بدل بيانات قد تكون قديمة بدقيقة كاملة.
    // 🆕 تجاوز الصلاحية وقت التشغيل (.صلاحية) — أمر .صلاحية نفسه مستثنى
    // عمدًا حتى ما ينقفل المطور خارج التحكم بالغلط.
    const effectivePermission =
      command.name === "صلاحية" ? command.permission : getPermissionOverride(command.name) ?? command.permission;

    let permMetadata = metadata;
    if (isGroup && effectivePermission !== "all") {
      try {
        permMetadata = getGroupCache(chatId, 10_000) || (await fetchGroupMetadataSafe(sock, chatId));
      } catch (err) {
        logger.warn("تعذر تحديث بيانات المجموعة قبل فحص الصلاحية، استخدام النسخة المخزنة مؤقتًا.", err);
      }
    }

    const allowed = await checkPermission(
      sock,
      chatId,
      senderJid,
      effectivePermission,
      permMetadata || undefined,
      command.requireBotAdmin !== false,
      command.allowVirtualAdmin !== false
    );
    if (!allowed) return;

    const ctx: CommandContext = {
      // 🆕 (طلب صريح: براندنج تلقائي لكل رد نصي) — راجع تعليق
      // createBrandedSock بملف utils/interactive.ts للتفاصيل الكاملة
      // وحماية التكرار اللانهائي. محصور هنا فقط (سياق تنفيذ أمر)، ما
      // يؤثر على أي رسالة ثانية بالمشروع (ترحيب/جدولة/قرار طرد...).
      sock: createBrandedSock(sock, senderJid),
      chatId,
      senderJid,
      isGroup,
      metadata: permMetadata,
      msg,
      args,
      text: joinedRest ?? withoutPrefix.slice(cmdName.length).trim(),
      quoted: getQuotedMessage(msg),
      isSubBot: !!options?.subBot,
    };

    // 🛡️ منع السبام: نفس الشخص ما ينفذ أوامر أسرع من مرة كل 1.2 ثانية (المطور مستثنى) —
    // بدون هذا، 20 ضغطة سريعة على قائمة/لعبة تولّد 20 صورة وتجمّد البوت.
    if (!isOwner(senderJid, permMetadata || undefined, sock)) {
      const cdKey = `${getBotScopeId(sock)}:${chatId}:${digitsOnly(senderJid)}`;
      const nowTs = Date.now();
      if (nowTs - (lastCommandAt.get(cdKey) || 0) < COMMAND_COOLDOWN_MS) return;
      lastCommandAt.set(cdKey, nowTs);
      if (lastCommandAt.size > 2000) {
        for (const [k, t] of lastCommandAt) if (nowTs - t > 60_000) lastCommandAt.delete(k);
      }
    }

    logger.command(`${cmdName} ← ${senderJid}`);
    try {
      await runLimited(() => {
        let timer: NodeJS.Timeout | undefined;
        const timeout = new Promise<never>((_, reject) => {
          timer = setTimeout(() => reject(new Error("COMMAND_TIMEOUT")), COMMAND_TIMEOUT_MS);
        });
        const run = msgContextStore.run(
          { groupName: isGroup ? permMetadata?.subject || undefined : "خاص", category: command.category },
          () => command.execute(ctx)
        );
        return Promise.race([run, timeout]).finally(() => {
          if (timer) clearTimeout(timer);
        });
      });
      // 🆕 (نظام المستويات) — كل تنفيذ أمر ناجح يعطي XP بسيط (كولداون دقيقة
      // لكل شخص، راجع addXpWithCooldown بملف database/db.ts). معزول بـ
      // try/catch خاص فيه حتى لو صار خطأ هنا ما يُظهر "فشل تنفيذ الأمر"
      // زور على أمر نجح فعليًا.
      try {
        addXpWithCooldown(senderJid, 5 + Math.floor(Math.random() * 6));
      } catch {
        /* تجاهل — XP ميزة إضافية، ما تستاهل توقف أي شي */
      }
    } catch (err) {
      // قبل كذا أي خطأ داخل أمر كان يُبتلع بصمت بالـ catch العام بالأسفل
      // (تسجيل بالسجلات بس، بدون أي رد للمستخدم) — وهذا يبدو تمامًا كأن
      // "البوت ما يرد". الحين نرسل رسالة واضحة بدل الصمت.
      logger.error(`فشل تنفيذ الأمر .${cmdName}:`, err);
      try {
        await ctx.sock.sendMessage(
          chatId,
          {
            text:
              (err as any)?.message === "COMMAND_TIMEOUT"
                ? "⏱️ الأمر أخذ وقت طويل وتم إيقافه. حاول مرة ثانية."
                : "❌ صار خطأ أثناء تنفيذ الأمر. حاول مرة ثانية.",
          },
          { quoted: msg }
        );
      } catch {
        /* حتى لو فشل إرسال رسالة الخطأ نفسها، ما نكسر شي */
      }
      return; // ما نكمل لخطوة التفاعل التأكيدي لأن الأمر فشل فعليًا
    }

    // 🆕 (طلب صريح) بعد أكثر من 5 استخدامات لنفس الأمر بنفس المجموعة من
    // نفس الشخص، يوصله رد عشوائي طريف — داخل المجموعات فقط.
    const nagReply = CONFIG.LEGACY_REPLIES ? checkCommandNag(isGroup, chatId, senderJid, command.name) : undefined;
    if (nagReply) {
      try {
        await ctx.sock.sendMessage(chatId, { text: nagReply }, { quoted: msg });
      } catch {
        /* لا نكسر تنفيذ الأمر الأساسي لو فشل إرسال هذا الرد الجانبي */
      }
    }

    // ===== تفاعل تأكيدي (Reaction) على كل أمر تم تنفيذه =====
    // مطلوب صراحة: تفاعل فقط (مو رد رسالة) على رسالة الأمر نفسها حتى
    // يعرف المستخدم إن أمره اتنفذ فعلًا. إيموجي عشوائي من مجموعة ثابتة.
    // بمعزل تمامًا عن أزرار واتساب (اللي تبقى best-effort دايمًا)، فهذا
    // التفاعل يشتغل 100% لأنه نفس آلية sock.sendMessage العادية.
    try {
      const emoji = REACTION_EMOJIS[Math.floor(Math.random() * REACTION_EMOJIS.length)];
      await sock.sendMessage(chatId, { react: { text: emoji, key: msg.key } });
    } catch (err) {
      logger.warn("تعذر إرسال تفاعل تأكيد الأمر.", err);
    }
  } catch (err) {
    logger.error("خطأ أثناء معالجة رسالة:", err);
  }
}
