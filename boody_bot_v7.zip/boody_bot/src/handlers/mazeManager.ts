/**
 * 🧊 لعبة "متاهة 3D" (.متاهة) — منظور الشخص الأول بالـ Raycasting.
 * كل ضغطة زر = خطوة/دوران، ونرسم المشهد الجديد. الهدف: توصل للكتلة الخضراء.
 * الحالة شخصية لكل لاعب بكل كروب (نفس نمط fpsManager).
 */
import { WASocket } from "@whiskeysockets/baileys";
import { getBotScopeId, jidToMention } from "../utils/helpers";
import { sendButtonMessage, buildSingleSelectButton } from "../utils/interactive";
import { addPoint } from "../database/db";
import { CONFIG } from "../config/config";
import { generateMaze, renderView, renderMap, Grid, DX, DY, DIR_NAMES } from "../utils/mazeRay";

interface Game {
  playerJid: string;
  grid: Grid;
  x: number;
  y: number;
  dir: number;
  steps: number;
  mapUses: number;
}

const CELLS = 6;
const MAX_MAPS = 2;
const sessions = new Map<string, Game>();

function key(sock: WASocket, chatId: string, senderJid: string): string {
  return `${getBotScopeId(sock)}:${chatId}:${senderJid}`;
}

export function isRunning(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.has(key(sock, chatId, senderJid));
}

export function end(sock: WASocket, chatId: string, senderJid: string): boolean {
  return sessions.delete(key(sock, chatId, senderJid));
}

async function sendScene(sock: WASocket, chatId: string, game: Game, message: string): Promise<void> {
  const image = await renderView(game.grid, game.x, game.y, game.dir);
  const rows = [
    { command: "maze_fwd", label: "⬆️ تقدّم", description: "خطوة للأمام" },
    { command: "maze_left", label: "↩️ يسار", description: "دوران 90° لليسار" },
    { command: "maze_right", label: "↪️ يمين", description: "دوران 90° لليمين" },
    { command: "maze_back", label: "🔄 استدر للخلف", description: "دوران 180°" },
    { command: "maze_map", label: `🗺️ خريطة (${MAX_MAPS - game.mapUses} متبقية)`, description: "تعرض مكانك والخروج (تضيف 10 خطوات)" },
  ];
  await sendButtonMessage(sock, chatId, {
    text: `🧊 *متاهة 3D* — ${jidToMention(game.playerJid)}\n🧭 تواجه: ${DIR_NAMES[game.dir]} | 👣 الخطوات: ${game.steps}\n\n${message}`,
    mentions: [game.playerJid],
    image,
    extraButtons: [buildSingleSelectButton("🧭 تحرّك", "اختر حركتك", rows)],
    fallbackNote: `اكتب: ${CONFIG.PREFIX}تقدم / ${CONFIG.PREFIX}يمين / ${CONFIG.PREFIX}يسار / ${CONFIG.PREFIX}خلف / ${CONFIG.PREFIX}خريطة`,
  });
}

export async function start(sock: WASocket, chatId: string, senderJid: string): Promise<void> {
  const { grid } = generateMaze(CELLS);
  const game: Game = { playerJid: senderJid, grid, x: 1, y: 1, dir: 1, steps: 0, mapUses: 0 };
  // اتجاه البداية: نحو أول ممر مفتوح
  for (let d = 0; d < 4; d++) {
    if (grid[1 + DY[d]]?.[1 + DX[d]] === 0) { game.dir = d; break; }
  }
  sessions.set(key(sock, chatId, senderJid), game);
  await sendScene(sock, chatId, game, "دخلت المتاهة! دوّر على الكتلة الخضراء المتوهجة — هي الخروج 🟩");
}

export async function handleAction(sock: WASocket, chatId: string, senderJid: string, text: string): Promise<boolean> {
  const k = key(sock, chatId, senderJid);
  const game = sessions.get(k);
  if (!game) return false;

  const t = text.trim();
  const w = t.startsWith(CONFIG.PREFIX) ? t.slice(CONFIG.PREFIX.length).trim() : t;
  let action: "fwd" | "left" | "right" | "back" | "map" | null = null;
  if (["maze_fwd", "تقدم", "امام"].includes(w)) action = "fwd";
  else if (["maze_left", "يسار"].includes(w)) action = "left";
  else if (["maze_right", "يمين"].includes(w)) action = "right";
  else if (["maze_back", "خلف"].includes(w)) action = "back";
  else if (["maze_map", "خريطة"].includes(w)) action = "map";
  else return false;

  if (action === "left") { game.dir = (game.dir + 3) % 4; await sendScene(sock, chatId, game, "↩️ دُرت لليسار."); return true; }
  if (action === "right") { game.dir = (game.dir + 1) % 4; await sendScene(sock, chatId, game, "↪️ دُرت لليمين."); return true; }
  if (action === "back") { game.dir = (game.dir + 2) % 4; await sendScene(sock, chatId, game, "🔄 استدرت للخلف."); return true; }

  if (action === "map") {
    if (game.mapUses >= MAX_MAPS) {
      await sendScene(sock, chatId, game, "🗺️ خلصت مرات الخريطة!");
      return true;
    }
    game.mapUses++;
    game.steps += 10;
    const image = await renderMap(game.grid, game.x, game.y, game.dir);
    await sock.sendMessage(chatId, { image, caption: "🗺️ خريطتك: 🔴 أنت (والخط الأصفر اتجاهك) — 🟩 الخروج. (+10 خطوات)" });
    await sendScene(sock, chatId, game, "كمّل طريقك 👇");
    return true;
  }

  // تقدّم
  const nx = game.x + DX[game.dir];
  const ny = game.y + DY[game.dir];
  const cell = game.grid[ny]?.[nx];
  if (cell === undefined || cell === 1) {
    await sendScene(sock, chatId, game, "🧱 حائط! لف يمين أو يسار.");
    return true;
  }
  game.steps++;
  if (cell === 2) {
    sessions.delete(k);
    const pts = game.steps <= 60 ? 5 : game.steps <= 120 ? 3 : 1;
    addPoint(chatId, senderJid, pts);
    await sock.sendMessage(chatId, {
      text: `🏆 *وصلت للخروج!* ${jidToMention(senderJid)}\n👣 الخطوات: ${game.steps}\n🎖️ النقاط: +${pts}`,
      mentions: [senderJid],
    });
    return true;
  }
  game.x = nx;
  game.y = ny;
  await sendScene(sock, chatId, game, "⬆️ تقدمت خطوة.");
  return true;
}
