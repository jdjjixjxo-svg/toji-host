import {
  WASocket,
  WAMessage,
  proto,
  generateWAMessageFromContent,
  generateWAMessageContent,
} from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { logger } from "./logger";
import { downloadImageBuffer } from "./imageSearch";
import { autoFrame } from "./frame";

/**
 * 🆕 (بند 5) — يبني contextInfo الذي يخلي الرسالة تظهر بتاغ "معاد توجيهها"
 * الأخضر واسم البوت بالأزرق قابل للضغط (يفتح القناة)، بنفس شكل صورة
 * بوت "itadori" اللي أرسلها صاحب المشروع كمثال. يرجع undefined لو
 * CHANNEL_JID فارغ بالـ.env حتى لا يكسر أي رسالة عادية.
 *
 * ⚠️ best-effort غير موثّق رسميًا وغير مُختبر على حساب حقيقي — راجع
 * تعليق CHANNEL_JID بـ config.ts لتفاصيل الحصول عليه وأسباب عدم التأكد.
 */
/**
 * 🆕 (حل تلقائي كامل) — بدل ما نطلب من صاحب البوت يجيب CHANNEL_JID يدويًا
 * (يحتاج استعلامًا فعليًا من واتساب وقت التشغيل، مستحيل نسويه من هنا بدون
 * اتصال حقيقي)، البوت الآن يسوي هذا الاستعلام بنفسه تلقائيًا أول ما يتصل،
 * مستخدمًا CHANNEL_LINK الموجود أصلًا بالـ.env — بدون أي خطوة يدوية إضافية.
 *
 * القيمة المكتشفة تُخزَّن هنا بالذاكرة فقط (متغيّر وحدة/module-level)،
 * وتُستخدم تلقائيًا بكل رسالة لاحقة عبر buildNewsletterForwardContext().
 * لو صاحب البوت حط CHANNEL_JID يدويًا بالـ.env، هذا يبقى له الأولوية دائمًا
 * (نتحقق منه أولًا) ونتجاوز الاستعلام بالكامل.
 */
let resolvedChannelJid: string | undefined;

/**
 * يستخرج كود الدعوة من رابط قناة واتساب بأي شكل شائع له
 * (https://whatsapp.com/channel/XXXX أو chat.whatsapp.com/channel/XXXX
 * مع/بدون معاملات إضافية بآخر الرابط).
 */
function extractChannelInviteCode(link: string): string | undefined {
  const match = link.match(/channel\/([A-Za-z0-9]+)/);
  return match?.[1];
}

/**
 * يُستدعى مرة وحدة فور نجاح الاتصال (connection === "open") لأي مقبس —
 * رئيسي أو فرعي، ما يهم. يحاول يحل CHANNEL_JID تلقائيًا من CHANNEL_LINK
 * عبر sock.newsletterMetadata الرسمية بمكتبة Baileys. best-effort بالكامل:
 * أي فشل (رابط غير صالح، القناة غير موجودة، إصدار Baileys لا يدعم الدالة...)
 * يُسجَّل بالـlogger فقط ولا يوقف تشغيل البوت أبدًا ولا يكسر أي رسالة.
 */
export async function resolveChannelJidFromLink(sock: WASocket): Promise<void> {
  if (CONFIG.CHANNEL_JID || resolvedChannelJid) return; // مضبوط يدويًا أو محلول مسبقًا — لا داعي لإعادة المحاولة
  if (!CONFIG.CHANNEL_LINK) return; // ما فيه رابط أصلًا نستخرج منه شي

  const code = extractChannelInviteCode(CONFIG.CHANNEL_LINK);
  if (!code) {
    logger.warn(`⚠️ تعذّر استخراج كود الدعوة من CHANNEL_LINK: ${CONFIG.CHANNEL_LINK}`);
    return;
  }

  try {
    const metadata = await (sock as any).newsletterMetadata("invite", code);
    const jid: string | undefined = metadata?.id;
    if (jid) {
      resolvedChannelJid = jid;
      logger.success(`🩺 تم اكتشاف CHANNEL_JID تلقائيًا: ${jid}`);
      logger.info(
        `💡 (اختياري) لو تبي تثبّت هذي القيمة بدل إعادة اكتشافها كل مرة، ` +
          `أضفها بملف .env هكذا: CHANNEL_JID=${jid}`
      );
    } else {
      logger.warn("⚠️ استعلام newsletterMetadata رجع بدون معرّف قناة (id) صالح.");
    }
  } catch (err) {
    logger.warn(
      "⚠️ تعذّر اكتشاف CHANNEL_JID تلقائيًا من CHANNEL_LINK (تاغ \"معاد توجيهها\" سيبقى متوقفًا). التفاصيل:",
      err
    );
  }
}

export function buildNewsletterForwardContext(): Record<string, any> | undefined {
  const channelJid = CONFIG.CHANNEL_JID || resolvedChannelJid;
  if (!channelJid) return undefined;
  return {
    isForwarded: true,
    forwardingScore: 9999,
    forwardedNewsletterMessageInfo: {
      newsletterJid: channelJid,
      newsletterName: CONFIG.BOT_NAME,
      serverMessageId: Math.floor(Math.random() * 1_000_000),
    },
  };
}

/**
 * 🆕 (تعميم البراندنج على كل مقبس) — كانت index.ts تغلّف sock.sendMessage
 * يدويًا محليًا بعد إنشاء المقبس الرئيسي مباشرة، لكن subBotManager.ts
 * ينشئ مقابس Baileys مستقلة تمامًا لكل رقم يُنصَّب عبر ".تنصيب" (سطرين
 * منفصلين فيه يستدعيان makeWASocket) ولم تكن تمر أبدًا من نفس التغليف —
 * فأي فعالية/رسالة تُرسل من بوت فرعي كانت تخرج عادية بدون تاغ "معاد
 * توجيهها". هذي الدالة تجمع نفس منطق التغليف بمكان واحد بدل تكراره
 * بثلاث ملفات مختلفة، وتُستدعى الآن على *كل* مقبس (الرئيسي + كل بوت
 * فرعي) مباشرة بعد إنشائه.
 *
 * لو CHANNEL_JID فاضي بالـ.env، buildNewsletterForwardContext() ترجع
 * undefined ولا نغلّف شي إطلاقًا — بدون أي خطر كسر لمن ما يبي هذي الميزة.
 */
export function applyNewsletterBranding(sock: WASocket): void {
  // 🔧 (تعديل مهم): لا نتحقق من buildNewsletterForwardContext() هنا وقت
  // التغليف مباشرة، لأن CHANNEL_JID قد يكون غير محلول بعد (يُحل لاحقًا
  // عند نجاح الاتصال عبر resolveChannelJidFromLink). لو انتظرنا قيمة
  // جاهزة الآن فقط، أي رسالة تُرسل قبل اكتمال الحل التلقائي كانت
  // ستفوتها الميزة للأبد حتى لو تحلّت القيمة بعدها بثوانٍ. لذلك نغلّف
  // طالما فيه أي إمكانية للتفعيل (CHANNEL_JID يدوي أو CHANNEL_LINK
  // نستنتج منه لاحقًا)، ونحسب السياق طازج بكل استدعاء فعلي للإرسال.
  const originalSendMessage = sock.sendMessage.bind(sock);
  sock.sendMessage = (async (jid: string, content: any, options?: any) => {
    const newsletterCtx = buildNewsletterForwardContext();
    // 🔧 (طلب صريح: "مو كل الردود" — رجّع كلام المشرفين/ردود الأوامر العادية
    // لطبيعتها) — القالب الموحّد (الإطار الكبير) يبقى فقط على قوائم/أقسام
    // البوت الصريحة (عبر menuTemplates.ts و sendButtonMessage)، ولا يُطبَّق
    // تلقائيًا على أي رد نصي عادي (تم الطرد/الكتم/أخطاء/نتائج الألعاب...).
    // شيلنا التغليف التلقائي اللي كان يفعل هذا هنا؛ sock.sendMessage صار
    // يمرر النص كما هو بالضبط بدون أي تأطير إضافي.
    // 🔧 استثناء صريح: رسائل "خاصة" مو محتوى عادي (حذف رسالة/تفاعل...) —
    // دمج contextInfo فيها بلا داعي وقد يكسر شرط التحقق الداخلي بمكتبة
    // Baileys اللي يفحص وجود مفتاح "delete"/"react" بمفرده بالكائن.
    const isSpecialContent =
      content && typeof content === "object" && ("delete" in content || "react" in content);

    const mergedContent =
      newsletterCtx && content && typeof content === "object" && !isSpecialContent
        ? {
            ...content,
            contextInfo: { ...(content.contextInfo || {}), ...newsletterCtx },
          }
        : content;
    return originalSendMessage(jid, mergedContent, options);
  }) as typeof sock.sendMessage;

  logger.info(
    '🩺 تغليف "معاد توجيهها" مفعّل على هذا المقبس (سيبدأ العمل الفعلي فور حل CHANNEL_JID).'
  );
}

/**
 * ============================================================================
 * 🔘 أزرار واتساب التفاعلية الأصلية (Native Buttons) — ملاحظة مهمة جدًا
 * ============================================================================
 * مكتبة @whiskeysockets/baileys الرسمية أوقفت الدعم الجاهز لهذا النوع من
 * الرسائل عبر sock.sendMessage() (راجع القضية الرسمية رقم 2239 بمستودع
 * المكتبة). لهذا نبني الرسالة يدويًا هنا باستخدام proto.Message.InteractiveMessage
 * الموجود أصلًا داخل نفس المكتبة الرسمية (بدون أي حزمة خارجية غير موثوقة)،
 * ونرسلها عبر sock.relayMessage() مباشرة.
 *
 * 🔧 سبب عدم ظهور الزر سابقًا: بناء رسالة الـ protobuf وحده لا يكفي —
 * واتساب يتجاهل أي رسالة "interactive/native_flow" لا يرافقها عنصر
 * XML خاص (Binary Node) بالاسم <biz><interactive type="native_flow"/></biz>
 * داخل حزمة الإرسال نفسها. هذا العنصر هو ما يخبر خوادم واتساب أن الرسالة
 * تحتوي فعليًا على أزرار قابلة للعرض. أضفناه هنا عبر خيار additionalNodes
 * الرسمي في relayMessage (بدون تعديل أي ملف داخل المكتبة نفسها).
 *
 * هذا أسلوب "أفضل محاولة" (best-effort): قد لا يظهر الزر على كل الأجهزة/
 * النسخ لأن واتساب لا يضمن عرضه لحسابات الأفراد (غير الأعمال). لذلك أي
 * استدعاء هنا محمي بـ try/catch ويرجع تلقائيًا لرسالة عادية (نفس الصورة +
 * النص، بدون أزرار حقيقية) بدون أي رقم أو رابط ظاهر لو فشل الإرسال — حتى
 * لا ينكسر أي أمر أبدًا.
 *
 * 🎯 كيف تُطابَق ضغطة الزر بأمر حقيقي:
 * واتساب لا يرسل حقل "id" الذي نضعه بالزر — يرسل النص المعروض على الزر
 * نفسه (display_text) كرسالة عادية بالشات. فلو كتبنا نص الزر مع البادئة
 * (مثل ".ترفيه") قد ينكسر التعرّف عليه إذا سبقته زخرفة/إيموجي أو تغيّر
 * ترتيب الأحرف (خصوصًا مع النص العربي RTL). لتفادي ذلك كليًا: نص الزر
 * حر تمامًا (أي زخرفة نريدها)، ونسجّله بخريطة مطابقة (buttonTriggerMap)
 * تربطه بالأمر الحقيقي، فيتعرف عليه handler الرسائل بمطابقة تامة للنص
 * بدل الاعتماد على البادئة.
 * ============================================================================
 */

/**
 * يبني عنصر الـ Binary Node المطلوب ليعترف واتساب برسالة native_flow.
 * مختلف بين المجموعات (biz + interactive/native_flow فقط) والمحادثات
 * الخاصة (يضاف لها عنصر bot أيضًا)، حسب ما يرسله تطبيق واتساب الرسمي.
 */
function buildInteractiveBinaryNodes(chatId: string): any[] {
  const bizNode = {
    tag: "biz",
    attrs: {},
    content: [
      {
        tag: "interactive",
        attrs: { type: "native_flow", v: "1" },
        content: [
          {
            tag: "native_flow",
            attrs: { v: "9", name: "mixed" },
          },
        ],
      },
    ],
  };

  const isGroup = chatId.endsWith("@g.us");
  if (isGroup) return [bizNode];

  return [bizNode, { tag: "bot", attrs: { biz_bot: "1" } }];
}

export interface QuickButton {
  /** معرّف داخلي فقط (لا يصل فعليًا لواتساب) — نتركه للتوثيق/التتبع */
  id: string;
  /** النص الظاهر على الزر — هذا بالضبط ما يصل كرسالة عند الضغط عليه */
  text: string;
}

/**
 * خريطة: نص الزر (كما هو، بعد trim) → اسم الأمر الحقيقي المسجّل بـ
 * commandRegistry (بدون بادئة). تُملأ تلقائيًا عبر sectionButton() أدناه.
 * يستخدمها messageHandler ليطابق أي رسالة واردة من ضغطة زر بأمرها الصحيح
 * بغض النظر عن الزخرفة/الإيموجي الموجودة على الزر.
 */
const buttonTriggerMap = new Map<string, string>();
// نسخة ثانية بمفاتيح "منظّفة" (بدون إيموجي/رموز زخرفية/مسافات زايدة/علامات
// اتجاه خفية RTL) — تحمي المطابقة لو واتساب رجّع نص الزر بشكل مختلف شوي
// عن اللي أرسلناه بالضبط (زر بلا إيموجي، مسافة إضافية، حرف اتجاه مخفي...).
const normalizedButtonTriggerMap = new Map<string, string>();
// كل أسماء الأوامر (بدون زخرفة) اللي عندها زر واحد على الأقل — تُستخدم
// كخطة أخيرة: أي نص وارد يتحول بعد التنظيف لنفس اسم الأمر بالضبط (بأي
// إيموجي/زخرفة كانت قبله أو بعده، مو بس اللي سجّلناه نحن بالزر) يُقبل.
const buttonCommandNames = new Set<string>();

/** يشيل الإيموجي والرموز الزخرفية وعلامات الاتجاه الخفية ويوحّد المسافات */
function normalizeButtonText(raw: string): string {
  return raw
    .replace(/[\u200e\u200f\u202a-\u202e]/g, "") // علامات اتجاه خفية (RTL/LTR marks)
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u2B00-\u2BFF]/gu, "") // إيموجي شائعة
    .replace(/\s+/g, " ")
    .trim();
}

/** يبني زر قسم واحد ويسجّله تلقائيًا بخريطة المطابقة */
export function sectionButton(command: string, label: string): QuickButton {
  const trimmed = label.trim();
  buttonTriggerMap.set(trimmed, command);
  const normalized = normalizeButtonText(trimmed);
  if (normalized) normalizedButtonTriggerMap.set(normalized, command);
  buttonCommandNames.add(command);
  return { id: `${CONFIG.PREFIX}${command}`, text: label };
}

/** يبحث عن أمر مطابق لنص وصل من ضغطة زر. يرجع undefined لو مش نص زر معروف */
export function matchButtonTrigger(text: string): string | undefined {
  const trimmed = text.trim();
  const exact = buttonTriggerMap.get(trimmed);
  if (exact) return exact;

  // خطة بديلة: مطابقة بعد تنظيف النص (بدون إيموجي/رموز/مسافات زايدة)
  const normalized = normalizeButtonText(trimmed);
  if (!normalized) return undefined;
  const byLabel = normalizedButtonTriggerMap.get(normalized);
  if (byLabel) return byLabel;

  // خطة أخيرة: النص بعد التنظيف يطابق اسم أمر عنده زر بالأصل — بغض النظر
  // عن أي زخرفة/إيموجي كانت محيطة فيه (حتى لو مو نفس اللي سجّلناه إحنا).
  if (buttonCommandNames.has(normalized)) return normalized;
  return undefined;
}

/** زر خام (name + buttonParamsJson) بأي نوع native_flow تدعمه واتساب — يُستخدم
 * لأنواع غير "quick_reply/cta_url" العاديتين (مثال: buildCopyCodeButton بالأسفل). */
export interface RawFlowButton {
  name: string;
  buttonParamsJson: string;
}

/**
 * 🆕 (طلب صريح: "أزرار مش جهة اتصال") — زر يفتح رابط واتساب مباشرة
 * (wa.me/<رقم>) بدل إرسال بطاقة جهة اتصال (vCard). يُستخدم بقسم ".المطورين".
 */
export function waLinkButton(label: string, phoneNumber: string): RawFlowButton {
  const url = `https://wa.me/${phoneNumber.replace(/[^0-9]/g, "")}`;
  return {
    name: "cta_url",
    buttonParamsJson: JSON.stringify({ display_text: label, url, merchant_url: url }),
  };
}

/**
 * 🆕 (طلب صريح: "زر واحد يفتح نافذة فيها أزرار" بدل صف طويل من الأزرار)
 * يبني زر واحد من نوع native_flow "single_select" — نفس زر "قائمة" الأصلي
 * بواتساب: يظهر كزر واحد فقط بالرسالة، وعند الضغط عليه يفتح واتساب نافذة
 * منفصلة فيها كل الخيارات (rows) كقائمة يختار المستخدم منها بند واحد.
 * كل بند يُسجَّل تلقائيًا بنفس خريطة مطابقة الأزرار (matchButtonTrigger)
 * عبر sectionButton() الأصلية، فيشتغل بالضبط زي أي زر عادي بعد الاختيار.
 */
/** يجلب وصف الأمر من السجل تلقائيًا لو ما انكتب وصف للصف — require كسول لتفادي الاستيراد الدائري. */
function autoRowDescription(command: string): string {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { commandRegistry } = require("../handlers/commandRegistry");
    const name = command.trim().split(/\s+/)[0];
    return commandRegistry.get(name)?.description || "";
  } catch {
    return "";
  }
}

export function buildSingleSelectButton(
  buttonLabel: string,
  sectionTitle: string,
  rows: { command: string; label: string; description?: string }[]
): RawFlowButton {
  const listRows = rows.map((r, i) => {
    // يسجل نفس البند بخريطة المطابقة العادية (بدون إرجاع QuickButton فعلي —
    // ما نستخدمه هنا كزر مستقل، فقط للتسجيل بخريطة matchButtonTrigger).
    sectionButton(r.command, r.label);
    const id = `${CONFIG.PREFIX}${r.command}_${i}`;
    // 🐛 (إصلاح جذري) — لما المستخدم يختار بند من قائمة "single_select"،
    // واتساب لا يرجّع نص العنوان (title) إطلاقًا، يرجّع حرفيًا نفس قيمة
    // "id" اللي حطيناها بالسطر فوق (عبر listResponseMessage.singleSelectReply
    // .selectedRowId). matchButtonTrigger() كانت تطابق فقط على نص العنوان
    // (r.label)، فأي اختيار من قائمة منسدلة كان يفشل دائمًا بتحذير "ضغطة
    // زر لم تُطابَق بأي أمر" رغم إن الزر شغال ظاهريًا. الحل: نسجل الـid
    // نفسه بخريطة المطابقة أيضًا، فيتطابق تمامًا كما وصل من واتساب.
    buttonTriggerMap.set(id, r.command);
    return {
      header: "",
      title: r.label,
      // وصف تحت كل أمر: من الصف نفسه، وإلا من وصف الأمر المسجّل (حد واتساب ~72 حرف)
      description: (r.description || autoRowDescription(r.command)).slice(0, 72),
      id,
    };
  });

  return {
    name: "single_select",
    buttonParamsJson: JSON.stringify({
      title: buttonLabel,
      sections: [{ title: sectionTitle, rows: listRows }],
    }),
  };
}

/**
 * قائمة اختيار بعدة أقسام (sections) — كل قسم له عنوان وبنوده. نفس آلية
 * buildSingleSelectButton (id البند = ".<الأمر>" فيُنفَّذ الأمر مباشرة عند الاختيار).
 * تُستخدم مثلًا لقائمة «النقلات المتاحة» بالشطرنج مقسّمة حسب القطعة.
 */
export function buildSectionedSelectButton(
  buttonLabel: string,
  sections: { title: string; rows: { command: string; label: string; description?: string }[] }[]
): RawFlowButton {
  return {
    name: "single_select",
    buttonParamsJson: JSON.stringify({
      title: buttonLabel,
      sections: sections
        .filter((sec) => sec.rows.length)
        .map((sec) => ({
          title: sec.title.slice(0, 24),
          rows: sec.rows.map((r) => {
            const id = `${CONFIG.PREFIX}${r.command}`;
            buttonTriggerMap.set(id, r.command);
            return { header: "", title: r.label.slice(0, 24), description: (r.description || "").slice(0, 72), id };
          }),
        })),
    }),
  };
}

/**
 * 🆕 (ميزة .تنصيب) زر "نسخ الكود" — نوع native_flow حقيقي بواتساب
 * (cta_copy) يخلي المستخدم يضغط فينسخ القيمة مباشرة لحافظة جهازه، بدل
 * ما يحتاج يحدد النص يدويًا. best-effort مثل باقي الأزرار هنا بالضبط —
 * لو فشل الإرسال بأي جهاز يرجع تلقائيًا لرسالة عادية عبر sendButtonMessage
 * (والكود يبقى ظاهر بنص الرسالة نفسه فينسخه المستخدم يدويًا بكل الأحوال).
 */
export function buildCopyCodeButton(code: string, label = "🔡انسخ الكود"): RawFlowButton {
  return {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
      display_text: label,
      id: `copy_code_${Date.now()}`,
      copy_code: code,
    }),
  };
}

function buildNativeFlowButtons(
  quickButtons: QuickButton[],
  extraButtons: RawFlowButton[] = [],
  excludeUtilityButtons = false
) {
  const buttons: { name: string; buttonParamsJson: string }[] = [
    ...extraButtons,
    ...quickButtons.map((b) => ({
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({ display_text: b.text, id: b.id }),
    })),
  ];

  // 🆕 (طلب صريح: إزالة أزرار المطور/الدعم/القناة من رسالة قرار الطرد
  // بعد 3 تحذيرات) — لو excludeUtilityButtons=true نتوقف هنا، فترجع فقط
  // الأزرار المخصصة للأمر (extraButtons + quickButtons) بدون أي إضافة.
  if (excludeUtilityButtons) return buttons;

  // 🔧 (طلب صريح) أزرار مراسلة المطورين حُذفت من كل الرسائل — التواصل صار بقسم
  // مستقل (.تواصل) بدل زر ثابت بكل رسالة.

  // 🆕 زر دعم البوت: يفتح كروب الدعم مباشرة (نفس فكرة زر "مراسلة المطور"
  // بالضبط، بس برابط كروب بدل رقم واتساب). يظهر قبل زر "عرض القناة"
  // مباشرة. الرابط يُقرأ من CONFIG.SUPPORT_GROUP_LINK — لو فارغ، الزر
  // لا يُضاف إطلاقًا لتفادي زر مكسور بلا رابط.
  if (CONFIG.SUPPORT_GROUP_LINK) {
    buttons.push({
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        // 🔧 (طلب صريح) تغيير اسم هذا الزر إلى "🔱الــتــنــصــيــب🔱" —
        // الرابط يبقى نفسه (SUPPORT_GROUP_LINK)، فقط النص الظاهر تغيّر.
        display_text: "🔱الــتــنــصــيــب🔱",
        url: CONFIG.SUPPORT_GROUP_LINK,
        merchant_url: CONFIG.SUPPORT_GROUP_LINK,
      }),
    });
  }

  // 🔧 (طلب صريح جديد) حذفنا زر "📢 عرض القناة" اليدوي هنا نهائيًا — تاغ
  // "معاد توجيهها" (buildNewsletterForwardContext بالأعلى) أصلًا يعرض اسم
  // القناة كعنصر قابل للضغط تلقائيًا فوق الرسالة نفسها، فصار الزر مكرر.
  // الأزرار الثابتة المتبقية هنا (مراسلة المطور/الدعم) تبقى كما هي.

  return buttons;
}

/**
 * يبني رأس الرسالة التفاعلية (Header) بصورة أو فيديو مرفق داخل نفس
 * الرسالة (مش رسالة منفصلة). يستخدم generateWAMessageContent الرسمية
 * من نفس مكتبة Baileys لرفع/تجهيز الميديا بنفس الطريقة التي تستخدمها
 * أي رسالة صورة/فيديو عادية، ثم يُدرجها داخل header الرسالة التفاعلية.
 */
async function buildMediaHeader(
  sock: WASocket,
  media?: { image?: Buffer; video?: Buffer; gifPlayback?: boolean }
): Promise<any> {
  if (!media || (!media.image && !media.video)) return undefined;
  try {
    if (media.image) {
      const content = await generateWAMessageContent(
        { image: media.image },
        { upload: sock.waUploadToServer } as any
      );
      if (!content.imageMessage) return undefined;
      return { hasMediaAttachment: true, imageMessage: content.imageMessage };
    }
    if (media.video) {
      const content = await generateWAMessageContent(
        { video: media.video, gifPlayback: media.gifPlayback ?? true },
        { upload: sock.waUploadToServer } as any
      );
      if (!content.videoMessage) return undefined;
      return { hasMediaAttachment: true, videoMessage: content.videoMessage };
    }
  } catch (err) {
    logger.warn("⚠️ تعذر تجهيز الميديا داخل رأس الرسالة التفاعلية.", err);
  }
  return undefined;
}

export async function sendButtonMessage(
  sock: WASocket,
  chatId: string,
  opts: {
    text: string;
    footer?: string;
    quoted?: WAMessage;
    mentions?: string[];
    quickButtons?: QuickButton[];
    /** 🆕 أزرار خام إضافية (مثل زر نسخ الكود) — تُضاف قبل أزرار quickButtons */
    extraButtons?: RawFlowButton[];
    /** صورة أو فيديو تُرفق برأس نفس الرسالة (بدل رسالة منفصلة) */
    image?: Buffer;
    video?: Buffer;
    gifPlayback?: boolean;
    /** نص بديل يُضاف بآخر الرسالة العادية لو فشلت الأزرار (بدون أي رقم/رابط) */
    fallbackNote?: string;
    /**
     * 🆕 (طلب صريح: إزالة أزرار المطور/القناة/الكروب من رسالة قرار الطرد
     * بعد 3 تحذيرات) — لو true، الرسالة تعرض فقط أزرار quickButtons/
     * extraButtons المحدّدة صراحة، بدون إضافة صف الأزرار الثابتة (مراسلة
     * المطور، المطور الثاني، الدعم، القناة) اللي تُضاف تلقائيًا بكل رسالة
     * أزرار عادية بالمشروع.
     */
    excludeUtilityButtons?: boolean;
  }
): Promise<void> {
  // القالب الموحّد لكل الرسائل (لا يعيد تأطير نص مؤطّر أصلًا)
  opts = { ...opts, text: autoFrame(opts.text, chatId) };
  try {
    const header = await buildMediaHeader(sock, {
      image: opts.image,
      video: opts.video,
      gifPlayback: opts.gifPlayback,
    });

    const content = proto.Message.fromObject({
      interactiveMessage: {
        header,
        body: { text: opts.text },
        footer: opts.footer ? { text: opts.footer } : undefined,
        nativeFlowMessage: {
          buttons: buildNativeFlowButtons(
            opts.quickButtons || [],
            opts.extraButtons || [],
            opts.excludeUtilityButtons
          ),
        },
        // 🆕 (بند 5) ندمج تاغ "معاد توجيهها" الأزرق (لو CHANNEL_JID مضبوط)
        // مع منشن المستلمين (لو فيه) بنفس كائن contextInfo الواحد — واتساب
        // يتجاهل أي حقل فارغ/undefined بهدوء فما فيه خطر كسر أي حالة قديمة.
        contextInfo:
          opts.mentions?.length || buildNewsletterForwardContext()
            ? {
                ...(opts.mentions?.length ? { mentionedJid: opts.mentions } : {}),
                ...(buildNewsletterForwardContext() || {}),
              }
            : undefined,
      },
    });

    const waMessage = generateWAMessageFromContent(chatId, content, {
      userJid: sock.user?.id || "",
      quoted: opts.quoted?.message ? opts.quoted : undefined,
    } as any);

    await sock.relayMessage(chatId, waMessage.message!, {
      messageId: waMessage.key.id || undefined,
      additionalNodes: buildInteractiveBinaryNodes(chatId),
    } as any);
  } catch (err) {
    logger.warn(
      "⚠️ تعذر إرسال رسالة بأزرار تفاعلية (native buttons)، تم الرجوع تلقائيًا لرسالة عادية (نفس الصورة والنص بدون أزرار).",
      err
    );
    const fallbackText = `${opts.text}${opts.fallbackNote ? `\n\n${opts.fallbackNote}` : ""}`;
    // 🆕 (بند 5) نمرر نفس تاغ "معاد توجيهها" حتى لرسالة الرجوع العادية
    // (لو فشلت الأزرار)، عبر contextInfo — sock.sendMessage يقبله كخيار
    // إضافي بجانب mentions بدون أي تعارض.
    const newsletterCtx = buildNewsletterForwardContext();
    // 🔒 __skipBrand: علامة داخلية بحتة (راجع createBrandedSock بالأسفل) —
    // تمنع أي حلقة تكرار لا نهائية لو استُدعيت هذي الدالة أصلًا من داخل
    // sock مُغلَّف بالبراندنج التلقائي (منشن/زر القناة/المطور): بدونها،
    // فشل الأزرار هنا يرسل نص عادي، الغلاف يحاول يبرندنه من جديد عبر نفس
    // الدالة، تفشل بنفس السبب، فترجع نص عادي... حلقة بلا نهاية. توضع فقط
    // بالرسائل الاحتياطية هنا، وتُحذف قبل الإرسال الفعلي (باييليز ما
    // يفهمها، هي فقط إشارة داخلية لغلاف sendMessage).
    try {
      if (opts.image) {
        await sock.sendMessage(
          chatId,
          {
            image: opts.image,
            caption: fallbackText,
            mentions: opts.mentions,
            contextInfo: newsletterCtx as any,
            __skipBrand: true,
          } as any,
          opts.quoted ? { quoted: opts.quoted } : undefined
        );
      } else if (opts.video) {
        await sock.sendMessage(
          chatId,
          {
            video: opts.video,
            gifPlayback: opts.gifPlayback ?? true,
            caption: fallbackText,
            mentions: opts.mentions,
            contextInfo: newsletterCtx as any,
            __skipBrand: true,
          } as any,
          opts.quoted ? { quoted: opts.quoted } : undefined
        );
      } else {
        await sock.sendMessage(
          chatId,
          { text: fallbackText, mentions: opts.mentions, contextInfo: newsletterCtx as any, __skipBrand: true } as any,
          opts.quoted ? { quoted: opts.quoted } : undefined
        );
      }
    } catch (fallbackErr) {
      logger.error("❌ فشل حتى الرجوع للرسالة العادية:", fallbackErr);
    }
  }
}

/** أزرار التنقل القياسية (رجوع للقائمة الرئيسية) تُستخدم بعد أي قائمة قسم فرعي */
export function navButtons(): QuickButton[] {
  return [sectionButton("menu", "🏠 القائمة الرئيسية")];
}

/**
 * ============================================================================
 * 🆕 (طلب صريح: "كل الرسائل الي لا تحتوي على صورة حط فيها صورة بروفايل
 * أي مستخدم وزر القناة وزر المطور... حتى أوامر النذار أوامر نكت تنمر")
 * ============================================================================
 * يبني نسخة "مُبرندة" من sock تُستخدم فقط داخل ctx.sock بسياق تنفيذ
 * الأوامر (راجع messageHandler.ts) — أي أمر يرسل رسالة "نص فقط" (بدون
 * صورة/فيديو/ستيكر/مستند...) عبر ctx.sock.sendMessage تتحول تلقائيًا
 * لرسالة أزرار تفاعلية (نفس sendButtonMessage) بصورة بروفايل أول شخص
 * بالمنشن (mentions[0]) لو موجود، وإلا صورة بروفايل المرسل نفسه —
 * وزرّا "مراسلة المطور"/"عرض القناة" مضافان تلقائيًا لأنهما جزء أصلي من
 * كل رسالة أزرار (راجع buildNativeFlowButtons أعلاه، ما يحتاج أي تعديل
 * إضافي هنا).
 *
 * ⚠️ عمدًا محصور بـ ctx.sock فقط (مو sock الخام بـ index.ts) — رسائل
 * الترحيب/الوداع/الجدولة/قرار الطرد وغيرها تُرسل عبر sock الخام مباشرة
 * وتبقى تمامًا كما هي (أغلبها أصلًا فيها صورة مرفقة يدويًا).
 *
 * ⚠️ حماية من التكرار اللانهائي: sendButtonMessage نفسها، عند فشل
 * الأزرار، ترجع لرسالة عادية عبر sock.sendMessage — لو مرّرنا هذا الـ
 * sock نفسه (المُبرندن) لها، هذي الرسالة الاحتياطية كانت ح تتحول
 * لبراندنج من جديد، يفشل بنفس السبب، يرجع لعادية من جديد... حلقة بلا
 * نهاية. الحل: نمرر لها sock *الخام الأصلي* دائمًا (المتغير `sock` هنا
 * بالإغلاق closure)، وكل رسائلها الاحتياطية موسومة أصلًا بـ __skipBrand
 * (راجع نهاية sendButtonMessage أعلاه) كحماية مضاعفة.
 */
function isPlainBrandableText(
  content: unknown
): content is { text: string; mentions?: string[]; contextInfo?: unknown } {
  if (!content || typeof content !== "object") return false;
  if ((content as any).__skipBrand) return false;
  const c = content as Record<string, unknown>;
  if (typeof c.text !== "string" || !c.text.trim()) return false;
  const allowedKeys = new Set(["text", "mentions", "contextInfo"]);
  return Object.keys(c).every((k) => allowedKeys.has(k));
}

export function createBrandedSock(sock: WASocket, fallbackPictureJid?: string): WASocket {
  const rawSendMessage = sock.sendMessage.bind(sock);

  const branded = { ...sock } as WASocket;
  // 🔧 إصلاح جذري مهم جدًا (السبب الحقيقي المحتمل وراء: ".ايقاف/.تشغيل
  // مو شغالة"، "المطور الثاني ما يُعتبر مطور"، "البوتات الفرعية ما تعتبر
  // صاحبها مطور"): `{ ...sock }` أعلاه ينسخ فقط الخصائص العادية القابلة
  // للتعداد (enumerable own properties). مكتبة Baileys غالبًا تعرّف
  // "sock.user" كـgetter (خاصية محسوبة)، وهذا النوع من الخصائص **لا
  // ينتقل تلقائيًا عبر spread** — فيصير "branded.user" = undefined
  // بصمت تام، رغم إن sock.user الأصلي فيه القيمة الصحيحة فعليًا! وبما إن
  // كل ميزات هذي المحادثة (getBotScopeId, isOwner الذاتي...) تعتمد على
  // ctx.sock.user لمعرفة "رقم هذا البوت بالذات"، كانت كلها ترجع
  // "unknown" دائمًا عبر أوامر command files (اللي تستخدم ctx.sock)، بينما
  // فحوصات messageHandler.ts (اللي تستخدم sock الخام مباشرة) ترجع الرقم
  // الصحيح — فيصير التخزين (عبر ctx.sock) والقراءة (عبر sock الخام)
  // بمفتاحين مختلفين تمامًا، فيبدو الأمر "ما يشتغل".
  // الحل: نجعل "user" بالنسخة المموّهة قراءة حيّة دائمًا من sock الأصلي
  // (getter صريح)، بغض النظر عن طريقة تعريفها الداخلية بمكتبة Baileys.
  Object.defineProperty(branded, "user", {
    get: () => sock.user,
    enumerable: true,
    configurable: true,
  });
  branded.sendMessage = (async (jid: string, content: any, options?: any) => {
    if (!isPlainBrandableText(content)) {
      if (content && typeof content === "object" && "__skipBrand" in content) {
        const { __skipBrand, ...rest } = content;
        return rawSendMessage(jid, rest, options);
      }
      return rawSendMessage(jid, content, options);
    }

    const mentionJid = content.mentions?.[0] || fallbackPictureJid;
    let image: Buffer | undefined;
    if (mentionJid) {
      try {
        const url = await sock.profilePictureUrl(mentionJid, "image");
        if (url) image = await downloadImageBuffer(url);
      } catch {
        image = undefined; // ما عنده صورة بروفايل أو تعذر تحميلها — نكمل بدون صورة
      }
    }

    try {
      // 🔧 دائمًا sock الخام الأصلي هنا (مو branded) — راجع تعليق الحماية
      // من التكرار اللانهائي أعلاه.
      await sendButtonMessage(sock, jid, {
        text: content.text,
        mentions: content.mentions,
        image,
        quoted: options?.quoted,
      });
      return undefined as any; // القيمة المرجعة غير مستخدمة بأي مكان بالمشروع حاليًا
    } catch (err) {
      logger.warn("⚠️ فشل تحويل رسالة نصية لرسالة مبرندة، رجوع لرسالة عادية بدون براندنج.", err);
      return rawSendMessage(jid, content as any, options);
    }
    // 🔧 تحويل عبر "unknown" أولًا (بدل "as typeof sock.sendMessage" مباشرة)
    // — بعض إصدارات تعريفات Baileys تجعل "sendMessage" دالة بعدة توقيعات
    // (overloads) لا تتقاطع بما يكفي هيكليًا مع دالتنا العامة هنا حسب
    // TypeScript (خطأ TS2352 "insufficient overlap")، فيرفض التحويل
    // المباشر أحيانًا. المرور بـ unknown هو الحل القياسي والآمن (لا يغيّر
    // أي سلوك وقت التشغيل إطلاقًا، فرق نوعي فقط وقت البناء).
  }) as unknown as typeof sock.sendMessage;

  return branded;
}
