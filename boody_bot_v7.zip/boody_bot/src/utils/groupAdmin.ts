import { WASocket, GroupMetadata } from "@whiskeysockets/baileys";
import { digitsOnly } from "./helpers";
import { logger } from "./logger";

export type ParticipantAction = "promote" | "demote" | "remove";

export interface AdminActionResult {
  ok: boolean;
  /** رمز حالة واتساب الفعلي لآخر محاولة فاشلة (403 = غير مصرّح، 404 = مو بالمجموعة...) */
  status?: string;
  reason?: string;
}

const REASONS: Record<string, string> = {
  "403": "واتساب رفض: البوت مو مشرف بالمجموعة (أو الشخص هو منشئ المجموعة).",
  "401": "واتساب رفض: البوت مو مشرف بالمجموعة.",
  "404": "الشخص مو موجود بالمجموعة.",
  "406": "واتساب رفض الطلب (غير مقبول).",
  "409": "العملية منفّذة أصلًا (الشخص بنفس الحالة).",
  "400": "واتساب ما فهم معرّف الشخص (مشكلة LID).",
};

/**
 * 🔧 إصلاح «رفع ادمن / ترقية / تنزيل / طرد» تقول نجحت لكن ما يتغير شي:
 * groupParticipantsUpdate ما يرمي خطأ لما واتساب يرفض — يرجّع مصفوفة فيها status
 * (403…) وكنا نعتبر عدم وجود استثناء = نجاح. الحين نقرأ status الفعلي، ونجرّب
 * كل صيغ معرّف العضو (id الخام / رقم الهاتف / LID) لأن مجموعات @lid تقبل بعضها فقط.
 */
export async function updateParticipant(
  sock: WASocket,
  chatId: string,
  action: ParticipantAction,
  target: string,
  metadata?: GroupMetadata | null
): Promise<AdminActionResult> {
  const digits = digitsOnly(target);
  const p = metadata?.participants.find(
    (x) => digitsOnly(x.id) === digits || digitsOnly((x as any).jid) === digits || digitsOnly((x as any).lid) === digits
  ) as any;
  const candidates = [...new Set([p?.id, p?.jid, p?.lid, target].filter((x): x is string => !!x))];

  let lastStatus = "";
  let lastErr = "";
  for (const jid of candidates) {
    try {
      const res: any[] = await sock.groupParticipantsUpdate(chatId, [jid], action);
      const st = String(res?.[0]?.status ?? "");
      if (st.startsWith("2") || st === "") {
        // «409» لـ promote/demote = الحالة موجودة أصلًا → نعتبرها نجاح منطقي
        return { ok: true, status: st || "200" };
      }
      lastStatus = st;
      if (st === "409") return { ok: true, status: st, reason: REASONS["409"] };
    } catch (err) {
      lastErr = err instanceof Error ? err.message : String(err);
      logger.warn(`groupParticipantsUpdate(${action}) فشل بالمعرّف ${jid}:`, err);
    }
  }
  return { ok: false, status: lastStatus || undefined, reason: REASONS[lastStatus] || (lastErr ? `خطأ: ${lastErr}` : "فشل غير معروف") };
}

/** هل البوت مشرف فعلًا؟ (فحص حي من واتساب، مو من كاش قديم) — للتشخيص فقط */
export async function isBotAdminLive(sock: WASocket, chatId: string): Promise<boolean | null> {
  try {
    const md = await sock.groupMetadata(chatId);
    const ids = [sock.user?.id, (sock.user as any)?.lid].map((x) => digitsOnly(x)).filter(Boolean);
    const me = md.participants.find((x: any) => ids.includes(digitsOnly(x.id)) || ids.includes(digitsOnly(x.jid)) || ids.includes(digitsOnly(x.lid)));
    return !!me && (me.admin === "admin" || me.admin === "superadmin");
  } catch {
    return null;
  }
}
