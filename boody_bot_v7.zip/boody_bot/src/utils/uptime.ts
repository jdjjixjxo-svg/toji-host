/**
 * وقت إقلاع البوت — يُسجَّل مرة واحدة فقط عند أول استيراد لهذا الملف
 * (يُستورد من src/index.ts عند بدء التشغيل)، وتقرأه أي قائمة/أمر لاحقًا
 * لحساب مدة التشغيل (Uptime) الحقيقية بدل قيمة وهمية.
 */
export const BOT_START_TIME = Date.now();

/** يحوّل مدة التشغيل بالميلي ثانية إلى صيغة عربية مقروءة: يوم/ساعة/دقيقة */
export function formatUptime(): string {
  const ms = Date.now() - BOT_START_TIME;
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const parts: string[] = [];
  if (days) parts.push(`${days}ي`);
  if (hours) parts.push(`${hours}س`);
  if (minutes) parts.push(`${minutes}د`);
  if (!days && !hours) parts.push(`${seconds}ث`);

  return parts.join(" ") || "0ث";
}
