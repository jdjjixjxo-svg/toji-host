/**
 * 🎭 بنك ردود تلقائية إضافي (بناءً على طلب صريح) — منفصل عن
 * FUN_REPLIES بملف funReplies.ts لأن أغلب هذي العبارات جمل/كلمات دقيقة
 * (مو مجرد بادئة كلمة وحدة)، فتحتاج دالة تحقق (test) خاصة بكل واحدة
 * بدل نظام "بادئة الكلمة" البسيط. تُفحص فقط على رسائل عادية (مو أوامر)
 * وبنفس شرط إعداد الردود_التلقائية — راجع الاستخدام بـ messageHandler.ts.
 */
import { stripDiacritics } from "./helpers";
import { CONFIG } from "../config/config";

/** ينظّف النص لغرض المطابقة: يشيل التشكيل + علامات الترقيم الشائعة + يوحّد المسافات */
function clean(text: string): string {
  return stripDiacritics(text.trim())
    .replace(/[.,!؟?،؛:"'*_\-()]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** يتحقق هل كلمة معينة موجودة *بالضبط* داخل الرسالة (مو مجرد جزء من كلمة أطول) */
function hasExactWord(text: string, word: string): boolean {
  return clean(text).split(" ").includes(word);
}

/**
 * 🆕 يتحقق هل كلمة معينة هي *أول كلمة* بالرسالة بالضبط (أو الرسالة كلها
 * بس هالكلمة) — بعكس hasExactWord اللي تقبل الكلمة بأي مكان بالرسالة.
 * طُلب صراحة لكلمة "هاي": كانت ترد على أي رسالة تحتوي "هاي" بأي موضع
 * (مثلاً "شلونك هاي" أو "هاي شلونك")، والمطلوب فقط لو "هاي" أول كلمة
 * (تغطي حالة الرسالة "هاي" لوحدها تلقائيًا، لأنها حينها أول وآخر كلمة).
 */
function isFirstWord(text: string, word: string): boolean {
  const parts = clean(text).split(" ").filter(Boolean);
  return parts[0] === word;
}

// ===== ردود عامة للجميع =====
export interface QuickReply {
  test: (text: string) => boolean;
  replies: string[];
  // 🆕 (طلب صريح: "ردود المطور تكون بس لرقم المطور الرئيسي... حد قال
  // خرس ما يرد عليه برد يخص المطور، أريده للمطور بس") — هذي الردود
  // نصها يخاطب الشخص وكأنه المطور ("لو انك مو مطوري بس"...)، وما كان
  // فيه أي تحقق فعلي من الهوية — أي عضو عادي يكتب "اخرس" كان يوصله نفس
  // الرد المخصص فعليًا للمطور. الآن نفلترها صراحة بـsenderJid.
  developerOnly?: true;
}

const QUICK_REPLIES: QuickReply[] = [
  {
    // "جيت" / "جييت" / أي مدّ إضافي بنفس الكلمة
    test: (t) => /^جي+ت$/.test(clean(t)) || hasExactWord(t, "جيت"),
    replies: ["لف ورجع من فين ما جيت 🙂"],
  },
  {
    // 🔧 إصلاح (طلب صريح): قبل كذا كانت ترد على "هاي" بأي موضع بالرسالة
    // (hasExactWord) — الآن ترد فقط لو "هاي" أول كلمة، أو الرسالة "هاي" لوحدها.
    test: (t) => isFirstWord(t, "هاي"),
    replies: ["*الله يعني ابوك عليك*"],
  },
  {
    test: (t) => hasExactWord(t, "بربك"),
    replies: ["علي اطلاق قبل ازواج كداب"],
  },
  {
    // "حاره" / "الجو حار" / "درجة الحرارة" وأي صيغة مشابهة
    test: (t) => {
      const c = clean(t);
      return (
        /الجو\s*حار/.test(c) ||
        /درجه?\s*الحراره?/.test(c) ||
        hasExactWord(t, "حاره") ||
        hasExactWord(t, "حار")
      );
    },
    replies: ["ستحمل يلا انت عربي"],
  },
  {
    test: (t) => /صدام\s*حسين/.test(clean(t)),
    replies: ["عم الكل"],
  },
  {
    test: (t) => hasExactWord(t, "العراق"),
    replies: ["احلى تحيه لبن بلدي"],
  },
  {
    test: (t) => hasExactWord(t, "مليت"),
    replies: ["عزمني ورقص لك 🙂"],
  },

  // 🆕 ردود مضافة بطلب صريح (دفعة جديدة)
  {
    // "اع" بأي عدد تكرار للحرف (اعععع...) — نفس فكرة "هيهيهي" بالأسفل
    test: (t) => /^اع{2,}$/.test(clean(t).replace(/\s+/g, "")),
    replies: ["وجععععععع"],
  },
  {
    test: (t) => hasExactWord(t, "باي"),
    replies: ["قول ستودعتكم وخلك فخامه⚕️"],
  },
  {
    // أي صيغة قريبة من "اكتمو البوت" / "كتم البوت" / "اسكتوا البوت"
    test: (t) => {
      const c = clean(t);
      return /(اكتم|كتم|اسكت|ساكت|اخرس)\w*\s*(ال)?بوت|(ال)?بوت\s*(اكتم|كتم|اسكت|ساكت|اخرس)\w*/.test(c);
    },
    replies: ["لهدرجه انا مضايقك 🙂 طب والله اني جامد"],
  },
  {
    // "ههههه" بأي عدد تكرار
    test: (t) => /^(هه){2,}h?$/.test(clean(t).replace(/\s+/g, "")),
    replies: ["دوم اضحكه حبيبي"],
  },
  {
    // "هيهيهي" بأي عدد تكرار
    test: (t) => /^(هي){2,}$/.test(clean(t).replace(/\s+/g, "")),
    replies: ["اضحك زي الخلق"],
  },
  {
    // "لا بنوري" لازم تُفحص *قبل* "منور" (بالأسفل بجدول المنشن) — وإلا
    // "منور" ما راح تنطبق أصلًا هنا، لكن نفس الترتيب صحيح ومهم لو تشابهت
    // الكلمات مستقبلًا
    test: (t) => /لا\s*بنوري/.test(clean(t)),
    replies: ["اششششششش"],
  },
  {
    test: (t) => hasExactWord(t, "منوره"),
    replies: ["بنورييييي"],
  },
  {
    test: (t) => {
      const words = clean(t).split(" ");
      return words.includes("بنات") || words.includes("البنات") || words.includes("بنوات");
    },
    replies: ["فينهم فينهم 🐶 سمعت طاري بنات فينه اموت فيهم"],
  },

  // ===== ردود مرتبطة بموضوع "المطور" (للمطور الرئيسي فقط — راجع تعليق developerOnly) =====
  {
    test: (t) => hasExactWord(t, "اخرس"),
    replies: ["والله لو انك مو مطوري بس"],
    developerOnly: true,
  },
  {
    // "انا مطوره" (يدّعي إنه هو المطور اللي برمج البوت) — غير "انا مطورك"
    // اللي إلها معالجة خاصة بالتحقق الفعلي (راجع messageHandler.ts)
    test: (t) => {
      const c = clean(t);
      return /انا\s*مطوره\b/.test(c) && !/انا\s*مطورك/.test(c);
    },
    replies: ["البوتات تطوره ناس محترمة وثرية، ليش انا خضي بمطور زيك 🙂"],
    developerOnly: true,
  },
  {
    // "قليل برمجه" لوحدها (بدون كلمة "بوت" ملاصقة — تلك إلها رد خاص فيه منشن، تحت)
    test: (t) => {
      const c = clean(t);
      return /قليل\s*برمجه/.test(c) && !/بوت\s*قليل\s*برمجه|قليل\s*برمجه\s*بوت/.test(c);
    },
    replies: ["تربيتك الفعو.. اقصد برمجتك 😅"],
    developerOnly: true,
  },
  {
    test: (t) => /احترم\s*مطورك/.test(clean(t)),
    replies: ["من زينه ههه ليتني باقي 0.1 ولا مسويني"],
    developerOnly: true,
  },
  {
    test: (t) => /طيح\s*الله\s*ح(ظ|ض)ك/.test(clean(t)),
    replies: ["عراقي مو بيدك"],
    developerOnly: true,
  },
];

/** يفحص كل الردود بالترتيب، ويرجّع أول رد مطابق (عشوائي من مصفوفته لو فيه أكثر من واحد) */
export function matchQuickReply(text: string, senderJid?: string): string | undefined {
  const senderDigits = senderJid ? senderJid.split("@")[0].split(":")[0].replace(/[^0-9]/g, "") : "";
  for (const item of QUICK_REPLIES) {
    if (item.developerOnly && senderDigits !== CONFIG.OWNER_NUMBER) continue;
    if (item.test(text)) {
      return item.replies[Math.floor(Math.random() * item.replies.length)];
    }
  }
  return undefined;
}

// ===== ردود تحتاج منشن فعلي (@) لرقم المطور داخل النص =====
interface MentionQuickReply {
  test: (text: string) => boolean;
  build: () => { text: string; mentions: string[] };
}

export const MENTION_QUICK_REPLIES: MentionQuickReply[] = [
  {
    // 🆕 (طلب صريح: غيّر رد "منور" ليصير منشن حقيقي لرقم محدد بدل رد نصي)
    test: (t) => hasExactWord(clean(t), "منور"),
    build: () => ({
      text: `بنور فهد@9647848333271`,
      mentions: ["9647848333271@s.whatsapp.net"],
    }),
  },
  {
    // 🆕 (طلب صريح) "حلو" → منشن فعلي لنفس رقم "فهد" المستخدم برد "منور"
    test: (t) => hasExactWord(clean(t), "حلو"),
    build: () => ({
      text: `زي فهد@9647848333271`,
      mentions: ["9647848333271@s.whatsapp.net"],
    }),
  },
  {
    // "بوت قليل برمجه" (أو معكوسة) — بنفس معنى "قليل برمجه" العادية، بس
    // موجهة للبوت تحديدًا فتحيله لمطوره الحقيقي بمنشن فعلي.
    test: (t) => /بوت\s*قليل\s*برمجه|قليل\s*برمجه\s*بوت/.test(clean(t)),
    build: () => ({
      text: `قول لـ@${CONFIG.OWNER_NUMBER} هو البرمجني.. ليش خضي مش زي باقي هل بوتات اخ بس الله يرحم انمرد`,
      mentions: [CONFIG.OWNER_JID],
    }),
  },
];

export function matchMentionQuickReply(text: string): MentionQuickReply | undefined {
  return MENTION_QUICK_REPLIES.find((item) => item.test(text));
}

/**
 * 🆕 (طلب صريح: "اربع احات → خمس احا"، "4 احات → خمس احا"، "خمس احات
 * → 6 احات"... خليها تعد كذا لحد الـ50") — رد ديناميكي (مو نص ثابت):
 * يفهم أي عدد بصيغة رقم (1-50) أو كلمة عربية شائعة (1-10)، ويرد بنفس
 * العدد +1 بصيغة رقمية "احات".
 * ⚠️ الكلمات العربية مدعومة فقط لـ1-10 (كتابة كل كلمات 11-50 يدويًا
 * غير عملي) — الأرقام بالخانات (كتابة "23 احات" مثلًا) مدعومة كاملة
 * لحد 50 زي ما طلبت بالضبط.
 */
const AHAT_WORD_NUMBERS: Record<string, number> = {
  واحد: 1,
  احده: 1,
  اثنين: 2,
  ثنتين: 2,
  ثلاث: 3,
  ثلاثه: 3,
  اربع: 4,
  اربعه: 4,
  خمس: 5,
  خمسه: 5,
  ست: 6,
  سته: 6,
  سبع: 7,
  سبعه: 7,
  ثمان: 8,
  ثمانيه: 8,
  تسع: 9,
  تسعه: 9,
  عشر: 10,
  عشره: 10,
};

export function matchAhatCounter(text: string): string | undefined {
  const c = clean(text);
  const m = c.match(/^(\d{1,2}|[\u0600-\u06FF]+)\s*احات?$/);
  if (!m) return undefined;

  const raw = m[1];
  const n = /^\d+$/.test(raw) ? parseInt(raw, 10) : AHAT_WORD_NUMBERS[raw];
  if (!n || n < 1 || n > 50) return undefined;

  const next = Math.min(n + 1, 50);
  return `${next} احات`;
}
