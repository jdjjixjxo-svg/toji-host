/**
 * محرّك متاهة 3D (Raycasting على طريقة Wolfenstein) — يرسم منظور الشخص الأول
 * كصورة PNG بكسل ببكسل بدون أي خط أو مكتبة إضافية (sharp فقط).
 * الشبكة: 1 = حائط، 0 = ممر، 2 = باب الخروج (كتلة خضراء متوهجة).
 */
import sharp from "sharp";

export type Grid = number[][];
export const DX = [0, 1, 0, -1]; // 0=شمال 1=شرق 2=جنوب 3=غرب
export const DY = [-1, 0, 1, 0];
export const DIR_NAMES = ["الشمال", "الشرق", "الجنوب", "الغرب"];

/** يولّد متاهة كاملة بحفر DFS (كل خلية متصلة). الحجم الفعلي = 2*cells+1 */
export function generateMaze(cells: number): { grid: Grid; exit: { x: number; y: number } } {
  const n = cells * 2 + 1;
  const grid: Grid = Array.from({ length: n }, () => Array(n).fill(1));
  const stack: [number, number][] = [[1, 1]];
  grid[1][1] = 0;
  while (stack.length) {
    const [cx, cy] = stack[stack.length - 1];
    const opts: [number, number][] = [];
    for (let d = 0; d < 4; d++) {
      const nx = cx + DX[d] * 2;
      const ny = cy + DY[d] * 2;
      if (nx > 0 && ny > 0 && nx < n - 1 && ny < n - 1 && grid[ny][nx] === 1) opts.push([nx, ny]);
    }
    if (!opts.length) {
      stack.pop();
      continue;
    }
    const [nx, ny] = opts[Math.floor(Math.random() * opts.length)];
    grid[(cy + ny) / 2][(cx + nx) / 2] = 0;
    grid[ny][nx] = 0;
    stack.push([nx, ny]);
  }
  const exit = { x: n - 2, y: n - 2 };
  grid[exit.y][exit.x] = 2;
  return { grid, exit };
}

const W = 480;
const H = 300;
const FOV_PLANE = 0.66;

/** يرسم منظور اللاعب من خلية (x,y) باتجاه dir */
export async function renderView(grid: Grid, x: number, y: number, dir: number): Promise<Buffer> {
  const buf = Buffer.alloc(W * H * 3);
  const px = x + 0.5;
  const py = y + 0.5;
  const dirX = DX[dir];
  const dirY = DY[dir];
  const planeX = -dirY * FOV_PLANE;
  const planeY = dirX * FOV_PLANE;

  // سقف وأرضية بتدرّج
  for (let row = 0; row < H; row++) {
    const half = H / 2;
    const t = Math.abs(row - half) / half; // 0 عند الأفق، 1 عند الحافة
    const isCeil = row < half;
    const r = isCeil ? 18 + t * 10 : 40 + t * 55;
    const g = isCeil ? 20 + t * 12 : 32 + t * 40;
    const b = isCeil ? 40 + t * 30 : 28 + t * 20;
    for (let col = 0; col < W; col++) {
      const i = (row * W + col) * 3;
      buf[i] = r;
      buf[i + 1] = g;
      buf[i + 2] = b;
    }
  }

  for (let col = 0; col < W; col++) {
    const camX = (2 * col) / W - 1;
    const rayX = dirX + planeX * camX;
    const rayY = dirY + planeY * camX;
    let mapX = Math.floor(px);
    let mapY = Math.floor(py);
    const deltaX = rayX === 0 ? 1e30 : Math.abs(1 / rayX);
    const deltaY = rayY === 0 ? 1e30 : Math.abs(1 / rayY);
    let stepX: number, stepY: number, sideX: number, sideY: number;
    if (rayX < 0) { stepX = -1; sideX = (px - mapX) * deltaX; } else { stepX = 1; sideX = (mapX + 1 - px) * deltaX; }
    if (rayY < 0) { stepY = -1; sideY = (py - mapY) * deltaY; } else { stepY = 1; sideY = (mapY + 1 - py) * deltaY; }
    let hit = 0;
    let side = 0;
    for (let guard = 0; guard < 64 && !hit; guard++) {
      if (sideX < sideY) { sideX += deltaX; mapX += stepX; side = 0; } else { sideY += deltaY; mapY += stepY; side = 1; }
      const cell = grid[mapY]?.[mapX];
      if (cell === undefined) { hit = 1; break; }
      if (cell > 0) hit = cell;
    }
    const perp = side === 0 ? sideX - deltaX : sideY - deltaY;
    const dist = Math.max(0.05, perp);
    const lineH = Math.min(H * 3, Math.floor(H / dist));
    const start = Math.max(0, Math.floor(H / 2 - lineH / 2));
    const end = Math.min(H - 1, Math.floor(H / 2 + lineH / 2));

    const fade = 1 / (1 + dist * 0.32);
    const shade = (side === 1 ? 0.72 : 1) * fade;
    // نقش بسيط: خطوط طوب أفقية خفيفة ليعطي إحساس ملمس
    let base: [number, number, number] = hit === 2 ? [70, 240, 130] : [118, 128, 170];
    for (let row = start; row <= end; row++) {
      let m = shade;
      if (hit === 1) {
        const v = ((row - (H / 2 - lineH / 2)) / lineH) * 6;
        if (Math.abs(v - Math.round(v)) < 0.05) m *= 0.78;
      }
      const i = (row * W + col) * 3;
      buf[i] = Math.min(255, base[0] * m);
      buf[i + 1] = Math.min(255, base[1] * m);
      buf[i + 2] = Math.min(255, base[2] * m);
    }
  }
  return sharp(buf, { raw: { width: W, height: H, channels: 3 } }).png().toBuffer();
}

/** خريطة علوية (من فوق) مع موقع اللاعب واتجاهه وباب الخروج */
export async function renderMap(grid: Grid, x: number, y: number, dir: number): Promise<Buffer> {
  const n = grid.length;
  const S = 24;
  const size = n * S;
  const buf = Buffer.alloc(size * size * 3);
  const put = (X: number, Y: number, c: [number, number, number]) => {
    if (X < 0 || Y < 0 || X >= size || Y >= size) return;
    const i = (Y * size + X) * 3;
    buf[i] = c[0]; buf[i + 1] = c[1]; buf[i + 2] = c[2];
  };
  for (let cy = 0; cy < n; cy++) {
    for (let cx = 0; cx < n; cx++) {
      const c: [number, number, number] = grid[cy][cx] === 1 ? [70, 76, 110] : grid[cy][cx] === 2 ? [70, 240, 130] : [225, 225, 235];
      for (let yy = 0; yy < S; yy++) for (let xx = 0; xx < S; xx++) put(cx * S + xx, cy * S + yy, c);
    }
  }
  const cxp = x * S + S / 2;
  const cyp = y * S + S / 2;
  for (let yy = -7; yy <= 7; yy++) for (let xx = -7; xx <= 7; xx++) if (xx * xx + yy * yy <= 49) put(cxp + xx, cyp + yy, [230, 50, 60]);
  for (let k = 0; k < 16; k++) for (let w = -1; w <= 1; w++) put(Math.round(cxp + DX[dir] * k + (DY[dir] !== 0 ? w : 0)), Math.round(cyp + DY[dir] * k + (DX[dir] !== 0 ? w : 0)), [255, 220, 60]);
  return sharp(buf, { raw: { width: size, height: size, channels: 3 } }).png().toBuffer();
}
