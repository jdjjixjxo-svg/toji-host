/**
 * مهلة افتراضية لكل استدعاء fetch بالمشروع (مرة واحدة على مستوى العملية).
 * أي طلب بدون signal صريح يُقطع بعد 45 ثانية بدل ما يعلق للأبد ويشغل مكان أمر بالطابور.
 * الطلبات التي تمرّر signal خاص بها تبقى كما هي.
 */
const DEFAULT_FETCH_TIMEOUT_MS = 45_000;

const originalFetch = globalThis.fetch;
if (typeof originalFetch === "function" && !(originalFetch as any).__boodyPatched) {
  const patched: typeof fetch = (input: any, init?: any) => {
    if (init?.signal) return originalFetch(input, init);
    return originalFetch(input, { ...(init || {}), signal: AbortSignal.timeout(DEFAULT_FETCH_TIMEOUT_MS) });
  };
  (patched as any).__boodyPatched = true;
  globalThis.fetch = patched;
}

export {};
