import { proto, WAMessage, GroupMetadata, WASocket, fetchLatestBaileysVersion } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { logger } from "./logger";
import { isDeveloper } from "./developerIdentity";

/**
 * يرسل تفاصيل خطأ فعلي للمطور — يستخدم بأي أمر ممكن يفشل لأسباب خارجية
 * (خدمة API، وسائط منتهية...) حتى يقدر المطور يشخّص السبب الحقيقي بدل
 * الاعتماد على رسالة عامة أو سجلات سيرفر ما عنده وصول لها.
 *
 * 🔧 إصلاح: قبل كذا كانت ترسل فقط لـ CONFIG.OWNER_JID (رقم ثابت من
 * .env). المشكلة: لو المطور نفسه هو من يشغّل الأمر بمحادثته الخاصة مع
 * البوت (أشيع سيناريو اختبار)، بعض حسابات واتساب الحديثة تفتح تلك
 * المحادثة بمعرّف "@lid" مختلف تمامًا عن "OWNER_NUMBER@s.whatsapp.net"
 * — فترسل الرسالة فعليًا (بدون أي خطأ) لكن لشات ثاني ما يشوفه المستخدم
 * أبدًا، فيحس إنه "ما وصله شي خالص". الحل: لو الشخص اللي شغّل الأمر هو
 * المطور نفسه (بمطابقة الأرقام)، نرسل كمان مباشرة بنفس المحادثة المفتوحة
 * حاليًا (chatId) كضمان — هذا المسار مضمون 100% لأنه نفس الشات اللي هو
 * شايفه أصلًا، بغض النظر عن أي التباس JID/@lid.
 */
export async function notifyOwnerOfError(
  sock: WASocket,
  command: string,
  reason: string,
  ctx?: { chatId: string; senderJid: string }
) {
  const text = `⚠️ *خطأ فعلي بأمر ${command}*\n\n${reason}`;

  try {
    await sock.sendMessage(CONFIG.OWNER_JID, { text });
  } catch (err) {
    logger.warn(`تعذر إرسال تفاصيل خطأ ${command} لرقم المطور الثابت (OWNER_JID).`, err);
  }

  if (ctx && isDeveloperIdentity(ctx.senderJid)) {
    const isSameChat = digitsOnly(ctx.chatId) === digitsOnly(CONFIG.OWNER_NUMBER);
    if (!isSameChat) {
      try {
        await sock.sendMessage(ctx.chatId, { text });
      } catch (err) {
        logger.warn(`تعذر إرسال تفاصيل خطأ ${command} بنفس محادثة المطور.`, err);
      }
    }
  }
}

/**
 * 🔧 (توحيد مركزي: "لا تجعل كل أمر يخترع طريقة تحقق مختلفة") — كانت هذي
 * دالة مستقلة تكرر نفس منطق isOwner() يدويًا هنا، وكانت **ناسية بالكامل
 * فحص المطور الثاني (CONFIG.OWNER_NUMBER_2)** — يعني المطور الثاني ما
 * كان يحصل على نسخة من رسائل خطأ الأوامر على الخاص حتى لو هو نفسه من
 * شغّل الأمر اللي فشل. الحل: تُفوَّض الآن بالكامل لـutils/developerIdentity.ts
 * (المصدر المركزي الوحيد لمفهوم "مطور" بكل المشروع).
 */
function isDeveloperIdentity(jid: string): boolean {
  return isDeveloper(jid);
}

const DEFAULT_WA_VERSION: [number, number, number] = [2, 3000, 1042466098];

/**
 * 🔧 إصلاح جذري لسبب فشل الربط ("تعذّر ربط الجهاز" بالهاتف، سواء بكود
 * الاقتران أو حتى QR): دالة Baileys الرسمية `fetchLatestBaileysVersion`
 * ترجع نسخة بروتوكول واتساب-ويب متوقفة (Stale) رغم أنها تعلّم عليها
 * "isLatest: true" — واتساب يقبل الطلب ويولّد كود/QR بشكل طبيعي، لكنه
 * يرفض إتمام الربط الفعلي لأن رقم النسخة قديم من منظور سيرفراته. هذا
 * موثّق كخلل معروف بمكتبة Baileys نفسها (raileys/Baileys#2679).
 *
 * البديل `fetchLatestWaWebVersion` يجيب رقم النسخة الفعلي الحالي من
 * واتساب-ويب مباشرة (مو من كاش/قائمة المكتبة الداخلية) فيصير الربط
 * ناجح فورًا. نستخدمه أولًا، ولو فشل (مثلًا نسخة قديمة من الحزمة ما
 * عندها هذا التصدير) نرجع لـ fetchLatestBaileysVersion، ولو فشلت هي
 * كمان نستخدم رقم نسخة حديث ثابت كخيار أخير بدل قيمة قديمة جدًا.
 */
export async function getWaVersion(): Promise<[number, number, number]> {
  try {
    // بعض إصدارات الحزمة القديمة ما تصدّر هذي الدالة — نستوردها ديناميكيًا
    // حتى ما يفشل الاستيراد كامل لو غير موجودة.
    const baileys = await import("@whiskeysockets/baileys");
    const fetchLatestWaWebVersion = (baileys as any).fetchLatestWaWebVersion;
    if (typeof fetchLatestWaWebVersion === "function") {
      const { version } = await fetchLatestWaWebVersion({});
      if (Array.isArray(version) && version.length === 3) {
        // 🩺 تشخيص: يطبع بالضبط أي نسخة استُخدمت وأي مصدر — مهم جدًا
        // لتشخيص مشاكل الربط لاحقًا بدون تخمين.
        logger.info(`🩺 نسخة واتساب-ويب المستخدمة (fetchLatestWaWebVersion — المصدر الصحيح): ${version.join(".")}`);
        return version as [number, number, number];
      }
    }
  } catch (err) {
    logger.warn("تعذر جلب نسخة واتساب-ويب الفعلية (fetchLatestWaWebVersion)، تجربة البديل...", err);
  }

  try {
    const { version } = await fetchLatestBaileysVersion();
    logger.warn(
      `🩺 استُخدم fetchLatestBaileysVersion كبديل (نسخة: ${version.join(
        "."
      )}) — هذا المصدر معروف بإرجاع نسخة قديمة أحيانًا (Baileys#2679) وقد يسبب فشل الربط. راجع لماذا فشل fetchLatestWaWebVersion أعلاه بالسجل.`
    );
    return version as [number, number, number];
  } catch (err) {
    logger.warn("تعذر جلب أحدث إصدار لبروتوكول واتساب من Baileys أيضًا، سيتم استخدام إصدار افتراضي ثابت.", err);
    logger.warn(`🩺 استُخدم الإصدار الثابت الاحتياطي: ${DEFAULT_WA_VERSION.join(".")}`);
    return DEFAULT_WA_VERSION;
  }
}

/**
 * يستخرج "id" الزر اللي ضغط عليه المستخدم من رسائل الأزرار التفاعلية
 * الحديثة (native flow: quick_reply/cta_reply...)، والتي تصل بصيغة
 * interactiveResponseMessage مع paramsJson (نص JSON) بدل حقل مباشر.
 * نُرجع undefined بأمان لو الشكل غير متوقع بدل ما نكسر استخراج النص كامل.
 */
function extractNativeFlowId(m: proto.IMessage): string | undefined {
  const paramsJson = m.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
  if (!paramsJson) return undefined;
  try {
    const parsed = JSON.parse(paramsJson);
    // بعض نسخ واتساب ترجع id، وبعضها ترجع display_text كحقل بديل — نجرب الاثنين
    if (typeof parsed?.id === "string" && parsed.id) return parsed.id;
    if (typeof parsed?.display_text === "string" && parsed.display_text) return parsed.display_text;
    return undefined;
  } catch {
    return undefined;
  }
}

/** يستخرج النص من أي نوع رسالة (نصية، كابشن صورة، رد، ضغطة زر...) */
export function extractMessageText(msg: WAMessage): string {
  const m = msg.message;
  if (!m) return "";
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    (m.buttonsResponseMessage as any)?.selectedDisplayText ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    (m as any).templateButtonReplyMessage?.selectedId ||
    (m as any).templateButtonReplyMessage?.selectedDisplayText ||
    extractNativeFlowId(m) ||
    // بعض الأجهزة/النسخ ترجع نص الزر داخل body الرسالة التفاعلية نفسها
    (m.interactiveResponseMessage as any)?.body?.text ||
    ""
  ).trim();
}

/** يرجع الرسالة المقتبسة (Quoted) إن وجدت */
export function getQuotedMessage(
  msg: WAMessage
): proto.IMessage | null | undefined {
  return msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
}

/** يرجع JID صاحب الرسالة المقتبسة إن وجد */
export function getQuotedParticipant(msg: WAMessage): string | undefined {
  // 🔧 حقل participant القادم من Baileys/protobuf نوعه الفعلي
  // "string | null | undefined" (proto3 optional) — إرجاعه مباشرة بدون
  // تحويل يسبب خطأ نوع (TS2322: null غير قابل للإسناد لـ string|undefined).
  return msg.message?.extendedTextMessage?.contextInfo?.participant || undefined;
}

/**
 * 🔧 إصلاح مهم (سبب "أوامر .ملصق/.صوره/.تغيير_الصورة ما تشتغل أحيانًا
 * على وسائط مردود عليها"، خصوصًا صور/فيديوهات ليست حديثة جدًا):
 * كانت هذي الأوامر تبني كائن رسالة وهمي لتحميل الوسائط المقتبسة بالشكل
 * `{ message: quoted, key: msg.key }` — أي تستخدم "key" الرسالة الحالية
 * (رسالة الرد نفسها اللي فيها الأمر النصي، مثل ".ملصق") بدل "key" الرسالة
 * الأصلية المقتبسة (الصورة/الفيديو الفعلي). روابط وسائط واتساب تنتهي
 * صلاحيتها بسرعة نسبيًا، فحين تفشل Baileys بفك التشفير تحاول تلقائيًا
 * "إعادة الطلب" (reuploadRequest) باستخدام id/participant الموجودين
 * بالـ key — ولأنها كانت id الرسالة الخطأ (رسالة الرد لا الوسائط)، يفشل
 * طلب إعادة الرفع من سيرفرات واتساب، فيفشل الأمر بالكامل بصمت أو برسالة
 * خطأ عامة. الحل: نبني الـ key الصحيح فعليًا من contextInfo (stanzaId
 * وparticipant الحقيقيين للرسالة المقتبسة) بدل استعارة key رسالة الرد.
 */
export function buildQuotedMessage(msg: WAMessage): WAMessage | null {
  const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
  const quotedMessage = contextInfo?.quotedMessage;
  if (!quotedMessage) return null;
  return {
    key: {
      remoteJid: msg.key.remoteJid,
      fromMe: false,
      id: contextInfo?.stanzaId || undefined,
      participant: contextInfo?.participant || undefined,
    },
    message: quotedMessage,
  } as WAMessage;
}

/** يستخرج JIDs المذكورين (@منشن) داخل الرسالة */
export function getMentionedJids(msg: WAMessage): string[] {
  return msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

/**
 * ينسق الوقت والتاريخ بالعربي، لكن بأرقام إنجليزية (1 2 3) دائمًا وليس
 * الأرقام الهندية العربية (١ ٢ ٣) — طلب صريح لتوحيد شكل الأرقام بكل البوت.
 */
export function formatDateTime() {
  const now = new Date();
  // نحدد المنطقة الزمنية صراحة (بغداد UTC+3، بدون توقيت صيفي) بدل الاعتماد
  // على توقيت السيرفر الافتراضي (غالبًا UTC) — هذا سبب فرق الساعات اللي
  // كان يظهر بالمنيو (مثلاً 07:18 صباحًا بالمنيو مقابل 10:18 فعليًا).
  const TIME_ZONE = "Asia/Baghdad";
  return {
    date: now.toLocaleDateString("en-GB", { timeZone: TIME_ZONE }), // مثال: 25/07/2026
    time: now.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
      timeZone: TIME_ZONE,
    }), // مثال: 3:50 PM
  };
}

/** يحوّل أي أرقام هندية عربية (٠-٩) قد تتسرب من مصدر خارجي إلى أرقام إنجليزية */
export function toEnglishDigits(input: string | number): string {
  const map: Record<string, string> = {
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
  };
  return String(input).replace(/[٠-٩]/g, (d) => map[d] ?? d);
}

/** فاصل بسيط بين الرقم و@s.whatsapp.net */
export function numberToJid(number: string): string {
  const clean = number.replace(/[^0-9]/g, "");
  return `${clean}@s.whatsapp.net`;
}

export function jidToMention(jid: string): string {
  return `@${jid.split("@")[0]}`;
}

export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * يستخرج الأرقام فقط من أي JID (يزيل @s.whatsapp.net أو @lid أو @g.us).
 * يُستخدم للمقارنة الآمنة بين رقمين حتى لو جاء أحدهما بصيغة @lid
 * (نظام واتساب الجديد للخصوصية الذي بدأ يستبدل الأرقام الحقيقية بمعرّفات
 * مؤقتة في بعض المجموعات — راجع ملاحظة LID في permissions.ts).
 */
export function digitsOnly(jid: string | undefined | null): string {
  if (!jid) return "";
  // نقطع أولًا عند "@" (يفصل النطاق: s.whatsapp.net/g.us/lid)
  // ثم عند ":" (يفصل رقم الجهاز في معرّفات المستخدمين متعددي الأجهزة،
  // مثل sock.user.id اللي يجي غالبًا بصيغة "9053xxxxxxx:31@s.whatsapp.net").
  // لو ما قطعنا عند ":" بيندمج رقم الجهاز مع الرقم الحقيقي وتفشل كل مقارنة.
  return jid.split("@")[0].split(":")[0].replace(/[^0-9]/g, "");
}

/**
 * 🆕 (عزل البوتات الفرعية عن بعضها) — يرجع معرّفًا ثابتًا لهوية "أي بوت"
 * (رقمه الحقيقي المرتبط حاليًا: main أو أي بوت فرعي) مستخرَجًا من
 * sock.user.id نفسه. يُستخدم كجزء من مفاتيح حالات الألعاب/الفعاليات
 * الجارية بالذاكرة (eventManager, ticTacToeManager, game2048Manager,
 * snakeManager, kickDecisionManager) حتى لا تتشارك مجموعة فيها أكثر من
 * بوت (رئيسي + فرعي/فرعيين) نفس حالة اللعبة بينهم عن طريق الخطأ (لعبة
 * بدأها بوت تُحل بإجابة توصل لبوت آخر بنفس المجموعة). لا علاقة له بأي
 * صلاحية أو إعداد — مجرد مفتاح تقني داخلي فقط.
 * لو لم يتوفر sock.user.id لأي سبب (نادر جدًا)، يرجع "unknown" بدل ما
 * يفشل — أفضل من كسر اللعبة كليًا.
 */
export function getBotScopeId(sock: { user?: { id?: string } }): string {
  return digitsOnly(sock.user?.id) || "unknown";
}

/**
 * 🔧 إصلاح مهم (سبب "أمر .نون/.قص يقول تم بس ما يغيّر النقاط فعليًا"،
 * وبنفس الشكل ممكن يأثر على النذارات/الحظر/الكتم، وكان يسبب أيضًا توليد
 * كود تنصيب مربوط برقم LID داخلي بدل رقم الهاتف الحقيقي — راجع الشرح
 * الكامل بالأسفل):
 * نفس مشكلة الـ @lid — العضو نفسه ممكن يوصل مرة كمنشن بصيغة "xxxx@lid"
 * ومرة ثانية (كمرسل رسالته هو نفسه لاحقًا) بصيغة "xxxx@s.whatsapp.net".
 * إذا استخدمنا الـ JID الخام مباشرة كمفتاح تخزين (نقاط/تحذيرات/حظر...)
 * بنكتب أحيانًا تحت مفتاحين مختلفين لنفس الشخص، فتبدو النقاط "ما تغيرت"
 * رغم إن الأمر نفّذ فعليًا (كتب/عدّل مفتاحًا غير اللي القراءة تعرضه).
 * الحل: نبحث عن العضو داخل بيانات المجموعة (metadata) ونرجّع له JID موحّد
 * وثابت (بالأولوية: رقم الهاتف الحقيقي، وإلا id كما هو) بغض النظر عن
 * الصيغة اللي وصل فيها في تلك اللحظة بالذات.
 *
 * 🔧 إصلاح جذري (سبب فشل ".تنصيب" — الكود يظهر لكن الربط يفشل عند إدخاله):
 * الكود القديم هنا كان يقرأ حقلًا اسمه "phoneNumber" من كائن المشارك —
 * لكن بفحص المصدر الفعلي لمكتبة Baileys 6.7.23 (extractGroupMetadata في
 * lib/Socket/groups.js) تأكدت إن هذا الحقل غير موجود إطلاقًا بهذا الاسم.
 * الحقول الحقيقية اللي ترجعها المكتبة لكل مشارك هي:
 *   - id  → الـ JID الخام كما وصل من واتساب (قد يكون بصيغة @lid لو المجموعة
 *           تستخدم addressingMode: 'lid')
 *   - jid → رقم الهاتف الحقيقي دائمًا (بصيغة @s.whatsapp.net) — هذا هو
 *           الحقل الصحيح الذي يجب قراءته
 *   - lid → معرّف الـ LID (إن وُجد)
 * بما إن "phoneNumber" غير موجود، كان digitsOnly(anyP.phoneNumber) يرجع
 * دائمًا فارغًا، فالدالة كانت تتجاهل الرقم الحقيقي تمامًا وترجع
 * participant.id كما هو — وهو بمجموعات addressingMode:'lid' يكون معرّف
 * LID داخلي وليس رقم هاتف حقيقي. هذا بالضبط سبب أمر ".تنصيب" يولّد كود
 * اقتران مربوط برقم LID داخلي بدل رقم واتساب الحقيقي للمستخدم، فيظهر الكود
 * بالرسالة لكنه لا يرتبط أبدًا بحساب واتساب المستخدم الفعلي عند إدخاله.
 * الحل: نقرأ participant.jid (الحقل الصحيح والموثّق فعليًا بالمكتبة) بدل
 * "phoneNumber" غير الموجود، وبإزالة أي "as unknown as" غير ضرورية بما إن
 * jid/lid حقول رسمية أصلًا بنوع GroupParticipant.
 */
export function resolveGroupJid(
  jid: string,
  metadata?: GroupMetadata | null
): string {
  if (!metadata || !jid) return jid;
  const target = digitsOnly(jid);
  if (!target) return jid;

  const participant = metadata.participants.find((p) => {
    return (
      digitsOnly(p.id) === target ||
      digitsOnly(p.jid) === target ||
      digitsOnly(p.lid) === target
    );
  });
  if (!participant) return jid;

  const phoneDigits = digitsOnly(participant.jid);
  if (phoneDigits) return `${phoneDigits}@s.whatsapp.net`;
  return participant.id;
}

/**
 * 🆕 نسخة "صارمة" من resolveGroupJid مخصصة فقط لسياقات لازم فيها رقم
 * هاتف حقيقي وموثوق 100% (حاليًا: توليد كود اقتران بأمر .تنصيب) —
 * راجع src/commands/install/install.ts.
 *
 * الفرق الجوهري عن resolveGroupJid: تلك الدالة تسقط رجوعًا (fallback)
 * لـ participant.id الخام لو ما لقت رقم هاتف حقيقي (participant.jid) —
 * وهذا مقصود ومناسب لسياقات عامة (نقاط/تحذيرات/حظر...) لأن أي معرّف
 * ثابت أفضل من لا شي هناك. لكن بسياق تنصيب بوت فرعي، لو كان ذلك الرجوع
 * فعليًا معرّف "@lid" مؤقت وليس رقم هاتف، فاستخدامه كـ"رقم" لطلب كود
 * اقتران يولّد كودًا مربوطًا برقم غير موجود أصلًا فيفشل الربط بصمت (وهذا
 * بالضبط أحد أسباب مشكلة Username/@lid المُبلَّغ عنها). لذلك هذي الدالة
 * *لا تخمّن أبدًا*: ترجع رقم الهاتف الحقيقي (participant.jid) فقط إن
 * وُجد فعليًا بصيغة موثوقة، وإلا ترجع null صراحة — القرار حينها للمستدعي
 * (يطلب من المستخدم يكتب رقمه يدويًا بدل التخمين).
 */
export function resolveRealPhoneJid(
  jid: string,
  metadata?: GroupMetadata | null
): string | null {
  if (!metadata || !jid) return null;
  const target = digitsOnly(jid);
  if (!target) return null;

  const participant = metadata.participants.find((p) => {
    return (
      digitsOnly(p.id) === target ||
      digitsOnly(p.jid) === target ||
      digitsOnly(p.lid) === target
    );
  });
  if (!participant) return null;

  const phoneDigits = digitsOnly(participant.jid);
  if (!phoneDigits) return null; // لا يوجد رقم هاتف حقيقي موثوق — لا نخمّن من id/lid

  return `${phoneDigits}@s.whatsapp.net`;
}

/**
 * 🆕 ينظّف ويتحقق من رقم هاتف كتبه المستخدم يدويًا (مثال:
 * ".تنصيب +44 7453 388374"). يزيل المسافات/الشرطات/الأقواس وأي تنسيق
 * غير ضروري، ويحوّل أي أرقام هندية عربية لإنجليزية أولًا. يرجع الأرقام
 * فقط (بدون +) لو كانت الصيغة صالحة (بين 7 و15 رقمًا — نطاق أرقام
 * الهواتف الدولية القياسي E.164)، أو null لو الصيغة غير صالحة.
 * لا علاقة لهذي الدالة بـ@lid أو Username إطلاقًا — فقط تحقق تنسيقي من
 * نص أدخله المستخدم بنفسه صراحة.
 */
export function parseManualPhoneNumber(input: string): string | null {
  if (!input) return null;
  const englishDigitsInput = toEnglishDigits(input.trim());
  // نشيل كل شي غير الأرقام و"+" (مسافات، شرطات، أقواس، أي رمز آخر)
  const cleaned = englishDigitsInput.replace(/[^\d+]/g, "");
  const digits = cleaned.replace(/^\+/, "");
  if (!/^[0-9]{7,15}$/.test(digits)) return null;
  return digits;
}

/** يستخرج JID الهدف من منشن أو رد على رسالة، ويوحّده عبر resolveGroupJid */
export function getTargetJid(
  msg: WAMessage,
  metadata?: GroupMetadata | null
): string | undefined {
  const raw = getMentionedJids(msg)[0] || getQuotedParticipant(msg);
  if (!raw) return undefined;
  return resolveGroupJid(raw, metadata);
}

/**
 * يغلّف نصًا كاملًا بنجمتي تعريض (*) بشكل صحيح دون أن تقع إحداهما وسط
 * كلمة (وهو ما يكسر تنسيق الخط في واتساب). يُزال أي فراغ زائد على الأطراف
 * قبل التغليف حتى تكون النجمة ملاصقة لبداية ونهاية النص فقط.
 */
export function bold(text: string): string {
  return `*${text.trim()}*`;
}

/**
 * 🔧 إصلاح مهم (سبب "كثير أوامر/ردود ما تشتغل بسبب الحركات" مثل ًٍُِّْ):
 * لوحات مفاتيح عربية كثيرة (خصوصًا بالجوال) تضيف حركات تشكيل تلقائيًا أو
 * بالخطأ. أي مقارنة نصية تعتمد على startsWith/تطابق حرفي كانت تفشل لو
 * زادت حركة وحدة بالنص. نشيل حركات التشكيل والتطويل فقط هنا (بدون تغيير
 * الحروف نفسها) قبل أي مقارنة.
 */
export function stripDiacritics(text: string): string {
  return text.normalize("NFKC").replace(/[\u064B-\u0652\u0670\u0640]/g, "");
}

/** يفحص هل تحتوي الرسالة على كلمة تبدأ بسابقة معينة (مثال: "ملل") */
export function containsWordStartingWith(text: string, prefix: string): boolean {
  return text
    .split(/\s+/)
    .some((word) => stripDiacritics(word).replace(/[.,!؟?،]/g, "").startsWith(prefix));
}

/**
 * 🔧 إصلاح مهم (سبب "قال أحدهم سلام ماشي، والبوت رد عليه وعليكم السلام
 * بالغلط"): النسخة القديمة كانت تعتبر أي رسالة فيها *كلمة تبدأ* بـ"سلام"
 * تحية، حتى لو كانت وسط جملة عادية مالها علاقة بالتحية أصلًا (مثل "سلام
 * ماشي"، أو حتى كلمة "سلامتك" اللي تبدأ بنفس الحروف بس معناها مختلف
 * تمامًا). الحل: نشترط أن الكلمة الأولى بالرسالة تكون التحية *بالضبط*
 * (سلام/السلام/اسلام/سلامو...)، وأي كلمات بعدها لازم تكون فقط من امتداد
 * صيغة التحية المعروفة ("عليكم ورحمة الله وبركاته") — أي كلمة زايدة غير
 * متوقعة (زي "ماشي") تلغي اعتبارها تحية فعلية.
 */
const GREETING_CONTINUATION_WORDS = new Set([
  "عليكم",
  "ورحمة",
  "ورحمه",
  "رحمة",
  "رحمه",
  "الله",
  "وبركاته",
  "وبركاتة",
  "بركاته",
  "بركاتة",
]);

/** يفحص هل الرسالة فيها تحية "سلام" بأي صيغة شائعة (سلام / السلام / اسلام / سلامو...) */
export function isGreeting(text: string): boolean {
  const words = text
    .trim()
    .split(/\s+/)
    .map((w) => stripDiacritics(w).replace(/[.,!؟?،]/g, ""))
    .filter(Boolean);
  if (words.length === 0) return false;

  const isGreetingWord = /^(و)?(ال|ا)?سلام(و|ا)?$/.test(words[0]);
  if (!isGreetingWord) return false;

  return words.slice(1).every((w) => GREETING_CONTINUATION_WORDS.has(w));
}

/**
 * يفحص هل الرسالة فيها طلب "صلوا على النبي" بأي صيغة كتابة شائعة، بشرط
 * دقيق: لازم يكون فيها إشارة لفعل الصلاة (صل/صلو/صلي/الصلاة/اصلاة) *و*
 * إشارة صريحة للنبي (النبي/الرسول/محمد/ﷺ) بنفس الرسالة معًا. هذا الشرط
 * المزدوج يمنع الانطلاق الخاطئ على جمل عادية زي "أنا أصلًا ما أشربها"
 * اللي فيها كلمة "أصلا" بس بدون أي علاقة بالصلاة على النبي.
 */
export function isSalawatTrigger(text: string): boolean {
  const clean = stripDiacritics(text);
  const hasSalahWord = /صل[وي]?ا?ة?|الصلاة/.test(clean);
  if (!hasSalahWord) return false;
  return /(النبي|الرسول|محمد|نبينا|ﷺ)/.test(clean);
}
