import { CONFIG } from "../config/config";

/**
 * سطر تواصل ثابت مع المطور، يُضاف بآخر أي رسالة نريد أنها تحتوي "زر" تواصل.
 *
 * ⚠️ لا يظهر أي رقم أو رابط wa.me كنص داخل الرسالة إطلاقًا (كما طُلب).
 * التواصل الفعلي يتم عبر:
 *  1) زر native حقيقي (💬 مراسلة المطور) تضيفه رسائل القوائم عبر
 *     sendButtonMessage من utils/interactive.ts، أو
 *  2) بطاقة جهة الاتصال الرسمية (VCard) التي يرسلها أمر .المطور وفيها
 *     زر "مراسلة" أصلي 100% من واتساب نفسه.
 * لذلك هذا السطر مجرد توجيه نصي آمن لأمر .المطور، وليس رابطًا مباشرًا.
 */
export function devContactFooter(): string {
  return `\n\n💬 للتواصل مع المطور اكتب: ${CONFIG.PREFIX}المطور`;
}

/** يضيف سطر تواصل المطور لنص جاهز */
export function withDevContact(text: string): string {
  return `${text}${devContactFooter()}`;
}
