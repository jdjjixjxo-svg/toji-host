import { GoogleGenAI } from "@google/genai";
import { CommandContext } from "../handlers/types";
import { CONFIG } from "../config/config";
import { logger } from "./logger";
import { getMedia, reply } from "./friendUtils";

const VISION_MODEL = "gemini-3.1-flash-lite";

/** يحلل صورة/فيديو (مباشر أو مردود عليه) بالذكاء الاصطناعي. يرجع false لو ما فيه وسائط. */
export async function analyzeMediaIfPresent(ctx: CommandContext): Promise<boolean> {
  const media = await getMedia(ctx, ["image", "video"]).catch(() => null);
  if (!media) return false;
  if (!CONFIG.GEMINI_API_KEY) {
    await reply(ctx, "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env.");
    return true;
  }
  if (media.buffer.length > 18 * 1024 * 1024) {
    await reply(ctx, "❌ الملف كبير جدًا للتحليل (الحد ~18MB).");
    return true;
  }
  await reply(ctx, "🔍 جاري التحليل...");
  try {
    const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
    const question = ctx.text.trim() || "حلل هذا المحتوى بالتفصيل بالعربية: ماذا يوجد فيه؟ ومن/ما هي العناصر المهمة؟";
    const res = await ai.models.generateContent({
      model: VISION_MODEL,
      contents: [
        { text: question },
        { inlineData: { mimeType: media.kind === "video" ? "video/mp4" : "image/jpeg", data: media.buffer.toString("base64") } },
      ],
    });
    const out = (res as any).text || "";
    await reply(ctx, out ? `🧠 *التحليل:*\n\n${out}` : "❌ لم يصل تحليل.");
  } catch (err) {
    logger.error("فشل تحليل الوسائط:", err);
    await reply(ctx, "❌ تعذر التحليل حاليًا.");
  }
  return true;
}
