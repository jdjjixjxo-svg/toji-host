/** أدوات مشتركة تستخدمها أوامر الترفيه الجديدة (تفادي تكرار نفس الكود بكل ملف) */

export function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/** رقم عشوائي ثابت لنفس الـ seed بنفس اليوم (حتى لا تتغير النتيجة كل ثانية) */
export function seededPercent(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 101;
}

export function percentBar(percent: number): string {
  const filled = Math.round(percent / 10);
  return "🟩".repeat(filled) + "⬜".repeat(10 - filled);
}

/** يرجع نسخة جديدة من المصفوفة بترتيب عشوائي (Fisher-Yates) بدون تعديل الأصلية */
export function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/**
 * يبني قائمة خيارات لعبة "اختيار من متعدد" (زر واحد صحيح + بقية خاطئة)،
 * بترتيب عشوائي. يستبعد أي تكرار لنفس الإجابة الصحيحة من مصدر الخيارات
 * الخاطئة (pool)، ويكتفي بأقل عدد متوفر لو الـ pool صغير.
 */
export function buildQuizOptions(
  correctAnswer: string,
  pool: string[],
  count = 4
): string[] {
  const wrongPool = shuffle(
    [...new Set(pool.filter((p) => p.trim() !== correctAnswer.trim()))]
  );
  const wrongOptions = wrongPool.slice(0, Math.max(0, count - 1));
  return shuffle([correctAnswer, ...wrongOptions]);
}
