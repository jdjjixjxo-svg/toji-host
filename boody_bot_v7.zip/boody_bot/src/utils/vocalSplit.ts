import ytSearch from "yt-search";
import { withTimeout } from "./timeout";
import { CommandContext } from "../handlers/types";
import { separateVocalsApprox, extractAudioFromVideo } from "./ffmpegMedia";
import { downloadYouTubeBuffer } from "./downloader";
import { getMedia, reply } from "./friendUtils";
import { logger } from "./logger";

/** مشترك بين .عزل و .فصل_صوت */
export async function runVocalSplit(ctx: CommandContext, allowLink: boolean) {
  try {
    let audio: Buffer | null = null;
    const media = await getMedia(ctx, ["audio", "video"]).catch(() => null);
    if (media) {
      audio = media.kind === "video" ? await extractAudioFromVideo(media.buffer) : media.buffer;
    } else if (allowLink && ctx.text.trim()) {
      const q = ctx.text.trim();
      let url = q;
      if (!/^https?:\/\//i.test(q)) {
        const r = await withTimeout(ytSearch(q), 12_000, "YT_SEARCH_TIMEOUT");
        const v = r.videos?.[0];
        if (!v) return reply(ctx, "❌ ما لقيت نتيجة.");
        if (v.seconds > 8 * 60) return reply(ctx, "❌ المقطع أطول من 8 دقائق.");
        url = v.url;
      }
      await reply(ctx, "⏳ جاري تحميل المقطع...");
      audio = await extractAudioFromVideo(await downloadYouTubeBuffer(url));
    }
    if (!audio) {
      return reply(ctx, allowLink ? "❗ رد على صوت/فيديو، أو اكتب رابط يوتيوب/اسم الأغنية." : "❗ رد على صوت أو فيديو بهذا الأمر.");
    }
    if (audio.length > 25 * 1024 * 1024) return reply(ctx, "❌ الملف كبير جدًا (الحد ~25MB).");
    await reply(ctx, "🎚️ جاري الفصل (تقريبي)...");
    const { vocals, music } = await separateVocalsApprox(audio);
    await ctx.sock.sendMessage(ctx.chatId, { audio: vocals, mimetype: "audio/mpeg" }, { quoted: ctx.msg });
    await ctx.sock.sendMessage(ctx.chatId, { audio: music, mimetype: "audio/mpeg" }, { quoted: ctx.msg });
    await reply(ctx, "✅ الأول = الصوت البشري تقريبًا، والثاني = الموسيقى.\n_⚠️ فصل تقريبي (إلغاء القناة المركزية): الجودة أقل من أدوات الذكاء الاصطناعي المتخصصة، ويعمل أفضل مع الأغاني الستيريو._");
  } catch (err) {
    logger.error("فشل فصل الصوت:", err);
    await reply(ctx, "❌ تعذر فصل الصوت.");
  }
}
