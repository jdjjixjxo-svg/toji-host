/**
 * 🆕 (طلب صريح: أوامر .ز1 إلى .ز11 من بوت صاحبك) — 11 نمط زخرفة نصية
 * مختلفة، كل واحد يحوّل الحروف الإنجليزية/الأرقام لنطاق يونيكود مختلف.
 * الأنماط اللي ما لها حروف عربية مكافئة (خطوط يونيكود التزيين خاصة
 * بالحروف اللاتينية فقط) تُطبَّق فقط على الأحرف اللاتينية بالنص، والباقي
 * (عربي/مسافات/رموز) يمر بدون تغيير.
 */

type CharMap = Record<string, string>;

function buildMap(upper: string, lower: string, digits?: string): CharMap {
  const U = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
  const L = "abcdefghijklmnopqrstuvwxyz".split("");
  const D = "0123456789".split("");
  const map: CharMap = {};
  const upperChars = [...upper];
  const lowerChars = [...lower];
  U.forEach((c, i) => (map[c] = upperChars[i] || c));
  L.forEach((c, i) => (map[c] = lowerChars[i] || c));
  if (digits) {
    const digitChars = [...digits];
    D.forEach((c, i) => (map[c] = digitChars[i] || c));
  }
  return map;
}

// كل سطر: (أ-ي كابيتال)(أ-ي سمول)(0-9 لو متوفرة)
export const DECORATION_STYLES: CharMap[] = [
  buildMap("𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙", "𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳", "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗"), // ز1: بولد
  buildMap("𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁", "𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛"), // ز2: بولد إيطاليك
  buildMap("𝒜𝐵𝒞𝒟�ℰ�ℱ𝒢�ℋℐ𝒥𝒦�ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵", "𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏"), // ز3: كاليجرافي
  buildMap("𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ", "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷"), // ز4: فراكتور (قوطي)
  buildMap("𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ", "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫", "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡"), // ز5: دبل سترايك
  buildMap("𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹", "𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓", "𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫"), // ز6: سانس سيريف
  buildMap("𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉", "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣", "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿"), // ز7: مونوسبيس
  buildMap("ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᵠᴿˢᵀᵁⱽᵂˣʸᶻ".toUpperCase(), "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ"), // ز8: سمول كابس
  buildMap("ABCDEFGHIJKLMNOPQRSTUVWXYZ".replace(/./g, (c) => String.fromCodePoint(c.charCodeAt(0) + 0xfee0)), "abcdefghijklmnopqrstuvwxyz".replace(/./g, (c) => String.fromCodePoint(c.charCodeAt(0) + 0xfee0)), "0123456789".replace(/./g, (c) => String.fromCodePoint(c.charCodeAt(0) + 0xfee0))), // ز9: عريض كامل (Fullwidth)
  buildMap("ǝ,qƆpƎℲפHIſʞ˥WNOԀQɹS┴∩ΛMX⅄Z".slice(0, 26), "ɐqɔpǝɟƃɥıɾʞlɯuodbɹsʇnʌʍxʎz"), // ز10: مقلوب (Upside down)
  buildMap("ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ", "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ", "⓪①②③④⑤⑥⑦⑧⑨"), // ز11: دائري
];

export function applyDecorationStyle(text: string, styleIndex: number): string {
  const map = DECORATION_STYLES[styleIndex];
  if (!map) return text;
  return [...text].map((ch) => map[ch] || ch).join("");
}
