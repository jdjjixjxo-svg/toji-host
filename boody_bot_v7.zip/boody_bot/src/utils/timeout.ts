/**
 * يحدّ أي وعد (بحث/تحميل/مكتبة خارجية) بمهلة زمنية — لو تعلّق يرمي خطأ TIMEOUT
 * بدل ما يجمّد الأمر ويشغل مكان بالطابور للأبد.
 */
export function withTimeout<T>(promise: Promise<T>, ms: number, label = "TIMEOUT"): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(label)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}
