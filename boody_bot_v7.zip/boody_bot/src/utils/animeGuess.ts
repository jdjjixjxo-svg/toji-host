import sharp from "sharp";
import { CommandContext } from "../handlers/types";
import { eventManager } from "../handlers/eventManager";
import { searchImages, downloadImageBuffer, postJson } from "./imageSearch";
import { logger } from "./logger";
import { reply } from "./friendUtils";

// [الاسم بالعربي (الإجابة الرسمية), الاسم بالإنجليزي للبحث, إجابات بديلة مقبولة]
const CHARACTERS: [string, string, string[]][] = [
  ["ناروتو", "Naruto Uzumaki", ["naruto", "نارتو"]],
  ["ساسكي", "Sasuke Uchiha", ["sasuke", "ساسوكي"]],
  ["لوفي", "Monkey D. Luffy", ["luffy", "لوفى"]],
  ["زورو", "Roronoa Zoro", ["zoro", "زورو رورونوا"]],
  ["غوكو", "Son Goku", ["goku", "جوكو"]],
  ["ايرين", "Eren Yeager", ["eren", "إيرين", "ايرن"]],
  ["ميكاسا", "Mikasa Ackerman", ["mikasa"]],
  ["تانجيرو", "Tanjiro Kamado", ["tanjiro", "تانجيرو كامادو"]],
  ["نيزوكو", "Nezuko Kamado", ["nezuko", "نيزوكو كامادو"]],
  ["سايتاما", "Saitama", ["saitama"]],
  ["غون", "Gon Freecss", ["gon", "جون"]],
  ["هيسوكا", "Hisoka Morow", ["hisoka"]],
  ["ليفاي", "Levi Ackerman", ["levi", "ليفاى", "ليڤاي"]],
  ["ايتاتشي", "Itachi Uchiha", ["itachi", "إيتاتشي", "اتاتشي"]],
  ["كاكاشي", "Kakashi Hatake", ["kakashi"]],
  ["هيناتا", "Hinata Hyuga", ["hinata"]],
];

/** صورة رسمية للشخصية من AniList (مجاني، بدون مفتاح) — أدق بكثير من بحث الويب العشوائي */
async function fromAniList(englishName: string): Promise<Buffer | null> {
  try {
    const r = await postJson("https://graphql.anilist.co", {
      query: "query($s:String){Character(search:$s){name{full} image{large}}}",
      variables: { s: englishName },
    });
    const url: string | undefined = r?.data?.Character?.image?.large;
    if (!url) return null;
    const buf = await downloadImageBuffer(url);
    return buf && buf.length > 3000 ? buf : null;
  } catch (err) {
    logger.warn("⚠️ AniList ما رجّع صورة الشخصية:", err);
    return null;
  }
}

async function fromWebSearch(englishName: string): Promise<Buffer | null> {
  const urls = await searchImages(`${englishName} anime character face`, 12);
  for (const u of urls.sort(() => Math.random() - 0.5).slice(0, 4)) {
    try {
      const b = await downloadImageBuffer(u);
      if (b && b.length > 3000) return b;
    } catch {
      /* جرّب التالي */
    }
  }
  return null;
}

/** لعبة تخمين شخصية أنمي من صورة (mode: full = صورة مموّهة، eye = قص العينين) */
export async function startAnimeGuess(ctx: CommandContext, mode: "full" | "eye") {
  if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
    await reply(ctx, "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو اكتب .استسلم");
    return;
  }
  const [name, english, alts] = CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)];
  try {
    const buf = (await fromAniList(english)) || (await fromWebSearch(english));
    if (!buf) return reply(ctx, "❌ ما قدرت أجيب صورة الشخصية حاليًا، حاول مرة ثانية بعد شوي.");

    let out: Buffer;
    if (mode === "eye") {
      const meta = await sharp(buf).metadata();
      const w = meta.width || 400;
      const h = meta.height || 400;
      // شريط العينين: الثلث العلوي تقريبًا من صور الوجوه الرأسية (AniList)
      out = await sharp(buf)
        .extract({ left: Math.floor(w * 0.12), top: Math.floor(h * 0.14), width: Math.floor(w * 0.76), height: Math.floor(h * 0.24) })
        .resize({ width: 900, kernel: "lanczos3" })
        .sharpen()
        .jpeg({ quality: 88 })
        .toBuffer();
    } else {
      out = await sharp(buf).resize({ width: 700, withoutEnlargement: true }).blur(12).jpeg({ quality: 80 }).toBuffer();
    }

    const title = mode === "eye" ? "خمن الشخصية من العين" : "احزر الشخصية";
    if (!eventManager.start(ctx.sock as any, ctx.chatId, title, name, 45_000, alts)) return;
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        image: out,
        caption:
          (mode === "eye" ? "👁️ *خمّن الشخصية من عينيها*" : "🎭 *احزر الشخصية من الصورة المموّهة*") +
          "\n\nاكتب اسم الشخصية بالعربي (مثال: ناروتو).\n⏱️ عندكم 45 ثانية — أول إجابة صحيحة تفوز بنقطة!\nللاستسلام: .استسلم",
      },
      { quoted: ctx.msg }
    );
  } catch (err) {
    logger.error("فشل بدء لعبة تخمين الشخصية:", err);
    await reply(ctx, "❌ تعذر بدء اللعبة حاليًا.");
  }
}
