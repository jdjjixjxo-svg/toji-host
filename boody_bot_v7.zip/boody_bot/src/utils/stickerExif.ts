import webpmux from "node-webpmux";

/**
 * 🆕 (طلب صريح: "قصدي ينشئ حزمة في واتساب مثل ستيكرات باك") — هذا هو
 * الأسلوب *الحقيقي والموثّق* اللي تستخدمه كل بوتات واتساب لإنشاء ملصقات
 * "حزمة" فعلية: كل ملصق يُرسل كرسالة ستيكر عادية (مو ملف مضغوط)، لكن
 * نحقن بداخله بيانات EXIF خاصة (اسم الحزمة + الناشر + نفس المعرّف
 * "sticker-pack-id" لكل ملصقات نفس الطلب). واتساب نفسه يقرأ هذي البيانات
 * فيربط الملصقات المتشابهة ببعضها بمعلومات حزمة موحّدة (تظهر عند فتح
 * تفاصيل الملصق) — هذا مو تخمين، هذا نفس الأسلوب المستند لمواصفة واتساب
 * الرسمية لملصقات الطرف الثالث (نفس ما تستخدمه مكتبات زي
 * wa-sticker-formatter داخليًا عبر نفس حزمة node-webpmux).
 *
 * ⚠️ يحتاج حزمة "node-webpmux" (أُضيفت بـ package.json) — **لازم
 * `npm install` من جديد** حتى تتوفر فعليًا، وإلا الأمر سيفشل برسالة
 * "Cannot find module 'node-webpmux'" (يُمسك ويُعالج داخل .حزمة).
 *
 * ⚠️ صراحة: واتساب لا يعرض نافذة "تثبيت الحزمة" التلقائية للملصقات
 * المُرسَلة من بوت غير رسمي (تلك حصرية لملصقات مُنشأة عبر تطبيق واتساب
 * نفسه أو شركاء رسميين) — لكن ربط الملصقات ببيانات حزمة موحّدة عبر EXIF
 * يبقى يعمل ويظهر بمعلومات الملصق، وهذا أقصى ما يمكن تحقيقه بدون API
 * رسمي لواتساب لِلأعمال.
 */
export async function addStickerPackExif(
  webpBuffer: Buffer,
  packId: string,
  packName: string,
  publisher: string
): Promise<Buffer> {
  const img = new webpmux.Image();
  await img.load(webpBuffer);

  const json = {
    "sticker-pack-id": packId,
    "sticker-pack-name": packName,
    "sticker-pack-publisher": publisher,
    emojis: ["🙂"],
  };

  // 🔧 هيدر EXIF ثابت (TIFF header + معرف الحقل الخاص بواتساب) — نفس
  // البايتات المستخدمة بكل مكتبات الملصقات المعروفة، لا تُغيَّر.
  const exifHeader = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
    0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
  ]);
  const jsonBuffer = Buffer.from(JSON.stringify(json), "utf-8");
  const exif = Buffer.concat([exifHeader, jsonBuffer]);
  exif.writeUIntLE(jsonBuffer.length, 14, 4);

  img.exif = exif;
  const saved = await img.save(null);
  return Buffer.isBuffer(saved) ? saved : Buffer.from(saved);
}
