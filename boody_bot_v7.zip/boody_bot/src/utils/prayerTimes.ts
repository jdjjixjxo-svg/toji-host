import { logger } from "./logger";

/**
 * مواقيت الصلاة بتوقيت مكة المكرمة — نجيبها من Aladhan API (مجاني، بدون
 * مفتاح) مرة وحدة كل يوم ونخزنها بالذاكرة (تتغير يوميًا حسب حساب الفلك).
 * method=4 = رابطة العالم الإسلامي / أم القرى (المرجع المعتمد لمكة).
 */

export interface PrayerTimes {
  fajr: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

const MECCA_TIME_ZONE = "Asia/Riyadh"; // نفس فارق توقيت مكة (UTC+3 بدون توقيت صيفي)

let cache: { dateKey: string; times: PrayerTimes } | null = null;

function todayMeccaDateKey(): string {
  // مثال: 2026-08-01 — نستخدمه كمفتاح تخزين مؤقت لكل يوم
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: MECCA_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const y = parts.find((p) => p.type === "year")?.value;
  const m = parts.find((p) => p.type === "month")?.value;
  const d = parts.find((p) => p.type === "day")?.value;
  return `${y}-${m}-${d}`;
}

/** الوقت الحالي بتوقيت مكة، صيغة HH:MM (24 ساعة) — يُقارن مباشرة بمخرجات الـ API */
export function currentMeccaTimeHHMM(): string {
  const now = new Date();
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: MECCA_TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(now);
}

/** يجيب مواقيت اليوم لمكة المكرمة، بالتخزين المؤقت (مرة كل يوم بس) */
export async function getTodayMeccaPrayerTimes(): Promise<PrayerTimes | null> {
  const dateKey = todayMeccaDateKey();
  if (cache && cache.dateKey === dateKey) return cache.times;

  try {
    const url =
      "https://api.aladhan.com/v1/timingsByCity?city=Makkah&country=SaudiArabia&method=4";
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data: any = await res.json();
    const t = data?.data?.timings;
    if (!t) throw new Error("شكل استجابة غير متوقع من API المواقيت");

    // الـ API يرجع صيغة زي "12:15 (AST)" أحيانًا — نشيل أي جزء بعد المسافة
    const clean = (s: string) => String(s).split(" ")[0];

    const times: PrayerTimes = {
      fajr: clean(t.Fajr),
      dhuhr: clean(t.Dhuhr),
      asr: clean(t.Asr),
      maghrib: clean(t.Maghrib),
      isha: clean(t.Isha),
    };

    cache = { dateKey, times };
    return times;
  } catch (err) {
    logger.warn("تعذر جلب مواقيت الصلاة لمكة المكرمة اليوم.", err);
    return null;
  }
}
