import { welcomeText, goodbyeText } from "./menuTemplates";

/**
 * يبني نص بطاقة الترحيب بالقالب الموحّد (يُستخدم بأمر .ترحيب اليدوي وبالترحيب
 * التلقائي عند دخول عضو جديد).
 */
export function buildWelcomeCard(groupName: string, mention: string, customLine?: string): string {
  const card = welcomeText({ user: mention, group: groupName });
  const line = customLine?.trim();
  return line ? card.replace(`ـ⌬┋ ${mention}\n`, `ـ⌬┋ ${mention}\nـ⌬┋ *${line}*\n`) : card;
}

/** بطاقة الوداع بالقالب الموحّد (تُرسل مع صورة بروفايل العضو المغادر). */
export function buildGoodbyeCard(_groupName: string, mention: string): string {
  return goodbyeText({ user: mention });
}
