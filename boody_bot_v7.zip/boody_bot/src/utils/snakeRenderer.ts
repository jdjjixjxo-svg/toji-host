/**
 * 🆕 رسم لعبة الثعبان كصورة PNG فعلية (شبكة 2D حقيقية) — مو نص بس.
 *
 * ⚠️ اخترنا مكتبة Jimp تحديدًا (مو canvas/napi-rs) لأنها مكتوبة بالكامل
 * بـ JavaScript الصرف بدون أي اعتمادية native تحتاج تحميل/بناء ملف
 * تنفيذي وقت "npm install" — بالضبط نفس المشكلة اللي واجهناها مع ffmpeg
 * على استضافات مقيّدة مثل Katabump. Jimp تشتغل بأي استضافة بدون أي
 * إعداد إضافي أو خطر فشل تثبيت.
 *
 * ملاحظة إصدار: نثبّت (package.json) على النسخة الكلاسيكية 0.22.x من
 * Jimp عمدًا — إصدار 1.x الأحدث غيّر الـ API بالكامل (طريقة import
 * مختلفة، Constructor مختلف). نفضّل الثبات على واجهة برمجية موثقة
 * ومستقرة تمامًا بدل المخاطرة بكود يعتمد على توثيق غير مؤكد.
 */
import Jimp from "jimp";
import { SnakeGame } from "../handlers/snakeManager";

const CELL = 48; // بكسل لكل خانة بالشبكة

const COLOR_BG = Jimp.rgbaToInt(24, 26, 34, 255);
const COLOR_GRID = Jimp.rgbaToInt(40, 44, 56, 255);
const COLOR_HEAD = Jimp.rgbaToInt(110, 231, 150, 255);
const COLOR_BODY = Jimp.rgbaToInt(52, 168, 83, 255);
const COLOR_FOOD = Jimp.rgbaToInt(237, 66, 69, 255);

function fillRect(image: Jimp, x: number, y: number, w: number, h: number, color: number) {
  image.scan(x, y, w, h, function (this: Jimp, _x: number, _y: number, idx: number) {
    this.bitmap.data.writeUInt32BE(color, idx);
  });
}

export async function renderSnakeImage(game: SnakeGame): Promise<Buffer> {
  const pixelSize = game.size * CELL;
  const image = await new Jimp(pixelSize, pixelSize, COLOR_BG);

  // خطوط شبكة خفيفة تفصل الخانات بصريًا
  for (let i = 0; i <= game.size; i++) {
    const x = Math.min(i * CELL, pixelSize - 1);
    const y = Math.min(i * CELL, pixelSize - 1);
    fillRect(image, x, 0, 1, pixelSize, COLOR_GRID);
    fillRect(image, 0, y, pixelSize, 1, COLOR_GRID);
  }

  // الأكل (تفاحة) — مربع أحمر بمنتصف الخانة
  fillRect(image, game.food.x * CELL + 6, game.food.y * CELL + 6, CELL - 12, CELL - 12, COLOR_FOOD);

  // جسم الثعبان أولًا، ثم الرأس فوقه (يضمن وضوح الرأس دائمًا)
  game.snake.forEach((p, i) => {
    if (i === 0) return;
    fillRect(image, p.x * CELL + 3, p.y * CELL + 3, CELL - 6, CELL - 6, COLOR_BODY);
  });
  const head = game.snake[0];
  fillRect(image, head.x * CELL + 2, head.y * CELL + 2, CELL - 4, CELL - 4, COLOR_HEAD);

  return image.getBufferAsync(Jimp.MIME_PNG);
}
