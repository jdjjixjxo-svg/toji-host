/**
 * 🆕 تكامل مع MangaDex — API رسمي وموثّق ومجاني بالكامل (بدون مفتاح)،
 * راجع https://api.mangadex.org/docs. يغطي المانجا والمانهوا معًا
 * (كلها بنفس الكتالوج، بدون فرق بالـAPI).
 */
import { PDFDocument } from "pdf-lib";

const BASE = "https://api.mangadex.org";

export async function searchManga(title: string): Promise<{ id: string; title: string } | null> {
  const res = await fetch(`${BASE}/manga?title=${encodeURIComponent(title)}&limit=1`);
  const data: any = await res.json();
  const manga = data?.data?.[0];
  if (!manga) return null;
  const titles = manga.attributes?.title || {};
  const name = titles.en || titles.ar || Object.values(titles)[0] || title;
  return { id: manga.id, title: String(name) };
}

export async function getLatestChapter(mangaId: string): Promise<{ id: string; chapter: string } | null> {
  // نفضّل عربي، وإلا إنجليزي — أي فصل متوفر
  for (const lang of ["ar", "en"]) {
    const res = await fetch(
      `${BASE}/manga/${mangaId}/feed?translatedLanguage[]=${lang}&order[chapter]=desc&limit=1&contentRating[]=safe&contentRating[]=suggestive`
    );
    const data: any = await res.json();
    const ch = data?.data?.[0];
    if (ch) return { id: ch.id, chapter: ch.attributes?.chapter || "?" };
  }
  return null;
}

export async function downloadChapterAsPdf(chapterId: string): Promise<Buffer> {
  const res = await fetch(`${BASE}/at-home/server/${chapterId}`);
  const data: any = await res.json();
  const { baseUrl, chapter } = data;
  const pageFiles: string[] = chapter.data; // جودة كاملة (dataSaver أخف لو الحجم مشكلة)

  const pdfDoc = await PDFDocument.create();

  for (const page of pageFiles.slice(0, 20)) {
    // 🔧 (تشخيص: "JavaScript heap out of memory" على استضافة قليلة
    // الذاكرة) — 40 صفحة كاملة الجودة بالذاكرة دفعة وحدة ثقيلة جدًا.
    // خفّضناها لـ20 صفحة كحد أقصى لكل فصل — لا تزال قراءة مريحة، وتقلل
    // ذروة استهلاك الذاكرة للنص تقريبًا.
    try {
      const imgRes = await fetch(`${baseUrl}/data/${chapter.hash}/${page}`);
      const imgBuffer = Buffer.from(await imgRes.arrayBuffer());
      const isPng = page.toLowerCase().endsWith(".png");
      const image = isPng ? await pdfDoc.embedPng(imgBuffer) : await pdfDoc.embedJpg(imgBuffer);
      const pdfPage = pdfDoc.addPage([image.width, image.height]);
      pdfPage.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
    } catch {
      continue; // صفحة وحدة فشلت، نكمل الباقي
    }
  }

  const bytes = await pdfDoc.save();
  return Buffer.from(bytes);
}
