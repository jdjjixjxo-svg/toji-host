/**
 * 🆕 رسم لعبة "٢٠٤٨" كصورة PNG حقيقية (نفس أسلوب snakeRenderer.ts
 * بالضبط) — Jimp فقط، بدون أي مكتبة رسم native (راجع تعليق snakeRenderer
 * لسبب هذا الاختيار: يشتغل على أي استضافة بدون خطر فشل تثبيت).
 */
import Jimp from "jimp";
import { Game2048 } from "../handlers/game2048Manager";

const CELL = 110; // بكسل لكل خانة بالشبكة
const GAP = 8; // مسافة فاصلة بين الخانات

const COLOR_BG = Jimp.rgbaToInt(24, 26, 34, 255);
const COLOR_EMPTY = Jimp.rgbaToInt(44, 48, 60, 255);

// ألوان البلاطات حسب القيمة — كلما زادت القيمة صار اللون أغمق/أدفأ
const TILE_COLORS: Record<number, number> = {
  2: Jimp.rgbaToInt(90, 100, 120, 255),
  4: Jimp.rgbaToInt(100, 110, 90, 255),
  8: Jimp.rgbaToInt(210, 140, 60, 255),
  16: Jimp.rgbaToInt(220, 110, 50, 255),
  32: Jimp.rgbaToInt(220, 90, 70, 255),
  64: Jimp.rgbaToInt(220, 70, 60, 255),
  128: Jimp.rgbaToInt(210, 180, 60, 255),
  256: Jimp.rgbaToInt(210, 170, 40, 255),
  512: Jimp.rgbaToInt(210, 160, 20, 255),
  1024: Jimp.rgbaToInt(190, 60, 140, 255),
  2048: Jimp.rgbaToInt(160, 40, 170, 255),
};
const COLOR_TILE_MAX = Jimp.rgbaToInt(40, 20, 60, 255); // أي قيمة أكبر من 2048

function fillRect(image: Jimp, x: number, y: number, w: number, h: number, color: number) {
  image.scan(x, y, w, h, function (this: Jimp, _x: number, _y: number, idx: number) {
    this.bitmap.data.writeUInt32BE(color, idx);
  });
}

export async function renderGame2048Image(game: Game2048): Promise<Buffer> {
  const pixelSize = game.size * CELL;
  const image = await new Jimp(pixelSize, pixelSize, COLOR_BG);

  const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);

  for (let y = 0; y < game.size; y++) {
    for (let x = 0; x < game.size; x++) {
      const value = game.grid[y][x];
      const px = x * CELL + GAP / 2;
      const py = y * CELL + GAP / 2;
      const size = CELL - GAP;
      const color = value === 0 ? COLOR_EMPTY : TILE_COLORS[value] || COLOR_TILE_MAX;
      fillRect(image, px, py, size, size, color);

      if (value !== 0) {
        const label = String(value);
        const textWidth = Jimp.measureText(font, label);
        const textHeight = Jimp.measureTextHeight(font, label, size);
        image.print(
          font,
          px + Math.max(0, (size - textWidth) / 2),
          py + Math.max(0, (size - textHeight) / 2),
          label
        );
      }
    }
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}
