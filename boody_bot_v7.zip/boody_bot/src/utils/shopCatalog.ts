/**
 * 🆕 قائمة المتجر (طلب صريح: "متجر للنقاط فيه ألقاب وغيرها"، وبنفس الطلب
 * الصريح: "ما بدي شي يأتي على المشرفين" — يعني ممنوع بيع أي شيء يتعلق
 * بترقية أدمن أو طرد أو أي صلاحية إدارية إطلاقًا. كل عنصر هنا تجميلي بحت:
 * مجرد نص لقب يظهر ببطاقة ".انا"، صفر تأثير على صلاحيات المجموعة.
 *
 * لإضافة لقب جديد: أضف سطر بنفس الشكل (id فريد + السعر بالعملات).
 */
export interface ShopItem {
  id: string;
  title: string; // النص اللي يظهر كلقب
  price: number;
}

export const SHOP_TITLES: ShopItem[] = [
  { id: "star", title: "🌟 نجم المجموعة", price: 500 },
  { id: "fire", title: "🔥 نار", price: 600 },
  { id: "genius", title: "🧠 عبقري", price: 700 },
  { id: "gentleman", title: "🎩 محترم", price: 750 },
  { id: "lightning", title: "⚡ البرق", price: 900 },
  { id: "shadow", title: "🥷 الظل", price: 1000 },
  { id: "dragon", title: "🐉 التنين", price: 1200 },
  { id: "legend", title: "🏆 أسطورة", price: 1800 },
  { id: "king", title: "👑 ملك/ملكة", price: 2500 },
];

export function findShopItem(idOrTitle: string): ShopItem | undefined {
  const q = idOrTitle.trim();
  return SHOP_TITLES.find((i) => i.id === q || i.title === q || i.title.includes(q));
}
