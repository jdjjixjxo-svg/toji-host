/**
 * مساعدات مشتركة للأوامر المضافة من قائمة بوت الصديق.
 * كل شيء هنا خفيف على الذاكرة (الاستضافة 308MB): بيانات صغيرة، سقوف ثابتة.
 */
import { WASocket, GroupMetadata, WAMessage, downloadMediaMessage } from "@whiskeysockets/baileys";
import NodeCache from "node-cache";
import { db } from "../database/db";
import { CONFIG } from "../config/config";
import { Command, CommandContext } from "../handlers/types";
import { isGroupAdmin, isOwner } from "../middlewares/permissions";
import { normalizeArabicCommand } from "./arabicNormalize";
import { buildQuotedMessage } from "./helpers";
import { logger } from "./logger";

// ========================= إعدادات المجموعة الإضافية =========================
export interface FriendCfg {
  badWordsOn: boolean;
  badWords: string[];
  badWordsMode: "delete" | "kick";
  antiMedia: boolean;
  antiSticker: boolean;
  antiBot: boolean;
  adminOnly: boolean; // .مود
  botMuted: boolean; // .منع_بوت
  lockedCmds: string[]; // .قفل_امر
  autoAccept: boolean; // .طلبات تلقائي
  linkMode: "warn" | "delete" | "kick"; // .منع_الروابط
  // 🆕 (طلب صريح: ".3=طرد") — لو مفعّل: أي عضو يبعث 3 روابط (حتى لو
  // متفرقة، ما يشترط بنفس الرسالة) يُطرد تلقائيًا فورًا بدون تدخل يدوي.
  // لو غير مفعّل (الافتراضي): يرجع النظام القديم (linkMode أعلاه) هو
  // المتحكم — تحذير/حذف/طرد حسب اختيار المشرف بـ.منع_الروابط.
  threeLinkKick: boolean;
  snapshot?: { subject: string; desc: string; pic?: string; announce: boolean; restrict: boolean; at: number };
}

const DEFAULT_CFG: FriendCfg = {
  badWordsOn: false,
  badWords: [],
  badWordsMode: "delete",
  antiMedia: false,
  antiSticker: false,
  antiBot: false,
  adminOnly: false,
  botMuted: false,
  lockedCmds: [],
  autoAccept: false,
  linkMode: "warn",
  threeLinkKick: false,
};

export function getFriendCfg(groupId: string): FriendCfg {
  const v = (db as any).get(["friend", groupId]).value();
  return { ...DEFAULT_CFG, ...(v || {}) };
}

export function setFriendCfg(groupId: string, patch: Partial<FriendCfg>) {
  (db as any).set(["friend", groupId], { ...getFriendCfg(groupId), ...patch }).write();
}

// ========================= أدوات عامة =========================
export async function reply(ctx: CommandContext, text: string, mentions?: string[]) {
  await ctx.sock.sendMessage(ctx.chatId, { text, ...(mentions ? { mentions } : {}) }, { quoted: ctx.msg });
}

export const ON_WORDS = ["تشغيل", "تفعيل", "on", "فتح", "شغل"];
export const OFF_WORDS = ["ايقاف", "إيقاف", "تعطيل", "off", "اطفاء", "قفل"];

/** يقرأ أول كلمة كتشغيل/إيقاف: true / false / undefined لو غير واضح */
export function parseOnOff(word?: string): boolean | undefined {
  if (!word) return undefined;
  const w = normalizeArabicCommand(word);
  if (ON_WORDS.map(normalizeArabicCommand).includes(w)) return true;
  if (OFF_WORDS.map(normalizeArabicCommand).includes(w)) return false;
  return undefined;
}

const tag = (v: boolean) => (v ? "✅ مفعّل" : "❌ متوقف");

/** مصنع أوامر تشغيل/إيقاف بسيطة (بدون أي ذكاء اصطناعي، فقط قيمة true/false) */
export function toggleCommand(opts: {
  name: string;
  aliases?: string[];
  description: string;
  label: string;
  category?: Command["category"];
  get: (ctx: CommandContext) => boolean;
  set: (ctx: CommandContext, value: boolean) => Promise<void> | void;
  requireBotAdmin?: boolean;
}): Command {
  return {
    name: opts.name,
    aliases: opts.aliases,
    category: opts.category || "مشرفين",
    description: opts.description,
    permission: "admin",
    groupOnly: true,
    requireBotAdmin: opts.requireBotAdmin ?? false,
    execute: async (ctx) => {
      const explicit = parseOnOff(ctx.args[0]);
      const next = explicit === undefined ? !opts.get(ctx) : explicit;
      await opts.set(ctx, next);
      await reply(ctx, `${opts.label}: ${tag(next)}\n(للتغيير: .${opts.name} تشغيل | ايقاف)`);
    },
  };
}

type MediaKind = "image" | "video" | "audio" | "sticker" | "document";

/** يجلب وسائط من الرسالة نفسها أو من الرسالة المردود عليها */
export async function getMedia(
  ctx: CommandContext,
  kinds: MediaKind[]
): Promise<{ buffer: Buffer; kind: MediaKind; message: any } | null> {
  const pick = (m: any): { kind: MediaKind; message: any } | null => {
    if (!m) return null;
    const inner = m.ephemeralMessage?.message || m.viewOnceMessage?.message || m.viewOnceMessageV2?.message || m;
    for (const k of kinds) {
      const node = inner[`${k}Message`];
      if (node) return { kind: k, message: node };
    }
    return null;
  };
  const direct = pick(ctx.msg.message);
  const quotedFound = pick(ctx.quoted);
  const found = direct || quotedFound;
  if (!found) return null;
  const source = direct ? ctx.msg : buildQuotedMessage(ctx.msg) ?? ctx.msg;
  const buffer = (await downloadMediaMessage(
    source as WAMessage,
    "buffer",
    {},
    { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
  )) as Buffer;
  return { buffer, kind: found.kind, message: found.message };
}

/** حد أقصى آمن لحجم الملفات المُحمَّلة بالذاكرة (308MB رام) */
export const MAX_DOWNLOAD_BYTES = 45 * 1024 * 1024;

export async function fetchBuffer(url: string, maxBytes = MAX_DOWNLOAD_BYTES, headers: Record<string, string> = {}): Promise<Buffer> {
  const res = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36", ...headers },
    redirect: "follow",
    signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) throw new Error(`HTTP_${res.status}`);
  const len = Number(res.headers.get("content-length") || 0);
  if (len && len > maxBytes) throw new Error("FILE_TOO_LARGE");
  const chunks: Buffer[] = [];
  let total = 0;
  const reader = (res.body as any).getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxBytes) {
      try { await reader.cancel(); } catch { /* تجاهل */ }
      throw new Error("FILE_TOO_LARGE");
    }
    chunks.push(Buffer.from(value));
  }
  return Buffer.concat(chunks);
}

export async function fetchJson<T = any>(url: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "User-Agent": "Mozilla/5.0", ...(init.headers || {}) },
    signal: AbortSignal.timeout(30_000),
  });
  if (!res.ok) throw new Error(`HTTP_${res.status}`);
  return (await res.json()) as T;
}

// ========================= سجل نص المحادثة (لأمر .ملخص) =========================
const chatBuf = new Map<string, { n: string; t: string }[]>();
const MAX_CHAT_LINES = 80;

export function recordChatLine(chatId: string, name: string, text: string) {
  if (!text) return;
  const list = chatBuf.get(chatId) || [];
  list.push({ n: name, t: text.slice(0, 280) });
  if (list.length > MAX_CHAT_LINES) list.splice(0, list.length - MAX_CHAT_LINES);
  chatBuf.set(chatId, list);
  if (chatBuf.size > 60) chatBuf.delete(chatBuf.keys().next().value as string); // سقف عدد المجموعات بالذاكرة
}

export function getChatLines(chatId: string) {
  return chatBuf.get(chatId) || [];
}

// ========================= نشاط الأعضاء (.نشاطي / .احصائيات-المجموعة) =========================
const activity = new Map<string, Record<string, number>>();
let activityDirty = false;

function loadActivity(groupId: string): Record<string, number> {
  let a = activity.get(groupId);
  if (!a) {
    a = { ...(((db as any).get(["friendAct", groupId]).value() as Record<string, number>) || {}) };
    activity.set(groupId, a);
  }
  return a;
}

export function bumpActivity(groupId: string, jid: string) {
  const a = loadActivity(groupId);
  a[jid] = (a[jid] || 0) + 1;
  activityDirty = true;
}

export function getActivity(groupId: string): Record<string, number> {
  return loadActivity(groupId);
}

const flushTimer = setInterval(() => {
  if (!activityDirty) return;
  activityDirty = false;
  try {
    for (const [gid, data] of activity) (db as any).set(["friendAct", gid], data).write();
  } catch (err) {
    logger.warn("تعذر حفظ نشاط الأعضاء:", err);
  }
}, 60_000);
flushTimer.unref?.();

// ========================= الغياب (.اختفاء) =========================
interface AfkEntry { reason: string; since: number }
const afk = new Map<string, Record<string, AfkEntry>>();
const afkNotified = new Map<string, number>();

function loadAfk(groupId: string): Record<string, AfkEntry> {
  let a = afk.get(groupId);
  if (!a) {
    a = { ...(((db as any).get(["friendAfk", groupId]).value() as Record<string, AfkEntry>) || {}) };
    afk.set(groupId, a);
  }
  return a;
}

export function setAfk(groupId: string, jid: string, reason: string) {
  const a = loadAfk(groupId);
  a[jid] = { reason, since: Date.now() };
  (db as any).set(["friendAfk", groupId], a).write();
}

export function clearAfk(groupId: string, jid: string): AfkEntry | null {
  const a = loadAfk(groupId);
  const e = a[jid];
  if (!e) return null;
  delete a[jid];
  (db as any).set(["friendAfk", groupId], a).write();
  return e;
}

export function getAfk(groupId: string, jid: string): AfkEntry | null {
  return loadAfk(groupId)[jid] || null;
}

export function humanDuration(ms: number): string {
  const m = Math.floor(ms / 60000);
  if (m < 1) return "أقل من دقيقة";
  if (m < 60) return `${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ساعة`;
  return `${Math.floor(h / 24)} يوم`;
}

// ========================= الحماية الإضافية + الغياب + النشاط =========================
function unwrap(m: any): any {
  return m?.ephemeralMessage?.message || m?.viewOnceMessage?.message || m?.viewOnceMessageV2?.message || m;
}

async function safeDelete(sock: WASocket, chatId: string, msg: WAMessage) {
  try {
    await sock.sendMessage(chatId, { delete: msg.key });
  } catch (err) {
    logger.warn("تعذر حذف رسالة مخالفة (تأكد أن البوت مشرف):", err);
  }
}

async function safeKick(sock: WASocket, chatId: string, jid: string) {
  try {
    await sock.groupParticipantsUpdate(chatId, [jid], "remove");
  } catch (err) {
    logger.warn("تعذر طرد عضو مخالف (تأكد أن البوت مشرف):", err);
  }
}

export function normalizeForWords(s: string): string {
  return normalizeArabicCommand(s).replace(/[^\p{L}\p{N}\s]/gu, "").replace(/\s+/g, " ");
}

/**
 * يُستدعى من messageHandler لكل رسالة جماعية (قبل أي فحص نص).
 * يرجع true لو الرسالة انتهت (حُذفت/تجاهلت) ولا داعي لمعالجتها أكثر.
 */
export async function runFriendHooks(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  msg: WAMessage,
  rawText: string,
  metadata: GroupMetadata
): Promise<boolean> {
  const cfg = getFriendCfg(chatId);
  const exempt = isOwner(senderJid, metadata, sock) || isGroupAdmin(metadata, senderJid);
  const isCmd = rawText.startsWith(CONFIG.PREFIX);
  const cmdText = isCmd ? normalizeArabicCommand(rawText.slice(CONFIG.PREFIX.length).trim()) : "";
  const firstWord = cmdText.split(/\s+/)[0] || "";

  // .منع_بوت (أو ".منع بوت" بمسافة): البوت يتجاهل كل شيء بهذي المجموعة إلا أمر التبديل نفسه
  if (cfg.botMuted && !/^منع[_\s]+بوت(?:\s|$)/.test(cmdText)) return true;

  // .مود: الأوامر للمشرفين فقط
  if (cfg.adminOnly && isCmd && !exempt) return true;

  // نشاط + سجل محادثة
  bumpActivity(chatId, senderJid);
  if (rawText && !isCmd) {
    const name = (msg as any).pushName || senderJid.split("@")[0];
    recordChatLine(chatId, name, rawText);
  }

  // الغياب: عودة تلقائية + إشعار لمن يمنشن غائبًا
  try {
    const mine = getAfk(chatId, senderJid);
    if (mine && Date.now() - mine.since > 4000 && !/^اختفاء$/.test(firstWord)) {
      clearAfk(chatId, senderJid);
      await sock.sendMessage(
        chatId,
        { text: `👋 رجع @${senderJid.split("@")[0]} بعد غياب ${humanDuration(Date.now() - mine.since)}`, mentions: [senderJid] },
        { quoted: msg }
      );
    }
    const mentioned: string[] = unwrap(msg.message)?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    for (const jid of mentioned) {
      const e = getAfk(chatId, jid);
      const k = `${chatId}:${jid}`;
      if (e && Date.now() - (afkNotified.get(k) || 0) > 60_000) {
        afkNotified.set(k, Date.now());
        await sock.sendMessage(
          chatId,
          { text: `💤 @${jid.split("@")[0]} غائب منذ ${humanDuration(Date.now() - e.since)}\n📝 السبب: ${e.reason}`, mentions: [jid] },
          { quoted: msg }
        );
      }
    }
  } catch (err) {
    logger.warn("تعذر معالجة نظام الغياب:", err);
  }

  if (exempt || msg.key.fromMe) return false;

  const m = unwrap(msg.message) || {};

  if (cfg.antiSticker && m.stickerMessage) {
    await safeDelete(sock, chatId, msg);
    return true;
  }
  if (cfg.antiMedia && (m.imageMessage || m.videoMessage || m.audioMessage || m.documentMessage || m.ptvMessage)) {
    await safeDelete(sock, chatId, msg);
    return true;
  }
  if (cfg.badWordsOn && cfg.badWords.length && rawText) {
    const norm = ` ${normalizeForWords(rawText)} `;
    if (cfg.badWords.some((w) => norm.includes(` ${normalizeForWords(w)} `) || norm.includes(normalizeForWords(w)))) {
      await safeDelete(sock, chatId, msg);
      if (cfg.badWordsMode === "kick") await safeKick(sock, chatId, senderJid);
      else await sock.sendMessage(chatId, { text: `🚫 @${senderJid.split("@")[0]} كلمة ممنوعة!`, mentions: [senderJid] });
      return true;
    }
  }
  // بوتات Baileys القديمة تولّد معرّف رسالة يبدأ بـ BAE5 وطوله 16 — إشارة تقريبية وليست قطعية
  if (cfg.antiBot && /^BAE5[0-9A-F]{12}$/i.test(msg.key.id || "")) {
    await safeDelete(sock, chatId, msg);
    await safeKick(sock, chatId, senderJid);
    return true;
  }
  return false;
}

/** يطبّق نمط عقوبة الروابط المختار (.منع_الروابط) — يرجع true إن تم التعامل معه بالكامل */
export async function handleLinkMode(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  msg: WAMessage
): Promise<boolean> {
  const mode = getFriendCfg(chatId).linkMode;
  if (mode === "warn") return false;
  await safeDelete(sock, chatId, msg);
  if (mode === "kick") await safeKick(sock, chatId, senderJid);
  return true;
}

// 🆕 (طلب صريح: ".3=طرد") — عدّاد روابط لكل عضو بكل مجموعة، بحد أقصى
// ساعة واحدة (بعدها يصفّر تلقائيًا حتى ما يتراكم على عضو نسي الموضوع
// من زمان). خفيف على الذاكرة تمامًا مثل باقي الكاشات هنا (رقم واحد فقط
// لكل مفتاح، يُمسح تلقائيًا).
const threeLinkCounter = new NodeCache({ stdTTL: 60 * 60 });
export const THREE_LINK_THRESHOLD = 3;

/**
 * .3=طرد (لو مفعّلة بالمجموعة): يعدّ روابط العضو، ولو وصل 3 يطرده فورًا
 * ويصفّر عدّاده. يرجع true لو تعامل مع الرسالة بالكامل (حذف + تحذير/طرد).
 */
export async function handleThreeLinkKick(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  msg: WAMessage
): Promise<boolean> {
  await safeDelete(sock, chatId, msg);

  const key = `${chatId}:${senderJid}`;
  const count = (threeLinkCounter.get<number>(key) || 0) + 1;
  const mention = `@${senderJid.split("@")[0]}`;

  if (count >= THREE_LINK_THRESHOLD) {
    threeLinkCounter.del(key);
    await sock.sendMessage(chatId, {
      text: `🚫 ${mention} تم طردك تلقائيًا لإرسالك ${THREE_LINK_THRESHOLD} روابط.`,
      mentions: [senderJid],
    });
    await safeKick(sock, chatId, senderJid);
  } else {
    threeLinkCounter.set(key, count);
    await sock.sendMessage(chatId, {
      text: `🚫 ممنوع إرسال الروابط بهذه المجموعة!\n${mention} ⚠️ رابط (${count}/${THREE_LINK_THRESHOLD}) — عند الوصول لـ${THREE_LINK_THRESHOLD} تُطرد تلقائيًا.`,
      mentions: [senderJid],
    });
  }
  return true;
}

// ========================= الردود التلقائية العالمية (.اضافة_رد) =========================
export function getAutoReplies(): Record<string, string> {
  return (((db as any).get(["friendGlobal", "autoReplies"]).value() as Record<string, string>) || {});
}

export function setAutoReplies(map: Record<string, string>) {
  (db as any).set(["friendGlobal", "autoReplies"], map).write();
}

export async function tryGlobalAutoReply(sock: WASocket, msg: WAMessage, chatId: string, text: string): Promise<boolean> {
  const map = getAutoReplies();
  const keys = Object.keys(map);
  if (!keys.length) return false;
  const norm = normalizeForWords(text);
  const hit = keys.find((k) => normalizeForWords(k) === norm);
  if (!hit) return false;
  await sock.sendMessage(chatId, { text: map[hit] }, { quoted: msg });
  return true;
}
