import https from "https";

function fetchJson(url: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const req = https
      .get(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
          },
        },
        (res) => {
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}`));
            res.resume();
            return;
          }
          let body = "";
          res.on("data", (c) => (body += c));
          res.on("end", () => {
            try {
              resolve(JSON.parse(body));
            } catch (err) {
              reject(err);
            }
          });
        }
      )
      .on("error", reject);
    req.setTimeout(10_000, () => req.destroy(new Error("TIMEOUT")));
  });
}

/**
 * 🆕 (أمر .اغنيه) — بحث أغاني عبر iTunes Search API الرسمي من Apple.
 * اخترنا هذا المصدر تحديدًا (بدل سكرابينغ يوتيوب/مواقع تحميل مشابهة)
 * لأنه:
 * - API رسمي مجاني بدون أي مفتاح تسجيل، مصمم أصلًا للاستخدام العام.
 * - يرجّع JSON مباشر (مو HTML نحتاج نكشطه ونتوقع تغيّره بدون إشعار).
 * - previewUrl ثابت وموثوق (رابط مباشر لملف صوتي حقيقي، مو رابط يحتاج
 *   حل/فك تشفير زي تيك توك).
 *
 * ⚠️ القيد الوحيد: previewUrl مقطع معاينة ٣٠ ثانية فقط من الأغنية (قيد
 * من Apple نفسها، مو من عندنا) — مو الأغنية كاملة. هذا أفضل بكثير من
 * مصدر غير موثوق يعطي أغنية كاملة أحيانًا ولا يشتغل أحيانًا ثانية.
 *
 * ⚠️ صراحة: لم يُختبر فعليًا (بيئة الكتابة بلا اتصال إنترنت) — best-effort.
 */
export interface SongResult {
  title: string;
  artist: string;
  previewUrl: string;
}

/**
 * 🔧 إصلاح جذري مهم جدًا (سبب "يجيب أغاني غريبة ما إلها علاقة بالطلب"):
 * iTunes Search API بدون تحديد "country" يبحث بمتجر أمريكا (US) افتراضيًا
 * — ومتجر أمريكا يفهرس أغاني عربية/خليجية قليلة جدًا أو بعناوين مختلفة،
 * فيرجع أقرب تطابق لاتيني عشوائي بدل الأغنية المطلوبة فعليًا. الحل:
 * نبحث أول شي بمتجر السعودية (SA — أقرب متجر يغطي أغاني عربية/خليجية
 * بشكل حقيقي)، ولو رجع فاضي نجرب بدون تحديد بلد (افتراضي عام) كحل احتياطي.
 */
async function searchItunes(term: string, country?: string): Promise<any[]> {
  const countryParam = country ? `&country=${country}` : "";
  const api = `https://itunes.apple.com/search?term=${encodeURIComponent(
    term
  )}&media=music&entity=song&limit=15${countryParam}`;
  const data: any = await fetchJson(api);
  return data?.results || [];
}

export async function searchSong(query: string): Promise<SongResult | null> {
  // 🔧 (سبب فعلي محتمل لـ "ما يجيب الأغنية المطلوبة" بدون أي رسالة خطأ
  // واضحة) — كان الـtry/catch هنا يبلع أي خطأ فعلي (انقطاع نت، حظر IP،
  // فشل fetchJson...) ويرجّعه null بصمت، فيصير مطابق تمامًا لحالة "فعلًا
  // ما فيه أغنية بهالاسم" من منظور .اغنيه.ts — تعذّر التفريق بينهم. الحين
  // ما فيه try/catch شامل هنا؛ أي خطأ فعلي ينفلت لـ.اغنيه.ts (يبلّغ
  // المطور تلقائيًا عبر notifyOwnerOfError)، ونرجع null فقط لحالة "فعلًا
  // ما فيه نتيجة مطابقة" (طلب فاضي / iTunes رجع نتايج بدون معاينة صوت).
  // 🔧 (طلب صريح: "ما يجيب الاغنية المطلوبة") — تحسين حقيقي إضافي: كنا
  // نشيل بس التشكيل (تشكيل الحروف)، لكن اختلاف رسم نفس الحرف (أ/إ/آ vs
  // ا، ة vs ه، ى vs ي) يخلي iTunes ما يطابق أغاني موجودة فعلًا بكتالوجه
  // لمجرد اختلاف رسم بسيط بكتابة المستخدم عن اسم الأغنية الرسمي.
  const normalized = query
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .trim()
    .replace(/\s+/g, " ");
  if (!normalized) return null;

  let results = await searchItunes(normalized, "SA");
  if (!results.length) results = await searchItunes(normalized);

  // 🔧 (طلب صريح: "لا يستسلم من أول نتيجة فارغة") — لو ما فيه نتائج
  // بالعبارة كاملة وفيها أكثر من كلمة، نعيد المحاولة بأول كلمة بس
  // (بحث أوسع بنفس الـAPI الحقيقي، مو أغنية عشوائية غير مرتبطة).
  if (!results.length) {
    const words = normalized.split(" ");
    if (words.length > 1) {
      results = await searchItunes(words[0], "SA");
      if (!results.length) results = await searchItunes(words[0]);
    }
  }

  const withPreview = results.filter((r) => r.previewUrl);
  if (!withPreview.length) return null;
  // 🔧 (طلب صريح: "لسه عشوائي" رغم كتابة اسم محدد) — كان يختار عشوائيًا
  // من بين كل النتائج (حتى لو 15 نتيجة غير مرتبطة فعليًا)، فيلغي فايدة
  // البحث المحدد كليًا. iTunes يرتب النتائج بالأصلح أول شي — نأخذ
  // أول نتيجة فقط (الأدق)، بدل اختيار عشوائي بينها.
  const pick = withPreview[0];
  return {
    title: pick.trackName || query,
    artist: pick.artistName || "غير معروف",
    previewUrl: pick.previewUrl,
  };
}

/** كلمات بحث شائعة تُستخدم عشوائيًا لو المستخدم ما كتب اسم أغنية (.اغنيه بدون نص) */
export const RANDOM_SONG_TERMS = [
  "Amr Diab",
  "Fairuz",
  "Tamer Hosny",
  "Mohamed Ramadan",
  "Cheb Khaled",
  "Wegz",
  "Elissa",
  "Nancy Ajram",
  "Hamza Namira",
  "Marshmello",
];
