import { AsyncLocalStorage } from "async_hooks";

/**
 * سياق الرسالة الجارية (اسم المجموعة + قسم الأمر) — يُملأ من messageHandler
 * أثناء تنفيذ أي أمر، ويقرأه القالب الموحّد (utils/frame.ts) تلقائيًا
 * حتى يظهر اسم المجموعة وقسم الأمر بكل رسالة دون تمريرهما يدويًا.
 */
export interface MsgContext {
  groupName?: string;
  category?: string;
}

export const msgContextStore = new AsyncLocalStorage<MsgContext>();

export function getMsgContext(): MsgContext | undefined {
  return msgContextStore.getStore();
}
