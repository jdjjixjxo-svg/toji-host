import path from "path";
import fs from "fs";
import { WASocket } from "@whiskeysockets/baileys";
import { logger } from "./logger";

// فيديو مشترك (بدون صوت) يُستخدم كـ GIF متحرك — مرفق داخل مجلد assets
// بجذر المشروع حتى لا يحتاج بناء TypeScript له (يُقرأ مباشرة وقت التشغيل).
export const MENU_VIDEO_PATH = path.resolve(process.cwd(), "assets", "menu.mp4");

let cachedBuffer: Buffer | null = null;

/** يقرأ فيديو المنيو مرة واحدة ويخزّنه بالذاكرة لتفادي قراءة القرص بكل استخدام */
export function getMenuVideoBuffer(): Buffer | null {
  if (cachedBuffer) return cachedBuffer;
  try {
    if (!fs.existsSync(MENU_VIDEO_PATH)) {
      logger.warn(`فيديو المنيو غير موجود في: ${MENU_VIDEO_PATH}`);
      return null;
    }
    cachedBuffer = fs.readFileSync(MENU_VIDEO_PATH);
    return cachedBuffer;
  } catch (err) {
    logger.error("فشل قراءة فيديو المنيو:", err);
    return null;
  }
}

/**
 * صور هوية الأقسام (أنمي) — واحدة لكل قسم، مرفقة داخل assets/sections.
 * نفس فكرة فيديو المنيو تمامًا: قراءة من القرص مرة واحدة وتخزينها بالذاكرة.
 */
export type SectionKey =
  | "main"
  | "fun"
  | "admin"
  | "protection"
  | "tools"
  | "settings"
  | "developer"
  | "sunnah"
  | "bot";

const SECTIONS_DIR = path.resolve(process.cwd(), "assets", "sections");
const sectionImageCache = new Map<SectionKey, Buffer | null>();

/** يقرأ صورة قسم معيّن مرة واحدة ويخزّنها بالذاكرة. يرجع null إن كانت غير موجودة (بأمان دون كسر الأمر). */
export function getSectionImageBuffer(section: SectionKey): Buffer | null {
  if (sectionImageCache.has(section)) {
    return sectionImageCache.get(section)!;
  }
  const filePath = path.join(SECTIONS_DIR, `${section}.jpg`);
  try {
    if (!fs.existsSync(filePath)) {
      logger.warn(`صورة القسم غير موجودة: ${filePath}`);
      sectionImageCache.set(section, null);
      return null;
    }
    const buffer = fs.readFileSync(filePath);
    sectionImageCache.set(section, buffer);
    return buffer;
  } catch (err) {
    logger.error(`فشل قراءة صورة القسم (${section}):`, err);
    sectionImageCache.set(section, null);
    return null;
  }
}

/**
 * يرسل صورة هوية القسم كرسالة مستقلة أولًا (كما طُلب: الصورة أولًا ثم
 * القائمة). لو الصورة غير موجودة لأي سبب، لا يفعل شيئًا ولا يكسر الأمر —
 * القائمة النصية تُرسل بعدها بشكل طبيعي بكل الأحوال.
 */
export async function sendSectionImage(
  sock: WASocket,
  chatId: string,
  section: SectionKey,
  caption: string
): Promise<void> {
  const buffer = getSectionImageBuffer(section);
  if (!buffer) return;
  try {
    await sock.sendMessage(chatId, { image: buffer, caption });
  } catch (err) {
    logger.error(`فشل إرسال صورة القسم (${section}):`, err);
  }
}

/**
 * يرسل صورة هوية القسم + نص القائمة الكامل في رسالة واحدة فقط
 * (Image + Caption)، بدل رسالتين منفصلتين. لو الصورة غير موجودة لأي
 * سبب، يرسل النص وحده بدون كسر الأمر.
 */
export async function sendSectionMenu(
  sock: WASocket,
  chatId: string,
  section: SectionKey,
  text: string,
  opts?: { mentions?: string[] }
): Promise<void> {
  const buffer = getSectionImageBuffer(section);
  try {
    if (buffer) {
      await sock.sendMessage(chatId, { image: buffer, caption: text, mentions: opts?.mentions });
    } else {
      await sock.sendMessage(chatId, { text, mentions: opts?.mentions });
    }
  } catch (err) {
    logger.error(`فشل إرسال قائمة القسم (${section}):`, err);
    try {
      await sock.sendMessage(chatId, { text, mentions: opts?.mentions });
    } catch {
      /* تجاهل */
    }
  }
}

/**
 * 🖼️ فعالية ".خمن" — بنك صور الأنمي.
 * كل صورة داخل assets/quiz اسم ملفها هو الإجابة الصحيحة (بدون الامتداد).
 * نقرأ قائمة الملفات مرة واحدة ونخزّنها بالذاكرة، ونقرأ كل صورة من القرص
 * وقت الاستخدام فقط (بدل تحميل الصور كاملة بالذاكرة من البداية).
 */
const QUIZ_DIR = path.resolve(process.cwd(), "assets", "quiz");
let quizFilesCache: string[] | null = null;

function listQuizFiles(): string[] {
  if (quizFilesCache) return quizFilesCache;
  try {
    quizFilesCache = fs
      .readdirSync(QUIZ_DIR)
      .filter((f) => /\.(jpg|jpeg|png|webp)$/i.test(f));
  } catch (err) {
    logger.error("فشل قراءة مجلد صور فعالية خمن:", err);
    quizFilesCache = [];
  }
  return quizFilesCache;
}

export interface QuizImage {
  buffer: Buffer;
  /** الإجابة الصحيحة المستخرجة من اسم الملف */
  answer: string;
}

/**
 * 🔧 إصلاح مهم (سبب "فعالية .خمن تطلع الإجابة كأنها كود برمجي" مثل
 * "#U0646#U0627#U0631#U0648#U062a#U0648" بدل "ناروتو"): بعض أدوات ضغط/نقل
 * الملفات (خصوصًا على ويندوز) تفشل بترميز أسماء ملفات عربية (UTF-8) داخل
 * أرشيف ZIP، فتستبدل كل حرف بترميزه الرقمي بصيغة "#UXXXX" كحل بديل. اسم
 * الملف نفسه هو الإجابة الصحيحة بهذي الفعالية، فلو وصل الملف بهذي الصيغة
 * المشوّهة (حتى لو أُعيد رفع الأصول لاحقًا لسبب مشابه)، نفكّها هنا تلقائيًا
 * قبل استخدامها كإجابة، بدل ما يظهر للمستخدم كود بدل اسم الشخصية الحقيقي.
 */
function decodeMangledFilename(name: string): string {
  if (!/#U[0-9A-Fa-f]{4}/.test(name)) return name;
  return name.replace(/#U([0-9A-Fa-f]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}

/** يختار صورة عشوائية من بنك صور فعالية "خمن" مع إجابتها الصحيحة. */
export function getRandomQuizImage(): QuizImage | null {
  const files = listQuizFiles();
  if (!files.length) return null;
  const file = files[Math.floor(Math.random() * files.length)];
  try {
    const buffer = fs.readFileSync(path.join(QUIZ_DIR, file));
    const answer = decodeMangledFilename(path.parse(file).name.trim());
    return { buffer, answer };
  } catch (err) {
    logger.error(`فشل قراءة صورة فعالية خمن (${file}):`, err);
    return null;
  }
}

/** عدد الصور المتوفرة حاليًا في بنك فعالية "خمن" (للعرض داخل رسائل الأخطاء إن لزم). */
export function quizImageCount(): number {
  return listQuizFiles().length;
}

/**
 * 🆕 يرجع أسماء شخصيات أخرى من نفس بنك صور "خمن" (مستخرجة من أسماء
 * الملفات الأخرى) لاستخدامها كخيارات خاطئة بأزرار الاختيار من متعدد.
 * لا تحتاج فتح الصور نفسها — بس أسماء الملفات.
 */
export function getQuizAnswerPool(): string[] {
  return listQuizFiles().map((f) => decodeMangledFilename(path.parse(f).name.trim()));
}

/**
 * 🌹 صورة "صلّوا على النبي ﷺ" — تُستخدم كصورة افتراضية لأي فعالية أو تذكير
 * لا تملك صورة خاصة به (حسب الطلب: أي فعالية بدون صور تاخذ هذه الصورة،
 * أما الفعاليات التي معها صور أصلًا مثل .خمن فتبقى بصورها الخاصة).
 */
const SALAWAT_PATH = path.resolve(process.cwd(), "assets", "salawat.jpg");
let salawatCache: Buffer | null = null;

export function getSalawatImageBuffer(): Buffer | null {
  if (salawatCache) return salawatCache;
  try {
    if (!fs.existsSync(SALAWAT_PATH)) {
      logger.warn(`صورة الصلاة على النبي غير موجودة في: ${SALAWAT_PATH}`);
      return null;
    }
    salawatCache = fs.readFileSync(SALAWAT_PATH);
    return salawatCache;
  } catch (err) {
    logger.error("فشل قراءة صورة الصلاة على النبي:", err);
    return null;
  }
}

/**
 * يرسل نصًا مع صورة "صلوا على النبي" كصورة افتراضية (لأي فعالية/رسالة
 * بدون صورة خاصة بها). لو الصورة غير موجودة لأي سبب، يرسل نصًا عاديًا
 * بدلًا منها بدون كسر الأمر.
 */
export async function sendWithSalawatFallback(
  sock: WASocket,
  chatId: string,
  text: string
): Promise<void> {
  const buffer = getSalawatImageBuffer();
  try {
    if (buffer) {
      await sock.sendMessage(chatId, { image: buffer, caption: text });
    } else {
      await sock.sendMessage(chatId, { text });
    }
  } catch (err) {
    logger.error("فشل إرسال رسالة بصورة الصلاة على النبي:", err);
    try {
      await sock.sendMessage(chatId, { text });
    } catch {
      /* تجاهل */
    }
  }
}
