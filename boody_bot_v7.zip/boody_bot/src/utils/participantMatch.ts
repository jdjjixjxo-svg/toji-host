import { GroupMetadata } from "@whiskeysockets/baileys";

/**
 * 🆕 (توحيد مركزي: "لا تفترض sender === participant.id دائمًا... راجع
 * البيانات الفعلية وأنشئ helper مركزي للمقارنة") — هذا الملف هو المكان
 * الوحيد بكل المشروع اللي يعرف كيف "يطابق" JID شخص وارد (قد يكون
 * @s.whatsapp.net حقيقي أو @lid مؤقت حسب إعدادات خصوصية ذاك الشخص) مع
 * سجل مشارك داخل GroupMetadata.participants.
 *
 * السبب الجذري لمعظم مشاكل "مشرف رغم إنه مشرف" الموثّقة بهذا المشروع:
 * واتساب الحديث قد يرسل هوية العضو بالرسالة بصيغة (JID حقيقي أو LID
 * مؤقت) **مختلفة** عن الصيغة المخزّنة بـparticipant.id بنفس اللحظة —
 * فمقارنة مباشرة "senderJid === participant.id" تفشل رغم إن الشخص نفسه
 * فعلًا. الحل: نقارن *كل الحقول الثلاثة* الممكنة لكل مشارك (id الأساسي +
 * phoneNumber + lid لو موجودين) مع الهوية الواردة، ونعتبرهم نفس الشخص
 * لو تطابق **أي واحد منها**.
 *
 * كانت هذي بالضبط نفس 3-4 نسخ مكررة يدويًا بملفات مختلفة
 * (permissions.ts, developerIdentity.ts, db.ts) — توحّدت هنا الآن.
 *
 * ⚠️ عمدًا بدون أي imports مشروع أخرى (غير Baileys نفسه) لتفادي أي خطر
 * circular import — digitsOnly هنا نسخة محلية صغيرة بدل الاستيراد من
 * helpers.ts (نفس سبب استقلال developerIdentity.ts بالضبط).
 */
export function digitsOnly(jid: string | undefined | null): string {
  if (!jid) return "";
  return jid.split("@")[0].split(":")[0].replace(/[^0-9]/g, "");
}

/**
 * يبحث عن مشارك بالمجموعة يطابق الهوية الواردة (بأي من id/phoneNumber/lid)،
 * ويرجعه كامل (عشان يقدر المستدعي يفحص participant.admin أو أي حقل ثاني).
 */
export function findParticipant(metadata: GroupMetadata, jid: string) {
  const target = digitsOnly(jid);
  if (!target) return undefined;
  return metadata.participants.find((p) => {
    // 🔧 (سبب محتمل جدًا وراء "مشرف/مطور مو معروف رغم إنه فعلًا") —
    // ملف utils/helpers.ts (resolveGroupJid، مكتوبة بجلسة سابقة وتبدو
    // مبنية على تحقق فعلي) تتحقق من الحقل "jid"، بينما هذا الملف (مركزي،
    // مكتوب لاحقًا بدون بيانات حقيقية للتأكد) كان يتحقق من "phoneNumber"
    // فقط — قد يكون اسم الحقل الفعلي بنسخة Baileys المستخدمة "jid" لا
    // "phoneNumber"، فكانت كل المطابقات المعتمدة عليه تفشل صامتة. الآن
    // نتحقق من الاثنين معًا (أيًا كان الصحيح فعليًا يشتغل).
    const anyP = p as unknown as { phoneNumber?: string; jid?: string; lid?: string };
    return (
      digitsOnly(p.id) === target ||
      digitsOnly(anyP.phoneNumber) === target ||
      digitsOnly(anyP.jid) === target ||
      digitsOnly(anyP.lid) === target
    );
  });
}

/** يتحقق هل هوية واردة (jid) تطابق رقمًا محددًا (targetDigits)، عبر أي من حقول المشارك الثلاثة. */
export function participantMatchesDigits(
  metadata: GroupMetadata,
  jid: string,
  targetDigits: string
): boolean {
  if (!targetDigits) return false;
  if (digitsOnly(jid) === targetDigits) return true;
  const participant = findParticipant(metadata, jid);
  if (!participant) return false;
  const anyP = participant as unknown as { phoneNumber?: string; jid?: string; lid?: string };
  return (
    digitsOnly(participant.id) === targetDigits ||
    digitsOnly(anyP.phoneNumber) === targetDigits ||
    digitsOnly(anyP.jid) === targetDigits ||
    digitsOnly(anyP.lid) === targetDigits
  );
}
