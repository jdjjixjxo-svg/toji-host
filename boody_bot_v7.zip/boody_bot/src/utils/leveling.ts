/** 🆕 نظام مستويات بسيط: كل مستوى يحتاج XP أكثر من اللي قبله بشكل تراكمي. */

/** XP المطلوبة للانتقال من level إلى level+1. */
function xpNeededForLevel(level: number): number {
  return 100 * (level + 1);
}

export interface LevelInfo {
  level: number;
  xpIntoLevel: number; // XP الحالية داخل هذا المستوى
  xpForNextLevel: number; // كم تحتاج XP عشان يخلص هذا المستوى
}

/** يحول إجمالي XP إلى (مستوى + تقدّم داخل المستوى الحالي). */
export function getLevelFromXp(totalXp: number): LevelInfo {
  let level = 0;
  let remaining = Math.max(0, totalXp);
  let need = xpNeededForLevel(level);
  while (remaining >= need) {
    remaining -= need;
    level++;
    need = xpNeededForLevel(level);
  }
  return { level, xpIntoLevel: remaining, xpForNextLevel: need };
}

/** شريط تقدّم نصي بسيط للاستخدام داخل بطاقة البروفايل (.انا). */
export function progressBar(current: number, total: number, length = 10): string {
  const ratio = total > 0 ? Math.min(1, current / total) : 0;
  const filled = Math.round(ratio * length);
  return "▰".repeat(filled) + "▱".repeat(length - filled);
}
