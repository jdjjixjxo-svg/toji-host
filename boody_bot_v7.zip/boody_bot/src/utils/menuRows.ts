/** توزيع الأوامر المضافة على أقسام المنيو (بدل قسم "أوامر إضافية" المنفصل). */
export interface MenuRow { command: string; label: string; description: string }

export const ADMIN_EXTRA_ROWS: MenuRow[] = [
  { command: "ملخص", label: "📝 ملخص", description: "تلخيص المحادثة بأسلوب مرح (للمشرفين)" },
  { command: "منع_كلمات", label: "🚫 منع كلمات", description: "تشغيل/إيقاف منع الكلمات مع وضع حذف أو طرد" },
  { command: "منع_الروابط", label: "🔗 منع الروابط", description: "أوضاع: تحذير، حذف فقط، طرد" },
  { command: "منع_الميديا", label: "🖼️ منع الميديا", description: "حذف تلقائي للصور والفيديو والملفات" },
  { command: "منع_ملصقات", label: "🩹 منع ملصقات", description: "حذف الملصقات تلقائيًا" },
  { command: "منع_بطاقة", label: "📇 منع بطاقة", description: "منع بطاقات الاتصال" },
  { command: "مضاد_البوتات", label: "🤖 مضاد البوتات", description: "كشف وطرد البوتات الأجنبية (تقريبي)" },
  { command: "منع_بوت", label: "🔇 منع بوت", description: "إيقاف/تشغيل استجابة البوت بالمجموعة" },
  { command: "قفل_تنصيب", label: "🔒 قفل تنصيب", description: "قفل أمر التنصيب داخل الجروب" },
  { command: "مود", label: "🔐 مود", description: "قفل البوت للمشرفين فقط" },
  { command: "bye", label: "👋 bye", description: "الوداع التلقائي للمغادرين" },
  { command: "نسخ", label: "📦 نسخ", description: "حفظ واستعادة إعدادات الجروب" },
  { command: "تغيير_الاسم", label: "✏️ تغيير الاسم", description: "تغيير اسم المجموعة" },
  { command: "طلبات", label: "📥 طلبات", description: "عرض/قبول/رفض طلبات الانضمام أو القبول التلقائي" },
  { command: "مخفي", label: "👻 مخفي", description: "منشن مخفي للجميع مع دعم الميديا" },
  { command: "عيد_تحذير", label: "♻️ عيد تحذير", description: "تصفير تحذيرات عضو" },
  { command: "قفل_امر", label: "🔒 قفل أمر", description: "قفل أمر معيّن بالمجموعة" },
  { command: "فتح_امر", label: "🔓 فتح أمر", description: "فتح أمر مقفول" },
  { command: "احصائيات-المجموعة", label: "🏆 إحصائيات المجموعة", description: "لوحة شرف الأعضاء حسب التفاعل" },
  { command: "حذف_الألقاب", label: "🗑️ حذف الألقاب", description: "حذف لقب عضو أو كل الألقاب" },
  { command: "ستوري", label: "📸 ستوري", description: "نشر حالة يشوفها أعضاء المجموعة (للمشرفين)" },
];

export const TOOLS_EXTRA_ROWS: MenuRow[] = [
  { command: "تيك", label: "🎵 تيك", description: "تحميل تيك توك بدون علامة أو بحث" },
  { command: "يوتيوب", label: "▶️ يوتيوب", description: "تحميل فيديو بالرابط أو بالبحث" },
  { command: "ميديا", label: "📁 ميديا", description: "تحميل ملفات MediaFire" },
  { command: "غ", label: "🎧 غ", description: "صوت من تيك توك إلى MP3" },
  { command: "كلمات", label: "🎼 كلمات", description: "البحث عن كلمات الأغاني" },
  { command: "نغ", label: "⭕ نغ", description: "إرسال/تحويل فيديو دائري PTV" },
  { command: "تأثير", label: "✨ تأثير", description: "ملصق نصي بتأثيرات ألوان" },
  { command: "لصوت", label: "🔊 لصوت", description: "استخراج الصوت من الفيديو" },
  { command: "لفيديو", label: "🎞️ لفيديو", description: "تحويل الملصق المتحرك إلى فيديو" },
  { command: "لرابط", label: "🔗 لرابط", description: "رفع الميديا وتحويلها لرابط" },
  { command: "تزييف", label: "⏱️ تزييف", description: "تزييف مدة الفيديو/الريكورد" },
  { command: "صاخب", label: "📢 صاخب", description: "تضخيم الصوت" },
  { command: "عزل", label: "🎚️ عزل", description: "فصل الصوت عن الموسيقى (تقريبي)" },
  { command: "فصل_صوت", label: "🎙️ فصل صوت", description: "فصل الصوت من رابط أو رد (تقريبي)" },
];

export const AI_EXTRA_ROWS: MenuRow[] = [
  { command: "تحليل_صورة", label: "🔍 تحليل صورة", description: "تحليل الصور والفيديو بالذكاء الاصطناعي" },
  { command: "لكرتون", label: "🎨 لكرتون", description: "تحويل الصورة إلى أنمي" },
  { command: "تعرف", label: "🎧 تعرف", description: "محاولة التعرف على أغنية من مقطع" },
];

export const FUN_EXTRA_ROWS: MenuRow[] = [
  { command: "مارد", label: "🧞 مارد", description: "المارد الأزرق يخمّن شخصيتك بالأسئلة" },
  { command: "احزر", label: "🎭 احزر", description: "خمّن الشخصية من صورة مموّهة" },
  { command: "عين", label: "👁️ عين", description: "خمّن الشخصية من عينها" },
  { command: "اعكس_الكلمة", label: "🔄 اعكس الكلمة", description: "احزر الكلمة من شكلها المقلوب" },
  { command: "عشوائي", label: "🎯 عشوائي", description: "اختيار عضو عشوائي (يشتغل أيضًا باسم .زنجي)" },
  { command: "مراكم", label: "📊 مراكم", description: "نسبة عشوائية ترفيهية" },
];

export const SIDE_EXTRA_ROWS: MenuRow[] = [
  { command: "اقتراح", label: "💡 اقتراح أمر", description: "اقترح أمر أو ميزة جديدة — تصل للمطور مباشرة" },
  { command: "لقبي", label: "🏷️ لقبي", description: "معرفة لقبك" },
  { command: "لقبه", label: "🏷️ لقبه", description: "معرفة لقب عضو" },
  { command: "متوفر", label: "🔍 متوفر", description: "فحص توفر لقب" },
  { command: "حجز_لقب", label: "📌 حجز لقب", description: "احجز لقبًا لنفسك" },
  { command: "نشاطي", label: "📈 نشاطي", description: "إحصائيات نشاطك في المجموعة" },
  { command: "اختفاء", label: "💤 اختفاء", description: "تسجيل غياب مع سبب وعودة تلقائية" },
];

export const INSTALL_EXTRA_ROWS: MenuRow[] = [
  { command: "الغاء_تنصيب", label: "🗑️ إلغاء تنصيب", description: "إيقاف وحذف بوتك الفرعي" },
];

export const DEV_EXTRA_ROWS: MenuRow[] = [
  { command: "تست", label: "🧪 تست", description: "إرسال/تغيير الفيديو الدائري (للمطور)" },
  { command: "اضافة_رد", label: "💬 اضافة رد", description: "ردود تلقائية عالمية (للمطور)" },
];

