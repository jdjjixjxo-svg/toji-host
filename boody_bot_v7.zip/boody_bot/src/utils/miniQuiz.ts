import { WASocket } from "@whiskeysockets/baileys";
import { eventManager } from "../handlers/eventManager";
import { getGroupSettings } from "../database/db";
import { CommandContext } from "../handlers/types";

/**
 * 🔧 إعادة تصميم كاملة للقالب (طلب صريح): القالب القديم كان طويلًا
 * (تاريخ/وقت/اسم مجموعة بأسطر منفصلة + صندوق شرح كبير). القالب الجديد
 * مختصر ومرتب بالضبط حسب الشكل المطلوب. نفس الدالة تُستخدم لكل الفعاليات
 * (خمن الشخصية/الأعلام/الرياضيات/الايموجي...)، فتغييرها هنا يغطي الكل
 * دفعة وحدة بدل تكرار نفس التنسيق بكل ملف.
 */
export function buildEventCard(
  groupName: string,
  title: string,
  content: string,
  howToPlay: string,
  footer: string
): string {
  return (
    `╗═══╗⚕️╔═══╔\n` +
    `*${groupName}*\n` +
    `╝═══╝⚜️╚═══╚\n` +
    `*🫂${footer}*\n` +
    `ـــ 🥂 𓆩${title}𓆪🥂ـــ\n` +
    `> ${howToPlay}\n` +
    `╗══╝ ﷽ ╔══╔\n` +
    `*${content}*\n` +
    `*[『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』]*`
  );
}

/**
 * يشغّل فعالية تخمين خفيفة داخل المجموعة (نفس محرك .فعالية بالضبط، فقط
 * بواجهة أبسط للأوامر السريعة مثل .اعلام / .لغز / .ايموجي...). يعيد
 * استخدام eventManager بالكامل، فالفائز يحصل تلقائيًا على نقطة + عملات
 * بنكية (مربوطة مسبقًا داخل addPoint في db.ts)، و.استسلم يشتغل معها
 * تلقائيًا (نفس eventManager.revealAndStop المستخدم لكل الفعاليات).
 *
 * 🔧 (طلب صريح: "أي فعالية تعتمد على التخمين تستخدم أزرار فقط... أزل
 * أزرار التخمين منها") — أزلنا وضع الأزرار كليًا من هذي الدالة. أي
 * خيارات (options) تُمرَّر تظهر الآن كنص عادي ضمن شرح الفعالية فقط، بدون
 * أي زر — الإجابة الوحيدة المقبولة نص مكتوب يدويًا.
 */
export async function runMiniQuiz(
  ctx: CommandContext,
  title: string,
  question: string,
  answer: string,
  timeoutMs = 60_000,
  howToPlay = "أول شخص يجاوب صح يفوز بالنقاط والعملات البنكية.",
  options?: string[]
) {
  const settings = getGroupSettings(ctx.chatId);
  if (!settings.events) {
    await ctx.sock.sendMessage(ctx.chatId, {
      text: "⚠️ نظام الفعاليات متوقف في هذه المجموعة. فعّله عبر: .اعدادات فعاليات تشغيل",
    });
    return;
  }

  if (eventManager.isRunning(ctx.sock as WASocket, ctx.chatId)) {
    await ctx.sock.sendMessage(ctx.chatId, {
      text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم",
    });
    return;
  }

  eventManager.start(ctx.sock as WASocket, ctx.chatId, title, answer, timeoutMs);

  const groupName = ctx.metadata?.subject || "الخاص";
  const seconds = Math.round(timeoutMs / 1000);
  const footer = `⏱️ أول وحد يجاوب صح يفوز! (${seconds} ثانية)`;
  const fullHowToPlay = options?.length ? `${howToPlay} (${options.join(" / ")})` : howToPlay;

  const cardText = buildEventCard(groupName, title, question, fullHowToPlay, footer);
  await ctx.sock.sendMessage(ctx.chatId, { text: cardText });
}
