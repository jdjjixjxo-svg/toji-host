import { logger } from "./logger";
import { getJson, postJson, toEnglishQuery, downloadImageBuffer, searchImages } from "./imageSearch";

const tok = (s: string) =>
  s
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter((t) => t.length >= 3);

/** صورة شخصية أنمي/كرتون من AniList — نتأكد أن الاسم فعلًا يطابق (AniList يرجّع أقرب نتيجة حتى لو غلط) */
async function fromAniList(en: string): Promise<string | null> {
  try {
    const r = await postJson("https://graphql.anilist.co", {
      query: "query($s:String){Character(search:$s){name{full native alternative} image{large}}}",
      variables: { s: en },
    });
    const c = r?.data?.Character;
    if (!c?.image?.large) return null;
    const names = tok([c.name?.full, c.name?.native, ...(c.name?.alternative || [])].filter(Boolean).join(" "));
    const want = tok(en);
    return want.some((w) => names.includes(w)) ? (c.image.large as string) : null;
  } catch (err) {
    logger.warn("⚠️ AniList لم يرجّع صورة:", err);
    return null;
  }
}

/** صورة من ويكيبيديا (مشاهير/لاعبين/شخصيات أفلام وألعاب) — أدق مصدر لأشخاص حقيقيين */
async function fromWikipedia(en: string): Promise<string | null> {
  try {
    const url =
      "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=4&prop=pageimages&piprop=thumbnail&pithumbsize=700&format=json&origin=*&gsrsearch=" +
      encodeURIComponent(en);
    const data = await getJson(url);
    const pages: any[] = Object.values(data?.query?.pages || {});
    pages.sort((a, b) => (a.index || 99) - (b.index || 99));
    const hit = pages.find((p) => p?.thumbnail?.source);
    return hit?.thumbnail?.source || null;
  } catch (err) {
    logger.warn("⚠️ ويكيبيديا لم ترجّع صورة:", err);
    return null;
  }
}

/**
 * يجلب صورة للشخصية اللي خمّنها المارد (اسم عربي أو إنجليزي).
 * الترتيب: AniList (أنمي/كرتون) ← ويكيبيديا (مشاهير/أفلام/ألعاب) ← بحث الويب.
 */
export async function getCharacterImage(name: string): Promise<Buffer | null> {
  const en = await toEnglishQuery(name);
  const urls: string[] = [];
  const a = await fromAniList(en);
  if (a) urls.push(a);
  const w = await fromWikipedia(en);
  if (w) urls.push(w);
  if (urls.length < 2) {
    try {
      urls.push(...(await searchImages(`${en} character`, 6)));
    } catch {
      /* تجاهل */
    }
  }
  for (const u of urls.slice(0, 6)) {
    try {
      const buf = await downloadImageBuffer(u);
      if (buf && buf.length > 4000) return buf;
    } catch {
      /* جرّب الرابط التالي */
    }
  }
  return null;
}
