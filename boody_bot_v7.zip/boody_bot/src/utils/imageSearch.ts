import https from "https";
import { GoogleGenAI } from "@google/genai";
import { logger } from "./logger";
import { CONFIG } from "../config/config";

/**
 * 🔎 بحث صور (بدون مفتاح إجباري) — يخدم: .صور / .ملصقات (.حزمة) / ألعاب التخمين.
 *
 * 🔧 إصلاح جذري لمشكلة «الصور عشوائية مو حسب الطلب»:
 *  1) الكلمة العربية تُترجم أولًا للإنجليزية (Gemini لو المفتاح موجود، وإلا MyMemory
 *     المجاني) لأن محركات الصور تعطي نتائج أدق بكثير بالإنجليزي (مثال: «لوفي» → Monkey D. Luffy One Piece).
 *  2) عدة مصادر بالترتيب (Bing async ← DuckDuckGo ← Bing العادي ← Openverse)، وكل نتيجة
 *     نفحص عنوانها: ما نقبل إلا الصور اللي عنوانها يحتوي كلمة من الطلب فعلًا — هذا يفلتر
 *     صفحات «التمويه» اللي ترجع صور عشوائية ثابتة لأي كلمة.
 *  3) لو ما لقينا نتائج مطابقة العنوان نرجع للنتائج الخام (أفضل من لا شي) مع تسجيل تحذير.
 *
 * ⚠️ كلها مصادر عامة غير رسمية (ما عدا Openverse) وقد تتغير — كل شي محاط بـ try/catch
 * ويسجّل السبب بالـ log. لم تُختبر من بيئة التطوير (بلا إنترنت) — أرسل أي خطأ يطلع.
 */

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

function httpGet(url: string, headers: Record<string, string> = {}, timeoutMs = 15000): Promise<string> {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      { headers: { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9", ...headers } },
      (res) => {
        const status = res.statusCode || 0;
        if (status >= 300 && status < 400 && res.headers.location) {
          res.resume();
          httpGet(new URL(res.headers.location, url).toString(), headers, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (status !== 200) {
          res.resume();
          reject(new Error(`HTTP ${status}`));
          return;
        }
        const chunks: Buffer[] = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error("TIMEOUT"));
    });
  });
}

/** POST JSON بسيط (لـ AniList) */
export function postJson(url: string, body: unknown, timeoutMs = 15000): Promise<any> {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body));
    const u = new URL(url);
    const req = https.request(
      {
        hostname: u.hostname,
        path: u.pathname + u.search,
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": UA, "Content-Length": data.length },
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          try {
            if ((res.statusCode || 0) >= 400) return reject(new Error(`HTTP ${res.statusCode}`));
            resolve(JSON.parse(Buffer.concat(chunks).toString("utf-8")));
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error("TIMEOUT"));
    });
    req.write(data);
    req.end();
  });
}

export async function getJson(url: string, timeoutMs = 15000): Promise<any> {
  return JSON.parse(await httpGet(url, { Accept: "application/json" }, timeoutMs));
}

// ------------------------------- الترجمة للإنجليزية -------------------------------
const translateCache = new Map<string, string>();
const hasArabic = (s: string) => /[\u0600-\u06FF]/.test(s);

export async function toEnglishQuery(query: string): Promise<string> {
  const q = query.trim();
  if (!q || !hasArabic(q)) return q;
  const cached = translateCache.get(q);
  if (cached) return cached;

  let out = "";
  if (CONFIG.GEMINI_API_KEY) {
    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const res = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents:
          `Translate this Arabic image-search query into the best English search query. ` +
          `If it is a character/person/thing name, give its common English name plus the franchise/context in a few words ` +
          `(e.g. "لوفي" -> "Monkey D. Luffy One Piece"). Output ONLY the English query, no quotes, no explanation.\n\nQuery: ${q}`,
      });
      out = (res.text || "").split("\n")[0].replace(/["“”`]/g, "").trim();
    } catch (err) {
      logger.warn("⚠️ فشلت ترجمة كلمة البحث عبر Gemini — نجرب MyMemory:", err);
    }
  }
  if (!out) {
    try {
      const data = await getJson(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(q)}&langpair=ar|en`, 10000);
      out = String(data?.responseData?.translatedText || "").trim();
      if (hasArabic(out)) out = "";
    } catch (err) {
      logger.warn("⚠️ فشلت ترجمة كلمة البحث عبر MyMemory:", err);
    }
  }
  if (out) translateCache.set(q, out);
  return out || q;
}

// ------------------------------- المصادر -------------------------------
export interface ImageHit {
  url: string;
  title: string;
}

function decodeEntities(s: string): string {
  return s.replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\\u002f/gi, "/");
}

async function bingAsync(q: string): Promise<ImageHit[]> {
  const url = `https://www.bing.com/images/async?q=${encodeURIComponent(q)}&first=0&count=35&mmasync=1&adlt=strict`;
  const html = await httpGet(url, { Accept: "text/html,*/*" });
  const hits: ImageHit[] = [];
  for (const m of html.matchAll(/\sm="([^"]+)"/g)) {
    try {
      const j = JSON.parse(decodeEntities(m[1]));
      if (j?.murl && /^https?:\/\//.test(j.murl)) hits.push({ url: j.murl, title: String(j.t || j.desc || "") });
    } catch {
      /* عنصر ما هو JSON صور */
    }
  }
  return hits;
}

async function bingLegacy(q: string): Promise<ImageHit[]> {
  const html = await httpGet(`https://www.bing.com/images/search?q=${encodeURIComponent(q)}&form=HDRSC2&adlt=strict`);
  const hits: ImageHit[] = [];
  for (const m of html.matchAll(/murl&quot;:&quot;(https?:\/\/[^&"]+?)&quot;(?:[^]{0,600}?)&quot;t&quot;:&quot;([^&]*?)&quot;/g)) {
    hits.push({ url: decodeEntities(m[1]), title: decodeEntities(m[2] || "") });
  }
  if (!hits.length) {
    for (const m of html.matchAll(/murl&quot;:&quot;(https?:\/\/[^&"]+?)&quot;/g)) hits.push({ url: decodeEntities(m[1]), title: "" });
  }
  return hits;
}

async function duckDuckGo(q: string): Promise<ImageHit[]> {
  const page = await httpGet(`https://duckduckgo.com/?q=${encodeURIComponent(q)}&iax=images&ia=images`);
  const vqd = page.match(/vqd=["']?([\d-]+)["']?/)?.[1];
  if (!vqd) throw new Error("NO_VQD_TOKEN");
  const raw = await httpGet(
    `https://duckduckgo.com/i.js?l=wt-wt&o=json&q=${encodeURIComponent(q)}&vqd=${vqd}&f=,,,&p=1`,
    { Referer: "https://duckduckgo.com/", Accept: "application/json" }
  );
  const data = JSON.parse(raw);
  return (Array.isArray(data?.results) ? data.results : [])
    .filter((r: any) => typeof r?.image === "string" && r.image)
    .map((r: any) => ({ url: r.image as string, title: String(r.title || "") }));
}

async function openverse(q: string): Promise<ImageHit[]> {
  const data = await getJson(`https://api.openverse.org/v1/images/?q=${encodeURIComponent(q)}&page_size=30&mature=false`);
  return (Array.isArray(data?.results) ? data.results : [])
    .filter((r: any) => typeof r?.url === "string" && r.url)
    .map((r: any) => ({ url: r.url as string, title: String(r.title || "") }));
}

const STOP = new Set(["the", "a", "an", "of", "and", "in", "on", "for", "to", "hd", "image", "images", "photo", "picture", "pic"]);
function tokens(s: string): string[] {
  return s
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter((t) => t.length >= 3 && !STOP.has(t));
}

/** يقدّم النتائج اللي عنوانها يحتوي كلمة من الطلب، ويؤخّر الباقي */
function rank(hits: ImageHit[], words: string[]): { good: ImageHit[]; rest: ImageHit[] } {
  const good: ImageHit[] = [];
  const rest: ImageHit[] = [];
  const seen = new Set<string>();
  for (const h of hits) {
    if (seen.has(h.url)) continue;
    seen.add(h.url);
    const t = h.title.toLowerCase();
    (words.length && words.some((w) => t.includes(w)) ? good : rest).push(h);
  }
  return { good, rest };
}

/**
 * يبحث عن روابط صور مباشرة. `limit` = أقصى عدد روابط.
 * يرجع دائمًا مصفوفة (فاضية لو كل المصادر فشلت — والسبب بالـ log).
 */
export async function searchImages(query: string, limit = 30): Promise<string[]> {
  const q = query.trim();
  const en = await toEnglishQuery(q);
  const queries = [...new Set([en, q].filter(Boolean))];
  const words = [...new Set([...tokens(en), ...tokens(q)])];
  const sources: [string, (s: string) => Promise<ImageHit[]>][] = [
    ["Bing", bingAsync],
    ["DuckDuckGo", duckDuckGo],
    ["Bing-legacy", bingLegacy],
    ["Openverse", openverse],
  ];

  let fallback: string[] = [];
  for (const sq of queries) {
    for (const [name, fn] of sources) {
      try {
        const hits = await fn(sq);
        if (!hits.length) continue;
        const { good, rest } = rank(hits, words);
        if (good.length >= Math.min(5, limit)) return good.map((h) => h.url).concat(rest.map((h) => h.url)).slice(0, limit);
        if (!fallback.length && (good.length || rest.length)) {
          logger.warn(`⚠️ بحث الصور (${name}) لـ"${sq}": نتائج قليلة مطابقة للعنوان (${good.length}/${hits.length}).`);
          fallback = good.map((h) => h.url).concat(rest.map((h) => h.url));
        }
      } catch (err) {
        logger.warn(`⚠️ فشل بحث الصور عبر ${name} لـ"${sq}":`, err);
      }
    }
  }
  return fallback.slice(0, limit);
}

/**
 * 🔧 إصلاح (بعد فشل .حزمة فعليًا: "لقيت صور بس ما قدرت أحوّل ولا وحدة"):
 * النسخة القديمة كانت ترجع null بصمت على أي خطأ (حتى لو كان السبب واضح
 * ومختلف تمامًا من صورة لصورة) — فما كان فيه أي طريقة نعرف فعليًا ليش
 * فشلت كل الصور. الأسباب المحتملة الحقيقية اكتشفناها فقط بعد إضافة هذا
 * التفصيل:
 *  1) روابط "murl" من بينغ كثير منها تُحوّل (30x redirect) لصفحة أو CDN
 *     ثاني — والنسخة القديمة ما كانت تتبع أي تحويل أصلًا فترجع null فورًا.
 *  2) بعض المواقع تحمي الصور من hotlinking وترجع 200 لكن بصفحة HTML/خطأ
 *     بدل بيانات الصورة الفعلية (لهذا نتحقق من content-type كمان لا
 *     نعتمد فقط على statusCode).
 * الحين نرمي Error برسالة واضحة بدل إرجاع null، حتى تقدر stickerPack.ts
 * تسجّل السبب الحقيقي وتجمعه بدل ما تبتلع كل الأخطاء بصمت.
 */
export async function downloadImageBuffer(url: string, redirectsLeft = 3): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const req = https.get(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            Accept: "image/*,*/*;q=0.8",
          },
        },
        (res) => {
          const status = res.statusCode || 0;

          if (status >= 300 && status < 400 && res.headers.location) {
            res.resume(); // نفرّغ الاستجابة الحالية قبل ما نطلب الرابط الجديد
            if (redirectsLeft <= 0) {
              reject(new Error("TOO_MANY_REDIRECTS"));
              return;
            }
            const nextUrl = new URL(res.headers.location, url).toString();
            downloadImageBuffer(nextUrl, redirectsLeft - 1).then(resolve).catch(reject);
            return;
          }

          if (status !== 200) {
            reject(new Error(`HTTP ${status}`));
            return;
          }

          const contentType = String(res.headers["content-type"] || "");
          if (contentType && !contentType.startsWith("image/")) {
            // 200 لكن مو صورة فعليًا — غالبًا صفحة حماية hotlink أو خطأ HTML
            reject(new Error(`NOT_AN_IMAGE (content-type: ${contentType || "غير معروف"})`));
            return;
          }

          const chunks: Buffer[] = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => resolve(Buffer.concat(chunks)));
          res.on("error", (err) => reject(err));
        }
      );
      req.on("error", (err) => reject(err));
      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error("TIMEOUT"));
      });
    } catch (err) {
      reject(err instanceof Error ? err : new Error(String(err)));
    }
  });
}
