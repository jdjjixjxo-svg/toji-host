import { WASocket } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { sendButtonMessage } from "./interactive";
import { jidToMention } from "./helpers";

/** true لو رابط صفحة الألعاب الفورية مضبوط بـ GAMES_URL */
export function hasWebGames(): boolean {
  return /^https?:\/\//i.test(CONFIG.GAMES_URL || "");
}

/** يرسل بطاقة بزر "العب الآن" يفتح لعبة 3D فورية (حقيقية، بدون توليد صور) */
export async function sendWebGameCard(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  opts: { title: string; blurb: string; mode: string; buttonText?: string }
): Promise<void> {
  const url = `${CONFIG.GAMES_URL}${CONFIG.GAMES_URL.includes("#") ? "" : `#${opts.mode}`}`;
  await sendButtonMessage(sock, chatId, {
    text: `${opts.title}\n${jidToMention(senderJid)}\n\n${opts.blurb}\n\n🕹️ اللعبة تفتح فورًا وتتحرك بلمسة الأزرار — بدون انتظار.`,
    mentions: [senderJid],
    extraButtons: [
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({ display_text: opts.buttonText || "🎮 العب الآن", url, merchant_url: url }),
      },
    ],
    fallbackNote: `🎮 العب من هنا: ${url}`,
  });
}
