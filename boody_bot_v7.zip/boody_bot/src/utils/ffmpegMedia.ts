import path from "path";
import os from "os";
import crypto from "crypto";
import fs from "fs-extra";
import ffmpeg from "fluent-ffmpeg";
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg";
import { logger } from "./logger";

ffmpeg.setFfmpegPath(ffmpegInstaller.path);

// 🆕 (بسبب "أوامر متعلقة بالفيديو/الصوت ما تشتغل على بعض الاستضافات
// المقيّدة مثل Katabump"): مكتبة @ffmpeg-installer/ffmpeg تحمّل ملف
// ffmpeg التنفيذي الفعلي بنفسها أثناء "npm install" (سكربت postinstall
// خاص فيها). لو الاستضافة تمنع سكربتات postinstall أو تحجب الإنترنت
// وقت التثبيت، الملف التنفيذي ما ينحمّل أبدًا رغم إن حزمة npm نفسها
// مثبتة — فأي أمر يعتمد على ffmpeg كان يفشل بخطأ غامض (ENOENT من عملية
// فرعية) يصعب فهم سببه من رسالة الخطأ العامة للمستخدم. نتحقق من وجود
// الملف فعليًا هنا، ونرمي خطأ واضح السبب والحل لو كان مفقودًا، بدل
// خطأ نظام تشغيل مبهم.
function assertFfmpegAvailable() {
  if (!fs.existsSync(ffmpegInstaller.path)) {
    throw new Error(
      `FFMPEG_MISSING: ملف ffmpeg التنفيذي غير موجود بالمسار المتوقع (${ffmpegInstaller.path}). ` +
        `غالبًا فشل تحميله تلقائيًا وقت "npm install" (بعض الاستضافات تمنع سكربتات postinstall أو تحجب الإنترنت أثناء التثبيت). ` +
        `الحل: شغّل "npm rebuild @ffmpeg-installer/ffmpeg" من طرفية الاستضافة، أو احذف node_modules وأعد "npm install".`
    );
  }
}

/**
 * ينفّذ ffmpeg على بفر مدخل، ويرجع بفر المخرج. يكتب ملفات مؤقتة تحت
 * مجلد النظام (os.tmpdir) وينظّفها بعد الانتهاء بغض النظر عن النجاح/الفشل.
 *
 * 🔧 (تشخيص جذري لخطأ ".صوره" مع ملصقات متحركة: "ffmpeg exited with
 * code 1: Error while decoding stream... Cannot determine format of
 * input stream... Conversion failed!") — هذا الخطأ تحديدًا يصدر من
 * *مرحلة الفحص التلقائي* (probing) اللي يعملها ffmpeg قبل أي فك تشفير،
 * لمحاولة تخمين صيغة الملف من محتواه. animated webp تحديدًا معروف بكونه
 * حساس لهذي المرحلة مع نسخة ffmpeg الثابتة (static build) اللي توزّعها
 * حزمة @ffmpeg-installer/ffmpeg — أحيانًا يفشل التخمين حتى مع ملف صحيح
 * تمامًا. الحل الموثّق: نمرر صيغة المدخل صراحة (inputFormat) بدل ما
 * نعتمد على التخمين التلقائي، فتتخطى ffmpeg مرحلة الفحص هذي بالكامل.
 * هذا اختياري (undefined لبقية الاستخدامات اللي ما تحتاجه، مثل mp4/mp3).
 */
async function runFfmpeg(
  input: Buffer,
  inExt: string,
  outExt: string,
  configure: (cmd: ffmpeg.FfmpegCommand) => ffmpeg.FfmpegCommand,
  inputFormat?: string
): Promise<Buffer> {
  const id = crypto.randomBytes(6).toString("hex");
  const inPath = path.join(os.tmpdir(), `mrbot-${id}-in.${inExt}`);
  const outPath = path.join(os.tmpdir(), `mrbot-${id}-out.${outExt}`);

  assertFfmpegAvailable();

  try {
    await fs.writeFile(inPath, input);

    // 🔧 تحقق مبكر: لو البفر فاضي أو صغير جدًا (تحميل ناقص من واتساب،
    // مثلًا رابط وسائط منتهي الصلاحية رجع صفحة خطأ HTML بدل الملف
    // الفعلي)، ffmpeg يرمي بالضبط نفس رسالة "Cannot determine format"
    // المبهمة. نكتشفها هنا برسالة أوضح بدل ما تظهر كخطأ ffmpeg غامض.
    if (!input || input.length < 64) {
      throw new Error(
        `MEDIA_TOO_SMALL: البيانات المُحمَّلة صغيرة جدًا (${input?.length || 0} بايت) لتكون ملف وسائط صالح — التحميل من واتساب فشل جزئيًا أو رابط الوسائط منتهي الصلاحية.`
      );
    }

    await new Promise<void>((resolve, reject) => {
      let cmd = ffmpeg(inPath);
      if (inputFormat) cmd = cmd.inputFormat(inputFormat);
      cmd = configure(cmd.output(outPath));
      let stderrLog = "";
      cmd
        .on("stderr", (line: string) => {
          stderrLog += line + "\n";
        })
        .on("end", () => resolve())
        .on("error", (err) => {
          // 🔧 fluent-ffmpeg's err.message غالبًا مختصر جدًا ("ffmpeg
          // exited with code 1") — نلحق آخر أسطر stderr الفعلية (فيها
          // السبب الحقيقي) حتى تصل لسجل notifyOwnerOfError كاملة.
          const tail = stderrLog.trim().split("\n").slice(-5).join(" | ");
          reject(new Error(`${err.message}${tail ? ` — ffmpeg stderr: ${tail}` : ""}`));
        })
        .run();
    });

    return await fs.readFile(outPath);
  } finally {
    await fs.remove(inPath).catch(() => {});
    await fs.remove(outPath).catch(() => {});
  }
}

// 🆕 (طلب صريح: أمر ".تعديل_تست" يعدّل فيديو الترحيب الدائري المستخدم
// بأمر .تست) — تأثيرات فيديو بسيطة عبر فلاتر ffmpeg قياسية. نحذف الصوت
// عمدًا (noAudio) بكل التأثيرات، خصوصًا تغيير السرعة (setpts): تغيير
// سرعة الفيديو بدون تعديل الصوت بنفس النسبة (atempo) يخرب المزامنة
// تمامًا، وفيديوهات الترحيب الدائرية غالبًا مالها صوت أصلًا فما فيه خسارة
// حقيقية. لو احتجت لاحقًا صوت متزامن مع السرعة، أضف atempo بنفس نسبة setpts.
export const VIDEO_EDIT_EFFECTS: Record<string, string[]> = {
  اسود_ابيض: ["hue=s=0"],
  رمادي: ["hue=s=0"],
  سيبيا: ["colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131"],
  عكس: ["hflip"],
  دوران: ["transpose=1"], // 90 درجة مع عقارب الساعة
  تفتيح: ["eq=brightness=0.12"],
  تعتيم: ["eq=brightness=-0.12"],
  تباين: ["eq=contrast=1.4"],
  سلو: ["setpts=2.0*PTS"],
  ابطاء: ["setpts=2.0*PTS"],
  سريع: ["setpts=0.5*PTS"],
  تسريع: ["setpts=0.5*PTS"],
};

/** يطبّق تأثير فيديو (راجع VIDEO_EDIT_EFFECTS للأسماء المتاحة) ويرجع mp4 جديد. */
export async function applyVideoEdit(buffer: Buffer, effect: string): Promise<Buffer> {
  const chain = VIDEO_EDIT_EFFECTS[effect];
  if (!chain) throw new Error(`UNKNOWN_EFFECT: "${effect}" — استخدم أحد الأسماء المتاحة فقط.`);
  return runFfmpeg(buffer, "mp4", "mp4", (cmd) =>
    cmd.videoFilters(chain).noAudio().outputOptions(["-preset", "fast", "-movflags", "+faststart"])
  );
}

/**
 * يحوّل ملصق متحرك (animated webp) إلى فيديو mp4 قصير (لإرساله بخاصية
 * gifPlayback فيصير "صورة متحركة" داخل واتساب). يُستخدم بأمر .صوره.
 */
export async function animatedWebpToMp4(buffer: Buffer): Promise<Buffer> {
  // 🔧 إصلاح: ffmpeg نفسه لا يفك ترميز WebP المتحرك أبدًا ("Input format webp is not
  // available") — فالنسخة القديمة كانت تفشل دائمًا. نفك الإطارات بـ sharp (يدعم
  // WebP المتحرك) ثم نجمّعها بـ ffmpeg كفيديو.
  const sharp = (await import("sharp")).default;
  const meta = await sharp(buffer, { animated: true }).metadata();
  const pages = Math.min(meta.pages || 1, 120);
  const delayMs = Array.isArray(meta.delay) && meta.delay[0] > 0 ? meta.delay[0] : 80;
  const fps = Math.max(5, Math.min(30, Math.round(1000 / delayMs)));

  const id = crypto.randomBytes(6).toString("hex");
  const dir = path.join(os.tmpdir(), `mrbot-${id}-frames`);
  const outPath = path.join(os.tmpdir(), `mrbot-${id}-out.mp4`);
  assertFfmpegAvailable();
  await fs.ensureDir(dir);
  try {
    for (let i = 0; i < pages; i++) {
      const frame = await sharp(buffer, { page: i })
        .flatten({ background: "#ffffff" })
        .resize(512, 512, { fit: "contain", background: "#ffffff" })
        .png()
        .toBuffer();
      await fs.writeFile(path.join(dir, `f${String(i).padStart(4, "0")}.png`), frame);
    }
    await new Promise<void>((resolve, reject) => {
      let cmd = ffmpeg(path.join(dir, "f%04d.png")).inputOptions(["-framerate", String(fps)]);
      // ملصق ثابت (إطار واحد): نكرره ثانيتين ليصير فيديو صالحًا
      if (pages === 1) cmd = cmd.inputOptions(["-loop", "1"]).outputOptions(["-t", "2"]);
      cmd
        .outputOptions(["-movflags", "faststart", "-pix_fmt", "yuv420p", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"])
        .output(outPath)
        .on("end", () => resolve())
        .on("error", (err) => reject(err))
        .run();
    });
    return await fs.readFile(outPath);
  } finally {
    await fs.remove(dir).catch(() => {});
    await fs.remove(outPath).catch(() => {});
  }
}

/**
 * يستخرج الصوت فقط من فيديو (بدون أي معالجة للصورة) ويرجعه كـ MP3.
 * يُستخدم بأمر .تحميل_صوت (نفس فيديو .تحميل، لكن الصوت فقط).
 * "-vn" يشيل تيار الفيديو بالكامل فتكون النتيجة صوت فقط.
 */
export async function extractAudioFromVideo(buffer: Buffer): Promise<Buffer> {
  return runFfmpeg(buffer, "mp4", "mp3", (cmd) =>
    cmd.outputOptions(["-vn", "-acodec", "libmp3lame", "-q:a", "2"])
  );
}

/**
 * يحوّل فيديو إلى ملصق متحرك (animated webp)، بأكبر عدد ممكن من الثواني
 * (سقف آمن متوافق مع واتساب) وبتكرار لانهائي (loop). يُستخدم بأمر .ملصق.
 */
export async function videoToAnimatedSticker(buffer: Buffer, maxSeconds = 10): Promise<Buffer> {
  return runFfmpeg(buffer, "mp4", "webp", (cmd) =>
    cmd
      .duration(maxSeconds)
      .outputOptions([
        "-vcodec",
        "libwebp",
        "-filter:v",
        "fps=12,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0",
        "-loop",
        "0",
        "-preset",
        "default",
        "-an",
        "-vsync",
        "0",
        "-lossless",
        "0",
        "-compression_level",
        "6",
        "-q:v",
        "50",
      ])
  );
}

/**
 * 🆕 (طلب صريح: "خله يرسل هذا الفيديو كدائرة كل ما يدخل كروب جديد") —
 * فيديو "PTV" (Photo/Video Timeline) اللي يعرضه واتساب كدائرة لازم يكون
 * مربع الأبعاد (1:1) — الفيديو المرفوع مستطيل عادةً، فنربّعه هنا (قص
 * منتصف الفريم + حد أقصى للمدة، فيديو PTV أطول من ~60 ثانية غالبًا
 * يُرفض من واتساب نفسه).
 */
export async function videoToSquarePtv(buffer: Buffer, maxSeconds = 30): Promise<Buffer> {
  return runFfmpeg(buffer, "mp4", "mp4", (cmd) =>
    cmd
      .duration(maxSeconds)
      .outputOptions([
        "-vf",
        "crop='min(iw,ih)':'min(iw,ih)',scale=480:480",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-c:a",
        "aac",
        "-movflags",
        "+faststart",
      ])
  );
}

/** 🆕 (.صاخب) يضخّم مستوى الصوت مع محدّد قمم لتجنّب التشويه، ويرجعه MP3 */
export async function boostAudio(buffer: Buffer, factor = 6): Promise<Buffer> {
  return runFfmpeg(buffer, "ogg", "mp3", (cmd) =>
    cmd.audioFilters([`volume=${factor}`, "alimiter=limit=0.95"]).outputOptions(["-vn", "-acodec", "libmp3lame", "-q:a", "3"])
  );
}

/**
 * 🆕 (.عزل / .فصل_صوت) فصل تقريبي للصوت البشري عن الموسيقى بدون خدمات خارجية:
 * - الموسيقى: إلغاء القناة المركزية (الصوت البشري غالبًا في المنتصف بالأغاني الستيريو).
 * - الصوت: القناة المركزية فقط مع تصفية ترددات الصوت البشري.
 * الجودة أقل من أدوات AI المتخصصة (Demucs...) وتعمل أفضل مع الأغاني الستيريو.
 */
export async function separateVocalsApprox(buffer: Buffer): Promise<{ vocals: Buffer; music: Buffer }> {
  const music = await runFfmpeg(buffer, "mp3", "mp3", (cmd) =>
    cmd.audioFilters(["pan=stereo|c0=c0-c1|c1=c1-c0", "volume=2.5"]).outputOptions(["-vn", "-acodec", "libmp3lame", "-q:a", "3"])
  );
  const vocals = await runFfmpeg(buffer, "mp3", "mp3", (cmd) =>
    cmd
      .audioFilters(["pan=mono|c0=0.5*c0+0.5*c1", "highpass=f=180", "lowpass=f=5500", "volume=1.6"])
      .outputOptions(["-vn", "-acodec", "libmp3lame", "-q:a", "3"])
  );
  return { vocals, music };
}
