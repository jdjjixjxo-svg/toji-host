import zlib from "zlib";

export interface ZipEntry {
  name: string;
  data: Buffer;
}

/**
 * 🆕 (حل مشكلة "سبام 30 ملصق" بأمر .حزمة)
 * يبني ملف ZIP صالح (نفس الصيغة اللي تفهمها تطبيقات "صانع الملصقات" على
 * أندرويد/آيفون لما تُسمّى الملف بامتداد .wastickers) بدون أي حزمة
 * خارجية (archiver/adm-zip...). كتبناه يدويًا بصيغة ZIP القياسية
 * (تنسيق DEFLATE + جدول مركزي في النهاية) عمدًا بدل إضافة حزمة جديدة،
 * حتى لا يعتمد تثبيت البوت على حزمة إضافية قد تفشل بالاستضافة، ولأن
 * الحاجة هنا بسيطة (ملفات مسطّحة بدون مجلدات متداخلة).
 *
 * ⚠️ صراحة: هذا يبني ملف ZIP سليم 100% (يمكن فكه بأي برنامج ضغط عادي
 * للتأكد)، لكن هل تطبيقات صانع الملصقات على جهاز المستخدم فعليًا تستورد
 * حزمة كاملة بضغطة واحدة من ملف .wastickers يعتمد على أي تطبيق مثبت
 * عندهم (الأشهر: "Sticker Maker") ونوع/إصدار ذلك التطبيق — لم يُختبر على
 * جهاز حقيقي (بيئة الكتابة بلا اتصال). لو ما فتح تلقائيًا، يوصل كملف
 * زيب عادي يقدر المستخدم يفتحه يدويًا بدل ما يوصله 30 رسالة سبام —
 * وهذا أصلًا الهدف المباشر المطلوب.
 */
export function buildZip(entries: ZipEntry[]): Buffer {
  const crcTable = buildCrcTable();
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBuf = Buffer.from(entry.name, "utf-8");
    const compressed = zlib.deflateRawSync(entry.data);
    const crc = crc32(entry.data, crcTable);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); // local file header signature
    localHeader.writeUInt16LE(20, 4); // version needed to extract
    localHeader.writeUInt16LE(0, 6); // general purpose flag
    localHeader.writeUInt16LE(8, 8); // compression method = DEFLATE
    localHeader.writeUInt16LE(0, 10); // last mod time
    localHeader.writeUInt16LE(0, 12); // last mod date
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(entry.data.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28); // extra field length

    localParts.push(localHeader, nameBuf, compressed);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); // central directory signature
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0, 8); // flags
    centralHeader.writeUInt16LE(8, 10); // method
    centralHeader.writeUInt16LE(0, 12); // time
    centralHeader.writeUInt16LE(0, 14); // date
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(entry.data.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30); // extra length
    centralHeader.writeUInt16LE(0, 32); // comment length
    centralHeader.writeUInt16LE(0, 34); // disk number start
    centralHeader.writeUInt16LE(0, 36); // internal attrs
    centralHeader.writeUInt32LE(0, 38); // external attrs
    centralHeader.writeUInt32LE(offset, 42); // offset of local header

    centralParts.push(centralHeader, nameBuf);

    offset += localHeader.length + nameBuf.length + compressed.length;
  }

  const centralDirStart = offset;
  const centralDirBuf = Buffer.concat(centralParts);

  const endRecord = Buffer.alloc(22);
  endRecord.writeUInt32LE(0x06054b50, 0); // end of central directory signature
  endRecord.writeUInt16LE(0, 4); // disk number
  endRecord.writeUInt16LE(0, 6); // disk with central dir
  endRecord.writeUInt16LE(entries.length, 8); // entries on this disk
  endRecord.writeUInt16LE(entries.length, 10); // total entries
  endRecord.writeUInt32LE(centralDirBuf.length, 12);
  endRecord.writeUInt32LE(centralDirStart, 16);
  endRecord.writeUInt16LE(0, 20); // comment length

  return Buffer.concat([...localParts, centralDirBuf, endRecord]);
}

function buildCrcTable(): Uint32Array {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
}

function crc32(buf: Buffer, table: Uint32Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
