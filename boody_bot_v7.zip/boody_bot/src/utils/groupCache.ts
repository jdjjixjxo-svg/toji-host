import { GroupMetadata } from "@whiskeysockets/baileys";

/**
 * كاش مشترك لبيانات المجموعات (يستخدمه messageHandler و Baileys نفسه عبر cachedGroupMetadata).
 * 🔧 سبب البطء: بدون هذا الكاش، Baileys يجلب بيانات المجموعة من واتساب مع *كل* رسالة
 * يرسلها البوت بمجموعة (رحلة شبكة إضافية) — ويسبب أيضًا rate-overlimit ورسائل ما توصل.
 */
const cache = new Map<string, { data: GroupMetadata; ts: number }>();
export const GROUP_CACHE_TTL = 5 * 60_000;

export function setGroupCache(id: string, data: GroupMetadata): void {
  cache.set(id, { data, ts: Date.now() });
  while (cache.size > 300) cache.delete(cache.keys().next().value as string);
}
export function getGroupCache(id: string, ttl = GROUP_CACHE_TTL): GroupMetadata | undefined {
  const c = cache.get(id);
  return c && Date.now() - c.ts < ttl ? c.data : undefined;
}
export function invalidateGroupCache(id: string): void {
  cache.delete(id);
}
