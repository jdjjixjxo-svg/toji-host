/**
 * 🆕 رسم لوحة "إكس_أو" كصورة PNG واضحة (بدل النص القديم) — نفس أسلوب
 * renderer2048.ts وsnakeRenderer.ts بالضبط: Jimp فقط (بدون أي مكتبة رسم
 * native)، حتى يشتغل على أي استضافة بدون خطر فشل تثبيت.
 */
import Jimp from "jimp";

const CELL = 160; // بكسل لكل خانة
const GAP = 10; // سمك خطوط الشبكة
const SIZE = CELL * 3 + GAP * 4; // أبعاد الصورة الكاملة (مربعة)

const COLOR_BG = Jimp.rgbaToInt(20, 22, 30, 255); // خلفية خطوط الشبكة (غامقة)
const COLOR_EMPTY = Jimp.rgbaToInt(46, 50, 64, 255); // خانة فاضية
const COLOR_X = Jimp.rgbaToInt(200, 60, 70, 255); // خانة إكس (أحمر)
const COLOR_O = Jimp.rgbaToInt(60, 120, 200, 255); // خانة أو (أزرق)

function fillRect(image: Jimp, x: number, y: number, w: number, h: number, color: number) {
  image.scan(x, y, w, h, function (this: Jimp, _x: number, _y: number, idx: number) {
    this.bitmap.data.writeUInt32BE(color, idx);
  });
}

/**
 * يرسم لوحة اللعبة الحالية كصورة. board[] نفس تنسيق ticTacToeManager
 * (9 خانات: "1".."9" لخانة فاضية، أو "❌"/"⭕" لخانة محجوزة).
 */
export async function renderTicTacToeImage(board: string[]): Promise<Buffer> {
  const image = await new Jimp(SIZE, SIZE, COLOR_BG);
  const numberFont = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  const markFont = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);

  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 3; col++) {
      const idx = row * 3 + col;
      const cellValue = board[idx];
      const isX = cellValue === "❌";
      const isO = cellValue === "⭕";
      const px = GAP + col * (CELL + GAP);
      const py = GAP + row * (CELL + GAP);
      const color = isX ? COLOR_X : isO ? COLOR_O : COLOR_EMPTY;

      fillRect(image, px, py, CELL, CELL, color);

      const label = isX ? "X" : isO ? "O" : String(idx + 1);
      const font = isX || isO ? markFont : numberFont;
      const textWidth = Jimp.measureText(font, label);
      const textHeight = Jimp.measureTextHeight(font, label, CELL);
      image.print(
        font,
        px + Math.max(0, (CELL - textWidth) / 2),
        py + Math.max(0, (CELL - textHeight) / 2),
        label
      );
    }
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}
