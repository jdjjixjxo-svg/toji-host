import { getMsgContext } from "./msgContext";
import { getGroupCache } from "./groupCache";

/**
 * 🎨 القالب الموحّد لكل رسائل البوت (طلب صريح: نفس الشكل لكل القوائم والرسائل)
 *
 *   『 𝑩𝑶𝑶𝑫𝒀┆ 🌑 ┆𝑩𝑶𝑻 』
 *   ـ⌬┪─━─┢🩸┪─━─┢⌬
 *   ـ⌬┋ المحتوى...
 *   ـ⌬┪─━─┢🩸┪─━─┢⌬
 *   ـ⌬┋ اسم المجموعة
 *   ـ⌬┒━─━┈┉┈━─━─┎
 *   ـ⌬│ بطاقة القسم ┃
 *   ـ⌬┙━─━┈┉┈━─━─┖
 *
 * أي نص يمر من هنا يتحوّل تلقائيًا للقالب (إلا لو كان مؤطّرًا أصلًا).
 */
export const HEADER = "『 𝑩𝑶𝑶𝑫𝒀┆ 🌑 ┆𝑩𝑶𝑻 』";
export const SEP = "ـ⌬┪─━─┢🩸┪─━─┢⌬";
export const LINE = "ـ⌬┋";
export const CARD_TOP = "ـ⌬┒━─━┈┉┈━─━─┎";
export const CARD_BOTTOM = "ـ⌬┙━─━┈┉┈━─━─┖";

/** يبني بطاقة الخاتمة: ـ⌬│ نص ┃ */
export function cardLine(text: string): string {
  return `ـ⌬│ ${text}   ┃`;
}

/** هل النص مؤطّر أصلًا بالقالب (يمنع التأطير المزدوج) */
export function isFramed(text: string): boolean {
  return text.includes(CARD_TOP) && text.includes("𝑩𝑶𝑶𝑫𝒀");
}

const DECOR_ONLY = /^[\s\u200e\u200f_*~ـ✦✧─━═·\-﹌︵‿୨୧,()<>.⋆⊱༻𖥸༺⊰🏯◈▬✯彡爻✿ʘ]+$/u;

function isDecorLine(line: string): boolean {
  const t = line.trim();
  return t.length >= 3 && DECOR_ONLY.test(t) && !/[\p{L}\p{N}]/u.test(t.replace(/[ʘ]/g, ""));
}

function resolveGroupName(chatId?: string): string {
  const ctx = getMsgContext();
  if (ctx?.groupName) return ctx.groupName;
  if (chatId) {
    const cached = getGroupCache(chatId, Number.POSITIVE_INFINITY);
    if (cached?.subject) return cached.subject;
    return chatId.endsWith("@g.us") ? "المجموعة" : "خاص";
  }
  return "خاص";
}

function resolveCardText(): string {
  const cat = getMsgContext()?.category;
  const names: Record<string, string> = {
    بوت: "معلومات البوت",
    مشرفين: "قسم المشرفين",
    حماية: "قسم الحماية",
    ترفيه: "قسم الترفيه",
    ادوات: "قسم الأدوات",
    اعدادات: "إعدادات المجموعة",
    السنة: "قسم السنة النبوية",
    المطور: "قسم المطور",
    IA: "قسم الذكاء الاصطناعي",
    تحليل: "قسم التحليل",
    العاب2D: "قسم الألعاب",
    تنصيب: "قسم التنصيب",
  };
  return (cat && names[cat]) || "𝑩𝑶𝑶𝑫𝒀 𝑩𝑶𝑻";
}

/** يحوّل أي نص عادي للقالب الموحّد مع الحفاظ على محتواه كما هو */
export function autoFrame(text: string, chatId?: string, cardText?: string): string {
  const raw = (text || "").replace(/\r/g, "").trim();
  if (!raw || isFramed(raw)) return raw;

  const body: string[] = [];
  for (const line of raw.split("\n")) {
    if (isDecorLine(line)) {
      if (body[body.length - 1] !== SEP) body.push(SEP);
      continue;
    }
    if (!line.trim()) {
      // سطر فاضي: نبقيه فاضي (بدون بادئة) للفصل البصري بين الفقرات
      if (body.length && body[body.length - 1] !== "") body.push("");
      continue;
    }
    body.push(`${LINE} ${line.trim()}`);
  }
  while (body.length && (body[0] === "" || body[0] === SEP)) body.shift();
  while (body.length && (body[body.length - 1] === "" || body[body.length - 1] === SEP)) body.pop();

  return [
    HEADER,
    SEP,
    ...body,
    SEP,
    `${LINE} ${resolveGroupName(chatId)}`,
    CARD_TOP,
    cardLine(cardText || resolveCardText()),
    CARD_BOTTOM,
  ].join("\n");
}
