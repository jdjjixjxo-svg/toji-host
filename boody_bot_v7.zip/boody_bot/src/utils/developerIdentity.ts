import { WASocket, GroupMetadata } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { getBotSelfNumber, getOwnerLid } from "./botIdentity";
import { findParticipant, digitsOnly } from "./participantMatch";

/**
 * 🆕 (طلب صريح: "مصدر واحد للحقيقة بالنسبة للمطورين... isDeveloper(user)
 * بدل أن يكون كل أمر لديه طريقة مختلفة لمعرفة المطور") — هذا الملف هو
 * المصدر المركزي الوحيد لسؤال "هل هذا الشخص مطور؟" بكل المشروع.
 *
 * يعتمد على utils/participantMatch.ts (المصدر المركزي لمطابقة id/
 * phoneNumber/lid) — نفس الهلبر المستخدم بالضبط بـpermissions.ts
 * (isGroupAdmin) وdb.ts (isGlobalVirtualAdmin)، فكل أنظمة الهوية
 * بالمشروع توحّدت على نفس منطق المطابقة الآن.
 *
 * ⚠️ عمدًا لا يستورد أي شي من utils/helpers.ts — helpers.ts نفسه يستدعي
 * isDeveloper() هنا لإشعار المطور بالأخطاء، فلو استوردنا منه هنا كان
 * صار circular import (راجع نفس الملاحظة بـparticipantMatch.ts).
 */
function getBotScopeId(sock: { user?: { id?: string } }): string {
  return digitsOnly(sock.user?.id) || "unknown";
}

/**
 * يتحقق هل الرقم هو مطور (أساسي أو ثانٍ) — المصدر المركزي الوحيد.
 * يتعرف على:
 *   1) صاحب رقم أي بوت (رئيسي أو فرعي) بالذات، لما يمرَّر sock الخاص بذاك
 *      البوت — منعزل تمامًا لكل بوت (راجع تعليق messageHandler.ts).
 *   2) CONFIG.OWNER_NUMBER (المطور الأساسي، من .env).
 *   3) CONFIG.OWNER_NUMBER_2 (المطور الثاني، من .env) — صلاحيات مطابقة
 *      تمامًا للمطور الأساسي، بلا أي شرط أو تبعية بينهما.
 *   4) رقم الحساب المربوط فيه البوت الرئيسي حاليًا (botSelf) ولِده
 *      (ownerLid) المكتشفين تلقائيًا — يغطي حالة ربط البوت برقم المطور
 *      نفسه.
 * يدعم مطابقة id/phoneNumber/lid داخل بيانات المجموعة (metadata) لحل
 * مشكلة "@lid" الحديثة بواتساب (رقم مؤقت مختلف عن الرقم الحقيقي) —
 * عبر findParticipant() المركزية بدل مطابقة يدوية مكررة هنا.
 */
export function isDeveloper(jid: string, metadata?: GroupMetadata, sock?: WASocket): boolean {
  const target = digitsOnly(jid);
  if (!target) return false;

  if (sock && target === getBotScopeId(sock)) return true;

  const botSelf = getBotSelfNumber();
  const ownerLid = getOwnerLid();
  const owner2 = CONFIG.OWNER_NUMBER_2;
  const owner3 = CONFIG.OWNER_NUMBER_3;
  const developerNumbers = [CONFIG.OWNER_NUMBER, owner2, owner3, botSelf, ownerLid].filter(Boolean);

  if (developerNumbers.includes(target)) return true;

  if (metadata) {
    const participant = findParticipant(metadata, jid);
    if (participant) {
      const anyP = participant as unknown as { phoneNumber?: string; jid?: string; lid?: string };
      const participantDigits = [
        digitsOnly(participant.id),
        digitsOnly(anyP.phoneNumber),
        digitsOnly(anyP.jid),
        digitsOnly(anyP.lid),
      ];
      return developerNumbers.some((num) => participantDigits.includes(num));
    }
  }

  return false;
}
