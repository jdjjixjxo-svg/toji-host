import http from "http";
import fs from "fs";
import path from "path";
import { logger } from "./logger";

/**
 * 🎮 خادم صغير اختياري يقدّم صفحة الألعاب (assets/games/index.html) من نفس
 * استضافة البوت — بدون أي استضافة خارجية.
 * يشتغل فقط لو حطيت GAMES_PORT بـ .env (منفذ مفتوح/مخصص لسيرفرك بالاستضافة).
 * بعدها حط GAMES_URL=http://<IP أو الدومين>:<GAMES_PORT>/ فتظهر أزرار «العب الآن».
 * ⚠️ لو الاستضافة ما تفتح منفذ للعامة، استخدم بدله GitHub Pages/Netlify (شوف README).
 */
let started = false;

export function startGameServer(): void {
  const port = Number(process.env.GAMES_PORT || 0);
  if (!port || started) return;
  const file = path.resolve(process.cwd(), "assets", "games", "index.html");
  let html: Buffer;
  try {
    html = fs.readFileSync(file);
  } catch (err) {
    logger.warn("⚠️ ملف الألعاب assets/games/index.html غير موجود — ما بدأ خادم الألعاب.", err);
    return;
  }
  const server = http.createServer((req, res) => {
    const p = (req.url || "/").split("?")[0].split("#")[0];
    if (p === "/" || p === "/index.html" || p === "/index.html" || p === "/game") {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "public, max-age=300" });
      res.end(html);
    } else {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not found");
    }
  });
  server.on("error", (err) => logger.warn(`⚠️ تعذر تشغيل خادم الألعاب على المنفذ ${port}:`, err));
  server.listen(port, "0.0.0.0", () => {
    started = true;
    logger.success(`🎮 خادم الألعاب شغّال على المنفذ ${port} (ضع GAMES_URL=http://<IP>:${port}/ بـ .env)`);
  });
}
