import { GoogleGenAI } from "@google/genai";
import { CommandContext } from "../handlers/types";
import { CONFIG } from "../config/config";
import { sendButtonMessage, sectionButton } from "./interactive";
import { logger } from "./logger";
import { reply } from "./friendUtils";
import { getCharacterImage } from "./characterImage";

/**
 * 🧞 المارد الأزرق — لعبة تخمين شخصية بأسئلة نعم/لا، يديرها Gemini (بدون خدمات Akinator الخارجية
 * لأنها تُحجب كثيرًا من الاستضافات). الحالة بالذاكرة فقط وبسقف صغير.
 */
const MODEL = "gemini-3.1-flash-lite";
const MAX_QUESTIONS = 22;
const IDLE_MS = 20 * 60 * 1000;

interface GenieState {
  player: string;
  history: { q: string; a: string }[];
  pending: string; // آخر سؤال/تخمين عرضه البوت
  mode: "question" | "guess";
  wrongGuesses: string[];
  at: number;
}
const games = new Map<string, GenieState>();

function prune() {
  const now = Date.now();
  for (const [k, g] of games) if (now - g.at > IDLE_MS) games.delete(k);
  while (games.size > 30) games.delete(games.keys().next().value as string);
}

export const ANSWERS: Record<string, string> = {
  مارد_نعم: "نعم",
  مارد_لا: "لا",
  مارد_ربما: "ربما / غالبًا نعم",
  مارد_لا_اعرف: "لا أعرف",
};

function parseJson(text: string): any {
  const clean = text.replace(/```json|```/g, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  return JSON.parse(start >= 0 && end > start ? clean.slice(start, end + 1) : clean);
}

async function askGemini(state: GenieState): Promise<{ type: "question" | "guess"; text: string }> {
  const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
  const n = state.history.length;
  const forceGuess = n >= MAX_QUESTIONS;
  const transcript = state.history.map((h, i) => `${i + 1}. ${h.q} → ${h.a}`).join("\n") || "(لا أسئلة بعد)";
  const prompt = `أنت "المارد الأزرق" في لعبة تخمين شخصيات (مثل أكيناتور). اللاعب يفكر في شخصية مشهورة (حقيقية أو خيالية: أنمي، أفلام، ألعاب، مشاهير).
مهمتك: اطرح سؤالًا واحدًا بالعربية جوابه نعم/لا، وكل سؤال يقلّص الاحتمالات، ثم خمّن الشخصية عندما تكون واثقًا (عادة بعد 8 أسئلة أو أكثر).
الأسئلة والأجوبة حتى الآن:
${transcript}
تخمينات خاطئة سابقة (لا تكررها): ${state.wrongGuesses.join("، ") || "لا يوجد"}
عدد الأسئلة المطروحة: ${n} من ${MAX_QUESTIONS}.
${forceGuess ? "وصلت للحد الأقصى: يجب أن تخمّن الآن." : ""}
أجب بـ JSON فقط بلا أي نص إضافي، بأحد الشكلين:
{"type":"question","text":"السؤال؟"}
{"type":"guess","text":"اسم الشخصية"}`;
  const res = await ai.models.generateContent({ model: MODEL, contents: prompt, config: { responseMimeType: "application/json" } as any });
  const parsed = parseJson((res as any).text || "");
  const type = parsed.type === "guess" || forceGuess ? "guess" : "question";
  const text = String(parsed.text || parsed.name || "").trim();
  if (!text) throw new Error("EMPTY_GENIE_REPLY");
  return { type, text };
}

async function present(ctx: CommandContext, state: GenieState) {
  const n = state.history.length;
  if (state.mode === "question") {
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: `🧞 *المارد الأزرق* — سؤال ${n + 1}\n\n❓ ${state.pending}`,
      quoted: ctx.msg,
      quickButtons: [sectionButton("مارد_نعم", "✅ نعم"), sectionButton("مارد_لا", "❌ لا"), sectionButton("مارد_ربما", "🤔 ربما"), sectionButton("مارد_لا_اعرف", "🤷 لا أعرف")],
      excludeUtilityButtons: true,
      fallbackNote: "أجب بكتابة: .مارد_نعم أو .مارد_لا أو .مارد_ربما أو .مارد_لا_اعرف",
    });
  } else {
    // 🖼️ صورة الشخصية اللي خمّنها المارد (لو تعذّرت الصورة نكمل بالنص فقط)
    const image = await Promise.race([
      getCharacterImage(state.pending).catch(() => null),
      new Promise<null>((r) => setTimeout(() => r(null), 12_000)),
    ]);
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: `🧞 *أظن أن شخصيتك هي:*\n\n✨ *${state.pending}* ✨\n\nهل خمّنت صح؟`,
      image: image || undefined,
      quoted: ctx.msg,
      quickButtons: [sectionButton("مارد_صح", "🎯 صح"), sectionButton("مارد_غلط", "🙅 غلط")],
      excludeUtilityButtons: true,
      fallbackNote: "اكتب: .مارد_صح أو .مارد_غلط",
    });
  }
}

async function advance(ctx: CommandContext, state: GenieState) {
  try {
    const next = await askGemini(state);
    state.mode = next.type;
    state.pending = next.text;
    state.at = Date.now();
    await present(ctx, state);
  } catch (err) {
    logger.error("فشل المارد:", err);
    games.delete(ctx.chatId);
    await reply(ctx, "❌ المارد تعب قليلًا (تعذر الاتصال بالذكاء الاصطناعي). حاول لاحقًا بـ .مارد");
  }
}

export async function genieStart(ctx: CommandContext) {
  prune();
  if (!CONFIG.GEMINI_API_KEY) return reply(ctx, "❌ لعبة المارد تحتاج GEMINI_API_KEY بملف .env.");
  const cur = games.get(ctx.chatId);
  if (cur && cur.player !== ctx.senderJid && ctx.args[0] !== "جديد") {
    return reply(ctx, "⚠️ فيه لعبة مارد جارية للاعب ثاني. (لإلغائها اكتب: .مارد جديد)");
  }
  const state: GenieState = { player: ctx.senderJid, history: [], pending: "", mode: "question", wrongGuesses: [], at: Date.now() };
  games.set(ctx.chatId, state);
  await reply(ctx, "🧞 *المارد الأزرق*\nفكّر في شخصية (أنمي، مشاهير، أفلام، ألعاب...) وأنا أخمّنها بالأسئلة!\nجاري التفكير...");
  await advance(ctx, state);
}

export async function genieAnswer(ctx: CommandContext, cmdName: string) {
  const state = games.get(ctx.chatId);
  if (!state) return reply(ctx, "ℹ️ ما فيه لعبة جارية. ابدأ بـ .مارد");
  if (state.player !== ctx.senderJid) return reply(ctx, "🚫 هذي اللعبة للاعب اللي بدأها.");

  if (cmdName === "مارد_صح") {
    games.delete(ctx.chatId);
    return reply(ctx, `🧞🎉 عرفتها في ${state.history.length} سؤال! العب مرة ثانية بـ .مارد`);
  }
  if (cmdName === "مارد_غلط") {
    state.wrongGuesses.push(state.pending);
    if (state.wrongGuesses.length >= 3 || state.history.length >= MAX_QUESTIONS + 3) {
      games.delete(ctx.chatId);
      return reply(ctx, "🧞😔 غلبتني هالمرة! أنت فزت. العب مرة ثانية بـ .مارد");
    }
    await reply(ctx, "🧞 همم... خلّني أفكر أكثر.");
    return advance(ctx, state);
  }
  if (state.mode !== "question") return reply(ctx, "ℹ️ أجب على تخمين المارد بـ .مارد_صح أو .مارد_غلط");
  state.history.push({ q: state.pending, a: ANSWERS[cmdName] || "لا أعرف" });
  await advance(ctx, state);
}
