/**
 * 🆕 (طلب صريح) — كل ما عضو يستخدم أي أمر أكثر من 5 مرات (بنفس المجموعة)،
 * يوصله رد عشوائي من هذي القائمة بعد رد الأمر نفسه مباشرة. ما تشتغل إلا
 * داخل المجموعات (زي ما طُلب بالضبط) — الخاص ما يتأثر إطلاقًا.
 */

const NAG_REPLIES: string[] = [
  "خلاصصص ولك خلاصصصصص ما عندك حياه انت سيبني فحالي",
  "تشرب شاي؟",
  "احبك 🧸",
];

// عداد بالذاكرة فقط (يصفر مع أي إعادة تشغيل للبوت) — مفتاحه:
// "chatId:senderJid:commandName"
const usageCounts = new Map<string, number>();

/**
 * يزيد عداد استخدام أمر معيّن لعضو معيّن بمجموعة معيّنة، ويرجع رد عشوائي
 * لو صار العدد أكثر من 5 (6، 7، 8...، كل استخدام بعد الخامس)، أو undefined
 * لو لسا ما وصل الحد أو لو المحادثة ليست مجموعة.
 */
export function checkCommandNag(
  isGroup: boolean,
  chatId: string,
  senderJid: string,
  commandName: string
): string | undefined {
  if (!isGroup) return undefined;

  const key = `${chatId}:${senderJid}:${commandName}`;
  const count = (usageCounts.get(key) || 0) + 1;
  usageCounts.set(key, count);

  if (count > 5) {
    return NAG_REPLIES[Math.floor(Math.random() * NAG_REPLIES.length)];
  }
  return undefined;
}
