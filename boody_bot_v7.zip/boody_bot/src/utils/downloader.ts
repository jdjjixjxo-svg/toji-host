import https from "https";
import { withTimeout } from "./timeout";
import { logger } from "./logger";
// 🆕 (طلب صريح: "حل نهائي" لـ.ايديت) — مصدر يوتيوب بديل، راجع
// searchYouTubeEdit/downloadYouTubeBuffer بالأسفل.
import ytSearch from "yt-search";
import ytdl from "@distube/ytdl-core";

/**
 * أداة تنزيل الفيديوهات (تيك توك / انستقرام).
 *
 * ⚠️ ملاحظة مهمة (بنفس روح تعليق tts.ts): هذه خدمات خارجية غير رسمية
 * (tikwm لتيك توك، وقراءة meta tags العامة لانستقرام) وقد تتغير أو
 * تتوقف دون إشعار. لذلك كل دالة هنا مصممة لترمي خطأ واضح بدل تعطيل
 * البوت، والأمر نفسه (.تحميل) يمسك كل الأخطاء ويعرض رسالة مفهومة
 * للمستخدم بدل أي كراش.
 */

/**
 * 🔧 إصلاح استمرار HTTP 403 رغم ضبط الـ User-Agent والـ Referer سابقًا:
 * أغلب استضافات مجانية/مشتركة (Katabump وغيرها) تشارك مجموعة محدودة من
 * عناوين IP بين كل مستخدميها — ولو أي مستخدم آخر على نفس الاستضافة أساء
 * استخدام tikwm من قبل، تحظر tikwm عنوان IP كامل بغض النظر عن الهيدرز
 * المُرسلة (لا علاقة له بجهازك أو حسابك). الحل العملي: تمرير الطلب عبر
 * وسيط (proxy) عام مجاني كخطة بديلة تلقائية فقط عند فشل الطلب المباشر —
 * فيصير الطلب صادر من IP الوسيط لا IP الاستضافة، بدون أي إعداد إضافي
 * مطلوب من المطور ولا أي مفتاح API.
 */
const CORS_PROXY = "https://api.allorigins.win/raw?url=";
function viaProxy(url: string): string {
  return `${CORS_PROXY}${encodeURIComponent(url)}`;
}

// 🆕 (طلب صريح: "حل نهائي" لـ.ايديت) — السبب الأرجح لتكرار فشل tikwm
// تحديدًا من استضافات مثل Katabump: هذي الخدمات تحظر/تقيّد IPs مراكز
// البيانات (datacenter IPs) تحديدًا لمنع إساءة الاستخدام — نفس الاستضافة،
// نفس الـIP يُستخدم لآلاف المستخدمين، فتصنّفه tikwm كبوت. وسيط CORS
// وحيد قد يكون هو نفسه محظور (مستخدم بكثافة من مطورين كثر). الحل
// الواقعي الوحيد بدون مفتاح API مدفوع: تدوير أكثر من وسيط مختلف — لو
// وحد محظور، الثاني غالبًا مو محظور بعد (IP مختلف تمامًا).
const CORS_PROXY_FALLBACKS = [
  "https://api.allorigins.win/raw?url=",
  "https://corsproxy.io/?url=",
  "https://api.codetabs.com/v1/proxy?quest=",
];
function* proxyUrls(url: string): Generator<string> {
  for (const proxy of CORS_PROXY_FALLBACKS) {
    yield `${proxy}${encodeURIComponent(url)}`;
  }
}

export type Platform = "tiktok" | "instagram" | "direct";

export interface ResolvedVideo {
  videoUrl: string;
  platform: Platform;
}

/**
 * يتعرف على المنصة من الرابط. تيك توك وانستقرام معروفين بالاسم، وأي رابط
 * ثاني (مو منهم) يُعتبر "direct" — أي رابط فيديو عام (رابط مباشر لملف
 * فيديو، أو صفحة نقدر نطلع منها og:video عام) بدل رفضه فورًا، تنفيذًا
 * لطلب "يقبل أي رابط فيديو". هذا لا يشمل يوتيوب/فيسبوك/تويتر بشكل كامل
 * (تلك تحتاج مكتبة استخراج مخصصة لكل منصة، مو مجرد og:video عام) — راجع
 * resolveDirect() بالأسفل لتفاصيل الحدود الحقيقية لهذا الدعم العام.
 */
export function detectPlatform(url: string): Platform | null {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    if (/(^|\.)tiktok\.com$/.test(host) || host === "vm.tiktok.com" || host === "vt.tiktok.com") {
      return "tiktok";
    }
    if (/(^|\.)instagram\.com$/.test(host) || host === "instagr.am") {
      return "instagram";
    }
    // 🆕 "أي رابط فيديو": رابط مباشر لملف فيديو (امتداد معروف)، أو أي
    // صفحة https عامة أخرى — نحاول resolveDirect() قبل الاستسلام.
    if (/^https?:$/i.test(new URL(url).protocol)) {
      return "direct";
    }
    return null;
  } catch {
    return null;
  }
}

// مهلة الطلبات الصغيرة (JSON/HTML) — بدونها أي خدمة معلّقة تجمّد الأمر كله
const NET_TIMEOUT_MS = 10_000;

/** يشغّل كل المحاولات بالتوازي ويرجع أول نجاح (أسرع بكثير من التجربة واحدة بعد الثانية) */
function firstSuccess<T>(tasks: Array<() => Promise<T>>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let pending = tasks.length;
    if (!pending) return reject(new Error("NO_TASKS"));
    const errs: any[] = [];
    for (const task of tasks) {
      task()
        .then(resolve)
        .catch((e) => {
          errs.push(e);
          if (--pending === 0) {
            reject(errs.find((x) => x?.message === "NOT_A_VIDEO") || errs[0]);
          }
        });
    }
  });
}

function fetchJson(url: string, depth = 0): Promise<any> {
  return new Promise((resolve, reject) => {
    if (depth > 5) return reject(new Error("TOO_MANY_REDIRECTS"));
    const req = https
      .get(
        url,
        {
          // 🔧 هذا هو السبب الحقيقي وراء استمرار فشل .تحميل/.تحميل_صوت حتى بعد
          // إصلاح تحميل الفيديو النهائي من الـ CDN: هذا الطلب (لسيرفر tikwm
          // نفسه لجلب رابط الفيديو) كان لسا يستخدم User-Agent وهمي واضح
          // "MrBot/1.0" — وسيرفرات زي tikwm عندها حماية بسيطة ضد أي طلب لا
          // يشبه متصفح حقيقي وترفضه مباشرة (403) حتى قبل ما نوصل لمرحلة تحميل
          // الفيديو الفعلي أصلًا. نستخدم نفس الـ User-Agent الكامل زي باقي
          // الدوال + Referer من tikwm نفسه.
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            Referer: "https://www.tikwm.com/",
          },
        },
        (res) => {
          // 🔧 إصلاح (سبب فعلي محتمل لـ ".ايديت ما يشتغل"): هذي الدالة كانت
          // الوحيدة بالملف اللي ما تتبع أي تحويل (3xx) — بعكس fetchText
          // بالأسفل اللي تتبعه من زمان. لو رجع tikwm (أو أي API JSON ثاني)
          // تحويلًا بدل الرد المباشر، كانت النتيجة JSON.parse لصفحة فاضية
          // أو خطأ صامت بدل المتابعة للرابط الصحيح.
          if (
            res.statusCode &&
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            fetchJson(new URL(res.headers.location, url).toString(), depth + 1).then(resolve).catch(reject);
            return;
          }
          if (res.statusCode !== 200) {
            res.resume();
            reject(new Error(`HTTP ${res.statusCode}`));
            return;
          }
          const chunks: Buffer[] = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            try {
              resolve(JSON.parse(Buffer.concat(chunks).toString("utf-8")));
            } catch (err) {
              reject(err);
            }
          });
          res.on("error", reject);
        }
      )
      .on("error", reject);
    req.setTimeout(NET_TIMEOUT_MS, () => req.destroy(new Error("TIMEOUT")));
  });
}

function fetchText(url: string, depth = 0): Promise<string> {
  return new Promise((resolve, reject) => {
    if (depth > 5) return reject(new Error("TOO_MANY_REDIRECTS"));
    const req = https
      .get(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
          },
        },
        (res) => {
          if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            resolve(fetchText(new URL(res.headers.location, url).toString(), depth + 1));
            return;
          }
          if (res.statusCode !== 200) {
            res.resume();
            reject(new Error(`HTTP ${res.statusCode}`));
            return;
          }
          const chunks: Buffer[] = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
          res.on("error", reject);
        }
      )
      .on("error", reject);
    req.setTimeout(NET_TIMEOUT_MS, () => req.destroy(new Error("TIMEOUT")));
  });
}

/** يستخرج رابط الفيديو من استجابة tikwm، أو يرمي خطأ واضح حسب السبب */
function extractTikwmVideo(data: any): string {
  // tikwm يرجّع {code, msg, data}. code !== 0 يعني خطأ صريح من عندهم
  // (مو مجرد فيديو غير موجود) — نظهر رسالتهم الحقيقية بدل تخمين السبب.
  if (data && typeof data.code === "number" && data.code !== 0) {
    throw new Error(`TIKWM: ${data.msg || "خطأ غير معروف من المزوّد"}`);
  }
  const info = data?.data;
  const videoUrl: string | undefined = info?.hdplay || info?.play;
  if (!videoUrl) {
    // لو فيه صور فقط (سلايدشو) بدون فيديو، tikwm يرجع images[] بدل play
    if (!info?.duration && Array.isArray(info?.images) && info.images.length) {
      throw new Error("NOT_A_VIDEO");
    }
    throw new Error("NOT_FOUND");
  }
  return videoUrl.startsWith("http") ? videoUrl : `https://www.tikwm.com${videoUrl}`;
}

/** تيك توك عبر tikwm (بدون علامة مائية، بأفضل جودة متاحة)، مع إعادة محاولة عبر وسيط ومزوّد بديل احتياطي */
async function resolveTikTok(url: string): Promise<ResolvedVideo> {
  const api = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`;
  const viaTikwm = (target: string) => async (): Promise<ResolvedVideo> => ({
    videoUrl: extractTikwmVideo(await fetchJson(target)),
    platform: "tiktok",
  });
  // مباشر + كل الوسطاء + المزوّد البديل — كلها بالتوازي، أول نجاح يفوز
  return firstSuccess<ResolvedVideo>([
    viaTikwm(api),
    ...Array.from(proxyUrls(api)).map((p) => viaTikwm(p)),
    () => resolveTikTokFallback(url),
    () => resolveTikTokFallback(url, true),
  ]);
}

/** مزوّد بديل احتياطي لتيك توك (يُستخدم فقط لو tikwm حظر الطلب) */
async function resolveTikTokFallback(url: string, proxied = false): Promise<ResolvedVideo> {
  const api = `https://tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`;
  const data = await fetchJson(proxied ? viaProxy(api) : api);
  const videoUrl: string | undefined =
    data?.video?.noWatermark || data?.video?.wm || data?.video?.playAddr || data?.result?.video?.noWatermark;
  if (!videoUrl) throw new Error("NOT_FOUND");
  return { videoUrl, platform: "tiktok" };
}

/** انستقرام عبر قراءة وسوم og:video العامة لصفحة المنشور (بدون تسجيل دخول) */
async function resolveInstagram(url: string): Promise<ResolvedVideo> {
  const html = await fetchText(url);
  const videoMatch = html.match(/<meta property="og:video" content="([^"]+)"/i);
  if (videoMatch) {
    return { videoUrl: videoMatch[1].replace(/&amp;/g, "&"), platform: "instagram" };
  }

  // 🔧 إصلاح ("ما يقبل تحميل من انستا"): صفحة المنشور العادية (خصوصًا
  // الـ Reels، الشكل الأغلب اليوم) غالبًا ما ترجع بدون og:video إطلاقًا
  // لطلب بدون تسجيل دخول (انستقرام تعرض هيكل تطبيق فاضي يحتاج JavaScript
  // لعرض المحتوى الفعلي). نجرب endpoint الـ"embed" العام (لا يحتاج تسجيل
  // دخول للمحتوى العام، ومصمم أصلًا للعرض بمواقع خارجية) اللي غالبًا لسه
  // يرجع HTML يحتوي رابط الفيديو صراحة كنص "video_url":"...".
  // ⚠️ best-effort غير مضمون 100% (انستقرام تغيّر بنيتها بدون إشعار،
  // ولا يوجد اتصال إنترنت وقت كتابة هذا الإصلاح للتأكد الفعلي) — لو
  // استمرت المشكلة أرسل لنا رابط مثال فشل معه لنراجعه تحديدًا.
  const embedUrl = url.replace(/\/?(\?.*)?$/, "/embed/captioned/$1");
  try {
    const embedHtml = await fetchText(embedUrl);
    const jsonMatch = embedHtml.match(/"video_url":"([^"]+)"/);
    if (jsonMatch) {
      const videoUrl = jsonMatch[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/");
      return { videoUrl, platform: "instagram" };
    }
    if (/<meta property="og:image"/i.test(embedHtml) && !/video/i.test(embedHtml)) {
      throw new Error("NOT_A_VIDEO");
    }
  } catch (err: any) {
    if (err?.message === "NOT_A_VIDEO") throw err;
    /* نكمل لرسالة NOT_FOUND الموحّدة بالأسفل بدل ما نرمي خطأ الشبكة الداخلي كما هو */
  }

  if (/<meta property="og:image"/i.test(html)) {
    throw new Error("NOT_A_VIDEO");
  }
  throw new Error("NOT_FOUND");
}

/**
 * 🆕 ("أي رابط فيديو"): رابط عام غير تيك توك/انستقرام. حدّه الحقيقي:
 * - لو الرابط نفسه ملف فيديو مباشر (امتداد mp4/mov/webm/mkv...) → يُستخدم
 *   كما هو مباشرة بدون أي معالجة إضافية.
 * - غير ذلك، نحاول قراءة وسم og:video العام من الصفحة (نفس فكرة
 *   انستقرام) — يشتغل مع مواقع كثيرة تدعم Open Graph عادي.
 * ⚠️ هذا لا يشمل يوتيوب/فيسبوك/تويتر إلخ بشكل موثوق — تلك المنصات تشفّر
 * روابط الفيديو الفعلية ولا تضعها بوسم og:video عام، وتحتاج مكتبة
 * استخراج مخصصة لكل منصة (خارج نطاق هذا الإصلاح).
 */
async function resolveDirect(url: string): Promise<ResolvedVideo> {
  if (/\.(mp4|mov|webm|mkv|m4v)(\?|$)/i.test(url)) {
    return { videoUrl: url, platform: "direct" };
  }
  const html = await fetchText(url);
  const videoMatch = html.match(/<meta property="og:video(?::secure_url)?" content="([^"]+)"/i);
  if (!videoMatch) throw new Error("NOT_FOUND");
  return { videoUrl: videoMatch[1].replace(/&amp;/g, "&"), platform: "direct" };
}

export async function resolveVideo(url: string, platform: Platform): Promise<ResolvedVideo> {
  if (platform === "tiktok") return resolveTikTok(url);
  if (platform === "instagram") return resolveInstagram(url);
  return resolveDirect(url);
}

/**
 * 🆕 (بند 7 من الطلب) — .ايديت <نص>
 * يبحث بتيك توك عن فيديوهات "edit/تصميم" بالكلمة المعطاة عبر endpoint
 * البحث الخاص بـ tikwm (نفس المزوّد المستخدم أصلًا بـ.تحميل، غير رسمي
 * أيضًا) ويرجع رابط فيديو واحد عشوائي من النتائج بدون علامة مائية.
 *
 * لو ما كتب المستخدم نص، الأمر نفسه (commands/tools/edit.ts) يبحث بكلمة
 * عشوائية من قائمة تصاميم شائعة (edit / amv / تصميم) بدل ما يفشل.
 *
 * ⚠️ best-effort، لم يُختبر فعليًا (بلا اتصال إنترنت وقت الكتابة).
 */
/**
 * 🔧 (سبب "يجيب فيديو تافه ما له علاقة بالنص" — سواء كتبت شخصية أنمي أو
 * اسم علم مشهور): الكود القديم كان يتحول تلقائيًا لبحث DuckDuckGo/Bing
 * العام (كشط صفحة نتائج بحث) في أي حالة فشل أو فراغ من tikwm — وهذا
 * البحث العام يمسك *أي* رابط tiktok.com ظاهر بصفحة النتائج (روابط تنقّل،
 * إعلانات، "بحث مشابه"...) بغض النظر عن تطابقه الفعلي مع الكلمة المطلوبة،
 * فيرجع فيديو عشوائي لا علاقة له بالنص إطلاقًا. الحل: نعتمد فقط على بحث
 * tikwm الحقيقي (API بحث فعلي بالكلمة نفسها)، ولو فشل أو رجع فاضي نرجع
 * null صراحة (رسالة "ما لقيت" واضحة) بدل فيديو عشوائي غير مرتبط.
 */
async function tikwmSearch(keyword: string): Promise<any[]> {
  const api = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(keyword)}&count=15`;
  let data: any;
  try {
    data = await firstSuccess<any>([
      () => fetchJson(api),
      ...Array.from(proxyUrls(api)).map((p) => () => fetchJson(p)),
    ]);
  } catch (err: any) {
    throw new Error(`TIKWM_UNREACHABLE: فشلت كل المحاولات (${err?.message || err})`);
  }
  return data?.data?.videos || data?.data || [];
}

/**
 * 🔧 (طلب صريح: ".ايديت يقول ما لقيت رغم إن الشي موجود فعليًا — وسّع
 * البحث بدل الاستسلام من أول نتيجة فارغة") — بدون إعادة نفس مشكلة
 * الجولة اللي قبلها (فيديو عشوائي غير مرتبط عبر بحث محركات عامة)، هذا
 * التحسين يبقى محصورًا ببحث tikwm الحقيقي بالكلمة، بس بمحاولتين:
 * 1) العبارة كاملة كما كتبها المستخدم (بعد تنظيف مسافات/تشكيل).
 * 2) لو رجعت فاضية وفيها أكثر من كلمة، نعيد المحاولة بأول كلمة بس
 *    (بحث أوسع، مثلًا "ون بيس نهاية" → "ون بيس") — لسه بحث حقيقي
 *    بالكلمة نفسها، مو فيديو عشوائي غير مرتبط.
 *
 * 🔧 ملاحظة عن الإصلاح أعلاه بـtikwmSearch: هذي الدالة الآن ما تمسك
 * أخطاء "الخدمة متعطلة" (TIKWM_UNREACHABLE) وتحوّلها لـnull بصمت — تخليها
 * تنفلت لـ.ايديت.ts عشان يبلّغ المطور بالسبب الحقيقي بدل تخمين "ما فيه
 * نتيجة" في كل مرة.
 */
export async function searchTikTokVideo(keyword: string): Promise<ResolvedVideo | null> {
  const normalized = keyword.replace(/[\u064B-\u065F\u0670]/g, "").trim().replace(/\s+/g, " ");
  if (!normalized) return null;

  let list = await tikwmSearch(normalized);

  if (!list.length) {
    const words = normalized.split(" ");
    if (words.length > 1) {
      list = await tikwmSearch(words[0]);
    }
  }

  if (!list.length) return null;
  const pick = list[Math.floor(Math.random() * list.length)];
  const videoUrl: string | undefined = pick?.play || pick?.wmplay || pick?.hdplay;
  if (!videoUrl) return null;
  // روابط tikwm النسبية تبدأ بـ "/" أحيانًا — نكملها لرابط كامل
  const full = videoUrl.startsWith("http") ? videoUrl : `https://www.tikwm.com${videoUrl}`;
  return { videoUrl: full, platform: "tiktok" };
}


/**
 * ينزّل الفيديو كـ Buffer مع تتبع نسبة التقدم الحقيقية (من Content-Length).
 * onProgress يُستدعى بنسبة من 0 إلى 100 (مو أكثر من مرة كل ~500ms لتجنب
 * تعديل رسالة واتساب بمعدل مبالغ فيه، لأن واتساب يحدد Rate-limit للتعديل).
 */
export async function downloadBuffer(
  url: string,
  onProgress: (percent: number) => void,
  platform?: Platform
): Promise<Buffer> {
  try {
    return await downloadBufferOnce(url, onProgress, platform);
  } catch (err: any) {
    // 🔧 نفس منطق resolveTikTok أعلاه: لو التحميل المباشر لبيانات الفيديو
    // نفسها (بعد ما حصلنا على رابط CDN صحيح) فشل بـ 403 (حظر IP
    // الاستضافة)، نعيد المحاولة عبر كل وسيط بالقائمة بالترتيب (نفس تحسين
    // .ايديت — وسيط واحد قد يكون هو نفسه محظور).
    if (err?.message === "TIMEOUT") throw err;
    try {
      return await firstSuccess<Buffer>(
        Array.from(proxyUrls(url)).map((proxied) => () => downloadBufferOnce(proxied, onProgress, platform))
      );
    } catch {
      throw err;
    }
  }
}

function downloadBufferOnce(
  url: string,
  onProgress: (percent: number) => void,
  platform?: Platform
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    // 🔧 إصلاح HTTP 403: كنا نرسل User-Agent وهمي "MrBot/1.0" عند تحميل
    // الفيديو الفعلي من سيرفرات tikwm/instagram (CDN)، وهذي السيرفرات
    // ترفض أي طلب ما يشبه متصفح حقيقي وترجع 403. الحين نستخدم نفس
    // الـ User-Agent الكامل المستخدم أصلًا بـ fetchText، مع إضافة Referer
    // مناسب للمنصة (تيك توك يطلب Referer من tikwm نفسه، وانستقرام يطلب
    // Referer من instagram.com) لأن أغلب الـ CDN تتحقق من الـ Referer.
    const referer =
      platform === "tiktok"
        ? "https://www.tikwm.com/"
        : platform === "instagram"
        ? "https://www.instagram.com/"
        : (() => {
            try {
              return new URL(url).origin + "/";
            } catch {
              return undefined;
            }
          })();

    const request = https.get(
      url,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
          ...(referer ? { Referer: referer } : {}),
        },
      },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          downloadBuffer(res.headers.location, onProgress, platform).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode !== 200) {
          reject(new Error(`HTTP ${res.statusCode}`));
          return;
        }

        const total = Number(res.headers["content-length"] || 0);
        let received = 0;
        let lastEmit = 0;
        // 🔧 إصلاح #1 ("الخط ما يتحرك"): كانت هذي القيمة تُقرأ من
        // (res as any)._lastEmitTs بدون تهيئة أول قيمة أبدًا — أول عملية
        // طرح كانت Date.now() - undefined = NaN، وNaN > 900 دائمًا false،
        // فيتأخر أول تحديث فعلي للنسبة لحد ما توصل 10% من تلقاء نفسها.
        let lastEmitTs = Date.now();
        const chunks: Buffer[] = [];

        // 🔧 إصلاح #2 (السبب الأهم غالبًا لـ"ما يتحرك إطلاقًا"): كثير من
        // خوادم الفيديو (خصوصًا عبر وسيط CORS الاحتياطي CORS_PROXY أعلاه)
        // ما ترسل هيدر Content-Length إطلاقًا (Transfer-Encoding: chunked
        // بدون طول معروف مسبقًا) — فـ"total" يبقى 0 والشرط "if (total > 0)"
        // بالأسفل ما يشتغل ولا مرة واحدة طول التحميل، فتبقى الرسالة عالقة
        // على 0% لين النهاية فجأة. نضيف هنا محاكاة تقدم قائمة على الوقت
        // (تزيد تدريجيًا وتتوقف عند 90% لين يخلص التحميل فعليًا) تشتغل
        // فقط لما نكتشف عدم توفر Content-Length، فتبقى الرسالة "حية"
        // ومتحركة دائمًا بدل ما تجمد.
        let fakeProgressTimer: NodeJS.Timeout | null = null;
        if (!total) {
          let fakePercent = 0;
          fakeProgressTimer = setInterval(() => {
            fakePercent = Math.min(90, fakePercent + 7);
            onProgress(fakePercent);
          }, 700);
        }

        res.on("data", (chunk: Buffer) => {
          chunks.push(chunk);
          received += chunk.length;
          if (total > 0) {
            const percent = Math.min(99, Math.floor((received / total) * 100));
            const now = Date.now();
            if (percent - lastEmit >= 10 || now - lastEmitTs > 900) {
              lastEmit = percent;
              lastEmitTs = now;
              onProgress(percent);
            }
          }
        });

        res.on("end", () => {
          if (fakeProgressTimer) clearInterval(fakeProgressTimer);
          onProgress(100);
          resolve(Buffer.concat(chunks));
        });

        res.on("error", (err) => {
          if (fakeProgressTimer) clearInterval(fakeProgressTimer);
          logger.error("فشل تحميل بيانات الفيديو:", err);
          reject(err);
        });
      }
    );
    request.on("error", reject);
    request.setTimeout(45_000, () => {
      request.destroy(new Error("TIMEOUT"));
    });
  });
}

/**
 * 🆕 (طلب صريح: "حل نهائي" لـ.ايديت) — مصدر ثانٍ كامل مستقل عن tikwm
 * تمامًا: يوتيوب عبر مكتبتين معروفتين وموثقتين (مو مكتبات مجهولة):
 * yt-search (بحث بدون أي مفتاح API) + @distube/ytdl-core (تحميل، نسخة
 * مُتابَعة بنشاط وتصليحات متكررة، أوثق بكثير من ytdl-core الأصلية
 * المتوقفة عن الصيانة). يُستخدم فقط لو فشل tikwm بالكامل (راجع edit.ts) —
 * مو استبدال، إضافة مصدر بديل حقيقي.
 */
/**
 * 🔧 (طلب صريح: ".ايديت يجيب شي غير المطلوب") — كانت تاخذ أول نتيجة بحث
 * من يوتيوب بشكل أعمى، حتى لو كانت فيديو غير مرتبط فعليًا (مقطع أغنية،
 * تجميعة طويلة مصنّفة بشكل خاطئ...). الحين: نطلب عدة نتائج، ونستبعد أي
 * فيديو أطول من 6 دقائق (تصاميم/edits عادة قصيرة؛ أي شي أطول غالبًا مو
 * تصميم فعلي)، ونفضّل أول نتيجة يحتوي عنوانها فعليًا على الكلمة المطلوبة.
 */
export async function searchYouTubeEdit(query: string): Promise<ResolvedVideo | null> {
  const results = await withTimeout(ytSearch(`${query} edit`), 12_000, "YT_SEARCH_TIMEOUT");
  const candidates = (results?.videos || []).filter((v: any) => v.seconds > 0 && v.seconds < 6 * 60);
  if (!candidates.length) return null;

  const normalizedQuery = query.trim().toLowerCase();
  const relevant = candidates.find((v: any) => v.title?.toLowerCase().includes(normalizedQuery));
  const pick = relevant || candidates[0];
  return { videoUrl: pick.url, platform: "direct" };
}

const YT_TIMEOUT_MS = 75_000;
const YT_MAX_BYTES = 60 * 1024 * 1024;

function collectStream(stream: NodeJS.ReadableStream & { destroy?: (e?: Error) => void }): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let total = 0;
  return new Promise<Buffer>((resolve, reject) => {
    const timer = setTimeout(() => {
      stream.destroy?.(new Error("TIMEOUT"));
      reject(new Error("TIMEOUT"));
    }, YT_TIMEOUT_MS);
    const done = (fn: () => void) => {
      clearTimeout(timer);
      fn();
    };
    stream.on("data", (c: Buffer) => {
      total += c.length;
      if (total > YT_MAX_BYTES) {
        stream.destroy?.(new Error("FILE_TOO_LARGE"));
        return done(() => reject(new Error("FILE_TOO_LARGE")));
      }
      chunks.push(c);
    });
    stream.on("end", () => done(() => resolve(Buffer.concat(chunks))));
    stream.on("error", (e: Error) => done(() => reject(e)));
  });
}

export async function downloadYouTubeBuffer(videoUrl: string): Promise<Buffer> {
  return collectStream(ytdl(videoUrl, { quality: "lowest", filter: "videoandaudio" }) as any);
}

export async function downloadYouTubeAudioBuffer(videoUrl: string): Promise<Buffer> {
  return collectStream(ytdl(videoUrl, { quality: "lowestaudio", filter: "audioonly" }) as any);
}
