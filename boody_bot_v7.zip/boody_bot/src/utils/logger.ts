import chalk from "chalk";

const time = () => new Date().toLocaleTimeString("ar-EG");

export const logger = {
  info: (...args: unknown[]) =>
    console.log(chalk.cyan(`[${time()}] ℹ`), ...args),
  success: (...args: unknown[]) =>
    console.log(chalk.green(`[${time()}] ✔`), ...args),
  warn: (...args: unknown[]) =>
    console.log(chalk.yellow(`[${time()}] ⚠`), ...args),
  error: (...args: unknown[]) =>
    console.log(chalk.red(`[${time()}] ✖`), ...args),
  command: (...args: unknown[]) =>
    console.log(chalk.magenta(`[${time()}] ⚡`), ...args),
};
