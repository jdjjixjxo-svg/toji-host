import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { hasWebGames, sendWebGameCard } from "../../utils/webGame";
import { gamesMenuText } from "../../utils/menuTemplates";
import { sendButtonMessage, buildSectionedSelectButton, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { isOwner } from "../../middlewares/permissions";

/**
 * 🎮 .العاب — القسم الوحيد لكل ألعاب البوت (v4):
 *   🌐 ألعاب فورية (تفتح بالمتصفح وتشتغل لحظيًا)  ← تحتاج GAMES_URL
 *   💬 ألعاب بأزرار داخل الشات
 *   🎲 ألعاب كتابية
 * الصفوف تنفّذ أوامرها مباشرة. «.العاب <رقم اللعبة>» يفتح لعبة فورية معيّنة (مثل .العاب snake).
 */
type Row = { command: string; label: string; description: string };

// [id في صفحة الألعاب, أيقونة, اسم, وصف]
const WEB_GAMES: [string, string, string, string][] = [
  ["war", "⚔️", "WAR ZONE 3D", "حرب منظور الشخص الأول — موجات أعداء"],
  ["maze", "🧭", "متاهة 3D", "دوّر على الباب الأخضر بأسرع وقت"],
  ["snake", "🐍", "ثعبان", "كلاسيك بالسحب أو الأسهم"],
  ["g2048", "🔢", "2048", "اجمع الأرقام بالسحب"],
  ["ttt", "❌", "إكس أو", "ضد بوت ذكي"],
  ["dino", "🦖", "Dino", "اقفز فوق الصبار"],
  ["race", "🏎️", "NEON RACE", "سباق لا نهائي"],
  ["coin", "🪙", "COIN FALL", "اجمع العملات وتجنب القنابل"],
  ["target", "🎯", "TARGET", "اختبر سرعتك بالتصويب"],
  ["core", "⚡", "CORE RUSH", "أعلى Combo"],
  ["memory", "🧠", "MEMORY", "لعبة الذاكرة"],
  ["reaction", "💥", "REACTION", "قِس ردة فعلك"],
];

const CHAT_GAMES: Row[] = [
  { command: "مارد", label: "🧞 المارد", description: "يخمّن شخصيتك بالأسئلة ويعرض صورتها" },
  { command: "ثعبان", label: "🐍 ثعبان", description: "ثعبان بالأزرار" },
  { command: "2048", label: "🔢 2048", description: "دمج الأرقام بالأزرار" },
  { command: "إكس_أو", label: "❌ إكس أو", description: "ضد صديق أو البوت" },
  { command: "dino", label: "🦖 Dino Runner", description: "قفز فوق الصبار" },
  { command: "race", label: "🏎️ سباق سيارات", description: "سباق بالأزرار" },
  { command: "kuro", label: "🥷 KURO SLASH", description: "قتال ضد خصم" },
  { command: "عين", label: "👁️ خمن من العين", description: "خمّن شخصية الأنمي من عينها" },
  { command: "احزر", label: "🎭 احزر الشخصية", description: "صورة مموّهة لشخصية أنمي" },
  { command: "حجر_ورقة_مقص", label: "✊ حجر ورقة مقص", description: "لعبة سريعة" },
  { command: "قنبلة", label: "💣 القنبلة", description: "مرّر القنبلة قبل ما تنفجر" },
  { command: "قلوب", label: "💗 قلوب", description: "لعبة القلوب الجماعية" },
];
// تظهر فقط لما الألعاب الفورية غير مفعّلة (وإلا .fps و.متاهة يفتحون النسخة الفورية)
const CHAT_3D_FALLBACK: Row[] = [
  { command: "fps", label: "🔫 FPS", description: "حرب بالصور داخل الشات" },
  { command: "متاهة", label: "🧭 متاهة 3D", description: "متاهة بالصور داخل الشات" },
];
const TEXT_GAMES: Row[] = [
  { command: "المشنقة", label: "🪢 المشنقة", description: "خمّن الكلمة حرف حرف" },
  { command: "كلمة_السر", label: "🔐 كلمة السر", description: "فك الشيفرة" },
  { command: "رقم_سري", label: "🔢 الرقم السري", description: "خمّن الرقم" },
  { command: "سلسلة", label: "🔗 سلسلة الكلمات", description: "كل كلمة تبدأ بآخر حرف" },
  { command: "من_الاسرع", label: "⚡ من الأسرع", description: "أسرع واحد يكتب" },
  { command: "لو_خيروك", label: "🤔 لو خيروك", description: "اختيارات صعبة" },
  { command: "صراحه", label: "🗣️ صراحة", description: "أسئلة صراحة" },
  { command: "مين_اكثر", label: "👑 مين أكثر", description: "من الأكثر في المجموعة؟" },
  { command: "لغز", label: "🧩 لغز", description: "ألغاز للتفكير" },
  { command: "صح_او_خطا", label: "✅ صح أو خطأ", description: "أسئلة سريعة" },
  { command: "رياضيات", label: "➗ رياضيات", description: "تحدّي حسابي" },
  { command: "سباق_الشخصيات", label: "🏁 سباق الشخصيات", description: "سباق ممتع" },
];

function chunk(title: string, rows: Row[]) {
  const out: { title: string; rows: Row[] }[] = [];
  for (let i = 0; i < rows.length; i += 10) {
    out.push({ title: rows.length > 10 ? `${title} ${Math.floor(i / 10) + 1}/${Math.ceil(rows.length / 10)}` : title, rows: rows.slice(i, i + 10) });
  }
  return out;
}

const command: Command = {
  name: "العاب",
  aliases: ["الالعاب", "الألعاب", "ألعاب", "arcade", "اركيد", "games", "العاب_2D", "العاب2D", "games2d", "2d", "العاب_3D", "العاب3D", "games3d", "3d"],
  category: "العاب2D",
  description: "🎮 كل ألعاب البوت بمكان واحد: فورية بالمتصفح + ألعاب بأزرار + ألعاب كتابية",
  permission: "all",
  execute: async (ctx) => {
    const web = hasWebGames();
    const id = (ctx.args[0] || "").trim();

    // فتح لعبة فورية معيّنة: .العاب snake
    const g = WEB_GAMES.find((w) => w[0] === id);
    if (g && web) {
      return sendWebGameCard(ctx.sock, ctx.chatId, ctx.senderJid, {
        title: `${g[1]} *${g[2]}*`,
        blurb: g[3],
        mode: g[0],
        buttonText: "🎮 العب الآن",
      });
    }

    const p = CONFIG.PREFIX;
    const owner = isOwner(ctx.senderJid, ctx.metadata || undefined, ctx.sock);
    const sections = [
      ...(web
        ? chunk(
            "🌐 ألعاب فورية",
            WEB_GAMES.map((w) => ({ command: `العاب ${w[0]}`, label: `${w[1]} ${w[2]}`, description: w[3] }))
          )
        : []),
      ...chunk("💬 ألعاب بأزرار", web ? CHAT_GAMES : [...CHAT_GAMES, ...CHAT_3D_FALLBACK]),
      ...chunk("🎲 ألعاب كتابية", TEXT_GAMES),
    ];

    let text = gamesMenuText({
      instant: web ? WEB_GAMES.length : null,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
    });
    if (!web && owner) {
      text += `\n\n⚙️ (للمطور فقط) الألعاب الفورية غير مفعّلة — ضع GAMES_URL بملف .env (شوف README ← تشغيل الألعاب).`;
    }

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("fun") || undefined,
      extraButtons: [buildSectionedSelectButton("🎮 اختر لعبة", sections)],
      quickButtons: [...navButtons()],
      fallbackNote: `اكتب أمر أي لعبة مباشرة (مثل ${p}إكس_أو)، أو ${p}menu للقائمة الرئيسية`,
    });
  },
};

export default command;
