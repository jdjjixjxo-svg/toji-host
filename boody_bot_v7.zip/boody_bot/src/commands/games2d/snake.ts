import { Command } from "../../handlers/types";
import { snakeManager, Direction } from "../../handlers/snakeManager";
import { renderSnakeImage } from "../../utils/snakeRenderer";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";

const DIRECTION_WORDS: Record<string, Direction> = {
  فوق: "up",
  اعلى: "up",
  أعلى: "up",
  اعلا: "up",
  تحت: "down",
  اسفل: "down",
  أسفل: "down",
  يمين: "right",
  يمينا: "right",
  يسار: "left",
  شمال: "left",
};

/** أزرار الحركة — كل زر عبارة عن أمر كامل (.ثعبان فوق) مسجّل بخريطة الأزرار */
function moveButtons() {
  return [
    sectionButton("ثعبان فوق", "⬆️ فوق"),
    sectionButton("ثعبان يسار", "⬅️ يسار"),
    sectionButton("ثعبان يمين", "➡️ يمين"),
    sectionButton("ثعبان تحت", "⬇️ تحت"),
    sectionButton("ثعبان جديد", "🔁 لعبة جديدة"),
  ];
}

const command: Command = {
  name: "ثعبان",
  aliases: ["سنيك", "snake"],
  category: "العاب2D",
  description: "🐍 لعبة الثعبان الكلاسيكية — صورة حقيقية وأزرار تفاعلية. ابدأ بـ .ثعبان وحرّك بالأزرار",
  permission: "all",
  execute: async (ctx) => {
    const arg = ctx.args[0]?.trim().toLowerCase();

    // ما فيه لعبة شغالة حاليًا، أو المستخدم طلب صراحة بدء وحدة جديدة
    if (!snakeManager.isRunning(ctx.sock as any, ctx.chatId) || arg === "جديد" || arg === "new") {
      const game = snakeManager.start(ctx.sock as any, ctx.chatId);
      const image = await renderSnakeImage(game);
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `🐍 *لعبة الثعبان بدأت!*\n\n🍎 النقاط: ${game.score}\n\n🕹️ حرّك باستخدام الأزرار تحت 👇`,
        image,
        quoted: ctx.msg,
        quickButtons: [...moveButtons(), ...navButtons()],
        fallbackNote: `تعذّر عرض الأزرار على جهازك — حرّك بكتابة: .ثعبان فوق / تحت / يمين / يسار`,
      });
      return;
    }

    if (!arg || !(arg in DIRECTION_WORDS)) {
      const game = snakeManager.get(ctx.sock as any, ctx.chatId)!;
      const image = await renderSnakeImage(game);
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `⚠️ حدد اتجاه صحيح باستخدام الأزرار تحت 👇\n\n🍎 النقاط: ${game.score}`,
        image,
        quoted: ctx.msg,
        quickButtons: [...moveButtons(), ...navButtons()],
      });
      return;
    }

    const dir = DIRECTION_WORDS[arg];
    const game = snakeManager.move(ctx.sock as any, ctx.chatId, dir);
    if (!game) return;

    const image = await renderSnakeImage(game);

    if (game.over) {
      snakeManager.end(ctx.sock as any, ctx.chatId);
      const won = game.snake.length >= game.size * game.size;
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: won
          ? `🏆 *فزت! ملأت الشبكة كلها!*\n\n🍎 النتيجة النهائية: ${game.score}`
          : `💀 *انتهت اللعبة!*\n\n🍎 نتيجتك النهائية: ${game.score}`,
        image,
        quoted: ctx.msg,
        quickButtons: [sectionButton("ثعبان جديد", "🔁 لعبة جديدة"), ...navButtons()],
      });
      return;
    }

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: `🍎 النقاط: ${game.score}`,
      image,
      quoted: ctx.msg,
      quickButtons: [...moveButtons(), ...navButtons()],
    });
  },
};

export default command;
