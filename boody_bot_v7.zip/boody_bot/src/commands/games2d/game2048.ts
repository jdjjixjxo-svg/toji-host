import { Command } from "../../handlers/types";
import { game2048Manager, Direction2048 } from "../../handlers/game2048Manager";
import { renderGame2048Image } from "../../utils/renderer2048";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";

const DIRECTION_WORDS: Record<string, Direction2048> = {
  فوق: "up",
  اعلى: "up",
  أعلى: "up",
  اعلا: "up",
  تحت: "down",
  اسفل: "down",
  أسفل: "down",
  يمين: "right",
  يمينا: "right",
  يسار: "left",
  شمال: "left",
};

/** أزرار الحركة — نفس فكرة أزرار .ثعبان بالضبط (كل زر = أمر كامل مسجّل بخريطة الأزرار) */
function moveButtons() {
  return [
    sectionButton("2048 فوق", "⬆️ فوق"),
    sectionButton("2048 يسار", "⬅️ يسار"),
    sectionButton("2048 يمين", "➡️ يمين"),
    sectionButton("2048 تحت", "⬇️ تحت"),
    sectionButton("2048 جديد", "🔁 لعبة جديدة"),
  ];
}

const command: Command = {
  name: "2048",
  aliases: ["لعبة2048", "٢٠٤٨"],
  category: "العاب2D",
  description: "🔢 لعبة 2048 الكلاسيكية — صورة حقيقية وأزرار تفاعلية. ابدأ بـ .2048 وحرّك بالأزرار",
  permission: "all",
  execute: async (ctx) => {
    const arg = ctx.args[0]?.trim().toLowerCase();

    // ما فيه لعبة شغالة حاليًا، أو المستخدم طلب صراحة بدء وحدة جديدة
    if (!game2048Manager.isRunning(ctx.sock as any, ctx.chatId) || arg === "جديد" || arg === "new") {
      const game = game2048Manager.start(ctx.sock as any, ctx.chatId);
      const image = await renderGame2048Image(game);
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `🔢 *لعبة 2048 بدأت!*\n\n🏆 النقاط: ${game.score}\n\n🕹️ ادمج البلاطات المتشابهة بالأزرار تحت 👇`,
        image,
        quoted: ctx.msg,
        quickButtons: [...moveButtons(), ...navButtons()],
        fallbackNote: `تعذّر عرض الأزرار على جهازك — حرّك بكتابة: .2048 فوق / تحت / يمين / يسار`,
      });
      return;
    }

    if (!arg || !(arg in DIRECTION_WORDS)) {
      const game = game2048Manager.get(ctx.sock as any, ctx.chatId)!;
      const image = await renderGame2048Image(game);
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `⚠️ حدد اتجاه صحيح باستخدام الأزرار تحت 👇\n\n🏆 النقاط: ${game.score}`,
        image,
        quoted: ctx.msg,
        quickButtons: [...moveButtons(), ...navButtons()],
      });
      return;
    }

    const dir = DIRECTION_WORDS[arg];
    const game = game2048Manager.move(ctx.sock as any, ctx.chatId, dir);
    if (!game) return;

    const image = await renderGame2048Image(game);

    if (game.over) {
      game2048Manager.end(ctx.sock as any, ctx.chatId);
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `💀 *انتهت اللعبة! ما فيه حركة ممكنة بعد.*\n\n🏆 نتيجتك النهائية: ${game.score}`,
        image,
        quoted: ctx.msg,
        quickButtons: [sectionButton("2048 جديد", "🔁 لعبة جديدة"), ...navButtons()],
      });
      return;
    }

    // 🏆 بلاطة 2048 تُعلن مرة وحدة فقط (أول مرة توصلها)، واللعب يستمر بعدها عاديًا
    if (game.won && !game.wonAnnounced) {
      game.wonAnnounced = true;
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `🏆 *وصلت لبلاطة 2048! فزت!*\n\n🎮 تقدر تكمل تلعب لنتيجة أعلى.\n\n🏆 النقاط: ${game.score}`,
        image,
        quoted: ctx.msg,
        quickButtons: [...moveButtons(), ...navButtons()],
      });
      return;
    }

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: `🏆 النقاط: ${game.score}`,
      image,
      quoted: ctx.msg,
      quickButtons: [...moveButtons(), ...navButtons()],
    });
  },
};

export default command;
