import { Command } from "../../handlers/types";
import { getEconomy } from "../../database/db";
import { getTargetJid, jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "رصيدي",
  aliases: ["balance", "فلوسي"],
  category: "ادوات",
  description: "عرض رصيدك بالمحفظة والبنك",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const economy = getEconomy(target);
    const total = economy.wallet + economy.bank;

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `ـ𓆩 𝑾𝑨𝑳𝑳𝑬𝑻 𓆪ـ\n` +
          `▸ ـ${jidToMention(target)}ـ\n` +
          `💰 *المحفظة* ـ${economy.wallet}ـ\n` +
          `🏦 *البنك* ـ${economy.bank}ـ\n` +
          `✨ *الإجمالي* ـ${total}ـ\n\n` +
          `⋆｡‧˚ ثروتك تكبر ˚‧｡⋆`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
