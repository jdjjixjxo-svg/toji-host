import { Command } from "../../handlers/types";
import { SHOP_TITLES, findShopItem } from "../../utils/shopCatalog";
import { spendFromWallet, addOwnedTitle, hasOwnedTitle, setEquippedTitle, getEquippedTitle } from "../../database/db";

/**
 * 🆕 ".شراء <رقم أو اسم>" — يشتري لقب من ".متجر" بالعملات. لو ما عنده لقب
 * مفعّل أصلًا، نفعّل هذا تلقائيًا عشان يشوف أثره فورًا بدون خطوة زيادة.
 */
const command: Command = {
  name: "شراء",
  aliases: ["buy"],
  category: "ادوات",
  description: "يشتري لقب من المتجر بالعملات. مثال: .شراء 1  أو  .شراء نجم",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ حدد رقم أو اسم اللقب من «.متجر».\nمثال: .شراء 1" },
        { quoted: ctx.msg }
      );
      return;
    }

    const asIndex = Number(query);
    const item =
      Number.isInteger(asIndex) && asIndex >= 1 && asIndex <= SHOP_TITLES.length
        ? SHOP_TITLES[asIndex - 1]
        : findShopItem(query);

    if (!item) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `❌ ما لقيت هذا العنصر بالمتجر. شوف «.متجر» للقائمة الكاملة.` },
        { quoted: ctx.msg }
      );
      return;
    }

    const userId = ctx.senderJid;
    if (hasOwnedTitle(userId, item.title)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: `✅ عندك هذا اللقب أصلًا: ${item.title}` }, { quoted: ctx.msg });
      return;
    }

    const paid = spendFromWallet(userId, item.price);
    if (!paid) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `❌ رصيدك ما يكفي.\nسعر "${item.title}": 💰 ${item.price.toLocaleString("en-US")}` },
        { quoted: ctx.msg }
      );
      return;
    }

    addOwnedTitle(userId, item.title);
    let extra = "";
    if (!getEquippedTitle(userId)) {
      setEquippedTitle(userId, item.title);
      extra = "\n✨ تم تفعيله تلقائيًا كلقبك الحالي.";
    } else {
      extra = "\nلتفعيله: «.استخدام " + item.title + "»";
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎉 تم الشراء: ${item.title}${extra}\nشوف بطاقتك: «.انا»` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
