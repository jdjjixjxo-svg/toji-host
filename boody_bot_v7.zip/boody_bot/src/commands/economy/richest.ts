import { Command } from "../../handlers/types";
import { getRichest } from "../../database/db";
import { jidToMention, resolveGroupJid } from "../../utils/helpers";

const command: Command = {
  name: "اغنى",
  aliases: ["richest", "أغنى"],
  category: "ادوات",
  description: "أغنى أعضاء المجموعة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 إصلاح (سبب "اغنى تطلع أرصدة صفر لأعضاء أكيد عندهم عملات"):
    // كنا نأخذ p.id الخام من بيانات المجموعة مباشرة — بعض الأعضاء قد
    // يظهر معرّفهم هناك بصيغة "xxxx@lid" المؤقتة، بينما رصيدهم الفعلي
    // بقاعدة البيانات مخزّن تحت رقمهم الحقيقي (JID الذي يُحسم فيه
    // senderJid عبر resolveGroupJid وقت أي أمر آخر ينفّذونه، مثل .يومي
    // أو .تحويل). نفس الشخص = مفتاحان مختلفان، فتبدو محفظته فارغة هنا
    // رغم إنه فعليًا يملك رصيد. نمرر كل معرّف عبر resolveGroupJid أولًا
    // حتى نقرأ بنفس المفتاح اللي كُتب فيه فعليًا.
    const memberIds = (ctx.metadata?.participants || []).map((p) =>
      resolveGroupJid(p.id, ctx.metadata)
    );
    const list = getRichest(memberIds, 10);

    if (!list.length) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "📭 ما فيه أحد جمع عملات لسا بهذي المجموعة." });
      return;
    }

    const medals = ["🏅", "🥈", "🥉"];
    const lines = list.map((entry, i) => {
      const rank = medals[i] || `${i + 1}`;
      return `${rank} ${jidToMention(entry.userId)} ${entry.total}🪙`;
    });
    const groupName = ctx.metadata?.subject || "";

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `ـ,,︵୨(ㅇㅅㅇ)୧︵,,ـ\n` +
          `${lines[0] || ""}\n` +
          `﹌﹌﹌﹌﹌﹌﹌﹌\n` +
          `${lines.slice(1).join("\n")}\n` +
          `*${groupName}*`,
        mentions: list.map((e) => e.userId),
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
