import { Command } from "../../handlers/types";
import { withdrawFromBank } from "../../database/db";
import { toEnglishDigits } from "../../utils/helpers";

const command: Command = {
  name: "سحب",
  aliases: ["withdraw"],
  category: "ادوات",
  description: "سحب مبلغ من البنك إلى المحفظة. مثال: .سحب 100",
  permission: "all",
  execute: async (ctx) => {
    const amount = parseInt(toEnglishDigits(ctx.args[0] || ""), 10);
    if (!amount || amount <= 0) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "✏️ الاستخدام: .سحب <مبلغ>" }, { quoted: ctx.msg });
      return;
    }

    const success = withdrawFromBank(ctx.senderJid, amount);
    if (!success) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رصيدك بالبنك غير كافٍ." }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: `👛 تم سحب ${amount} عملة من البنك للمحفظة.` }, { quoted: ctx.msg });
  },
};

export default command;
