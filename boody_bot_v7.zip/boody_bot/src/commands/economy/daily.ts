import { Command } from "../../handlers/types";
import { claimDaily, dailyCooldownRemaining } from "../../database/db";

function formatRemaining(ms: number): string {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  return `${hours} ساعة و ${minutes} دقيقة`;
}

const command: Command = {
  name: "يومي",
  aliases: ["daily"],
  category: "ادوات",
  description: "استلام الراتب اليومي (200 عملة)",
  permission: "all",
  execute: async (ctx) => {
    const remaining = dailyCooldownRemaining(ctx.senderJid);
    if (remaining > 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `⏳ راتبك اليومي جاهز بعد ${formatRemaining(remaining)}.` },
        { quoted: ctx.msg }
      );
      return;
    }

    const amount = claimDaily(ctx.senderJid);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎁 استلمت راتبك اليومي: +${amount} عملة! تعال بكرة تاخذ غيرها.` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
