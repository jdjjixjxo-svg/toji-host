import { Command } from "../../handlers/types";
import { transferCoins } from "../../database/db";
import {
  getTargetJid,
  jidToMention,
  toEnglishDigits,
} from "../../utils/helpers";

const command: Command = {
  name: "تحويل",
  aliases: ["transfer"],
  category: "ادوات",
  description: "تحويل عملات لشخص آخر. مثال: .تحويل @شخص 100",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || null;
    const amountArg = ctx.args.find((a) => /^[0-9٠-٩]+$/.test(a));
    const amount = amountArg ? parseInt(toEnglishDigits(amountArg), 10) : NaN;

    if (!target || !amount || amount <= 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ الاستخدام: .تحويل @شخص <مبلغ>" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (target === ctx.senderJid) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "🙃 ما تقدر تحول لنفسك!" });
      return;
    }

    const success = transferCoins(ctx.senderJid, target, amount);
    if (!success) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رصيدك بالمحفظة غير كافٍ." });
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `✅ تم تحويل ${amount} عملة من ${jidToMention(ctx.senderJid)} إلى ${jidToMention(target)}`,
        mentions: [ctx.senderJid, target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
