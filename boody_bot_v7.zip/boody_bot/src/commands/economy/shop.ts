import { Command } from "../../handlers/types";
import { SHOP_TITLES } from "../../utils/shopCatalog";
import { getEconomy } from "../../database/db";

/**
 * 🆕 ".متجر" — يعرض قائمة الألقاب القابلة للشراء بالعملات. تجميلي بحت،
 * صفر علاقة بصلاحيات الأدمن أو الطرد (بطلب صريح من صاحب البوت).
 */
const command: Command = {
  name: "متجر",
  aliases: ["shop", "المتجر"],
  category: "ادوات",
  description: "يعرض ألقاب المتجر القابلة للشراء بالعملات — الشراء عبر «.شراء <رقم>»",
  permission: "all",
  execute: async (ctx) => {
    const economy = getEconomy(ctx.senderJid);
    const lines = SHOP_TITLES.map(
      (item, i) => `${i + 1}. ${item.title} — 💰 ${item.price.toLocaleString("en-US")}`
    ).join("\n");

    const text =
      `🛒 *متجر الألقاب*\n\n${lines}\n\n` +
      `رصيدك الحالي: 💰 ${economy.wallet.toLocaleString("en-US")}\n\n` +
      `للشراء: «.شراء <رقم أو اسم اللقب>»\nمثال: .شراء 1\n` +
      `بعد الشراء فعّله ببطاقتك: «.انا» ثم «.استخدام <رقم>»`;

    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
