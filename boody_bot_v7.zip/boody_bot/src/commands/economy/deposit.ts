import { Command } from "../../handlers/types";
import { depositToBank } from "../../database/db";
import { toEnglishDigits } from "../../utils/helpers";

const command: Command = {
  name: "ايداع",
  aliases: ["deposit", "إيداع"],
  category: "ادوات",
  description: "إيداع مبلغ من المحفظة إلى البنك. مثال: .ايداع 100",
  permission: "all",
  execute: async (ctx) => {
    const amount = parseInt(toEnglishDigits(ctx.args[0] || ""), 10);
    if (!amount || amount <= 0) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "✏️ الاستخدام: .ايداع <مبلغ>" }, { quoted: ctx.msg });
      return;
    }

    const success = depositToBank(ctx.senderJid, amount);
    if (!success) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رصيدك بالمحفظة غير كافٍ." }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: `🏛️ تم إيداع ${amount} عملة بالبنك.` }, { quoted: ctx.msg });
  },
};

export default command;
