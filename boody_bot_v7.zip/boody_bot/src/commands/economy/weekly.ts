import { Command } from "../../handlers/types";
import { claimWeekly, weeklyCooldownRemaining } from "../../database/db";

function formatRemaining(ms: number): string {
  const days = Math.floor(ms / 86400000);
  const hours = Math.floor((ms % 86400000) / 3600000);
  return `${days} يوم و ${hours} ساعة`;
}

const command: Command = {
  name: "اسبوعي",
  aliases: ["weekly", "أسبوعي"],
  category: "ادوات",
  description: "استلام الراتب الأسبوعي (1000 عملة)",
  permission: "all",
  execute: async (ctx) => {
    const remaining = weeklyCooldownRemaining(ctx.senderJid);
    if (remaining > 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `⏳ راتبك الأسبوعي جاهز بعد ${formatRemaining(remaining)}.` },
        { quoted: ctx.msg }
      );
      return;
    }

    const amount = claimWeekly(ctx.senderJid);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎁 استلمت راتبك الأسبوعي: +${amount} عملة!` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
