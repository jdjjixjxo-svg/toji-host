import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "بنك",
  aliases: ["bank", "اقتصاد"],
  category: "ادوات",
  description: "عرض قائمة أوامر البنك والنقاط",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;
    const text =
      `╭─❑ 🏦 *البنك والنقاط* ❑─╮\n` +
      `│ 🔁 ${p}تحويل @شخص <مبلغ> — تحويل من محفظتك\n` +
      `│ ⬇️ ${p}ايداع <مبلغ> — من المحفظة للبنك\n` +
      `│ ⬆️ ${p}سحب <مبلغ> — من البنك للمحفظة\n` +
      `╰──────────────────╯\n` +
      `💡 تكسب عملات تلقائيًا من الفوز بأي فعالية ترفيه!`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("tools") || undefined,
      quickButtons: [
        sectionButton("رصيدي", "💳 رصيدي"),
        sectionButton("يومي", "🎁 يومي"),
        sectionButton("اسبوعي", "🎁 اسبوعي"),
        sectionButton("اغنى", "👑 اغنى"),
        ...navButtons(),
      ],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
