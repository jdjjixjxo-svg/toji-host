import { Command } from "../../handlers/types";
import { getOwnedTitles, setEquippedTitle } from "../../database/db";

/**
 * 🆕 ".استخدام <رقم أو اسم>" — يفعّل لقب من ألقابك المملوكة (المعروضة
 * برقم عند ".انا"). ".استخدام الغاء" يشيل اللقب الحالي بدون ما يحذفه من
 * مملوكاتك.
 */
const command: Command = {
  name: "استخدام",
  aliases: ["استخدام_لقب", "use"],
  category: "ادوات",
  description: "يفعّل لقب من ألقابك المملوكة كلقبك الحالي. مثال: .استخدام 1 أو .استخدام الغاء",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    const userId = ctx.senderJid;

    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب رقم اللقب (شوف «.انا») أو اسمه.\nمثال: .استخدام 1\nولإلغاء لقبك الحالي: .استخدام الغاء" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (query === "الغاء" || query === "إلغاء") {
      setEquippedTitle(userId, "");
      await ctx.sock.sendMessage(ctx.chatId, { text: "✅ تم إلغاء تفعيل لقبك الحالي." }, { quoted: ctx.msg });
      return;
    }

    const owned = getOwnedTitles(userId);
    const asIndex = Number(query);
    const title =
      Number.isInteger(asIndex) && asIndex >= 1 && asIndex <= owned.length
        ? owned[asIndex - 1]
        : owned.find((t) => t === query || t.includes(query));

    if (!title) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ ما لقيت هذا اللقب ضمن مملوكاتك. شوف «.انا» للقائمة، أو «.متجر» للشراء." },
        { quoted: ctx.msg }
      );
      return;
    }

    setEquippedTitle(userId, title);
    await ctx.sock.sendMessage(ctx.chatId, { text: `✅ تم تفعيل لقبك: ${title}` }, { quoted: ctx.msg });
  },
};

export default command;
