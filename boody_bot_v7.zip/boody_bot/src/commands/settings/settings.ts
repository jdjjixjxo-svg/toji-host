import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { GroupSettings, setGroupSetting, getGroupSettings } from "../../database/db";
import { settingsMenuText } from "../../utils/menuTemplates";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { normalizeArabicCommand } from "../../utils/arabicNormalize";

const FEATURE_MAP: Record<string, keyof GroupSettings> = {
  حماية: "protection",
  روابط: "antilink",
  سبام: "antispam",
  فعاليات: "events",
  ترحيب: "welcome",
  وداع: "goodbye",
  الردود_التلقائية: "autoReply",
  صلاة: "salawat",
  مواقيت: "prayerTimes",
  استمارة: "formEnabled",
  جهات_اتصال: "antiContact",
};

// 🔧 إصلاح مهم (سبب "كثير أوامر ما تشتغل بسبب الحركات"): كان البحث عن
// اسم الميزة وحالة تشغيل/إيقاف يستخدم مطابقة نصية حرفية 100% — أي حركة
// إعرابية (تشكيل) يضيفها الكيبورد تلقائيًا، أو اختلاف بسيط بشكل الهمزة/
// الألف، كان يخلي البوت يرد "ميزة غير معروفة" رغم إن الاسم صحيح فعليًا.
// الحل: نبني خريطة بحث موحّدة (بعد إزالة التشكيل وتوحيد الحروف عبر
// normalizeArabicCommand) ونقارن فيها بدل المطابقة الحرفية المباشرة.
const NORMALIZED_FEATURE_MAP: Record<string, keyof GroupSettings> = Object.fromEntries(
  Object.entries(FEATURE_MAP).map(([label, key]) => [normalizeArabicCommand(label), key])
);

const command: Command = {
  name: "اعدادات",
  aliases: ["settings", "إعدادات"],
  category: "اعدادات",
  description: "التحكم بتفعيل/إيقاف ميزات المجموعة",
  permission: "admin",
  requireBotAdmin: false,
  // 🆕 مستثناة صراحة من صلاحية "الأدمن الوهمي" (.رفع_ادمن) بناءً على طلب
  // المالك: تشغيل/إيقاف ميزات البوت يبقى لمشرفي واتساب الحقيقيين أو
  // المطور فقط، حتى لو مُنح العضو صلاحية أدمن وهمي بهذي المجموعة.
  allowVirtualAdmin: false,
  groupOnly: true,
  execute: async (ctx) => {
    const [featureArg, stateArg] = ctx.args;

    if (!featureArg) {
      const s = getGroupSettings(ctx.chatId);
      const lines = Object.entries(FEATURE_MAP).map(
        ([label, key]) => `${label} : ${s[key] ? "✅" : "❌"}`
      );
      const text = settingsMenuText(lines);

      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text,
        image: getSectionImageBuffer("settings") || undefined,
        quickButtons: navButtons(),
        fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
      });
      return;
    }

    const key = NORMALIZED_FEATURE_MAP[normalizeArabicCommand(featureArg)];
    if (!key) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `⚠️ ميزة غير معروفة. الميزات المتاحة: ${Object.keys(FEATURE_MAP).join(", ")}`,
      });
      return;
    }

    const normalizedState = normalizeArabicCommand(stateArg || "");
    const onNorm = normalizeArabicCommand("تشغيل");
    const offNorm = normalizeArabicCommand("ايقاف"); // يطابق "إيقاف" أيضًا بعد توحيد الهمزة

    if (normalizedState !== onNorm && normalizedState !== offNorm) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ حدد الحالة: تشغيل أو ايقاف.",
      });
      return;
    }

    const newValue = normalizedState === onNorm;
    setGroupSetting(ctx.chatId, key, newValue);
    await ctx.sock.sendMessage(ctx.chatId, {
      text: `✅ تم ${newValue ? "تفعيل" : "إيقاف"} ميزة "${featureArg}" بنجاح.`,
    });
  },
};

export default command;
