import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

interface GeoResult {
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  country_code: string;
  admin1?: string;
}

const command: Command = {
  name: "حراره",
  aliases: ["حرارة", "weather"], // 🔧 شلنا "طقس" (كانت تتعارض مع أمر .طقس الآخر بحث بالمدينة)
  category: "ادوات",
  description: "يعرض درجة حرارة أهم مدن/محافظات دولة معيّنة. مثال: .حراره العراق",
  permission: "all",
  execute: async (ctx) => {
    const country = ctx.text.trim();
    if (!country) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب اسم الدولة بعد الأمر. مثال: .حراره العراق" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      // 1️⃣ نحدد كود الدولة أول شي عبر البحث الجغرافي
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
        country
      )}&count=1&language=ar&format=json`;
      const geoRes = await fetch(geoUrl);
      const geoData: any = await geoRes.json();
      const countryHit: GeoResult | undefined = geoData?.results?.[0];

      if (!countryHit) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ ما لقيت دولة بهذا الاسم: ${country}` },
          { quoted: ctx.msg }
        );
        return;
      }

      // 2️⃣ نجيب أهم المدن/المحافظات المطابقة لنفس كود الدولة
      const citiesUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
        country
      )}&count=15&language=ar&format=json`;
      const citiesRes = await fetch(citiesUrl);
      const citiesData: any = await citiesRes.json();
      let cities: GeoResult[] = (citiesData?.results || []).filter(
        (r: GeoResult) => r.country_code === countryHit.country_code
      );
      if (!cities.length) cities = [countryHit];
      cities = cities.slice(0, 10);

      // 3️⃣ نجيب حرارة كل مدينة (نتجاهل أي مدينة يفشل جلبها ونكمل الباقي)
      const lines: string[] = [];
      for (const city of cities) {
        try {
          const wUrl = `https://api.open-meteo.com/v1/forecast?latitude=${city.latitude}&longitude=${city.longitude}&current=temperature_2m`;
          const wRes = await fetch(wUrl);
          const wData: any = await wRes.json();
          const temp = wData?.current?.temperature_2m;
          if (typeof temp === "number") {
            lines.push(`  🌡️ ${city.name}${city.admin1 ? ` (${city.admin1})` : ""} — ${temp}°م`);
          }
        } catch {
          /* تجاهل مدينة فشلت وكمل بالباقي */
        }
      }

      if (!lines.length) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "❌ تعذر جلب بيانات الحرارة حاليًا، حاول مرة ثانية." },
          { quoted: ctx.msg }
        );
        return;
      }

      const text = `🌡️ *حرارة أهم مدن/محافظات ${countryHit.country || country}*\n\n${lines.join(
        "\n"
      )}`;
      await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر .حراره:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ صار خطأ أثناء جلب بيانات الحرارة. حاول مرة ثانية." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
