import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getGroupSettings } from "../../database/db";

/**
 * 🆕 .استمارة — يرسل استمارة "عبي البيانات" الجاهزة مع صورة بروفايل مرسل
 * الأمر نفسه.
 *
 * ⚠️ ملاحظة مهمة (بالضبط زي ما طُلب): هذا الأمر لا يعمل إطلاقًا بأي
 * مجموعة إلا لو فعّله أدمن المجموعة تحديدًا أولًا عبر:
 *   .اعدادات استمارة تشغيل
 * (مطفي افتراضيًا بكل مجموعة جديدة — راجع formEnabled بملف db.ts). لو
 * حاول أي شخص استخدامه قبل التفعيل، يوصله تنبيه واضح بدل ما يشتغل الأمر
 * بصمت أو يطلع خطأ غامض.
 */
const command: Command = {
  name: "استمارة",
  aliases: ["ستماره", "form"],
  category: "ادوات",
  description: "إرسال استمارة عبي بياناتك (يحتاج تفعيل من أدمن المجموعة أولًا)",
  permission: "all",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const settings = getGroupSettings(ctx.chatId);

    if (!settings.formEnabled) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ أمر الاستمارة غير مفعّل بهذي المجموعة.\n` +
            `على أدمن المجموعة تفعيله أولًا بأمر: ${CONFIG.PREFIX}اعدادات استمارة تشغيل`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const caption =
      '*عبي الاستمارة*\n' +
      '*الألقاب المأخوذة في بايو الجروب*\n\n' +
      '*⎔━─╌ ⊱╎⌯🌟⌯╎⊰ ╌─━⎔*\n' +
      '*❀┊📃الاســتـقـبـال ➸*\n\n' +
      '*☘︎🔖 اختر شخصية انمي ↫「 」*\n' +
      '*☘︎🎴 من اي انمي ↫「 」*\n' +
      '*☘︎💭 من طرف مين ↫「 」*\n' +
      '*☘︎👥 ولد ام بنت ↫ 「 」*\n\n' +
      '*⎔┄─ ⊱╎⌯🌟⌯╎⊰ ─┄⎔*\n\n' +
      '*①🏷️مسموح لقب من الأنمي، مانغا، مانهوا*\n' +
      '*②❌ لازم تختار لقب على نفس جنسك*\n\n' +
      '*⎔━─╌ ⊱╎⌯🌟⌯╎⊰ ╌─━⎔*\n' +
      `*⸙مـع تـحـ🖊️ـيـات ادارة⤦𝐃𝐊𝐓*\n` +
      `*<اسم النقابه>*`;

    try {
      const url = await ctx.sock.profilePictureUrl(ctx.senderJid, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");
      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: { url }, caption },
        { quoted: ctx.msg }
      );
    } catch {
      // ما فيه صورة بروفايل (أو مخفية بإعدادات الخصوصية) — نرسل النص
      // نفسه لوحده بدل ما يفشل الأمر بالكامل بصمت.
      await ctx.sock.sendMessage(ctx.chatId, { text: caption }, { quoted: ctx.msg });
    }
  },
};

export default command;
