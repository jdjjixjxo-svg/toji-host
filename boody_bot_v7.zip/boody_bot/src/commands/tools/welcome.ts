import { Command } from "../../handlers/types";
import { getTargetJid, getMentionedJids, jidToMention } from "../../utils/helpers";
import { buildWelcomeCard } from "../../utils/welcomeCard";

const command: Command = {
  name: "ترحيب",
  aliases: ["اترحيب", "رحب", "welcome"],
  category: "ادوات",
  description: "يرحب بشخص محدد ببطاقة حلوة وصورة بروفايله. مثال: .ترحيب @شخص [نص ترحيب اختياري]",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 إصلاح: نفس إصلاح باقي أوامر المنشن — target كان JID خام قد يصل
    // بصيغة @lid، وطلب profilePictureUrl تحته لاحقًا يفشل بصمت (يظهر
    // "ما عنده صورة بروفايل" حتى لو عنده فعليًا) لأن واتساب يحتاج الرقم
    // الحقيقي. getTargetJid يوحّده لنفس الصيغة المستخدمة بكل مكان ثاني.
    const target = getTargetJid(ctx.msg, ctx.metadata);

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ حدد شخص: .ترحيب @شخص، أو رد على رسالته." },
        { quoted: ctx.msg }
      );
      return;
    }

    const mentioned = getMentionedJids(ctx.msg);
    const customLine = mentioned.length
      ? ctx.args.slice(1).join(" ").trim() || undefined
      : ctx.args.join(" ").trim() || undefined;

    const groupName = ctx.metadata?.subject || "الكروب";
    const mention = jidToMention(target);
    const card = buildWelcomeCard(groupName, mention, customLine);

    try {
      const url = await ctx.sock.profilePictureUrl(target, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");
      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: { url }, caption: card, mentions: [target] },
        { quoted: ctx.msg }
      );
    } catch {
      // ما عنده صورة بروفايل أو مخفية — نرسل البطاقة كنص عادي بدون صورة
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: card, mentions: [target] },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
