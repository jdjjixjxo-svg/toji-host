import { Command } from "../../handlers/types";
import { searchTikTokVideo, downloadBuffer, searchYouTubeEdit, downloadYouTubeBuffer } from "../../utils/downloader";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * 🆕 (بند 7 من الطلب) — .ايديت <نص>
 * يجيب فيديو "تصميم/edit" لشخصية معينة. لو ما كتب المستخدم نص، يبحث
 * بكلمة عشوائية من قائمة تصاميم شائعة.
 *
 * 🔧 (طلب صريح: "حل نهائي") — تيك توك (tikwm) يفشل بشكل متكرر من
 * استضافات مثل Katabump (حظر IP مراكز البيانات، موثّق بتفصيل بملف
 * downloader.ts). الحين لو فشل تيك توك بالكامل، يجرب يوتيوب تلقائيًا
 * كمصدر بديل حقيقي ثانٍ (yt-search + @distube/ytdl-core) قبل ما يستسلم.
 */
const RANDOM_TOPICS = ["anime edit", "amv edit", "تصميم انمي", "تصميم كرتون", "edit capcut"];

const command: Command = {
  name: "ايديت",
  aliases: ["edit", "تصميم"],
  category: "ادوات",
  description: "أرسل فيديو تصميم/edit لشخصية معينة. مثال: .ايديت لوفي",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text?.trim() || RANDOM_TOPICS[Math.floor(Math.random() * RANDOM_TOPICS.length)];

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🎬 يدور تصميم لـ "${query}"...`,
    });

    let buffer: Buffer | undefined;
    let usedSource = "tiktok";
    const errors: string[] = [];

    try {
      const result = await searchTikTokVideo(query);
      if (result) {
        buffer = await downloadBuffer(result.videoUrl, () => {}, "tiktok");
      }
    } catch (err) {
      errors.push(`tiktok: ${err instanceof Error ? err.message : String(err)}`);
    }

    if (!buffer) {
      try {
        usedSource = "youtube";
        const ytResult = await searchYouTubeEdit(query);
        if (ytResult) {
          buffer = await downloadYouTubeBuffer(ytResult.videoUrl);
        }
      } catch (err) {
        errors.push(`youtube: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    if (!buffer) {
      logger.error("فشل أمر .ايديت من كل المصادر:", errors.join(" | "));
      await notifyOwnerOfError(ctx.sock, ".ايديت", errors.join(" | ") || "NO_RESULTS", {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ ما لقيت تصميم مناسب من أي مصدر حاليًا. جرب اسم/كلمة ثانية.",
      });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, {
      video: buffer,
      caption: `🎬 تصميم: ${query} (${usedSource === "tiktok" ? "تيك توك" : "يوتيوب"})`,
    });
  },
};

export default command;
