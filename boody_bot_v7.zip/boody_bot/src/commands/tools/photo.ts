import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";
import { animatedWebpToMp4 } from "../../utils/ffmpegMedia";

const command: Command = {
  name: "صوره",
  aliases: ["صورة", "photo"],
  category: "ادوات",
  description: "تحويل ملصق (ستيكر) إلى صورة عادية — أو صورة متحركة لو الملصق متحرك (رد عليه بهذا الأمر)",
  permission: "all",
  execute: async (ctx) => {
    const quotedSticker = ctx.quoted?.stickerMessage;
    const directSticker = ctx.msg.message?.stickerMessage;
    const stickerMsg = quotedSticker || directSticker;

    if (!stickerMsg && ctx.text.trim()) {
      // «.صوره لوفي» بدون ملصق → بحث صور بالكلمة (نفس أمر .صور)
      const { commandRegistry } = await import("../../handlers/commandRegistry");
      const search = commandRegistry.get("صور");
      if (search) return search.execute(ctx);
    }

    if (!stickerMsg) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ رد على ملصق بالأمر .صوره لتحويله لصورة.\nأو اكتب كلمة للبحث عن صور: .صور لوفي" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      // 🔧 إصلاح: نبني key صحيح من الرسالة المقتبسة الفعلية (راجع تعليق
      // buildQuotedMessage بالتفصيل) بدل استعارة key رسالة الرد.
      const source = quotedSticker ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;

      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        // 🔧 إصلاح: نفس مشكلة setpp.ts — بدون reuploadRequest يفشل تحميل
        // وسائط رسالة قديمة/مردود عليها بصمت لو انتهت صلاحية رابطها.
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      // 🎞️ ملصق متحرك → نحوّله لفيديو قصير بخاصية gifPlayback فيطلع "صورة
      // متحركة" داخل واتساب (نفس فكرة الملصق المتحرك بس بشكل صورة/GIF).
      if (stickerMsg.isAnimated) {
        const mp4 = await animatedWebpToMp4(buffer);
        await ctx.sock.sendMessage(
          ctx.chatId,
          { video: mp4, gifPlayback: true, caption: "🎞️ صورة متحركة" },
          { quoted: ctx.msg }
        );
        return;
      }

      const image = await sharp(buffer).png().toBuffer();
      await ctx.sock.sendMessage(ctx.chatId, { image }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .صوره:", err);
      await notifyOwnerOfError(ctx.sock, ".صوره", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ فشل تحويل الملصق لصورة. حاول مرة أخرى بملصق آخر." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
