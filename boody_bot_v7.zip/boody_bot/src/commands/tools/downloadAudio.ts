import { Command } from "../../handlers/types";
import { detectPlatform, resolveVideo, downloadBuffer } from "../../utils/downloader";
import { extractAudioFromVideo } from "../../utils/ffmpegMedia";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * 🆕 .تحميل_صوت — نفس أمر .تحميل بالضبط (تيك توك/انستقرام)، لكن يرسل
 * الصوت فقط بدل الفيديو كامل. نستخدم نفس منطق الحل (resolveVideo +
 * downloadBuffer) الموجود أصلًا بـ download.ts، ثم نستخرج الصوت من الفيديو
 * المُحمَّل عبر ffmpeg (extractAudioFromVideo) بدل إرساله كفيديو.
 */

function progressBar(percent: number): string {
  const total = 10;
  const filled = Math.round((percent / 100) * total);
  return "█".repeat(filled) + "░".repeat(total - filled);
}

const command: Command = {
  name: "تحميل_صوت",
  aliases: ["تنزيل_صوت", "downloadaudio", "دلود_صوت"],
  category: "ادوات",
  description: "تحميل الصوت فقط من فيديو تيك توك، انستقرام، أو أي رابط فيديو مباشر. مثال: .تحميل_صوت <رابط>",
  permission: "all",
  execute: async (ctx) => {
    const url = ctx.args[0];

    if (!url || !/^https?:\/\//i.test(url)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ أرسل رابط فيديو صحيح بعد الأمر.\nمثال: .تحميل_صوت https://vt.tiktok.com/xxxxx",
        __skipBrand: true,
      } as any);
      return;
    }

    const platform = detectPlatform(url);
    if (!platform) {
      // 🔧 نفس إصلاح download.ts بالضبط (سبب "الأمر ما يرد أحيانًا"): كان
      // يحذف الرسالة بصمت لو نجح الحذف، ويرسل التفسير فقط لو فشل. الحين
      // نرسل التفسير دائمًا، والحذف يبقى تنظيف اختياري بعده.
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ الرابط غير صالح أو غير مدعوم.",
        __skipBrand: true,
      } as any);
      if (ctx.metadata) {
        try {
          await ctx.sock.sendMessage(ctx.chatId, { delete: ctx.msg.key });
        } catch {
          /* تجاهل بأمان — الحذف تنظيف اختياري، المستخدم أصلًا استلم التفسير أعلاه */
        }
      }
      return;
    }

    const sent = await ctx.sock.sendMessage(ctx.chatId, {
      text: `📥 جاري تحميل الصوت...\n\n${progressBar(0)} 0%`,
      __skipBrand: true,
    } as any);
    const editKey = sent?.key;

    const editText = async (text: string) => {
      if (!editKey) return;
      try {
        await ctx.sock.sendMessage(ctx.chatId, { text, edit: editKey } as any);
      } catch (err) {
        logger.error("فشل تعديل رسالة تحميل الصوت:", err);
      }
    };

    try {
      const resolved = await resolveVideo(url, platform);

      const buffer = await downloadBuffer(
        resolved.videoUrl,
        (percent) => {
          // نخصص أول 70% لتحميل الفيديو الأصلي، والباقي لاستخراج الصوت
          const scaled = Math.round(percent * 0.7);
          editText(`📥 جاري تحميل الصوت...\n\n${progressBar(scaled)} ${scaled}%`);
        },
        platform
      );

      editText(`🎧 جاري استخراج الصوت...\n\n${progressBar(90)} 90%`);
      const audioBuffer = await extractAudioFromVideo(buffer);

      await ctx.sock.sendMessage(ctx.chatId, {
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        ptt: false,
      });

      await editText("✅ تم تحميل الصوت بنجاح");
    } catch (err: any) {
      logger.error("فشل أمر .تحميل_صوت:", err);

      // 🆕 نفس فكرة .تحميل: نبعت تفاصيل الخطأ الحقيقي لرقم المطور بالخاص
      // تلقائيًا بدل ما يبقى محصور بسجلات السيرفر فقط.
      await notifyOwnerOfError(ctx.sock, ".تحميل_صوت", String(err?.message || err), {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });

      const reason =
        err?.message === "NOT_A_VIDEO"
          ? "⚠️ الرابط يشير إلى صورة/منشور غير فيديو، الأمر يدعم الفيديوهات فقط."
          : err?.message === "NOT_FOUND"
          ? "⚠️ الفيديو غير موجود أو محذوف أو الرابط غير صحيح."
          : err?.message === "TIMEOUT"
          ? "⚠️ انتهت المهلة أثناء التحميل، جرّب مرة أخرى."
          : String(err?.message || "").startsWith("FFMPEG_MISSING")
          ? "⚠️ أدوات معالجة الصوت غير مثبتة صح على السيرفر حاليًا، تواصل مع مطور البوت."
          : `❌ تعذر تحميل الصوت حاليًا (${String(err?.message || "خطأ غير معروف")}). جرّب لاحقًا أو برابط آخر.`;

      await editText(reason);
    }
  },
};

export default command;
