import { Command } from "../../handlers/types";
import { getTargetJid, numberToJid } from "../../utils/helpers";
import { downloadImageBuffer } from "../../utils/imageSearch";
import { logger } from "../../utils/logger";
import sharp from "sharp";

/**
 * 🔧 إعادة تصميم (طلب صريح: "بطاقة احترافية فيها صورة البروفايل + رقمه/
 * يوزره، بدل صورة البروفايل الكاملة العادية") — بدل إرسال صورة البروفايل
 * خام، نبني بطاقة: خلفية متدرجة + الصورة داخل دائرة بحد أبيض + الرقم
 * مكتوب تحتها بخط واضح، عبر sharp (يدعم رسم SVG مع تضمين صورة base64
 * ورسترته لصورة نهائية).
 */
function buildCardSvg(imageBase64: string, label: string): string {
  const W = 700;
  const H = 850;
  const circleR = 260;
  const circleCx = W / 2;
  const circleCy = 330;
  const escapedLabel = label
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  return `
    <svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#1f1147"/>
          <stop offset="100%" stop-color="#5b1e91"/>
        </linearGradient>
        <clipPath id="circleClip">
          <circle cx="${circleCx}" cy="${circleCy}" r="${circleR}"/>
        </clipPath>
      </defs>
      <rect width="${W}" height="${H}" fill="url(#bg)"/>
      <circle cx="${circleCx}" cy="${circleCy}" r="${circleR + 12}" fill="none" stroke="#ffffff" stroke-width="8"/>
      <image href="data:image/jpeg;base64,${imageBase64}" x="${circleCx - circleR}" y="${circleCy - circleR}" width="${circleR * 2}" height="${circleR * 2}" clip-path="url(#circleClip)" preserveAspectRatio="xMidYMid slice"/>
      <text x="50%" y="${circleCy + circleR + 110}" text-anchor="middle" font-family="Sans-Serif" font-weight="bold" font-size="52" fill="#ffffff">${escapedLabel}</text>
      <text x="50%" y="${H - 50}" text-anchor="middle" font-family="Sans-Serif" font-size="28" fill="#c9b8ec">『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』</text>
    </svg>
  `;
}

const command: Command = {
  name: "بروفايل",
  aliases: ["profile", "صورة_البروفايل"],
  category: "ادوات",
  description: "بطاقة بروفايل احترافية (صورة + رقمه). مثال: .بروفايل @شخص أو رد على رسالته أو .بروفايل رقم",
  permission: "all",
  execute: async (ctx) => {
    const rawNumber = ctx.args[0]?.replace(/[^0-9]/g, "");
    const target = getTargetJid(ctx.msg, ctx.metadata) || (rawNumber ? numberToJid(rawNumber) : undefined);

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ حدد شخص: .بروفايل @شخص، أو رد على رسالته، أو .بروفايل رقم" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const url = await ctx.sock.profilePictureUrl(target, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");

      const pfpBuffer = await downloadImageBuffer(url);
      // نحوّلها لـJPEG موحّد أول شي (الصورة قد تجي بأي صيغة) قبل تضمينها بالـSVG
      const pfpJpeg = await sharp(pfpBuffer).resize(600, 600, { fit: "cover" }).jpeg({ quality: 90 }).toBuffer();
      const base64 = pfpJpeg.toString("base64");

      const number = target.split("@")[0];
      const svg = buildCardSvg(base64, `+${number}`);

      const cardImage = await sharp(Buffer.from(svg)).jpeg({ quality: 90 }).toBuffer();

      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: cardImage, caption: `🪪 بطاقة بروفايل @${number}`, mentions: [target] },
        { quoted: ctx.msg }
      );
    } catch (err) {
      logger.error("فشل بناء بطاقة البروفايل:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "🙈 ما فيه صورة بروفايل لهالشخص، أو مخفية بإعدادات الخصوصية." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
