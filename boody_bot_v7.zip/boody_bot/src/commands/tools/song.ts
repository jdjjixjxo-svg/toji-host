import ytSearch from "yt-search";
import { withTimeout } from "../../utils/timeout";
import { Command } from "../../handlers/types";
import { searchSong, RANDOM_SONG_TERMS } from "../../utils/musicSearch";
import { downloadBuffer, downloadYouTubeAudioBuffer } from "../../utils/downloader";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * .اغنيه [نص] — بدون نص: أغنية عشوائية. مع نص: يبحث عنه ويرسلها كاملة.
 *
 * 🔧 (طلب صريح: "يبعث الأغنية كاملة") — المصدر الأساسي الآن يوتيوب (نفس
 * البنية التحتية المستخدمة بأمر .يوتيوب أصلًا)، مو معاينة الـ٣٠ ثانية من
 * iTunes. لو تعذر يوتيوب لأي سبب (راجع تعليق downloadYouTubeAudioBuffer)،
 * نرجع تلقائيًا لمعاينة iTunes بدل ما يفشل الأمر بالكامل — ونقول للمستخدم
 * صراحة إنها معاينة لا أغنية كاملة بهالحالة، بدون أي التباس.
 */
const command: Command = {
  name: "اغنيه",
  aliases: ["اغنية", "song", "موسيقى"],
  category: "ادوات",
  description: "أغنية عشوائية بدون نص، أو ابحث باسم أغنية/فنان وترسلها كاملة. مثال: .اغنيه <اسم الأغنية>",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text?.trim() || RANDOM_SONG_TERMS[Math.floor(Math.random() * RANDOM_SONG_TERMS.length)];

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🎵 يدور أغنية لـ "${query}"...`,
      __skipBrand: true,
    } as any);

    // 🥇 المحاولة الأولى: الأغنية كاملة عبر يوتيوب
    try {
      const results = await withTimeout(ytSearch(query), 12_000, "YT_SEARCH_TIMEOUT");
      const video = (results?.videos || []).find((v: any) => v.seconds > 0 && v.seconds < 15 * 60);
      if (video) {
        const buffer = await downloadYouTubeAudioBuffer(video.url);
        await ctx.sock.sendMessage(ctx.chatId, {
          audio: buffer,
          mimetype: "audio/mp4",
          ptt: false, // أغنية كاملة تُرسل كملف صوت عادي بمشغّل، مو كفويس قصير
          fileName: `${video.title}.mp3`,
        });
        await ctx.sock.sendMessage(ctx.chatId, {
          text: `🎧 ${video.title}`,
          __skipBrand: true,
        } as any);
        return;
      }
    } catch (err) {
      logger.warn("⚠️ فشل جلب الأغنية كاملة من يوتيوب، جاري تجربة معاينة iTunes بدلها:", err);
    }

    // 🥈 خطة احتياطية: معاينة ٣٠ ثانية من iTunes (لو يوتيوب رفض/تعذر)
    try {
      const result = await searchSong(query);
      if (!result) {
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "❌ ما لقيت أغنية مناسبة. جرّب اسم أغنية/فنان ثاني.",
          __skipBrand: true,
        } as any);
        return;
      }

      const buffer = await downloadBuffer(result.previewUrl, () => {}, "direct");

      await ctx.sock.sendMessage(ctx.chatId, {
        audio: buffer,
        mimetype: "audio/mp4",
        ptt: true,
      });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🎧 ${result.title} — ${result.artist}\n⚠️ _تعذر جلبها كاملة من يوتيوب، هذي معاينة ٣٠ ثانية بدلها._`,
        __skipBrand: true,
      } as any);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .اغنيه بكل المصادر:", err);
      await notifyOwnerOfError(ctx.sock, ".اغنيه", reason, {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل جلب الأغنية من كل المصادر المتاحة. جرّب مرة ثانية بعد شوي.",
        __skipBrand: true,
      } as any);
    }
  },
};

export default command;
