import sharp from "sharp";
import { Command } from "../../handlers/types";
import { searchImages, downloadImageBuffer } from "../../utils/imageSearch";
import { addStickerPackExif } from "../../utils/stickerExif";
import { sleep, notifyOwnerOfError } from "../../utils/helpers";
import { logger } from "../../utils/logger";
import { CONFIG } from "../../config/config";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

/**
 * 🆕 .ملصقات <بحث> — الأمر اللي كانت بنيته التحتية جاهزة من قبل
 * (utils/imageSearch.ts + utils/stickerExif.ts، وكل تعليقاتها تشير صراحة
 * لأمر ".حزمة") لكن ما فيه أي ملف أمر فعلي يربطها ببعض — هذا هو.
 *
 * ⚠️ توضيح صريح ومهم (نفس تحذير stickerExif.ts): واتساب ما يعرض نافذة
 * "تثبيت الحزمة" التلقائية إلا لملصقات منشأة عبر تطبيقات رسمية/شريكة.
 * اللي نقدر نسويه فعليًا (وهو المعتمد بكل بوتات واتساب غير الرسمية) هو:
 * نرسل عدة ملصقات (رسائل منفصلة، مو ملف واحد ولا مضغوط) لكن كلها مربوطة
 * ببيانات EXIF لنفس "sticker-pack-id" — فتظهر مرتبطة ببعض بمعلومات الملصق
 * عند فتحها بواتساب. هذا أقصى حد ممكن تقنيًا بدون API رسمي لواتساب للأعمال.
 */
const PACK_SIZE = 30; // 🔧 (طلب صريح: ".حزمة لوفي" يجيب 30 ملصق) — كان 8

const command: Command = {
  name: "ملصقات",
  aliases: ["حزمة", "stickerpack"],
  category: "ادوات",
  description: "يرسل حزمة ملصقات (٨) لنفس الكلمة، مربوطة ببيانات حزمة موحّدة. مثال: .ملصقات لوفي",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text?.trim();
    if (!query) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ اكتب الكلمة بعد الأمر.\nمثال: .حزمة لوفي   أو   .ملصقات قطط",
      });
      return;
    }

    // 🆕 (طلب صريح: قيود على المحتوى الجنسي)
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🔎 أجهّز حزمة ملصقات لـ «${query}» — تحتاج نحو نصف دقيقة، انتظر الملصقات...`,
    });

    try {
      const urls = await searchImages(query, 30);
      if (!urls.length) {
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "❌ ما لقيت صور لهالكلمة. جرّب كلمة ثانية (الأفضل كلمة واضحة مثل: لوفي، قطط، ناروتو).",
        });
        return;
      }

      // 🔧 نفس معرّف الحزمة (packId) لكل الملصقات بهذا الطلب تحديدًا —
      // هذا هو اللي يخلي واتساب يربطهم ببعض كـ"حزمة" واحدة بمعلومات الملصق.
      const packId = `pack_${Date.now()}_${ctx.senderJid.split("@")[0]}`;
      const packName = `${query} — ${CONFIG.BOT_NAME}`;

      let sent = 0;
      const failures: string[] = [];

      for (const url of urls) {
        if (sent >= PACK_SIZE) break;
        try {
          const raw = await downloadImageBuffer(url);
          const webp = await sharp(raw)
            .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp()
            .toBuffer();
          const tagged = await addStickerPackExif(webp, packId, packName, CONFIG.BOT_NAME);

          await ctx.sock.sendMessage(ctx.chatId, { sticker: tagged });
          sent++;
          // ⏱️ فاصل بسيط بين كل ملصق وثاني — واتساب يحد معدل الإرسال
          // السريع المتتالي، وهذا يقلل احتمال حظر/تأخير الرسائل.
          await sleep(600);
        } catch (err) {
          const reason = err instanceof Error ? err.message : String(err);
          failures.push(reason);
          // صورة وحدة فشلت (رابط ميت/محمي) — نكمل البقية عادي، مو نوقف كل الحزمة
          continue;
        }
      }

      if (!sent) {
        logger.warn(`⚠️ فشلت كل صور .ملصقات لـ "${query}":`, failures.join(" | "));
        await notifyOwnerOfError(
          ctx.sock,
          ".ملصقات",
          `كل الصور فشلت لـ"${query}": ${failures.slice(0, 3).join(" | ")}`,
          { chatId: ctx.chatId, senderJid: ctx.senderJid }
        );
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "❌ لقيت صور بس ما قدرت أحوّل ولا وحدة لملصق. جرّب كلمة ثانية.",
        });
        return;
      }

      await ctx.sock.sendMessage(ctx.chatId, {
        text: `✅ تم! أرسلت ${sent} ملصق لـ «${query}».\nاضغط على أي ملصق ثم «إضافة للمفضلة» لحفظه.`,
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .ملصقات:", err);
      await notifyOwnerOfError(ctx.sock, ".ملصقات", reason, {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل تجهيز حزمة الملصقات. جرّب مرة ثانية بعد شوي.",
      });
    }
  },
};

export default command;
