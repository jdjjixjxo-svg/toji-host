import sharp from "sharp";
import { Command } from "../../handlers/types";
import { downloadImageBuffer } from "../../utils/imageSearch";
import { logger } from "../../utils/logger";
import { getEconomy, getXp, getOwnedTitles, getEquippedTitle } from "../../database/db";
import { getLevelFromXp, progressBar } from "../../utils/leveling";

/**
 * 🆕 ".انا" — بطاقة بروفايل شخصية (طلب صريح): صورة البروفايل + مستواه
 * (XP) + رصيده + لقبه الحالي (لو عنده)، وتحتها قائمة ألقابه المملوكة
 * ورقم كل وحدة عشان يفعّلها بـ".استخدام <رقم>". هذا أمر شخصي فقط (كل
 * واحد يشوف بطاقته هو، ما فيه استهداف أشخاص ثانين هنا — لهذا مختلف عن
 * أمر ".بروفايل" الموجود أصلًا).
 */
function escapeXml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildMeCardSvg(opts: {
  imageBase64: string | null;
  name: string;
  level: number;
  xpIntoLevel: number;
  xpForNextLevel: number;
  wallet: number;
  equippedTitle: string;
}): string {
  const W = 700;
  const H = 900;
  const circleR = 220;
  const circleCx = W / 2;
  const circleCy = 300;
  const barW = 500;
  const barX = (W - barW) / 2;
  const barY = 640;
  const ratio = opts.xpForNextLevel > 0 ? Math.min(1, opts.xpIntoLevel / opts.xpForNextLevel) : 0;

  const avatar = opts.imageBase64
    ? `<image href="data:image/jpeg;base64,${opts.imageBase64}" x="${circleCx - circleR}" y="${circleCy - circleR}" width="${circleR * 2}" height="${circleR * 2}" clip-path="url(#circleClip)" preserveAspectRatio="xMidYMid slice"/>`
    : `<circle cx="${circleCx}" cy="${circleCy}" r="${circleR}" fill="#3a2564"/><text x="50%" y="${circleCy + 25}" text-anchor="middle" font-size="90" fill="#ffffff">🙂</text>`;

  return `
    <svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#1f1147"/>
          <stop offset="100%" stop-color="#5b1e91"/>
        </linearGradient>
        <clipPath id="circleClip"><circle cx="${circleCx}" cy="${circleCy}" r="${circleR}"/></clipPath>
      </defs>
      <rect width="${W}" height="${H}" fill="url(#bg)"/>
      <circle cx="${circleCx}" cy="${circleCy}" r="${circleR + 10}" fill="none" stroke="#ffffff" stroke-width="7"/>
      ${avatar}

      <text x="50%" y="${circleCy + circleR + 65}" text-anchor="middle" font-family="Sans-Serif" font-weight="bold" font-size="44" fill="#ffffff">${escapeXml(opts.name)}</text>
      <text x="50%" y="${circleCy + circleR + 115}" text-anchor="middle" font-family="Sans-Serif" font-size="34" fill="#ffd166">${escapeXml(opts.equippedTitle || "بدون لقب")}</text>

      <text x="${barX}" y="${barY - 20}" font-family="Sans-Serif" font-size="30" fill="#c9b8ec">Level ${opts.level}</text>
      <text x="${barX + barW}" y="${barY - 20}" text-anchor="end" font-family="Sans-Serif" font-size="26" fill="#c9b8ec">${opts.xpIntoLevel}/${opts.xpForNextLevel} XP</text>
      <rect x="${barX}" y="${barY}" width="${barW}" height="28" rx="14" fill="#2a1a4d"/>
      <rect x="${barX}" y="${barY}" width="${barW * ratio}" height="28" rx="14" fill="#ffd166"/>

      <text x="50%" y="${barY + 90}" text-anchor="middle" font-family="Sans-Serif" font-size="36" fill="#7ef0a0">💰 ${opts.wallet.toLocaleString("en-US")} عملة</text>
      <text x="50%" y="${H - 40}" text-anchor="middle" font-family="Sans-Serif" font-size="26" fill="#c9b8ec">『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』</text>
    </svg>
  `;
}

const command: Command = {
  name: "انا",
  aliases: ["me", "حسابي", "بطاقتي"],
  category: "ادوات",
  description: "بطاقتك الشخصية: صورتك + مستواك + رصيدك + لقبك الحالي وألقابك المملوكة",
  permission: "all",
  execute: async (ctx) => {
    const userId = ctx.senderJid;
    const name = (ctx.msg as any)?.pushName || `+${userId.split("@")[0]}`;

    const economy = getEconomy(userId);
    const xp = getXp(userId);
    const { level, xpIntoLevel, xpForNextLevel } = getLevelFromXp(xp);
    const owned = getOwnedTitles(userId);
    const equipped = getEquippedTitle(userId) || "";

    let imageBase64: string | null = null;
    try {
      const url = await ctx.sock.profilePictureUrl(userId, "image");
      if (url) {
        const buf = await downloadImageBuffer(url);
        const jpeg = await sharp(buf).resize(500, 500, { fit: "cover" }).jpeg({ quality: 90 }).toBuffer();
        imageBase64 = jpeg.toString("base64");
      }
    } catch {
      imageBase64 = null; // ما فيه صورة بروفايل أو مخفية بالخصوصية — نكمل ببطاقة بدون صورة
    }

    try {
      const svg = buildMeCardSvg({
        imageBase64,
        name,
        level,
        xpIntoLevel,
        xpForNextLevel,
        wallet: economy.wallet,
        equippedTitle: equipped,
      });
      const cardImage = await sharp(Buffer.from(svg)).jpeg({ quality: 90 }).toBuffer();

      const titlesList = owned.length
        ? owned.map((t, i) => `${i + 1}. ${t}${t === equipped ? " ✅" : ""}`).join("\n")
        : "ما عندك أي لقب بعد — جرّب «.متجر»";

      const caption =
        `🪪 بطاقتك الشخصية\n\n` +
        `*ألقابك المملوكة:*\n${titlesList}\n\n` +
        (owned.length ? `للتفعيل: «.استخدام <رقم أو اسم اللقب>»\n` : "") +
        `لشراء ألقاب جديدة: «.متجر»`;

      await ctx.sock.sendMessage(ctx.chatId, { image: cardImage, caption }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل بناء بطاقة .انا:", err);
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ صار خطأ ببناء بطاقتك. حاول مرة ثانية." }, { quoted: ctx.msg });
    }
  },
};

export default command;
