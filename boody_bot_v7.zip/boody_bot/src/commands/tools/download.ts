import { Command } from "../../handlers/types";
import { detectPlatform, resolveVideo, downloadBuffer } from "../../utils/downloader";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * 🔧 ملاحظة مهمة: هذا الأمر كان اسمه المقترح ".تنزيل"، لكن هذا الاسم
 * مستخدم أصلًا لأمر إداري مختلف تمامًا (تنزيل مشرف من الإشراف —
 * src/commands/admin/demote.ts). لتفادي التعارض بين الأمرين تم اعتماد
 * اسم ".تحميل" لهذا الأمر (تحميل فيديو)، ووُضع في قسم الأدوات كما طُلب،
 * دون أي تعديل على أمر .تنزيل (تنزيل الإشراف) الموجود مسبقًا.
 */

function progressBar(percent: number): string {
  const total = 10;
  const filled = Math.round((percent / 100) * total);
  return "█".repeat(filled) + "░".repeat(total - filled);
}

const command: Command = {
  name: "تحميل",
  aliases: ["تنزيل_فيديو", "download", "دلود"],
  category: "ادوات",
  description: "تحميل فيديو من تيك توك، انستقرام، أو أي رابط فيديو مباشر. مثال: .تحميل <رابط>",
  permission: "all",
  execute: async (ctx) => {
    const url = ctx.args[0];

    if (!url || !/^https?:\/\//i.test(url)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ أرسل رابط فيديو صحيح بعد الأمر.\nمثال: .تحميل https://vt.tiktok.com/xxxxx",
        __skipBrand: true,
      } as any);
      return;
    }

    const platform = detectPlatform(url);
    if (!platform) {
      // 🔧 إصلاح (سبب "الأمر ما يرد ولا يعطي أي تفسير أحيانًا"): الكود
      // القديم كان يحذف رسالة الرابط الغير مدعوم بصمت تام لو نجح الحذف
      // (البوت مشرف بالمجموعة)، ويرسل رسالة التفسير فقط لو *فشل* الحذف —
      // يعني بأغلب الحالات العادية (بوت مشرف) المستخدم ما يشوف أي رد
      // إطلاقًا ويحس إن الأمر "ما يشتغل". الحين نرسل رسالة التفسير دائمًا
      // بغض النظر عن نجاح/فشل الحذف، والحذف يبقى إضافة تنظيفية اختيارية بس.
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ الرابط غير صالح أو غير مدعوم.",
        __skipBrand: true,
      } as any);
      if (ctx.metadata) {
        try {
          await ctx.sock.sendMessage(ctx.chatId, { delete: ctx.msg.key });
        } catch {
          /* تجاهل بأمان — الحذف تنظيف اختياري، المستخدم أصلًا استلم التفسير أعلاه */
        }
      }
      return;
    }

    // 🔧 (طلب صريح: إزالة الأزرار عن رسالة "جاري التحميل") — البراندنج
    // التلقائي (createBrandedSock) كان يحوّل هذي الرسالة النصية البسيطة
    // تلقائيًا لرسالة أزرار (لأنها {text} بس، بدون __skipBrand). نمنعه هنا.
    const sent = await ctx.sock.sendMessage(ctx.chatId, {
      text: `📥 جاري التحميل...\n\n${progressBar(0)} 0%`,
      __skipBrand: true,
    } as any);
    const editKey = sent?.key;

    const editText = async (text: string) => {
      if (!editKey) return;
      try {
        await ctx.sock.sendMessage(ctx.chatId, { text, edit: editKey } as any);
      } catch (err) {
        logger.error("فشل تعديل رسالة التحميل:", err);
      }
    };

    try {
      const resolved = await resolveVideo(url, platform);

      const buffer = await downloadBuffer(
        resolved.videoUrl,
        (percent) => {
          editText(`📥 جاري التحميل...\n\n${progressBar(percent)} ${percent}%`);
        },
        platform
      );

      await ctx.sock.sendMessage(ctx.chatId, {
        video: buffer,
        mimetype: "video/mp4",
        caption: `✅ تم التحميل بنجاح — ${
          platform === "tiktok" ? "TikTok" : platform === "instagram" ? "Instagram" : "رابط مباشر"
        } 📥`,
      });

      await editText("✅ تم التحميل بنجاح");
    } catch (err: any) {
      logger.error("فشل أمر .تحميل:", err);

      // 🆕 (بسبب "أكثر من مرة يقولي تعذر ومدري ليش"): كنا نسجّل الخطأ
      // الحقيقي بسجلات السيرفر فقط (logger.error) — وأغلب أصحاب
      // الاستضافات المجانية (مثل Katabump) ما يفتحون الـ Console أبدًا أو
      // ما يعرفون كيف. الحين نبعت تفاصيل الخطأ الحقيقي (رسالة الخطأ
      // الفعلية من الشبكة/الـ API) مباشرة لرقم المطور بالخاص تلقائيًا،
      // فيوصلك التشخيص الدقيق فورًا بدون فتح أي console.
      await notifyOwnerOfError(ctx.sock, ".تحميل", String(err?.message || err), {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });

      const reason =
        err?.message === "NOT_A_VIDEO"
          ? "⚠️ الرابط يشير إلى صورة/منشور غير فيديو، الأمر يدعم الفيديوهات فقط."
          : err?.message === "NOT_FOUND"
          ? "⚠️ الفيديو غير موجود أو محذوف أو الرابط غير صحيح."
          : err?.message === "TIMEOUT"
          ? "⚠️ انتهت المهلة أثناء التحميل، جرّب مرة أخرى."
          : `❌ تعذر تحميل الفيديو حاليًا (${String(err?.message || "خطأ غير معروف")}). جرّب لاحقًا أو برابط آخر.`;

      await editText(reason);
    }
  },
};

export default command;
