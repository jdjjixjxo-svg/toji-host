import { Command } from "../../handlers/types";
import { downloadImageBuffer } from "../../utils/imageSearch";
import { logger } from "../../utils/logger";
import sharp from "sharp";

/**
 * 🆕 .بروفايل_تعديل — يجيب صورة بروفايلك ويطبّق عليها فلتر لون عشوائي
 * (نفس فكرة فلاتر انستقرام البسيطة)، عبر sharp (بدون أي API خارجي —
 * كل المعالجة محلية بالسيرفر).
 */
type FilterName = "دافئ" | "بارد" | "أبيض وأسود" | "سيبيا" | "نيون بنفسجي" | "معكوس الألوان";

async function applyFilter(buffer: Buffer, filter: FilterName): Promise<Buffer> {
  let img = sharp(buffer).resize(700, 700, { fit: "cover" });

  switch (filter) {
    case "دافئ":
      img = img.tint({ r: 255, g: 200, b: 140 });
      break;
    case "بارد":
      img = img.tint({ r: 150, g: 200, b: 255 });
      break;
    case "أبيض وأسود":
      img = img.grayscale();
      break;
    case "سيبيا":
      img = img.tint({ r: 180, g: 140, b: 90 }).grayscale(false);
      break;
    case "نيون بنفسجي":
      img = img.tint({ r: 200, g: 120, b: 255 }).modulate({ brightness: 1.05, saturation: 1.4 });
      break;
    case "معكوس الألوان":
      img = img.negate({ alpha: false });
      break;
  }

  return img.jpeg({ quality: 90 }).toBuffer();
}

const FILTERS: FilterName[] = ["دافئ", "بارد", "أبيض وأسود", "سيبيا", "نيون بنفسجي", "معكوس الألوان"];

const command: Command = {
  name: "بروفايل_تعديل",
  aliases: ["تعديل_بروفايل", "فلتر_بروفايل"],
  category: "ادوات",
  description: "يجيب صورة بروفايلك ويطبّق عليها فلتر لون عشوائي حلو",
  permission: "all",
  execute: async (ctx) => {
    try {
      const url = await ctx.sock.profilePictureUrl(ctx.senderJid, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");

      const buffer = await downloadImageBuffer(url);
      const filter = FILTERS[Math.floor(Math.random() * FILTERS.length)];
      const edited = await applyFilter(buffer, filter);

      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: edited, caption: `🎨 فلتر: *${filter}*` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      logger.error("فشل .بروفايل_تعديل:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "🙈 ما قدرت أجيب صورة بروفايلك (مخفية بالخصوصية أو غير موجودة)." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
