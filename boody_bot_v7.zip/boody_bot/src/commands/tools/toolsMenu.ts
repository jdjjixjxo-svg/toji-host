import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons, buildSingleSelectButton } from "../../utils/interactive";
import { TOOLS_EXTRA_ROWS } from "../../utils/menuRows";
import { toolsMenuText } from "../../utils/menuTemplates";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "ادوات",
  aliases: ["tools", "أدوات"],
  category: "ادوات",
  description: "عرض قائمة الأدوات المتاحة",
  permission: "all",
  execute: async (ctx) => {
    const text = toolsMenuText();

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("tools") || undefined,
      extraButtons: [buildSingleSelectButton("📥 تحميل وتحويلات", "أدوات التحميل والوسائط", TOOLS_EXTRA_ROWS)],
      quickButtons: [sectionButton("بنك", "🏦 بنك"), ...navButtons()],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
