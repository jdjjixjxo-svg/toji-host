import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";
import { videoToAnimatedSticker } from "../../utils/ffmpegMedia";

const command: Command = {
  name: "ملصق",
  aliases: ["sticker", "ستيكر"],
  category: "ادوات",
  description: "تحويل صورة إلى ملصق، أو فيديو إلى ملصق متحرك (رد على صورة/فيديو بهذا الأمر)",
  permission: "all",
  execute: async (ctx) => {
    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    const quotedVideo = ctx.quoted?.videoMessage;
    const directVideo = ctx.msg.message?.videoMessage;
    const videoMsg = quotedVideo || directVideo;

    if (!imageMsg && !videoMsg) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ أرسل صورة أو فيديو مع الأمر .ملصق، أو رد بها على صورة/فيديو.",
      });
      return;
    }

    try {
      if (videoMsg) {
        // 🔧 إصلاح: نبني key صحيح من الرسالة المقتبسة الفعلية (راجع تعليق
        // buildQuotedMessage بالتفصيل) بدل استعارة key رسالة الرد.
        const source = quotedVideo ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;

        const buffer = (await downloadMediaMessage(
          source,
          "buffer",
          {},
          { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
        )) as Buffer;

        // 🎞️ نحدد أطول مدة ممكنة (سقف آمن 10 ثواني) — يتكرر تلقائيًا
        // بحلقة لا نهائية (loop) داخل الملصق نفسه.
        const durationSeconds = videoMsg.seconds ? Math.min(videoMsg.seconds, 10) : 10;
        const webp = await videoToAnimatedSticker(buffer, durationSeconds);

        await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
        return;
      }

      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;

      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;
      const webp = await sharp(buffer)
        .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp()
        .toBuffer();

      await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر الملصق:", err);
      await notifyOwnerOfError(ctx.sock, ".ملصق", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل إنشاء الملصق. حاول مرة أخرى بصورة أو فيديو آخر.",
      });
    }
  },
};

export default command;
