import { Command } from "../../handlers/types";
import https from "https";
import { logger } from "../../utils/logger";

/**
 * يستخدم خدمة Google Translate TTS المجانية كحل عملي بدون الحاجة لمفتاح API.
 * ملاحظة: هذه خدمة غير رسمية وقد تتغير أو تتوقف من طرف Google دون إشعار،
 * لذلك الأمر مصمم بحيث يفشل بأمان (رسالة خطأ واضحة) بدل تعطيل البوت.
 *
 * 🔧 إصلاح: الطلب القديم كان يفتقد بعض المعاملات (idx/total/textlen) وترويسة
 * Referer التي تعتمد عليها خدمة Google Translate TTS فعليًا للتحقق من الطلب
 * (نفس الصيغة التي تستخدمها مكتبة gTTS الشهيرة)، ما كان يجعل Google يرفض
 * الطلب بخطأ 403/400 صامت. تمت إضافتها هنا مع رسالة خطأ أوضح تُظهر رمز الحالة.
 */
function fetchTtsBuffer(text: string, lang = "ar"): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const clipped = text.slice(0, 200);
    const params = new URLSearchParams({
      ie: "UTF-8",
      q: clipped,
      tl: lang,
      total: "1",
      idx: "0",
      textlen: String(clipped.length),
      client: "tw-ob",
      prev: "input",
      ttsspeed: "1",
    });
    const url = `https://translate.google.com/translate_tts?${params.toString()}`;

    https
      .get(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            Referer: "https://translate.google.com/",
          },
        },
        (res) => {
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}`));
            return;
          }
          const chunks: Buffer[] = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => resolve(Buffer.concat(chunks)));
          res.on("error", reject);
        }
      )
      .on("error", reject);
  });
}

const command: Command = {
  name: "صوت",
  aliases: ["tts"],
  category: "ادوات",
  description: "تحويل نص إلى مقطع صوتي. مثال: .صوت مرحبا بكم",
  permission: "all",
  execute: async (ctx) => {
    if (!ctx.text) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ اكتب النص المراد تحويله بعد الأمر.\nمثال: .صوت مرحبا بكم",
      });
      return;
    }

    try {
      const audio = await fetchTtsBuffer(ctx.text);
      await ctx.sock.sendMessage(ctx.chatId, {
        audio,
        mimetype: "audio/mpeg",
        // ⚠️ ptt:true (رسالة صوتية) يتطلب من واتساب أن يكون الصوت بصيغة
        // OGG/Opus فعليًا، وإلا يظهر خطأ "هذا المقطع الصوتي غير متوفر" عند
        // المستلم رغم وصول الرسالة بنجاح. خدمة Google TTS ترجع MP3، فنرسله
        // كملف صوتي عادي (ptt:false) بدل رسالة صوتية، وبكذا يشتغل التشغيل
        // بشكل طبيعي دون الحاجة لتحويل الصيغة عبر ffmpeg (غير مضمون توفره
        // على استضافات مجانية مثل Katabump).
        ptt: false,
      });
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ تعذر تحويل النص إلى صوت حاليًا. حاول لاحقًا أو بنص أقصر.",
      });
    }
  },
};

export default command;
