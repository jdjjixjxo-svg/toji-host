import { Command } from "../../handlers/types";
import { FOOTER_DIVIDER } from "../../utils/theme";

// قائمة عامة شائعة ومتعارف عليها لأركان الصلاة (تفصيلها الدقيق قد يختلف
// شوي بين المذاهب الفقهية) — معروضة كتعريف عام وليست فتوى.
const PILLARS = [
  "١. النية",
  "٢. تكبيرة الإحرام (الله أكبر)",
  "٣. القيام مع القدرة",
  "٤. قراءة الفاتحة",
  "٥. الركوع",
  "٦. الرفع من الركوع",
  "٧. السجود على الأعضاء السبعة",
  "٨. الرفع من السجود والجلوس بينه",
  "٩. الطمأنينة في كل ركن",
  "١٠. التشهد الأخير",
  "١١. الجلوس له",
  "١٢. الصلاة على النبي ﷺ في التشهد الأخير",
  "١٣. الترتيب بين الأركان",
  "١٤. التسليم",
];

const command: Command = {
  name: "اركان_الصلاة",
  aliases: ["اركان_الصلاه", "اركان", "pillars"],
  category: "السنة",
  description: "تعريف عام بأركان الصلاة",
  permission: "all",
  execute: async (ctx) => {
    const text =
      `${FOOTER_DIVIDER}\n      🕌 *أركان الصلاة* 🕌\n${FOOTER_DIVIDER}\n\n` +
      `${PILLARS.join("\n")}\n\n` +
      `${FOOTER_DIVIDER}\n` +
      `ℹ️ تعريف عام شائع — بعض التفاصيل قد تختلف شوي بين المذاهب الفقهية، فارجع لأهل العلم لأي تفصيل دقيق.`;
    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
