import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const AYAHS: { text: string; source: string }[] = [
  { text: "﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا﴾", source: "سورة الشرح، آية 5" },
  { text: "﴿وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا﴾", source: "سورة الطلاق، آية 2" },
  { text: "﴿وَبَشِّرِ الصَّابِرِينَ﴾", source: "سورة البقرة، آية 155" },
  { text: "﴿ادْعُونِي أَسْتَجِبْ لَكُمْ﴾", source: "سورة غافر، آية 60" },
  { text: "﴿إِنَّ اللَّهَ مَعَ الصَّابِرِينَ﴾", source: "سورة البقرة، آية 153" },
  { text: "﴿وَقُل رَّبِّ زِدْنِي عِلْمًا﴾", source: "سورة طه، آية 114" },
  { text: "﴿فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ﴾", source: "سورة البقرة، آية 152" },
  { text: "﴿وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ﴾", source: "سورة الحديد، آية 4" },
  { text: "﴿لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا﴾", source: "سورة البقرة، آية 286" },
];

const command: Command = {
  name: "ايه",
  aliases: ["آية", "ايه_قرانية", "ayah"],
  category: "السنة",
  description: "آية قرآنية عشوائية",
  permission: "all",
  execute: async (ctx) => {
    const a = pickRandom(AYAHS);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `📖 ${a.text}\n\n_${a.source}_` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
