import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

// أحاديث مشهورة جدًا ومتفق على صحتها بين المسلمين (من أشهر الأحاديث النبوية)
const HADITHS: { text: string; source: string }[] = [
  { text: "«إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى»", source: "متفق عليه" },
  { text: "«مَنْ حُسْنِ إِسْلَامِ الْمَرْءِ تَرْكُهُ مَا لَا يَعْنِيهِ»", source: "رواه الترمذي" },
  { text: "«الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ»", source: "متفق عليه" },
  { text: "«لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ»", source: "متفق عليه" },
  { text: "«الدِّينُ النَّصِيحَةُ»", source: "رواه مسلم" },
  { text: "«مَنْ لَا يَرْحَمِ النَّاسَ لَا يَرْحَمْهُ اللهُ»", source: "متفق عليه" },
  { text: "«خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ»", source: "رواه البخاري" },
  { text: "«التَّبَسُّمُ فِي وَجْهِ أَخِيكَ صَدَقَةٌ»", source: "رواه الترمذي" },
  { text: "«مَنْ صَمَتَ نَجَا»", source: "رواه الترمذي" },
  { text: "«الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ»", source: "متفق عليه" },
];

const command: Command = {
  name: "حديث",
  aliases: ["hadith"],
  category: "السنة",
  description: "حديث نبوي مشهور عشوائي",
  permission: "all",
  execute: async (ctx) => {
    const h = pickRandom(HADITHS);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `📿 ${h.text}\n\n_${h.source}_` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
