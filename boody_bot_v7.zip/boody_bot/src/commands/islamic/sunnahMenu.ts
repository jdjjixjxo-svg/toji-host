import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sunnahMenuText } from "../../utils/menuTemplates";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "السنه",
  aliases: ["السنة", "sunnah", "دين", "اسلاميات"],
  category: "السنة",
  description: "قسم يضم أذكار، أركان الصلاة، حديث، آية، وسورة",
  permission: "all",
  execute: async (ctx) => {
    const text = sunnahMenuText();

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("sunnah") || undefined,
      extraButtons: [
        buildSingleSelectButton("👇 اختر محتوى", "السنة النبوية", [
          { command: "اذكار", label: "🤲 اذكار" },
          { command: "اركان_الصلاة", label: "🕌 اركان الصلاة" },
          { command: "حديث", label: "📿 حديث" },
          { command: "ايه", label: "📖 آية" },
          { command: "سورة", label: "📗 سورة" },
          { command: "menu", label: "🏠 القائمة الرئيسية" },
        ]),
      ],
      fallbackNote: `اكتب أمر أي محتوى مباشرة، أو للرجوع للقائمة الرئيسية: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
