import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const SURAHS: { name: string; number: number; verses: number; meaning: string }[] = [
  { name: "الفاتحة", number: 1, verses: 7, meaning: "افتتاح المصحف وأم القرآن، تُقرأ في كل ركعة" },
  { name: "الإخلاص", number: 112, verses: 4, meaning: "تعدل ثلث القرآن، تتحدث عن توحيد الله" },
  { name: "الفلق", number: 113, verses: 5, meaning: "من المعوذتين، للاستعاذة من شر ما خُلق" },
  { name: "الناس", number: 114, verses: 6, meaning: "من المعوذتين، للاستعاذة من شر الوسواس" },
  { name: "الكوثر", number: 108, verses: 3, meaning: "أقصر سورة بالقرآن، بشارة بالخير الكثير" },
  { name: "العصر", number: 103, verses: 3, meaning: "قسم بالعصر على أن الإنسان في خسر إلا من آمن وعمل صالحًا" },
  { name: "الضحى", number: 93, verses: 11, meaning: "نزلت تسلية للنبي ﷺ وبشارة بأن ربه ما تركه" },
  { name: "الشرح", number: 94, verses: 8, meaning: "تتحدث عن أن مع العسر يسرًا" },
  { name: "الملك", number: 67, verses: 30, meaning: "تُعرف بالمنجية، وردت فضائل بقراءتها" },
  { name: "يس", number: 36, verses: 83, meaning: "من السور المكية المشهورة، تتناول التوحيد والبعث" },
];

const command: Command = {
  name: "سورة",
  aliases: ["سوره", "surah"],
  category: "السنة",
  description: "معلومة سريعة عن سورة عشوائية من القرآن",
  permission: "all",
  execute: async (ctx) => {
    const s = pickRandom(SURAHS);
    const text =
      `📗 *سورة ${s.name}*\n` +
      `الترتيب في المصحف: ${s.number}\n` +
      `عدد الآيات: ${s.verses}\n` +
      `${s.meaning}`;
    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
