import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { hasActiveStory, endStory } from "../../handlers/storyManager";
import { bombManager } from "../../handlers/bombManager";
import { ticTacToeManager } from "../../handlers/ticTacToeManager";
import { snakeManager } from "../../handlers/snakeManager";
import { game2048Manager } from "../../handlers/game2048Manager";
import { hasActivePortal, endPortal } from "../../handlers/portalManager";
import { isRunning as isHeartsRunning, end as endHearts } from "../../handlers/heartsManager";
import { isRunning as isHangmanRunning, end as endHangman } from "../../handlers/hangmanManager";
import { isRunning as isSecretNumberRunning, end as endSecretNumber } from "../../handlers/secretNumberManager";
import { isRunning as isSpeedRunning, end as endSpeed } from "../../handlers/speedReactionManager";
import { isRunning as isWordChainRunning, end as endWordChain } from "../../handlers/wordChainManager";
import { isRunning as isPasswordRunning, end as endPassword } from "../../handlers/passwordGameManager";
import { isRunning as isDinoRunning, end as endDino } from "../../handlers/dinoManager";
import { isRunning as isFpsRunning, end as endFps } from "../../handlers/fpsManager";
import { isRunning as isMazeRunning, end as endMaze } from "../../handlers/mazeManager";
import { isRunning as isRaceRunning, end as endRace } from "../../handlers/raceManager";
import { isRunning as isKuroRunning, end as endKuro } from "../../handlers/kuroManager";

/**
 * أمر ".استسلم" — ينهي أي فعالية/لعبة جارية حاليًا (خمن، حزورة، قصة/الراوي،
 * قنبلة، إكس_أو، ثعبان، 2048) ويكشف الإجابة الصحيحة إن وُجدت، ثم يسمح
 * ببدء جولة جديدة مباشرة.
 * 🔧 (طلب صريح: "ما فيه أمر نهاء فعليًا للعاب متل إكس_أو وغيرها") — كل
 * مدراء الألعاب هذي كان عندهم أصلًا دالة end()/stop() جاهزة (ticTacToe:
 * stop، snake/2048: end) لكن ما كانت مربوطة بأي أمر يستدعيها — أي شخص
 * علق بلعبة ما كان له أي طريقة ينهيها. الحين هذا الأمر الموحّد يفحص كل
 * الألعاب المدعومة بالترتيب ويوقف أول وحدة جارية يلقاها.
 */
const command: Command = {
  name: "استسلم",
  aliases: ["استسلام", "سلم", "تسليم"], // 🔧 شلنا "نهاء/انهاء/إنهاء" (كانت تتعارض مع .انهاء الخاص بإيقاف الألعاب)
  category: "ترفيه",
  description: "إنهاء أي فعالية/لعبة جارية (خمن، قصة، قنبلة، إكس_أو، ثعبان، 2048)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 1) فعالية خمن/حزورة جارية؟
    const quizResult = eventManager.revealAndStop(ctx.sock as any, ctx.chatId);
    if (quizResult) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          `🏳️ *تم إنهاء فعالية ${quizResult.title}*\n\n` +
          `✅ الإجابة الصحيحة كانت: *${quizResult.answer}*\n\n` +
          `يمكنكم بدء جولة جديدة الآن.`,
      });
      return;
    }

    // 2) قصة/راوي جارية؟
    if (hasActiveStory(ctx.chatId)) {
      endStory(ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء القصة الجارية.*\n\nاكتب .قصة لبدء مغامرة جديدة.`,
      });
      return;
    }

    // 3) قنبلة جارية؟
    if (bombManager.isRunning(ctx.sock, ctx.chatId)) {
      bombManager.end(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء جولة القنبلة.*\n\nاكتبوا .قنبلة لبدء جولة جديدة.`,
      });
      return;
    }

    // 4) إكس_أو جارية؟
    if (ticTacToeManager.isRunning(ctx.sock, ctx.chatId)) {
      ticTacToeManager.stop(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة إكس_أو.*\n\nاكتبوا .إكس_أو @شخص لبدء لعبة جديدة.`,
      });
      return;
    }

    // 5) ثعبان جارية؟
    if (snakeManager.isRunning(ctx.sock, ctx.chatId)) {
      snakeManager.end(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة الثعبان.*`,
      });
      return;
    }

    // 6) 2048 جارية؟
    if (game2048Manager.isRunning(ctx.sock, ctx.chatId)) {
      game2048Manager.end(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة 2048.*`,
      });
      return;
    }

    // 7) بوابة جارية؟
    if (hasActivePortal(ctx.chatId, ctx.senderJid)) {
      endPortal(ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة البوابة.*`,
      });
      return;
    }

    // 🆕 Dino جارية؟
    if (isDinoRunning(ctx.sock, ctx.chatId, ctx.senderJid)) {
      endDino(ctx.sock, ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة Dino.*`,
      });
      return;
    }

    // 🆕 FPS جارية؟
    if (isFpsRunning(ctx.sock, ctx.chatId, ctx.senderJid)) {
      endFps(ctx.sock, ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة FPS.*`,
      });
      return;
    }

    // 🧊 متاهة 3D جارية؟
    if (isMazeRunning(ctx.sock, ctx.chatId, ctx.senderJid)) {
      endMaze(ctx.sock, ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, { text: `🏳️ *تم إنهاء المتاهة.*` });
      return;
    }

    // 🆕 سباق جارية؟
    if (isRaceRunning(ctx.sock, ctx.chatId, ctx.senderJid)) {
      endRace(ctx.sock, ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة السباق.*`,
      });
      return;
    }

    // 🆕 KURO جارية؟
    if (isKuroRunning(ctx.sock, ctx.chatId, ctx.senderJid)) {
      endKuro(ctx.sock, ctx.chatId, ctx.senderJid);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة KURO.*`,
      });
      return;
    }

    // 8) قلوب جارية؟
    if (isHeartsRunning(ctx.sock, ctx.chatId)) {
      endHearts(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة القلوب.*`,
      });
      return;
    }

    // 9) مشنقة جارية؟
    if (isHangmanRunning(ctx.sock, ctx.chatId)) {
      endHangman(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة المشنقة.*`,
      });
      return;
    }

    // 10) رقم سري جارية؟
    if (isSecretNumberRunning(ctx.sock, ctx.chatId)) {
      endSecretNumber(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة الرقم السري.*`,
      });
      return;
    }

    // 11) من الأسرع جارية؟
    if (isSpeedRunning(ctx.sock, ctx.chatId)) {
      endSpeed(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة من الأسرع.*`,
      });
      return;
    }

    // 12) سلسلة جارية؟
    if (isWordChainRunning(ctx.sock, ctx.chatId)) {
      endWordChain(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة السلسلة.*`,
      });
      return;
    }

    // 13) كلمة السر جارية؟
    if (isPasswordRunning(ctx.sock, ctx.chatId)) {
      endPassword(ctx.sock, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🏳️ *تم إنهاء لعبة كلمة السر.*`,
      });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, {
      text: "لا توجد فعالية جارية حاليًا.",
    });
  },
};

export default command;
