import { Command } from "../../handlers/types";
import { getLeaderboard } from "../../database/db";
import { jidToMention } from "../../utils/helpers";

const medals = ["🥇", "🥈", "🥉"];

const command: Command = {
  name: "الترتيب",
  aliases: ["النقاط", "leaderboard"],
  category: "ترفيه",
  description: "عرض لوحة المتصدرين في الفعاليات",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const top = getLeaderboard(ctx.chatId, 10);
    if (top.length === 0) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "لا توجد نقاط مسجلة بعد. ابدأ فعالية بـ .فعالية دول",
      });
      return;
    }

    const lines = top.map(
      (entry, i) =>
        `${medals[i] || `${i + 1}.`} ${jidToMention(entry.userId)} — ${entry.score} نقطة`
    );

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🏆 *لوحة المتصدرين*\n\n${lines.join("\n")}`,
      mentions: top.map((t) => t.userId),
    });
  },
};

export default command;
