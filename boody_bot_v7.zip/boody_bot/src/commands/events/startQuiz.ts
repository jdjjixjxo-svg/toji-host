import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { getGroupSettings } from "../../database/db";
import { QUESTION_BANKS, QuizCategory } from "./questionBank";
import { sendWithSalawatFallback } from "../../utils/media";
import { buildEventCard } from "../../utils/miniQuiz";
import { normalizeArabicCommand } from "../../utils/arabicNormalize";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";

const command: Command = {
  name: "فعالية",
  // 🔧 إصلاح: كان الاسم المستعار "خمن" هنا يجعل أمر .خمن يفتح فعالية
  // الأسئلة النصية (حزورة) بدل فعالية صور الأنمي كما هو مقصود. تم نقل
  // الاسم "خمن" إلى src/commands/events/imageQuiz.ts، وأصبح هذا الأمر
  // يُستدعى بـ "حزورة"/"حزوره" بدلًا منه (بدون كسر ."فعالية"/.quiz).
  aliases: ["quiz", "حزورة", "حزوره"],
  category: "ترفيه",
  description: "ابدأ فعالية تخمين. اكتبه بدون فئة لتظهر لك قائمة اختيار، أو مباشرة مثال: .فعالية دول",
  permission: "admin",
  requireBotAdmin: false,
  groupOnly: true,
  execute: async (ctx) => {
    const settings = getGroupSettings(ctx.chatId);
    if (!settings.events) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ نظام الفعاليات متوقف في هذه المجموعة. فعّله عبر: .اعدادات فعاليات تشغيل",
      });
      return;
    }

    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم",
      });
      return;
    }

    // 🆕 (طلب صريح: "زر واحد يفتح قائمة تختار منها، اسم الزر 'اختار'،
    // لحتى يبان النص كامل") — قبل كذا ما فيه أي طريقة تفاعلية لاختيار
    // الفئة أصلًا (لازم تكتبها يدويًا كوسيط نصي، وإلا ترجع "دول" افتراضيًا
    // بصمت). الحين لو كتبت .فعالية بدون فئة، أو فئة غلط، تطلع لك قائمة
    // "single_select" (زر واحد اسمه "اختار") فيها كل الفئات بنصها الكامل
    // بدون أي قص — نفس آلية القوائم المستخدمة بباقي أزرار المشروع.
    const categories = Object.keys(QUESTION_BANKS);
    const rawCategoryArg = ctx.args[0];

    if (!rawCategoryArg) {
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: "🎯 *اختر فئة الفعالية:*",
        extraButtons: [
          buildSingleSelectButton(
            "اختار",
            "فئات الفعالية",
            categories.map((c) => ({ command: `فعالية ${c}`, label: c }))
          ),
        ],
      });
      return;
    }

    // 🔧 إصلاح: كان البحث عن الفئة (دول/حيوانات/أفلام...) مطابقة حرفية
    // مباشرة، فأي حركة تشكيل أو اختلاف بسيط بالهمزة كان يرجّع "فئة غير
    // معروفة" رغم إن الاسم صحيح. الحين نقارن بعد إزالة التشكيل وتوحيد
    // الحروف، ونستخدم اسم الفئة الأصلي الصحيح من القائمة عند العثور عليه.
    const matchedKey = categories.find(
      (k) => normalizeArabicCommand(k) === normalizeArabicCommand(rawCategoryArg)
    );
    const category = (matchedKey || rawCategoryArg) as QuizCategory;
    const bank = QUESTION_BANKS[category];
    if (!bank) {
      await sendButtonMessage(ctx.sock, ctx.chatId, {
        text: `⚠️ فئة غير معروفة: "${rawCategoryArg}". اختر من القائمة تحت 👇`,
        extraButtons: [
          buildSingleSelectButton(
            "اختار",
            "فئات الفعالية",
            categories.map((c) => ({ command: `فعالية ${c}`, label: c }))
          ),
        ],
      });
      return;
    }

    const item = bank[Math.floor(Math.random() * bank.length)];
    eventManager.start(ctx.sock as any, ctx.chatId, `خمن ${category}`, item.answer, 60_000);

    const groupName = ctx.metadata?.subject || "الخاص";
    const card = buildEventCard(
      groupName,
      `خمن ${category}`,
      item.question,
      "جاوب على السؤال بالإجابة الصحيحة، أول شخص يجاوب صح يفوز بالنقاط والعملات.",
      `⏱️ أول إجابة صحيحة تفوز! (60 ثانية)`
    );

    // فعالية بدون صورة خاصة بها → نرفقها بصورة "صلوا على النبي" الافتراضية.
    await sendWithSalawatFallback(ctx.sock, ctx.chatId, card);
  },
};

export default command;
