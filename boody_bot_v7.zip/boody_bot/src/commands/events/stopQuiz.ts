import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";

const command: Command = {
  name: "ايقاف_الفعالية",
  aliases: ["إيقاف_الفعالية", "stopquiz"],
  category: "ترفيه",
  description: "إيقاف الفعالية الجارية في المجموعة",
  permission: "admin",
  requireBotAdmin: false,
  groupOnly: true,
  execute: async (ctx) => {
    const stopped = eventManager.stop(ctx.sock as any, ctx.chatId);
    await ctx.sock.sendMessage(ctx.chatId, {
      text: stopped ? "🛑 تم إيقاف الفعالية." : "لا توجد فعالية جارية حاليًا.",
    });
  },
};

export default command;
