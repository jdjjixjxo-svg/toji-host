import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { getGroupSettings } from "../../database/db";
import { getRandomQuizImage } from "../../utils/media";
import { logger } from "../../utils/logger";
import { buildEventCard } from "../../utils/miniQuiz";

/**
 * فعالية ".خمن" — تخمين شخصيات الأنمي بالصور.
 * 🔧 (طلب صريح: "أي فعالية تعتمد على التخمين تستخدم أزرار، أزل أزرار
 * التخمين منها. الفعاليات تعتمد على الرسالة والإجابة النصية فقط") —
 * أزلنا أزرار الاختيار من متعدد كليًا؛ الإجابة الوحيدة المقبولة الآن نص
 * مكتوب يدويًا بالمجموعة (يتحقق منه eventManager بنفس آلية بقية
 * الفعاليات، بدون أي تغيير هناك).
 */
const command: Command = {
  name: "خمن",
  aliases: ["فعالية_صورة", "فعاليه_صوره", "quizimage", "خمن_الصورة", "حزر", "حزر_الصور"],
  category: "ترفيه",
  description: "ابدأ فعالية تخمين شخصية أنمي من صورة عشوائية",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const settings = getGroupSettings(ctx.chatId);
    if (!settings.events) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ نظام الفعاليات متوقف بهالكروب. شغّله بـ: .اعدادات فعاليات تشغيل",
      });
      return;
    }

    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ فيه فعالية شغالة حاليًا! استنى تخلص أو استخدم .استسلم",
      });
      return;
    }

    const quiz = getRandomQuizImage();
    if (!quiz) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ ما لقيت صور بالبنك (assets/quiz). تأكد إن الصور موجودة بالمجلد وحاول مرة ثانية.",
      });
      return;
    }

    try {
      eventManager.start(ctx.sock as any, ctx.chatId, "خمن الشخصية!", quiz.answer, 60_000);

      const groupName = ctx.metadata?.subject || "الخاص";
      const card = buildEventCard(
        groupName,
        "خمن الشخصية!",
        "❓ مين هذي الشخصية؟",
        "شوف الصورة واكتب اسم الشخصية الصحيح بالمجموعة.",
        `⏱️ أول وحد يجاوب صح يفوز! (60 ثانية)`
      );

      await ctx.sock.sendMessage(ctx.chatId, { image: quiz.buffer, caption: card });
    } catch (err) {
      logger.error("فشل بدء فعالية خمن:", err);
      eventManager.stop(ctx.sock as any, ctx.chatId);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ ما قدرت أبدأ الفعالية، جرّب مرة ثانية.",
      });
    }
  },
};

export default command;
