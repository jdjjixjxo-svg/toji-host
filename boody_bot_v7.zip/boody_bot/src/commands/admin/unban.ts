import { Command } from "../../handlers/types";
import { unblockUser } from "../../database/db";
import { getTargetJid, jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "فك_الحظر",
  aliases: ["unban"],
  category: "مشرفين",
  description: "إلغاء حظر عضو من استخدام البوت",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ منشن العضو المراد فك حظره." });
      return;
    }
    unblockUser(ctx.chatId, target);
    await ctx.sock.sendMessage(ctx.chatId, {
      text: `✅ تم فك الحظر عن ${jidToMention(target)}.`,
      mentions: [target],
    });
  },
};

export default command;
