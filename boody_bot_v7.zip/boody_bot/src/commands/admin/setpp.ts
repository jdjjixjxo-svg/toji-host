import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { logger } from "../../utils/logger";
import { buildQuotedMessage } from "../../utils/helpers";

const command: Command = {
  name: "تغيير_الصورة",
  aliases: ["setpp"],
  category: "مشرفين",
  description: "تغيير صورة المجموعة (رد على صورة بهذا الأمر)",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const quoted = ctx.quoted;
    if (!quoted?.imageMessage) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ رُد على صورة بالأمر .تغيير_الصورة",
      });
      return;
    }
    try {
      // 🔧 إصلاح: نبني key صحيح من الرسالة المقتبسة الفعلية (راجع تعليق
      // buildQuotedMessage بالتفصيل) بدل استعارة key رسالة الرد.
      const source = buildQuotedMessage(ctx.msg) ?? ({ message: quoted, key: ctx.msg.key } as any);
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        // 🔧 إصلاح: بدون reuploadRequest، تحميل وسائط من رسالة قديمة/مردود
        // عليها يفشل بصمت لو رابط الوسائط بواتساب انتهت صلاحيته (شائع جدًا
        // مع الرسائل المردود عليها) — Baileys يحتاجه لإعادة طلب رابط جديد.
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;
      await ctx.sock.updateProfilePicture(ctx.chatId, buffer);
      await ctx.sock.sendMessage(ctx.chatId, { text: "🖼️ تم تحديث صورة المجموعة." });
    } catch (err) {
      logger.error("فشل أمر تغيير الصورة:", err);
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل تحديث الصورة." });
    }
  },
};

export default command;
