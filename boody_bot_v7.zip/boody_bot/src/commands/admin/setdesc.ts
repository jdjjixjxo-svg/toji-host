import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "تغيير_الوصف",
  aliases: ["setdesc"],
  category: "مشرفين",
  description: "تغيير وصف المجموعة",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    if (!ctx.text) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ اكتب الوصف الجديد بعد الأمر.\nمثال: .تغيير_الوصف مجموعة رائعة",
      });
      return;
    }
    try {
      await ctx.sock.groupUpdateDescription(ctx.chatId, ctx.text);
      await ctx.sock.sendMessage(ctx.chatId, { text: "📝 تم تحديث وصف المجموعة." });
    } catch (err) {
      logger.error("فشل أمر تغيير الوصف:", err);
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل تحديث الوصف." });
    }
  },
};

export default command;
