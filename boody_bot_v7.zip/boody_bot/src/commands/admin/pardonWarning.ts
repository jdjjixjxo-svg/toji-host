import { Command } from "../../handlers/types";
import { getWarnings, removeWarnings } from "../../database/db";
import { getTargetJid, jidToMention, bold, toEnglishDigits } from "../../utils/helpers";

const command: Command = {
  name: "إعفاء_الانذار",
  aliases: ["اعفاء", "عفاء_الانذار", "اعفاء_النذار", "اعفاء_نذار", "الغاء_نذار", "عفو_انذار"],
  category: "مشرفين",
  description:
    "يعفي عضو من عدد محدد من النذارات (منشن أو رد على رسالته). مثال: .عفاء_الانذار @شخص 1",
  permission: "admin", // نفس صلاحية بقية أوامر المشرفين — والمطور يتجاوزها دائمًا (isOwner) زي باقي الأوامر
  groupOnly: true,
  execute: async (ctx) => {
    // نفس نمط .نون: نستخدم getTargetJid بدل JID الخام حتى يوحّد الهدف
    // لرقم ثابت (حتى لو وصل بصيغة @lid مؤقتة)، فنعدّل فعليًا نفس مفتاح
    // النذارات اللي يقرأه أمر .نذار ولوحة الصدارة، لا مفتاح جديد فاضي.
    const rawMentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const target = getTargetJid(ctx.msg, ctx.metadata);

    // نفس منطق .نون: العدد يجي بعد المنشن لو فيه منشن، أو أول أرجيومنت لو رد
    const amountArg = rawMentioned ? ctx.args[1] : ctx.args[0];
    // 🔧 نفس إصلاح .نون: نحوّل الأرقام العربية الهندية (٠-٩) لإنجليزية قبل
    // Number()، وإلا رقم مكتوب بلوحة مفاتيح عربية يفشل بصمت.
    const amount = Number(toEnglishDigits(amountArg || ""));

    if (!target || !amountArg || !Number.isFinite(amount) || amount <= 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "⚠️ الاستخدام: .اعفاء_النذار @شخص عدد_النذارات — أو رد على رسالته واكتب .اعفاء_النذار عدد_النذارات",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const before = getWarnings(ctx.chatId, target);
    if (before <= 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `ℹ️ ${jidToMention(target)} ما عليه أي نذارات أصلًا.`, mentions: [target] },
        { quoted: ctx.msg }
      );
      return;
    }

    const updated = removeWarnings(ctx.chatId, target, amount);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `✅ تم إعفاء ${jidToMention(target)} من ${bold(`${before - updated}`)} نذار.\nنذاراته الحالية: ${bold(`${updated}`)} نذار.`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
