import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "حذف",
  aliases: ["delete", "del"],
  category: "مشرفين",
  description: "حذف رسالة عن طريق الرد عليها",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
    if (!contextInfo?.stanzaId || !contextInfo?.participant) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ رُد على الرسالة التي تريد حذفها بالأمر .حذف",
      });
      return;
    }

    // لازم نحدد fromMe صح: لو الرسالة المطلوب حذفها مرسلة من رقم البوت نفسه
    // (حالة شائعة إذا كان المطور يستخدم نفس رقم البوت)، لازم fromMe=true
    // وإلا واتساب يرفض عملية الحذف بصمت. قبل كذا كانت مثبّتة false دائمًا.
    const botPhone = ctx.sock.user?.id?.split(":")[0].split("@")[0];
    const targetPhone = contextInfo.participant.split(":")[0].split("@")[0];
    const isBotsOwnMessage = !!botPhone && botPhone === targetPhone;

    try {
      await ctx.sock.sendMessage(ctx.chatId, {
        delete: {
          remoteJid: ctx.chatId,
          fromMe: isBotsOwnMessage,
          id: contextInfo.stanzaId,
          participant: isBotsOwnMessage ? undefined : contextInfo.participant,
        },
      });
    } catch (err) {
      logger.error("فشل أمر الحذف (.حذف):", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل الحذف. تأكد أن البوت مشرف في المجموعة (إلا إذا كانت الرسالة من البوت نفسه).",
      });
    }
  },
};

export default command;
