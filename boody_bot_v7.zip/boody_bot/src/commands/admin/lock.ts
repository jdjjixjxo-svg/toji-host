import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "قفل",
  aliases: ["lock"],
  category: "مشرفين",
  description: "قفل المجموعة بحيث يكتب المشرفون فقط",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    try {
      await ctx.sock.groupSettingUpdate(ctx.chatId, "announcement");
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "🔒 تم قفل المجموعة، المشرفون فقط يمكنهم الكتابة الآن.",
      });
    } catch (err) {
      logger.error("فشل أمر القفل (.قفل):", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل القفل. تأكد أن البوت مشرف في المجموعة.",
      });
    }
  },
};

export default command;
