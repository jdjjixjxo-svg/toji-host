import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { logger } from "../../utils/logger";
import { updateParticipant, isBotAdminLive } from "../../utils/groupAdmin";

const command: Command = {
  name: "طرد",
  aliases: ["kick"],
  category: "مشرفين",
  description: "طرد عضو من المجموعة (منشن أو رد على رسالته)",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ منشن العضو أو رد على رسالته لطرده.\nمثال: .طرد @user",
      });
      return;
    }

    // 🔧 إصلاح جذري (سبب "أمر الطرد يرفض ويقول لازم أكون مشرف رغم إن
    // البوت مشرف فعليًا"): كان فيه هنا فحص محلي مسبق (isBotAdmin) يقارن
    // رقم/lid البوت يدويًا بقائمة مشاركين المجموعة قبل حتى محاولة الطرد.
    // هذا بالضبط نفس نوع الفحص المحلي غير الموثوق (بسبب أنظمة @lid
    // الحديثة) اللي تقرر إزالته بمكان ثاني بهذا المشروع (راجع تعليق
    // checkPermission بـpermissions.ts، ونفس الإصلاح بأمر .محي) — كان
    // يرفض الطرد حتى لو البوت أدمن حقيقي 100% لأن المطابقة المحلية فشلت.
    // الحل الصحيح (نفس فلسفة المشروع): ما نخمّن محليًا، نحاول الطرد
    // فعليًا مباشرة، وواتساب نفسه (مصدر الحقيقة الوحيد) يرفض بخطأ حقيقي
    // لو البوت مو أدمن فعلًا — والـcatch بالأسفل يتعامل مع هذا الاحتمال.
    try {
      // 🔧 (نفس إصلاح kickDecisionManager.ts) — رسالة الطرد وتنفيذ الطرد
      // منفصلان الآن: فشل الرسالة يُسجَّل ويُتجاوز، والطرد الفعلي دائمًا
      // يُحاول — بدل ما فشل رسالة يمنع الطرد الفعلي بصمت.
      try {
        await ctx.sock.sendMessage(ctx.chatId, {
          text:
            `ـ╭┈➤ 𝑲𝑰𝑪𝑲 ┈╯ـ\n` +
            `✂️ تم إخراج\n` +
            `ـ${jidToMention(target)}ـ\n` +
            `📌 *بواسطة* ـ${jidToMention(ctx.senderJid)}ـ\n` +
            `🕥 *الساعة* ـ${new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}ـ`,
          mentions: [target, ctx.senderJid],
        });
      } catch (msgErr) {
        logger.error("فشل إرسال رسالة الطرد (سيتم تنفيذ الطرد فعليًا رغم ذلك):", msgErr);
      }

      const res = await updateParticipant(ctx.sock, ctx.chatId, "remove", target, ctx.metadata);
      if (!res.ok) {
        const botAdmin = await isBotAdminLive(ctx.sock, ctx.chatId);
        await ctx.sock.sendMessage(ctx.chatId, {
          text: `❌ ما قدرت أطرده.\n${botAdmin === false ? "السبب: البوت نفسه مو مشرف بهذي المجموعة." : `السبب: ${res.reason}`}`,
        });
        return;
      }
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `👢 تم طرد ${jidToMention(target)} من المجموعة.`,
        mentions: [target],
      });
    } catch (err) {
      logger.error("فشل أمر الطرد (.طرد):", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل الطرد. تأكد أن البوت مشرف فعليًا في المجموعة (هذا شرط واتساب نفسه).",
      });
    }
  },
};

export default command;
