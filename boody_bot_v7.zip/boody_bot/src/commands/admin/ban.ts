import { Command } from "../../handlers/types";
import { blockUser } from "../../database/db";
import { getTargetJid, jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "حظر",
  aliases: ["ban"],
  category: "مشرفين",
  description: "منع عضو من استخدام أوامر البوت داخل المجموعة",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ منشن العضو المراد حظره." });
      return;
    }
    blockUser(ctx.chatId, target);
    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🚫 تم حظر ${jidToMention(target)} من استخدام البوت في هذه المجموعة.`,
      mentions: [target],
    });
  },
};

export default command;
