import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "فتح",
  aliases: ["unlock"],
  category: "مشرفين",
  description: "فتح المجموعة للجميع للكتابة",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    try {
      await ctx.sock.groupSettingUpdate(ctx.chatId, "not_announcement");
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "🔓 تم فتح المجموعة، الجميع يمكنهم الكتابة الآن.",
      });
    } catch (err) {
      logger.error("فشل أمر الفتح (.فتح):", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل الفتح. تأكد أن البوت مشرف في المجموعة.",
      });
    }
  },
};

export default command;
