import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { FOOTER_DIVIDER } from "../../utils/theme";
import { getGroupRules } from "../../database/db";

/**
 * 🆕 .القوانين — يعرض قوانين *هذي المجموعة تحديدًا فقط* (كل مجموعة لها
 * قوانينها الخاصة بها، مخزّنة منفصلة تمامًا عن أي مجموعة ثانية — راجع
 * groups.<groupId>.rules بملف db.ts). لو المشرف ما حدد قوانين بعد، يوضح
 * ذلك للمستخدم بدل ما يرد برسالة فاضية أو خطأ.
 */
const command: Command = {
  name: "القوانين",
  aliases: ["قوانين", "rules", "القانون"],
  category: "مشرفين",
  description: "عرض قوانين هذي المجموعة",
  permission: "all",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const rules = getGroupRules(ctx.chatId);

    if (!rules) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ ما فيه قوانين محددة لهذي المجموعة بعد.\n` +
            `المشرف يقدر يحددها بأمر: ${CONFIG.PREFIX}تغيير_القوانين <نص القوانين>`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const text =
      `${FOOTER_DIVIDER}\n      📜 *قوانين المجموعة* 📜\n${FOOTER_DIVIDER}\n\n` +
      `${rules}\n\n` +
      `${FOOTER_DIVIDER}`;

    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
