import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { setGroupRules } from "../../database/db";

/**
 * 🆕 .تغيير_القوانين — يحدد/يحدّث قوانين *هذي المجموعة تحديدًا فقط* (كل
 * مجموعة تخزّن قوانينها بشكل مستقل تمامًا عن أي مجموعة ثانية — راجع
 * groups.<groupId>.rules بملف db.ts). ما يحتاج البوت يكون مشرف واتساب
 * حقيقي (requireBotAdmin: false) لأنه لا ينفذ أي إجراء إشرافي فعلي
 * بواتساب — مجرد تخزين نص بقاعدة البيانات، بنفس منطق .اعدادات.
 */
const command: Command = {
  name: "تغيير_القوانين",
  aliases: ["setrules", "تعديل_القوانين"],
  category: "مشرفين",
  description: "تغيير قوانين هذي المجموعة",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    if (!ctx.text) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ اكتب نص القوانين بعد الأمر.\n` +
            `مثال: ${CONFIG.PREFIX}تغيير_القوانين ١- ممنوع السب\n٢- ممنوع الروابط`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    setGroupRules(ctx.chatId, ctx.text);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `📝 تم تحديث قوانين المجموعة بنجاح.\nلعرضها اكتب: ${CONFIG.PREFIX}القوانين` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
