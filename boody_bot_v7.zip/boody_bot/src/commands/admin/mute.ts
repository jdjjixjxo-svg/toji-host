import { Command } from "../../handlers/types";
import { muteUser } from "../../database/db";
import { getTargetJid, jidToMention, bold, toEnglishDigits } from "../../utils/helpers";
import { logger } from "../../utils/logger";

/**
 * ملاحظة تقنية: واتساب لا يدعم كتم عضو منفرد بشكل رسمي عبر Baileys.
 * البديل العملي المعتمد هنا: البوت يراقب رسائل هذا العضو ويحذفها تلقائيًا
 * طالما هو ضمن قائمة المكتومين (يتطلب أن يكون البوت مشرفًا).
 *
 * 🆕 إضافة: ".كتم <دقائق>" (بدون منشن) — يقفل الكروب بالكامل (مشرفين بس
 * يقدروا يكتبوا) لمدة محددة بالدقايق، وبعدها يفتحه تلقائيًا. مفيد لتهدئة
 * الكروب لفترة قصيرة بدون ما يحتاج المشرف يرجع يفتحه يدويًا.
 */

// مؤقتات الكتم المؤقت الجارية حاليًا لكل كروب (chatId -> timer)
const activeGroupMutes = new Map<string, NodeJS.Timeout>();

const command: Command = {
  name: "كتم",
  aliases: ["mute"],
  category: "مشرفين",
  description: "كتم عضو، أو كتم الكروب بالكامل لمدة دقايق: .كتم 4",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);

    // ===== وضع الكتم المؤقت للكروب بالكامل: .كتم <عدد الدقايق> =====
    if (!target) {
      // 🔧 نفس إصلاح .نون: نحوّل الأرقام العربية الهندية (٠-٩) لإنجليزية
      // قبل Number()، وإلا "٤" مثلًا يرجع NaN رغم إنه رقم صحيح فعليًا.
      const minutes = Number(toEnglishDigits(ctx.args[0] || ""));
      if (!ctx.args[0] || Number.isNaN(minutes) || minutes <= 0) {
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "⚠️ منشن العضو المراد كتمه، أو اكتب عدد الدقايق لكتم الكروب كله.\nمثال: .كتم @user أو .كتم 4",
        });
        return;
      }

      try {
        await ctx.sock.groupSettingUpdate(ctx.chatId, "announcement");
      } catch (err) {
        logger.error("فشل كتم الكروب المؤقت:", err);
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "❌ ما قدرت أقفل الكروب. تأكد إني مشرف بالكروب.",
        });
        return;
      }

      // إلغاء أي مؤقت سابق لنفس الكروب حتى ما يفتح قبل الوقت المطلوب
      const existing = activeGroupMutes.get(ctx.chatId);
      if (existing) clearTimeout(existing);

      await ctx.sock.sendMessage(ctx.chatId, {
        text: `🔇 تم كتم الكروب لمدة ${bold(`${minutes} دقيقة`)}، بيرجع يفتح لحاله.`,
      });

      const timer = setTimeout(async () => {
        activeGroupMutes.delete(ctx.chatId);
        try {
          await ctx.sock.groupSettingUpdate(ctx.chatId, "not_announcement");
          await ctx.sock.sendMessage(ctx.chatId, {
            text: "🔊 خلص وقت الكتم، الكروب رجع مفتوح للجميع.",
          });
        } catch (err) {
          logger.error("فشل فتح الكروب تلقائيًا بعد انتهاء الكتم المؤقت:", err);
        }
      }, minutes * 60_000);

      activeGroupMutes.set(ctx.chatId, timer);
      return;
    }

    // ===== كتم عضو معيّن (السلوك الأصلي) =====
    muteUser(ctx.chatId, target);

    // 🔧 إصلاح (v1.1.4 — سبب "يقول البوت مو مشرف رغم إنه مشرف فعليًا"):
    // قبل كذا كان فيه تحذير محلي هنا مبني على isBotAdmin() — نفس التخمين
    // المحلي غير الموثوق 100% بسبب مشكلة @lid (موضّح بالتفصيل بملف
    // permissions.ts)، واللي أزلناه من بقية أوامر الإشراف لنفس السبب
    // بالضبط (.تثبيت/.طرد/.ترقية/.تنزيل...). كان يطلع التحذير حتى لو
    // البوت مشرف فعليًا، فيبدو للمستخدم إن الأمر "خربان" رغم إنه يشتغل
    // صح. الحذف الفعلي لرسائل المكتوم يتم بحدث رسائل منفصل (مو هذا
    // الملف) وواتساب نفسه هو من يقرر وقتها لو البوت مشرف أو لا — ما
    // فيه داعي نخمن هنا مسبقًا.
    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🔇 تم كتم ${jidToMention(target)} — رح تنحذف رسائله تلقائيًا طالما البوت مشرف بالمجموعة.`,
      mentions: [target],
    });
  },
};

export default command;
