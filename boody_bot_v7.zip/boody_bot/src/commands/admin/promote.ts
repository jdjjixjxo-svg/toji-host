import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { logger } from "../../utils/logger";
import { updateParticipant, isBotAdminLive } from "../../utils/groupAdmin";

const command: Command = {
  name: "ترقية",
  aliases: ["promote"],
  category: "مشرفين",
  description: "ترقية عضو ليصبح مشرفًا",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ منشن العضو المراد ترقيته." });
      return;
    }
    const res = await updateParticipant(ctx.sock, ctx.chatId, "promote", target, ctx.metadata);
    if (res.ok) {
      await ctx.sock.sendMessage(ctx.chatId, { text: `⬆️ تم رفع ${jidToMention(target)} إلى مشرف.`, mentions: [target] }, { quoted: ctx.msg });
      return;
    }
    const botAdmin = await isBotAdminLive(ctx.sock, ctx.chatId);
    logger.error(`فشل أمر الترقية (status=${res.status}):`, res.reason);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `❌ ما قدرت أرفعه مشرف.\n${botAdmin === false ? "السبب: البوت نفسه مو مشرف بهذي المجموعة — ارفعه مشرف أولًا." : `السبب: ${res.reason}`}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
