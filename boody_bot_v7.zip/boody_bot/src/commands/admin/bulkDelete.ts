import { Command } from "../../handlers/types";
import { takeRecentMessageKeys } from "../../handlers/recentMessages";

/**
 * .محي <رقم> — يحذف العدد المطلوب من آخر الرسائل بهذي المجموعة (أي نوع:
 * نص/وسائط/ملصق)، ضمن حدود واتساب الفعلية.
 *
 * 🔧 إصلاح (سبب "يمحي بس رسايل البوت"): كان فيه فحص محلي مسبق "هل البوت
 * أدمن؟" (isBotAdmin) يقارن رقم/lid البوت يدويًا، ولو رجّع false كان
 * يستبعد رسائل بقية الأعضاء بالكامل قبل حتى المحاولة — نفس فخ فحص
 * "الأدمن الوهمي" اللي انحل بمكان ثاني بالمشروع (راجع تعليق checkPermission
 * بـpermissions.ts): مقارنة الأرقام محليًا غير موثوقة 100% بسبب أنظمة
 * @lid الحديثة، فكانت ترفض حذف رسائل الآخرين حتى لو البوت أدمن فعليًا.
 * الحل الصحيح (نفس فلسفة المشروع الموثّقة أصلًا): ما نخمّن محليًا — نحاول
 * حذف كل رسالة مسجّلة فعليًا (بوت أو غيره)، وواتساب نفسه (مصدر الحقيقة
 * الوحيد) يرفض اللي ما يقدر عليها فعلًا. العدد الناجح/الفاشل الحقيقي
 * يعكس هذا بالضبط، بدون أي وعد كاذب.
 */
const command: Command = {
  name: "محي",
  aliases: ["مسح_رسائل", "حذف_رسائل", "purge"],
  category: "مشرفين",
  description: "يحذف آخر عدد من الرسائل بالمجموعة. مثال: .محي 50",
  permission: "admin",
  requireBotAdmin: false, // نتحقق ونشرح بأنفسنا بالأسفل بدل رفض عام مبهم
  groupOnly: true,
  execute: async (ctx) => {
    const countArg = parseInt(ctx.args[0], 10);
    if (!countArg || countArg < 1) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ حدد عدد صحيح. مثال: .محي 50" },
        { quoted: ctx.msg }
      );
      return;
    }
    // سقف أمان معقول — حذف مئات الرسائل دفعة وحدة يضرب Rate limit واتساب
    // ويخلي أغلبها يفشل فعليًا، فنمنع رقم غير واقعي بدل وعد كاذب.
    const count = Math.min(countArg, 200);

    const keys = takeRecentMessageKeys(ctx.sock, ctx.chatId, count);

    if (!keys.length) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ ما فيه رسائل مسجّلة بالذاكرة المؤقتة لحذفها (البوت يسجّل الرسائل بعد انضمامه فقط، ولا يقدر يحذف رسائل قبل تشغيله)." },
        { quoted: ctx.msg }
      );
      return;
    }

    let success = 0;
    let failed = 0;
    let failedOthers = 0;
    for (const k of keys) {
      try {
        await ctx.sock.sendMessage(ctx.chatId, {
          delete: {
            remoteJid: ctx.chatId,
            id: k.id,
            fromMe: k.fromMe,
            participant: k.fromMe ? undefined : k.participant,
          },
        });
        success++;
      } catch {
        failed++;
        if (!k.fromMe) failedOthers++;
      }
    }

    const parts = [`🗑️ تم حذف ${success} من أصل ${keys.length} رسالة.`];
    if (failedOthers) {
      parts.push(
        `⚠️ فشل حذف ${failedOthers} من رسائل أعضاء آخرين — تأكد إن البوت أدمن فعليًا بالمجموعة (هذا شرط واتساب نفسه، مو قيد من عندنا).`
      );
    }
    if (failed - failedOthers > 0) {
      parts.push(`⚠️ فشل حذف ${failed - failedOthers} رسالة إضافية (غالبًا قديمة جدًا رفضها واتساب).`);
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: parts.join("\n") }, { quoted: ctx.msg });
  },
};

export default command;
