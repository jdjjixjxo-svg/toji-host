import { Command } from "../../handlers/types";
import { isGroupAdmin } from "../../middlewares/permissions";

const command: Command = {
  name: "منشن",
  aliases: ["الكل", "tagall"],
  category: "مشرفين",
  description: "منشن جميع الأعضاء، أو المشرفين بس: .منشن 1",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    if (!ctx.metadata) return;

    const adminsOnly = ctx.args[0] === "1";
    const allParticipants = ctx.metadata.participants.map((p) => p.id);
    const participants = adminsOnly
      ? allParticipants.filter((id) => isGroupAdmin(ctx.metadata!, id))
      : allParticipants;

    if (adminsOnly && participants.length === 0) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ ما لقيت مشرفين بالكروب.", __skipBrand: true } as any);
      return;
    }

    const note =
      (adminsOnly ? ctx.text.replace(/^1\s*/, "") : ctx.text) ||
      (adminsOnly ? "📢 نداء للمشرفين" : "📢 تنبيه لجميع الأعضاء");

    // 🔧 إصلاح: كانت الرسالة تعرض قائمة بكل الأعضاء (@شخص1 @شخص2 ...) داخل
    // النص، وهذا يجعلها طويلة ومزعجة في المجموعات الكبيرة. الآن نرسل فقط
    // النص المكتوب من المستخدم، وتصل إشعارات المنشن لكل الأعضاء عبر حقل
    // "mentions" بالخلفية (مدعوم من واتساب/Baileys) دون إظهار أسمائهم
    // أو أرقامهم داخل الرسالة.
    // 🔧 (طلب صريح: إزالة الأزرار عن .منشن) — __skipBrand يمنع البراندنج
    // التلقائي (اللي يحوّل أي رد نصي بسيط لرسالة أزرار) لهذا الأمر تحديدًا.
    await ctx.sock.sendMessage(ctx.chatId, {
      text: note,
      mentions: participants,
      __skipBrand: true,
    } as any);
  },
};

export default command;
