import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

// أطول مدة تثبيت متاحة رسميًا بواتساب (خيارات واتساب: 24 ساعة / 7 أيام / 30 يوم)
const THIRTY_DAYS_SECONDS = 30 * 24 * 60 * 60;

const command: Command = {
  name: "تثبيت",
  aliases: ["pin", "ثبت"],
  category: "مشرفين",
  description: "يثبت رسالة معينة لأطول مدة ممكنة (رد على الرسالة واكتب .تثبيت)",
  permission: "admin",
  requireBotAdmin: false,
  groupOnly: true,
  execute: async (ctx) => {
    const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
    if (!contextInfo?.stanzaId || !contextInfo?.participant) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ رُد على الرسالة اللي تبي تثبتها واكتب .تثبيت" },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🔧 إصلاح مهم (سبب "امر .تثبيت يقول البوت مو مشرف رغم إنه مشرف
    // فعليًا"): كان هذا الأمر وحده يستخدم فحص isBotAdmin محلي *يمنع*
    // التنفيذ مسبقًا بناءً على تخمين محلي بمقارنة أرقام/lid — نفس الفحص
    // غير الموثوق 100% الموضّح بالتفصيل بـ middlewares/permissions.ts،
    // والذي أُزيل من باقي أوامر الإشراف (.طرد/.ترقية/.تنزيل...) لنفس
    // السبب. الحين نترك واتساب نفسه يقرر (نحاول التنفيذ الفعلي)، ونمسك
    // الفشل الحقيقي بالـ catch تحت بنفس رسالة "تأكد إن البوت مشرف" —
    // بدل ما نمنع الأمر بتخمين محلي قد يخطئ رغم أن البوت مشرف فعليًا.
    try {
      await ctx.sock.sendMessage(ctx.chatId, {
        pin: {
          remoteJid: ctx.chatId,
          fromMe: false,
          id: contextInfo.stanzaId,
          participant: contextInfo.participant,
        },
        type: 1, // PIN_FOR_ALL
        time: THIRTY_DAYS_SECONDS,
      } as any);

      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "📌 تم تثبيت الرسالة لأطول مدة ممكنة (30 يوم)." },
        { quoted: ctx.msg }
      );
    } catch (err) {
      // ⚠️ ملاحظة: خاصية تثبيت الرسائل حديثة نسبيًا بواتساب، ودعمها داخل
      // مكتبة الاتصال قد يختلف حسب الإصدار المثبّت — لهذا أي فشل هنا
      // يُعامل بلطف بدل ما يكسر الأمر بالكامل.
      logger.warn("⚠️ تعذر تثبيت الرسالة:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر تثبيت الرسالة. تأكد إن البوت مشرف وحاول مرة ثانية." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
