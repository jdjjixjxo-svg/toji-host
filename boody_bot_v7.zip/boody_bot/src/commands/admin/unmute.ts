import { Command } from "../../handlers/types";
import { unmuteUser } from "../../database/db";
import { getTargetJid, jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "فك_الكتم",
  aliases: ["unmute", "فك"],
  category: "مشرفين",
  description: "فك كتم عضو",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ منشن العضو المراد فك كتمه." });
      return;
    }
    unmuteUser(ctx.chatId, target);
    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🔊 تم فك الكتم عن ${jidToMention(target)}.`,
      mentions: [target],
    });
  },
};

export default command;
