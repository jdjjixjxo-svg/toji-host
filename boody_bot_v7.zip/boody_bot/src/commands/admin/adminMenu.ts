import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons, buildSingleSelectButton } from "../../utils/interactive";
import { ADMIN_EXTRA_ROWS } from "../../utils/menuRows";
import { adminMenuText } from "../../utils/menuTemplates";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "مشرفين",
  aliases: ["admin", "ادارة", "إدارة"],
  category: "مشرفين",
  description: "عرض قائمة أوامر المشرفين",
  permission: "all",
  execute: async (ctx) => {
    const text = adminMenuText();

    // أوامر بدون أي مدخل مطلوب (منشن كل الكروب / قفل / فتح) → أزرار.
    // بقية أوامر الإشراف (طرد/حظر/كتم/ترقية...) تبقى كتابية عمدًا لأنها
    // تحتاج تحديد شخص بمنشن أو رد على رسالته، زي ما طلبت بالضبط.
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("admin") || undefined,
      extraButtons: [buildSingleSelectButton("🛡️ أوامر متقدمة", "أوامر المشرفين المتقدمة", ADMIN_EXTRA_ROWS)],
      quickButtons: [
        sectionButton("منشن", "📢 منشن الكل"),
        sectionButton("قفل", "🔒 قفل الكتابة"),
        sectionButton("فتح", "🔓 فتح الكتابة"),
        ...navButtons(),
      ],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
