import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { addWarning } from "../../database/db";
import { getTargetJid, jidToMention, bold } from "../../utils/helpers";
import { startKickDecision } from "../../handlers/kickDecisionManager";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "انذار",
  aliases: ["warn", "تحذير", "نذار"],
  category: "مشرفين",
  description: "انذار لعضو (منشن أو رد على رسالته) — بعد 3 انذارات يُكتم وتُرسل رسالة قرار للمشرفين (طرد/إعفاء/إبقاء بـ2)",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ منشن العضو أو رد على رسالته عشان تنذره.\nمثال: .نذار @user",
      });
      return;
    }

    const mention = jidToMention(target);
    const count = addWarning(ctx.chatId, target);

    // 🆕 خاصية النذار على الخاص أُلغيت بالكامل — النذار الآن يُرسل فقط
    // داخل المجموعة نفسها (رسالة واحدة بالأسفل)، بدون أي رسالة خاصة للعضو.

    // ===== 🔧 (طلب صريح: "لا تخليه يطرد حد تلقائي") =====
    // وصل العضو لعدد النذارات المسموح — قبل كذا كان يُطرد تلقائيًا هنا.
    // الآن: يُكتم فقط، وتُرسل رسالة قرار (بصورة بروفايله + 3 أزرار) تسمح
    // للمشرفين يقرروا طرده أو إعفاءه أو إبقاءه بـ 2 نذار — راجع
    // src/handlers/kickDecisionManager.ts للتفاصيل الكاملة.
    if (count >= CONFIG.MAX_WARNINGS) {
      if (!ctx.metadata) {
        // احتياط نظري: لو تعذر جلب بيانات المجموعة، ما نقدر نحدد
        // المشرفين للمنشن المخفي — نرجّع نذار عادي بدل ما نكسر الأمر.
        await ctx.sock.sendMessage(ctx.chatId, {
          text: `⚠️ نذار لـ ${mention} — (${bold(`${count}/${CONFIG.MAX_WARNINGS}`)}) — تعذر بدء تدفق قرار الطرد (تعذر جلب بيانات المجموعة).`,
          mentions: [target],
        });
        return;
      }
      try {
        await startKickDecision(ctx.sock, ctx.chatId, target, ctx.metadata);
      } catch (err) {
        logger.error("فشل بدء تدفق قرار الطرد بعد اكتمال النذارات:", err);
      }
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, {
      text:
        `▁▂▃▄ـ⚠ـ▄▃▂▁\n` +
        `*تحذير رسمي*\n` +
        `▸ ـ${mention}ـ\n` +
        `▸ *العدد* ـ${bold(`${count}/${CONFIG.MAX_WARNINGS}`)}ـ\n` +
        `🕥 *الساعة* ـ${new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}ـ\n\n` +
        ` _آخر فرصة قبل الطرد_`,
      mentions: [target],
    });
  },
};

export default command;
