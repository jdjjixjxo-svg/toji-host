import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { logger } from "../../utils/logger";
import { updateParticipant, isBotAdminLive } from "../../utils/groupAdmin";

const command: Command = {
  name: "تنزيل",
  aliases: ["demote", "خفض"],
  category: "مشرفين",
  description: "تنزيل مشرف ليصبح عضوًا عاديًا",
  permission: "admin",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ منشن المشرف المراد تنزيله." });
      return;
    }
    const res = await updateParticipant(ctx.sock, ctx.chatId, "demote", target, ctx.metadata);
    if (res.ok) {
      await ctx.sock.sendMessage(ctx.chatId, { text: `⬇️ تم تنزيل ${jidToMention(target)} من الإشراف.`, mentions: [target] }, { quoted: ctx.msg });
      return;
    }
    const botAdmin = await isBotAdminLive(ctx.sock, ctx.chatId);
    logger.error(`فشل أمر التنزيل (status=${res.status}):`, res.reason);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `❌ ما قدرت أنزّله.\n${botAdmin === false ? "السبب: البوت نفسه مو مشرف بهذي المجموعة." : `السبب: ${res.reason}`}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
