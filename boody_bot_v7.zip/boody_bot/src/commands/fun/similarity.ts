import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

const COMPARES: string[] = [
  "القطة 🐱 — لطيف بس مزاجي شوي",
  "الأسد 🦁 — قائد بالفطرة",
  "الباندا 🐼 — هادئ ومحبوب من الجميع",
  "الثعلب 🦊 — ذكي وسريع البديهة",
  "البومة 🦉 — حكيم ويسهر كثير",
  "الدلفين 🐬 — اجتماعي ومرح",
  "النمر 🐯 — قوي وواثق من نفسه",
  "الأرنب 🐰 — سريع وخفيف الظل",
];

const command: Command = {
  name: "تشبيه",
  aliases: ["similarity"],
  category: "ترفيه",
  description: "يشبّهك (أو شخص آخر) بشي طريف. مثال: .تشبيه @شخص",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `🔍 ${jidToMention(target)} يشبه... *${pickRandom(COMPARES)}*`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
