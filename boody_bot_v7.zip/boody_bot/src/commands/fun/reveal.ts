import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

/**
 * ".كشف" — يحاول يكشف مين "أونلاين" الحين بالمجموعة عن طريق الاشتراك الفعلي
 * بحالة الحضور (presence) من واتساب نفسه، مو تخمين أو نتيجة عشوائية.
 *
 * ملاحظة مهمة (وضّحناها برسالة الفشل نفسها): واتساب يخفي حالة "متصل الآن"
 * افتراضيًا عن أي رقم مو محفوظ عندك كجهة اتصال بخصوصية أغلب المستخدمين،
 * فالنتيجة تعتمد على إعدادات خصوصية كل عضو — مو قصور بالبوت. لأمانة النتيجة
 * ما نعرض شي مفبرك لو ما انكشف حد فعليًا.
 */
const WAIT_MS = 3000;

const command: Command = {
  name: "كشف",
  aliases: ["reveal", "المتصلين"],
  category: "ترفيه",
  description: "يحاول يكشف الأعضاء المتصلين الحين بالمجموعة (بدون منشن جماعي للكل)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (!ctx.metadata) return;

    await ctx.sock.sendMessage(ctx.chatId, { text: "🔎 جاري الكشف... ثواني 👀" });

    const onlineNow = new Set<string>();

    const handler = (update: any) => {
      const presences = update?.presences;
      if (!presences) return;
      for (const jid of Object.keys(presences)) {
        const state = presences[jid]?.lastKnownPresence;
        if (state === "available" || state === "composing" || state === "recording") {
          onlineNow.add(jid);
        }
      }
    };

    ctx.sock.ev.on("presence.update", handler);
    try {
      await ctx.sock.presenceSubscribe(ctx.chatId);
    } catch {
      // تجاهل بأمان — أحيانًا واتساب يرفض الاشتراك المتكرر بفارق وقت قصير
    }

    await new Promise((resolve) => setTimeout(resolve, WAIT_MS));
    ctx.sock.ev.off("presence.update", handler);

    // نطابق JIDs الحضور مع قائمة أعضاء المجموعة الرسمية (ctx.metadata.participants)
    // لأن واتساب أحيانًا يرجّع صيغة @lid من الحضور بدل @s.whatsapp.net، وهذا
    // كان يمنع المنشن من الظهور صح. هذا التطابق يضمن منشن سليم دائمًا.
    const knownParticipants = ctx.metadata?.participants.map((p) => p.id) || [];
    const phoneOf = (jid: string) => jid.split("@")[0].split(":")[0];
    const onlinePhones = new Set(Array.from(onlineNow, phoneOf));

    onlineNow.delete(ctx.senderJid); // احتياط إضافي بالصيغة الأصلية
    const senderPhone = phoneOf(ctx.senderJid);

    const targets = knownParticipants.filter(
      (jid) => onlinePhones.has(phoneOf(jid)) && phoneOf(jid) !== senderPhone
    );

    if (targets.length === 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "🙈 ما قدرنا نكشف حد أونلاين الحين.\n" +
            "السبب الأغلب: خصوصية واتساب تخفي حالة \"متصل الآن\" عن أي رقم مو محفوظ عند العضو — مو تقصير من البوت.",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const list = targets.map((jid) => `• ${jidToMention(jid)}`).join("\n");
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `👀 مكشوفين الحين:\n${list}`,
        mentions: targets,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
