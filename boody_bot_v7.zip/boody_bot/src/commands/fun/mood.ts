import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

/**
 * 🆕 أمر ".مزاج_البوت" — "نفسية البوت اليومية". مزاج البوت يتغيّر مرة
 * وحدة كل يوم (نفس المزاج لكل من يسأل بنفس اليوم، ثم يتغيّر تلقائيًا
 * بيوم جديد) بدون أي تخزين إضافي — مبني على رقم اليوم فقط (deterministic).
 * أمر "غريب بدون داعي" بطلب صريح من صاحب البوت.
 */
const MOODS: { emoji: string; label: string; note: string }[] = [
  { emoji: "😎", label: "فاهم كل شي اليوم", note: "اسألني أي شي وبردلك بثقة زايدة" },
  { emoji: "😴", label: "نعسان شوي", note: "الردود بطيئة اليوم شوي، اصبروا علي" },
  { emoji: "🔥", label: "نشيط ومزاجي حديدي", note: "جاهز لأي فعالية أو تحدي اليوم" },
  { emoji: "🙃", label: "فلسفي أكثر من اللازم", note: "كل رد اليوم فيه حكمة ما طلبتوها" },
  { emoji: "😹", label: "مود ساخر", note: "ما اضمن ردودي، ممكن تجيكم نكتة بدل الجواب" },
  { emoji: "🥶", label: "بارد ومقتضب", note: "ردود قصيرة اليوم، بدون حشو" },
  { emoji: "🤓", label: "جدّي ومركّز", note: "اليوم يوم الجدية، بلا مزح كثير" },
  { emoji: "🎭", label: "متقلب المزاج", note: "لا تستغربون لو تناقضت بردودي اليوم" },
];

function dayIndex(): number {
  const start = new Date(Date.UTC(2026, 0, 1)).getTime();
  const now = Date.now();
  const days = Math.floor((now - start) / (24 * 60 * 60 * 1000));
  return ((days % MOODS.length) + MOODS.length) % MOODS.length;
}

/** نسبة "الجنون" — ثابتة لكل شخص بحسب رقمه (deterministic) + تتغير مع اليوم */
function crazyMeter(jid: string): number {
  let hash = 0;
  const seed = `${jid}-${dayIndex()}`;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return hash % 101; // 0-100
}

const command: Command = {
  name: "مزاج_البوت",
  aliases: ["مزاج"], // 🔧 شلنا alias "mood" (كان يتعارض مع .تحليل_المزاج)
  category: "ترفيه",
  description: "يعرض مزاج البوت اليوم، ونسبة الجنون الخاصة فيك 😂",
  permission: "all",
  execute: async (ctx) => {
    const mood = MOODS[dayIndex()];
    const crazy = crazyMeter(ctx.senderJid);
    const mention = jidToMention(ctx.senderJid);
    const text =
      `${mention}\n` +
      `${mood.emoji} *مزاج البوت اليوم:* ${mood.label}\n` +
      `📝 ${mood.note}\n\n` +
      `🌀 *نسبة جنونك اليوم:* ${crazy}%`;
    await ctx.sock.sendMessage(ctx.chatId, { text, mentions: [ctx.senderJid] }, { quoted: ctx.msg });
  },
};

export default command;
