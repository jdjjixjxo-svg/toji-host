import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { funMenuText } from "../../utils/menuTemplates";
import { FUN_EXTRA_ROWS } from "../../utils/menuRows";

const command: Command = {
  name: "ترفيه",
  // نُبقي الأسماء القديمة كأسماء بديلة حتى لا ينكسر أي استخدام سابق
  // 🔧 إصلاح مهم: كان فيه هنا alias اسمه "فعاليه" (بالهاء) — وهذا نفس الشكل
  // اللي يتحول له اسم أمر ".فعالية" (بالتاء المربوطة) بعد التوحيد الداخلي
  // للأحرف العربية (ة/ه تُعاملان كحرف واحد بالمطابقة). كان هذا يسبب تعارض:
  // كتابة ".فعالية" (الأمر الحقيقي بـ startQuiz.ts، للمشرفين فقط) كانت
  // تُحوَّل دايمًا لهذا القسم (ترفيه، مفتوح للجميع) بدل ما تشغّل الفعالية
  // الفعلية أبدًا — لأن جدول الأسماء البديلة (aliasMap) له أولوية أعلى من
  // اسم الأمر المباشر عند تطابق نفس المفتاح. حذفناه من هنا حتى يرجع اسم
  // ".فعالية" يشتغل صح ويترابط بأمره الحقيقي المخصص للمشرفين.
  // 🔧 ملاحظة: أزلنا "العاب"/"ألعاب"/"games" من هنا — صارت تقصد قسم
  // "ألعاب 2D" الجديد تحديدًا (commands/games2d/games2dMenu.ts) بدل هذا
  // القسم. ألعاب الفرفشة السريعة هنا (إكس_او، حجر_ورقة_مقص...) تبقى
  // بنفس مكانها، بس عبر أسماء "ترفيه/fun/فعاليات" فقط.
  aliases: ["fun", "فعاليات", "events", "ترفيهات"],
  category: "ترفيه",
  description: "عرض كل أوامر الترفيه: ألعاب، فعاليات جماعية، ومرح",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;
    const text = funMenuText();


    // ملاحظة: الأوامر اللي تحتاج منشن (تنمر/عقاب/تسفيل/مديح/تقييم/حب/زواج/تشبيه/إكس_أو)
    // أو نص إضافي (اختيار/عكس/حجر_ورقة_مقص) أو فئة (حزورة/فعالية) — بتقصد
    // تبقى كتابية فقط لأنها تحتاج مدخل من المستخدم، زي ما طلبت بالضبط.
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("fun") || undefined,
      // 🆕 زر واحد يفتح قائمة اختيار بدل صف الأزرار الطويل السابق
      extraButtons: [
        buildSingleSelectButton("👇 اختر فعالية", "أوامر الترفيه", [
          { command: "اعلام", label: "🌍 اعلام" },
          { command: "لغز", label: "🧩 لغز" },
          { command: "ايموجي", label: "😀 ايموجي" },
          { command: "اكمل", label: "📝 اكمل" },
          { command: "رياضيات", label: "➗ رياضيات" },
          { command: "سرعة", label: "⌨️ سرعة" },
          { command: "خمن", label: "🖼️ خمن" },
          { command: "صح_او_خطا", label: "✅❌ صح او خطأ" },
          { command: "استسلم", label: "🏳️ استسلم" },
          { command: "دلع", label: "💌 دلع" },
          { command: "الترتيب", label: "🏆 الترتيب" },
          { command: "رمي_النرد", label: "🎲 رمي النرد" },
          { command: "نكتة", label: "😂 نكتة" },
          { command: "حكمة", label: "🦉 حكمة" },
          { command: "حقيقة", label: "💡 حقيقة" },
          { command: "تحدي", label: "🔥 تحدي" },
          { command: "ميم", label: "🤡 ميم" },
          { command: "قرعة", label: "🎟️ قرعة" },
          { command: "انمي", label: "📺 انمي" },
          { command: "اقتباس", label: "✨ اقتباس" },
          { command: "كشف", label: "👀 كشف" },
          { command: "عذر", label: "📋 عذر" },
          { command: "زخرفة", label: "✨ زخرفة" },
          { command: "مزاج_البوت", label: "🌀 مزاج البوت" },
          ...FUN_EXTRA_ROWS,
          { command: "menu", label: "🏠 القائمة الرئيسية" },
        ]),
      ],
      fallbackNote: `اكتب أمر أي فعالية مباشرة، أو للرجوع للقائمة الرئيسية: ${p}menu`,
    });
  },
};

export default command;
