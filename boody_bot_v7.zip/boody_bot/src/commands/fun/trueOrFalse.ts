import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { getGroupSettings } from "../../database/db";
import { pickRandom } from "../../utils/fun";
import { buildEventCard } from "../../utils/miniQuiz";

/**
 * 🆕 لعبة "صح أو خطأ": البوت يرمي معلومة عشوائية (بعضها صحيح وبعضها
 * خطأ عمدًا)، وتحتها زرين (✅ صح / ❌ خطأ). أول شخص يضغط الزر الصحيح
 * يفوز بنفس آلية باقي الفعاليات (نقطة + عملات بنكية عبر eventManager).
 */
interface TrueFalseItem {
  statement: string;
  isTrue: boolean;
}

const STATEMENTS: TrueFalseItem[] = [
  { statement: "🦈 سمك القرش أقدم من الأشجار على كوكب الأرض", isTrue: true },
  { statement: "🐘 الفيل هو الحيوان البري الوحيد اللي ما يقدر يقفز", isTrue: true },
  { statement: "🌍 الأرض هي الكوكب الوحيد اللي فيه ماء بالمجموعة الشمسية كلها بدون استثناء", isTrue: false },
  { statement: "🍯 العسل ما يفسد أبدًا حتى لو مر عليه آلاف السنين", isTrue: true },
  { statement: "🧠 الإنسان يستخدم 10% بس من دماغه طول حياته", isTrue: false },
  { statement: "🦩 لون النحام (الفلامنجو) الوردي سببه نوع الطعام اللي ياكله", isTrue: true },
  { statement: "🌕 القمر عنده جاذبية أقوى من جاذبية الأرض", isTrue: false },
  { statement: "🐧 كل أنواع طيور البطريق تعيش بالقارة القطبية الجنوبية بس", isTrue: false },
  { statement: "🍅 الطماطم فاكهة علميًا مش خضار", isTrue: true },
  { statement: "🕷️ العناكب كلها حشرات", isTrue: false },
  { statement: "🐙 الأخطبوط عنده 3 قلوب ودمه لونه أزرق", isTrue: true },
  { statement: "⚡ البرق أسخن من سطح الشمس لحظة حدوثه", isTrue: true },
  { statement: "🦴 جسم الإنسان البالغ فيه نفس عدد عظام الطفل الرضيع بالضبط", isTrue: false },
  { statement: "🐜 النمل ما ينام أبدًا طول حياته", isTrue: true },
  { statement: "🌋 كل البراكين بالعالم منطفئة ومافيه بركان نشط حاليًا", isTrue: false },
];

const command: Command = {
  name: "صح_او_خطا",
  aliases: ["صح_ام_خطأ", "صح_خطا", "truefalse"],
  category: "ترفيه",
  description: "فعالية صح أو خطأ: البوت يرمي معلومة وتحتها زرين، خمّن صح ولا غلط",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const settings = getGroupSettings(ctx.chatId);
    if (!settings.events) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ نظام الفعاليات متوقف بهالكروب. شغّله بـ: .اعدادات فعاليات تشغيل",
      });
      return;
    }

    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ فيه فعالية شغالة حاليًا! استنى تخلص أو استخدم .استسلم",
      });
      return;
    }

    const item = pickRandom(STATEMENTS);
    const correctAnswer = item.isTrue ? "صح" : "خطأ";
    const timeoutMs = 30_000;

    eventManager.start(ctx.sock as any, ctx.chatId, "صح أو خطأ", correctAnswer, timeoutMs);

    const groupName = ctx.metadata?.subject || "الخاص";
    const card = buildEventCard(
      groupName,
      "صح أو خطأ!",
      `❓ ${item.statement}`,
      "اكتب «صح» أو «خطأ» بالمجموعة — أول جواب صحيح يفوز.",
      `⏱️ لديك ${Math.round(timeoutMs / 1000)} ثانية فقط!`
    );

    await ctx.sock.sendMessage(ctx.chatId, { text: card });
  },
};

export default command;
