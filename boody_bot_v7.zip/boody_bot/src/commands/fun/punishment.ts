import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

const PUNISHMENTS: string[] = [
  "يرسل ملصق مضحك لكل أعضاء الكروب 😂",
  "يغيّر اسمه بالواتساب لمدة ساعة لأغرب اسم يختاره الأعضاء 😆",
  "يكتب اعتذار مضحك مبالغ فيه عن أي شي 😂",
  "يرسل صوت وهو يغني أي أغنية (تخيليًا 😄)",
  "يمدح كل شخص بالكروب بجملة واحدة مضحكة",
  "ما يحق له يشتكي من الجو لمدة يوم كامل 😅",
];

const command: Command = {
  name: "عقاب",
  aliases: ["punishment"],
  category: "ترفيه",
  description: "عقاب وهمي طريف لشخص (للفرفشة بس). مثال: .عقاب @شخص",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `⚖️ عقاب ${jidToMention(target)}: ${pickRandom(PUNISHMENTS)}`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
