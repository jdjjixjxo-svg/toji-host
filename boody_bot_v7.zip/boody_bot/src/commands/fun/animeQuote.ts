import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

// اقتباسات أصلية بروح الأنمي (مو منقولة حرفيًا من أي عمل محمي بحقوق نشر)
const QUOTES: string[] = [
  "مو مهم كم مرة تقع، المهم كم مرة تقوم وتكمل الطريق 🔥",
  "القوة الحقيقية تجيك من اللي تحبهم، مو من قوتك وحدك 🌟",
  "الخوف طبيعي، بس اللي يفرقك هو إنك تتحرك رغم خوفك ⚔️",
  "الحلم اللي ما يخليك تنام، هو نفسه اللي بيوصلك 🌙",
  "حتى أضعف خطوة للأمام أفضل من الوقوف بمكانك للأبد 👣",
  "الأصدقاء الحقيقيين يصيرون قوة إضافية بمعاركك 🤝",
];

const command: Command = {
  name: "اقتباس",
  aliases: ["quote"],
  category: "ترفيه",
  description: "اقتباس تحفيزي بروح الأنمي",
  permission: "all",
  execute: async (ctx) => {
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎌 «${pickRandom(QUOTES)}»` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
