import { Command } from "../../handlers/types";

const command: Command = {
  name: "عكس",
  aliases: ["reverse"],
  category: "ترفيه",
  description: "يعكس أي نص تكتبه. مثال: .عكس مرحبا",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim();
    if (!text) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ اكتب نص بعد الأمر. مثال: .عكس مرحبا" },
        { quoted: ctx.msg }
      );
      return;
    }
    const reversed = [...text].reverse().join("");
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🔁 ${reversed}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
