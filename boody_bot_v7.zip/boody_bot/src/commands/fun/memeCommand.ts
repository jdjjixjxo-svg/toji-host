import { Command } from "../../handlers/types";
import sharp from "sharp";
import fs from "fs";
import path from "path";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * 🔧 إعادة بناء كاملة (طلب صريح: "خليه صورة مش نص") — قبل كذا كان
 * الأمر يرسل نص عادي بس، والمطلوب صورة ميم حقيقية (خلفية + كتابة فوقها،
 * نفس ستايل الميمز المعروف).
 *
 * الطريقة: 5 رسومات أصلية بسيطة مرفقة بالمشروع (assets/memes/*.jpg —
 * مو صور محمية بحقوق نشر، رسمناها من الصفر) + مجموعة كتابات مضحكة عامة
 * تنطبق على أي مشهد منها، وندمجهم وقت التشغيل عبر sharp (نفس مكتبة
 * الصور المستخدمة أصلًا بالمشروع لأمر .صوره) بستايل الميمز الكلاسيكي:
 * كتابة بيضاء بحد أسود فوق الصورة.
 */
const MEMES_DIR = path.resolve(process.cwd(), "assets", "memes");
const TEMPLATES = ["rain_dog.jpg", "shrug.jpg", "facepalm.jpg", "sleepy_cat.jpg", "running.jpg"];

const CAPTIONS: string[] = [
  "أنا وكت أحزن",
  "أنا لما أشوف الفلوس تخلص قبل نص الشهر",
  "أنا يوم الاثنين الصبح",
  "أنا لما أذاكر يوم قبل الامتحان",
  "أنا لما أحد يسألني وين الفلوس اللي استلفتها",
  "أنا بعد ما أوعد نفسي أنام بدري",
  "أنا لما أشوف رصيدي بالبنك",
  "أنا لما أحد يقولي \"شكلك تعبان\"",
  "أنا لما أفتح الثلاجة بنص الليل",
  "أنا لما الواي فاي يقطع بأهم لحظة",
  "أنا لما أدور شغل وما ألقى",
  "أنا لما أحاول أبان طبيعي وأنا مو",
  "أنا لما يسألوني \"وين وصلت بحياتك؟\"",
  "أنا لما أحد يذكرني بغلطة قديمة",
  "أنا لما أشتغل يوم إجازة",
  "أنا بعد لايك وحد ما اقصده بالغلط",
  "أنا لما أحد يقول \"بس دقيقة وخلصنا\"",
  "أنا لما أشوف نفس الخبر يتكرر كل يوم",
  "أنا لما أحاول أوفر واشتري كل شي بروح",
  "أنا لما اصحى الساعة اللي نمت فيها بالضبط",
  "أنا لما أدور عذر معقول للتأخير",
  "أنا لما أشوف طلب الأكل وصل بارد",
  "أنا لما أقول هذا آخر أسبوع وأنا أعرف إنه مو",
  "أنا وأنا أحاول أفهم الفاتورة",
  "أنا لما أحد يسألني \"شفيك ساكت؟\"",
];

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** يبني SVG نص بستايل الميمز الكلاسيكي (أبيض بحد أسود) فوق الصورة */
function buildCaptionSvg(text: string, width: number): string {
  const fontSize = Math.round(width / 14);
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return `
    <svg width="${width}" height="${fontSize * 2.6}" xmlns="http://www.w3.org/2000/svg">
      <style>
        .caption {
          font: bold ${fontSize}px Sans-Serif;
          fill: white;
          stroke: black;
          stroke-width: ${Math.max(2, Math.round(fontSize / 14))};
          paint-order: stroke;
        }
      </style>
      <text x="50%" y="55%" text-anchor="middle" dominant-baseline="middle" class="caption">${escaped}</text>
    </svg>
  `;
}

const command: Command = {
  name: "ميمز",
  aliases: ["ميم", "meme"],
  category: "ترفيه",
  description: "ميم عشوائي (صورة + كتابة) مو نص بس",
  permission: "all",
  execute: async (ctx) => {
    try {
      const templateFile = pickRandom(TEMPLATES);
      const templatePath = path.join(MEMES_DIR, templateFile);
      if (!fs.existsSync(templatePath)) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "❌ ملفات الميمز غير موجودة بالسيرفر (assets/memes). خبر المطور." },
          { quoted: ctx.msg }
        );
        return;
      }

      const caption = pickRandom(CAPTIONS);
      const base = sharp(templatePath);
      const meta = await base.metadata();
      const width = meta.width || 800;
      const svg = Buffer.from(buildCaptionSvg(caption, width));

      const finalImage = await base
        .composite([{ input: svg, top: Math.round((meta.height || 800) * 0.03), left: 0 }])
        .jpeg({ quality: 88 })
        .toBuffer();

      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: finalImage },
        { quoted: ctx.msg }
      );
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .ميمز:", err);
      await notifyOwnerOfError(ctx.sock, ".ميمز", reason, {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ فشل توليد الميم. جرّب مرة ثانية." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
