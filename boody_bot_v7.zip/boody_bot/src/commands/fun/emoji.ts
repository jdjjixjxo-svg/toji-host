import { Command } from "../../handlers/types";
import { QUESTION_BANKS } from "../events/questionBank";
import { pickRandom, buildQuizOptions } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const command: Command = {
  name: "ايموجي",
  aliases: ["emoji"],
  category: "ترفيه",
  description: "خمن الكلمة أو المثل من الإيموجي",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const bank = QUESTION_BANKS["ايموجي"];
    const item = pickRandom(bank);
    const options = buildQuizOptions(
      item.answer,
      bank.map((b) => b.answer),
      4
    );
    await runMiniQuiz(
      ctx,
      "خمن الإيموجي",
      item.question,
      item.answer,
      45_000,
      "اكتب الإجابة الصحيحة بالمجموعة.",
      options
    );
  },
};

export default command;
