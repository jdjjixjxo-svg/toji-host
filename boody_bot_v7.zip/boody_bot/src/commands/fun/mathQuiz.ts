import { Command } from "../../handlers/types";
import { randomInt } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const command: Command = {
  name: "رياضيات",
  aliases: ["حساب", "math"],
  category: "ترفيه",
  description: "مسألة رياضيات سريعة، أول إجابة صحيحة تفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const a = randomInt(2, 50);
    const b = randomInt(2, 50);
    const ops = ["+", "-", "×"] as const;
    const op = ops[randomInt(0, ops.length - 1)];
    let result: number;
    if (op === "+") result = a + b;
    else if (op === "-") result = a - b;
    else result = a * b;

    await runMiniQuiz(
      ctx,
      "مسألة رياضيات",
      `🔢 كم ناتج: ${a} ${op} ${b} = ؟`,
      String(result),
      30_000
    );
  },
};

export default command;
