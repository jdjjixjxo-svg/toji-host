import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";
import { jidToMention } from "../../utils/helpers";

// 🔧 إصلاح: كان الاختصار الإنجليزي "draw" مستخدم هنا وبأمر .رسم (ia/draw.ts)
// بنفس الوقت — تعارض أسماء يخلي أحد الأمرين ياخذ الاختصار ويطيّح الثاني منه
// (حسب ترتيب تحميل الملفات). شلناه من هنا لأن ".رسم" (توليد صور بالذكاء
// الاصطناعي) أنسب لاختصار "draw" الشائع، وحطينا "raffle" بدلها هنا.
const command: Command = {
  name: "قرعة",
  aliases: ["سحب_قرعة", "raffle"],
  category: "ترفيه",
  description: "يسحب عضوًا عشوائيًا من المجموعة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const participants = (ctx.metadata?.participants || [])
      .map((p) => p.id)
      .filter((id) => id !== ctx.senderJid);

    if (!participants.length) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ ما فيه أعضاء كفاية بالمجموعة." });
      return;
    }

    const winner = pickRandom(participants);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎟️ نتيجة القرعة: ${jidToMention(winner)} 🎉`, mentions: [winner] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
