import { Command } from "../../handlers/types";
import { QUESTION_BANKS } from "../events/questionBank";
import { pickRandom, buildQuizOptions } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const command: Command = {
  name: "اعلام",
  aliases: ["فعالية_اعلام", "flags"],
  category: "ترفيه",
  description: "فعالية خمن الدولة من علمها",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const bank = QUESTION_BANKS["اعلام"];
    const item = pickRandom(bank);
    const options = buildQuizOptions(
      item.answer,
      bank.map((b) => b.answer),
      4
    );
    await runMiniQuiz(
      ctx,
      "خمن العلم",
      item.question,
      item.answer,
      45_000,
      "اكتب اسم الدولة الصحيح بالمجموعة.",
      options
    );
  },
};

export default command;
