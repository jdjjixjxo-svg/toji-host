import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, digitsOnly } from "../../utils/helpers";
import { addPoint, getPoints, setPoints, stealCooldownRemaining, markStealUsed } from "../../database/db";

/** يحوّل مللي ثانية متبقية لصيغة مقروءة (دقيقة وثانية) */
function formatRemaining(ms: number): string {
  const totalSeconds = Math.ceil(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  if (minutes <= 0) return `${seconds} ثانية`;
  if (seconds === 0) return `${minutes} دقيقة`;
  return `${minutes} دقيقة و${seconds} ثانية`;
}

const command: Command = {
  name: "سرقه",
  aliases: ["سرقة", "steal"],
  category: "ترفيه",
  description: "اسرق نقاط عشوائية (1-30) من شخص. مرة كل ساعة لكل شخص. مثال: .سرقه @شخص",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔒 كولداون ساعة واحدة لكل شخص (بغض النظر عن المجموعة)
    const stealerKey = digitsOnly(ctx.senderJid);
    const remaining = stealCooldownRemaining(stealerKey);
    if (remaining > 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `*خلاص عرفنا انك حرامي انتضر ${formatRemaining(remaining)} وتصرق تاني 😡*\n` +
            `*(نصيحه لا تصرق اصرقه حرام)*`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target || target === ctx.senderJid) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ الاستخدام: .سرقه @شخص — أو رد على رسالته." },
        { quoted: ctx.msg }
      );
      return;
    }

    // نسجل وقت الاستخدام أول شي حتى لو الضحية ما عنده نقاط — الأمر
    // "استُخدم" فعليًا بغض النظر عن نتيجة السرقة
    markStealUsed(stealerKey);

    const amount = Math.floor(Math.random() * 30) + 1; // 1 إلى 30
    const currentTargetPoints: number = getPoints(ctx.chatId, target);
    const stolen = Math.min(amount, currentTargetPoints);

    if (stolen === 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text: `😅 حاولت تسرق ${jidToMention(target)} بس ما لقيت عنده نقاط أصلًا يا حرامي!`,
          mentions: [target],
        },
        { quoted: ctx.msg }
      );
      return;
    }

    setPoints(ctx.chatId, target, currentTargetPoints - stolen);
    addPoint(ctx.chatId, ctx.senderJid, stolen);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `🕵️‍♂️ *عملية سرقة ناجحة!*\n\n` +
          `${jidToMention(ctx.senderJid)} سرق *${stolen}* نقطة من ${jidToMention(target)} 😈`,
        mentions: [ctx.senderJid, target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
