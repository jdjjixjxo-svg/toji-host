import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const FACTS: string[] = [
  "قلب الروبيان يقع في راسها 🦐",
  "العسل ما يفسد أبدًا، حتى لو عمره آلاف السنين 🍯",
  "الأخطبوط عنده 3 قلوب ودمه أزرق 🐙",
  "الموز يعتبر توت من الناحية العلمية، بينما الفراولة لأ 🍌",
  "بصمة اللسان مختلفة عند كل إنسان مثل بصمة الإصبع 👅",
  "النمل ما ينام أبدًا 🐜",
  "أطول حرب بالتاريخ استمرت 335 سنة بدون قتيل واحد 📜",
  "جسم الإنسان يحتوي تقريبًا نفس عدد النجوم اللي نقدر نشوفها بالسماء بالليل الصافي ⭐",
  "الفراشات تتذوق الطعام بأرجلها 🦋",
  "أوكسجين الأرض 20% منه ينتجه غابات الأمازون 🌳",
];

const command: Command = {
  name: "حقيقة",
  aliases: ["هل_تعلم", "fact"],
  category: "ترفيه",
  description: "معلومة أو حقيقة عشوائية ممتعة",
  permission: "all",
  execute: async (ctx) => {
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `💡 هل تعلم؟ ${pickRandom(FACTS)}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
