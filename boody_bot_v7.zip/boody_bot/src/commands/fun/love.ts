import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { seededPercent, percentBar } from "../../utils/fun";

const command: Command = {
  name: "حب",
  aliases: ["love"],
  category: "ترفيه",
  description: "نسبة حب بينك وبين شخص ثاني (للفرفشة بس). مثال: .حب @شخص",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || null;

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ منشن الشخص. مثال: .حب @شخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    const today = new Date().toDateString();
    const percent = seededPercent(ctx.senderJid + target + today + "love");

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `💘 نسبة الحب بين ${jidToMention(ctx.senderJid)} و ${jidToMention(target)}\n\n` +
          `${percent}%\n${percentBar(percent)}\n\n` +
          `للفرفشة بس 😄`,
        mentions: [ctx.senderJid, target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
