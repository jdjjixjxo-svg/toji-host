import { Command } from "../../handlers/types";
import { numberToJid, jidToMention } from "../../utils/helpers";

/**
 * 🆕 (طلب صريح: ".اخر_ظهور +رقم" أو منشن) — يستخدم نفس فكرة .كشف بالضبط
 * (presenceSubscribe فعلي من واتساب نفسه)، لكن لهدف واحد محدد بدل مسح
 * كل المجموعة.
 *
 * ⚠️ صراحة (نفس ملاحظة .كشف تمامًا): هذا لا "يخترق" خصوصية أحد — يرجع
 * فقط المعلومة اللي واتساب أصلًا يسمح للبوت يشوفها حسب إعدادات خصوصية
 * ذاك الشخص بالضبط (لو خصوصيته تخفي آخر ظهور عن غير جهات اتصاله، ما راح
 * يرجع أي شي، تمامًا متل تطبيق واتساب العادي).
 */
const WAIT_MS = 3000;

function resolveTargetJid(ctx: { args: string[]; mentions?: string[] }): string | null {
  if (ctx.mentions?.[0]) return ctx.mentions[0];
  const raw = ctx.args[0]?.replace(/[^0-9]/g, "");
  if (raw && raw.length >= 8) return numberToJid(raw);
  return null;
}

const command: Command = {
  name: "اخر_ظهور",
  aliases: ["آخر_ظهور", "lastseen"],
  category: "ترفيه",
  description: "يحاول يجيب آخر ظهور شخص برقمه أو منشنه (حسب خصوصية حسابه هو). مثال: .اخر_ظهور +201xxxxxxxxx",
  permission: "all",
  execute: async (ctx) => {
    const targetJid = resolveTargetJid(ctx as any);
    if (!targetJid) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب رقم أو منشن.\nمثال: .اخر_ظهور +201558983123\nأو رد/منشن على شخص بنفس الأمر." },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: "🔎 يدور آخر ظهور... ثواني" }, { quoted: ctx.msg });

    let result: { state?: string; lastSeen?: number } = {};
    const handler = (update: any) => {
      const presence = update?.presences?.[targetJid];
      if (presence) result = { state: presence.lastKnownPresence, lastSeen: presence.lastSeen };
    };

    ctx.sock.ev.on("presence.update", handler);
    try {
      await ctx.sock.presenceSubscribe(targetJid);
    } catch {
      // نتجاهل بأمان — أحيانًا واتساب يرفض اشتراك متكرر بفارق وقت قصير
    }
    await new Promise((resolve) => setTimeout(resolve, WAIT_MS));
    ctx.sock.ev.off("presence.update", handler);

    const mention = jidToMention(targetJid);

    if (result.state === "available") {
      await ctx.sock.sendMessage(ctx.chatId, { text: `🟢 ${mention} متصل الآن.`, mentions: [targetJid] }, { quoted: ctx.msg });
      return;
    }
    if (result.lastSeen) {
      const date = new Date(result.lastSeen * 1000);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `🕓 آخر ظهور لـ ${mention}: ${date.toLocaleString("ar-EG")}`, mentions: [targetJid] },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `🙈 ما قدرنا نجيب آخر ظهور ${mention}.\n` +
          `السبب الأغلب: خصوصية حسابه تخفي "آخر ظهور" عن أي رقم مو محفوظ عنده — مو تقصير من البوت.`,
        mentions: [targetJid],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
