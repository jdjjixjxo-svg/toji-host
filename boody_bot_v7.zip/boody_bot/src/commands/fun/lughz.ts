import { Command } from "../../handlers/types";
import { QUESTION_BANKS } from "../events/questionBank";
import { pickRandom } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const command: Command = {
  name: "لغز",
  aliases: ["فزورة", "riddle"],
  category: "ترفيه",
  description: "لغز عشوائي، أول واحد يحلّه يفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const item = pickRandom(QUESTION_BANKS["لغز"]);
    await runMiniQuiz(ctx, "لغز", item.question, item.answer);
  },
};

export default command;
