import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { seededPercent, percentBar } from "../../utils/fun";

const command: Command = {
  name: "زواج",
  aliases: ["marriage"],
  category: "ترفيه",
  description: "نسبة توافق زواج بينك وبين شخص ثاني (للفرفشة بس). مثال: .زواج @شخص",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || null;

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ منشن الشخص. مثال: .زواج @شخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    const today = new Date().toDateString();
    const percent = seededPercent(ctx.senderJid + target + today + "marriage");

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `💍 نسبة توافق الزواج بين ${jidToMention(ctx.senderJid)} و ${jidToMention(target)}\n\n` +
          `${percent}%\n${percentBar(percent)}\n\n` +
          `للفرفشة بس 😄`,
        mentions: [ctx.senderJid, target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
