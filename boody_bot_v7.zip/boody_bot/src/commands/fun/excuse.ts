import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

/**
 * 🆕 أمر ".عذر" — يولّد عذرًا عشوائيًا سخيفًا. أمر "غريب بدون داعي" بطلب
 * صريح من صاحب البوت، بنفس روح ".نكتة" (منشن أول شي ثم النص).
 */
const EXCUSES: string[] = [
  "والله جوالي كان طايح بالبحر، الحين لقيته",
  "كنت بمهمة سرية ما اقدر افصح عنها",
  "قطعوا الكهرباء عن الحي كامل، حتى الجوال ما شحن",
  "خلاص كنت نايم، بس نايم واعي شوي",
  "أمي قالت لازم اساعدها، وهي بعدها نايمة",
  "جوالي دخل نفس الغسالة، اسأل امي",
  "كنت اقرأ القرآن، بس بصوت السلاحف",
  "صديقي المفلس طلب مني اقرضه وقت، ما عاد عندي وقت",
  "النت كان بطيء جدًا لدرجة إن الرسالة وصلتني بكرة",
  "كان عندي اجتماع مهم مع نفسي وانتهى للتو",
  "غفوة الخمس دقايق تحولت لثلاث ساعات، القدر أقوى مني",
  "قطتي جلست على الجوال وما قدرت اخلّيها",
  "كنت اتمرن على تجاهل الاشعارات، نجحت اكثر من اللازم",
];

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const command: Command = {
  name: "عذر",
  aliases: ["excuse", "عذري"],
  category: "ترفيه",
  description: "يعطيك عذر جاهز عشوائي (سخيف بالكامل) لأي موقف",
  permission: "all",
  execute: async (ctx) => {
    const mention = jidToMention(ctx.senderJid);
    const excuse = pickRandom(EXCUSES);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `${mention}\n📋 *عذرك جاهز:*\n"${excuse}"`, mentions: [ctx.senderJid] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
