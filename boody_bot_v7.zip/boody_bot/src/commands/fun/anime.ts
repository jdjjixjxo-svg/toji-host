import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const ANIME_LIST: Array<{ title: string; note: string }> = [
  { title: "ون بيس", note: "مغامرة قراصنة بحثًا عن أعظم كنز بالعالم 🏴‍☠️" },
  { title: "ناروتو", note: "قصة نينجا شاب يحلم يصير أقوى زعيم لقريته 🍥" },
  { title: "اتاك أون تايتن", note: "بشر يقاومون عمالقة مرعبة خلف أسوار ضخمة 🧱" },
  { title: "دراغون بول", note: "محارب يسعى للتقوّي وحماية كوكب الأرض 🐉" },
  { title: "ديث نوت", note: "دفتر غامض يقتل أي اسم يُكتب فيه 📓" },
  { title: "فول ميتال الكيميائي", note: "أخوان يبحثان عن طريقة لاستعادة جسديهما ⚗️" },
  { title: "جوجتسو كايسن", note: "طلاب يقاتلون أرواحًا شريرة بقوى خاصة 👹" },
  { title: "ديمون سلاير", note: "شاب يقاتل الشياطين لإنقاذ أخته 🗡️" },
];

const command: Command = {
  name: "انمي",
  aliases: ["anime"],
  category: "ترفيه",
  description: "يقترح لك أنمي عشوائي",
  permission: "all",
  execute: async (ctx) => {
    const item = pickRandom(ANIME_LIST);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎌 اقتراح اليوم: *${item.title}*\n${item.note}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
