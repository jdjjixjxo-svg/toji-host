import { Command } from "../../handlers/types";

/**
 * 🆕 أمر ".زخرفة" — يحوّل أي نص لشكل مزخرف بنفس روح زر "🔱الــتــنــصــيــب🔱"
 * (تمديد الحروف العربية بالتطويل "ـ")، ولو النص إنجليزي بحت يحوّله لخط
 * "بولد إيطاليك" يونيكود (Mathematical Bold Italic) بنفس طريقة اسم
 * المطور بملف config.ts.
 */

// خريطة تحويل الحروف اللاتينية لخط Mathematical Bold Italic (Unicode)
const BOLD_ITALIC_MAP: Record<string, string> = {
  a: "𝒂", b: "𝒃", c: "𝒄", d: "𝒅", e: "𝒆", f: "𝒇", g: "𝒈", h: "𝒉", i: "𝒊",
  j: "𝒋", k: "𝒌", l: "𝒍", m: "𝒎", n: "𝒏", o: "𝒐", p: "𝒑", q: "𝒒", r: "𝒓",
  s: "𝒔", t: "𝒕", u: "𝒖", v: "𝒗", w: "𝒘", x: "𝒙", y: "𝒚", z: "𝒛",
  A: "𝑨", B: "𝑩", C: "𝑪", D: "𝑫", E: "𝑬", F: "𝑭", G: "𝑮", H: "𝑯", I: "𝑰",
  J: "𝑱", K: "𝑲", L: "𝑳", M: "𝑴", N: "𝑵", O: "𝑶", P: "𝑷", Q: "𝑸", R: "𝑹",
  S: "𝑺", T: "𝑻", U: "𝑼", V: "𝑽", W: "𝑾", X: "𝑿", Y: "𝒀", Z: "𝒁",
};

const ARABIC_RANGE = /[\u0600-\u06FF]/;

function decorate(input: string): string {
  const isArabic = ARABIC_RANGE.test(input);
  if (isArabic) {
    // تمديد كل حرف بتطويل (ـ) ما عدا المسافات، بنفس ستايل "الــتــنــصــيــب"
    const spaced = input
      .split("")
      .map((ch) => (ch === " " ? "  " : `${ch}ـ`))
      .join("")
      .replace(/ـ(\s)/g, "$1")
      .replace(/ـ$/, "");
    return `⋆༺ ${spaced} ༻⋆`;
  }
  const mapped = input
    .split("")
    .map((ch) => BOLD_ITALIC_MAP[ch] ?? ch)
    .join("");
  return `⋆༺ ${mapped} ༻⋆`;
}

const command: Command = {
  name: "زخرفة",
  aliases: ["زخرف", "decorate"],
  category: "ترفيه",
  description: "يزخرف أي نص تكتبه. مثال: .زخرفة بودي",
  permission: "all",
  execute: async (ctx) => {
    const input = ctx.text.trim();
    if (!input) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب نص بعد الأمر. مثال: .زخرفة بودي" },
        { quoted: ctx.msg }
      );
      return;
    }
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: decorate(input) },
      { quoted: ctx.msg }
    );
  },
};

export default command;
