import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const CHALLENGES: string[] = [
  "🎯 التحدي: غيّر صورتك الشخصية لأغرب صورة عندك لمدة ساعة!",
  "🎯 التحدي: أرسل آخر أغنية سمعتها بدون ما تقول اسمها، وخلي الكل يخمن!",
  "🎯 التحدي: اكتب أطرف موقف صار وياك بحياتك بجملة وحدة!",
  "🎯 التحدي: قلد شخصية مشهورة بالكتابة بس (بدون ذكر اسمها) وخلي الكل يخمن مين!",
  "🎯 التحدي: اذكر 3 أشياء تحبها بصوت مرتفع (تخيليًا 😄) واكتبها هنا!",
  "🎯 التحدي: اكتب حكمة اخترعتها إنت بنفسك الحين!",
];

const command: Command = {
  name: "تحدي",
  aliases: ["challenge"],
  category: "ترفيه",
  description: "تحدي عشوائي ممتع للمجموعة",
  permission: "all",
  execute: async (ctx) => {
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: pickRandom(CHALLENGES) },
      { quoted: ctx.msg }
    );
  },
};

export default command;
