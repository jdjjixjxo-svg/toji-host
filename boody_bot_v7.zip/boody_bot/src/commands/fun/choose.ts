import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";

const command: Command = {
  name: "اختيار",
  aliases: ["choose"],
  category: "ترفيه",
  description: "يختار لك بين خيارين أو أكثر. مثال: .اختيار بيتزا او برجر",
  permission: "all",
  execute: async (ctx) => {
    const options = ctx.text
      .split(/\s+او\s+|\s+أو\s+|\||,|،/)
      .map((o) => o.trim())
      .filter(Boolean);

    if (options.length < 2) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ اكتب خيارين أو أكثر مفصولين بـ (او). مثال: .اختيار بيتزا او برجر" },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎯 اخترت لك: *${pickRandom(options)}*` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
