import { Command } from "../../handlers/types";
import { pickRandom } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const SENTENCES: string[] = [
  "البرمجة متعة حقيقية",
  "الوقت كالسيف ان لم تقطعه قطعك",
  "من جد وجد ومن زرع حصد",
  "السرعة والدقة مهارة",
  "قهوة الصباح لا تعوض",
  "الصبر مفتاح الفرج",
];

const command: Command = {
  name: "سرعة",
  aliases: ["سباق_الكتابة", "speed"],
  category: "ترفيه",
  description: "سباق كتابة، أول من يكتب الجملة بالضبط يفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const sentence = pickRandom(SENTENCES);
    await runMiniQuiz(
      ctx,
      "سباق الكتابة",
      `⌨️ اكتب هالجملة بالضبط أسرع ما تقدر:\n\n*${sentence}*`,
      sentence,
      30_000
    );
  },
};

export default command;
