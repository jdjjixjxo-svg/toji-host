import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

const PRAISES: string[] = [
  "{mention} من أرقى الناس اللي أعرفهم، حضوره يفرق 🌹",
  "{mention} شخص يستاهل كل خير، ذوقه بالكلام يريح القلب 💛",
  "{mention} من أوفى الناس، ما يخذل صديق 🤝",
  "{mention} طاقته إيجابية، يدخل يفرح الجو 😄✨",
  "{mention} عنده ذكاء وحضور بيه، ما يمل منه أحد 🧠🌟",
  "{mention} من الناس اللي تحس بوجودهم راحة نفسية 🤍",
  "{mention} كريم بوقته وكلامه الطيب دايمًا 🌸",
  "{mention} شخص يستاهل الاحترام قبل أي شي 🙏",
  "{mention} حسه مرهف وقلبه طيب، ما يتغير على أحد 💫",
  "{mention} من القلائل اللي كلامهم يبني ما يهدم 🏗️🤍",
  "{mention} عنده صبر وحكمة يندر تلقاها بهالعمر 🌿",
  "{mention} إنسان يستاهل كل التقدير، الله يوفقه 🌟",
];

const command: Command = {
  name: "مديح",
  aliases: ["praise"],
  category: "ترفيه",
  description: "يمدحك بجملة حلوة. مثال: .مديح @شخص أو رد على رسالة",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const text = pickRandom(PRAISES).replace("{mention}", jidToMention(target));
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `✨ ${text}`, mentions: [target] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
