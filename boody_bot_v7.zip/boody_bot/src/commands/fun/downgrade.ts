import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

// "تسفيل" بأسلوب أب صارم يعاتب ابنه — خفيف وللفرفشة بس، بدون أي شتم أو ألفاظ بذيئة
const DOWNGRADES: string[] = [
  "يا {mention} والله خيبت أملي فيك، قوم سو شي بحياتك 😤",
  "{mention} من زمان قلتلك ذاكر، شفتك سامعني؟ 🙄",
  "{mention} أنا بعمرك كنت بنيت بيت، وانت للحين ما بنيت قرارك 😮‍💨",
  "قوم يا {mention}! الساعة 12 الظهر وانت نايم؟ ولا شغل ولا مذاكرة؟ 😑",
  "{mention} لو صرفت على نفسك ذكاء زي ما تصرف وقت بالجوال كنت طلعت مهندس 📱😤",
  "{mention} أنا سألتك سؤال بسيط ورجعتلي بألف عذر، الله يهديك 🤦",
  "شفت جيبك يا {mention}؟ فاضي زي خطتك المستقبلية 💸😅",
  "{mention} ياخي قوم اطلع اشتغل، القعدة هذي ما تطعم خبز 😩",
  "أنا مو زعلان منك يا {mention}، بس خايب أملي فيك شوي... زياده عن اللزوم 😔",
  "{mention} لما كنت بعمرك ما كان فيه جوال أصلاً وكنت أشتغل، وانت تشتكي من الوايفاي 📶😤",
  "قول لي يا {mention}، وش سويت اليوم غير إنك فتحت التطبيقات وقفلتها؟ 😑",
  "{mention} احترم نفسك شوي، عمرك مو صغير عشان تسولف كذا 🙄",
  "{mention} كل يوم تقول \"بكرة أرتب حياتي\" وصار عندك 100 بكرة مأجلة 😑",
  "يا {mention} أنا ما أطلب المستحيل، بس ولا نص جدية بحياتك؟ 😮‍💨",
  "{mention} شفت أصحابك وين وصلوا، وانت للحين تسولف نفس السوالف 🙄",
  "قوم يا {mention}، الدنيا ما تنتظر حد، وانت قاعد تنتظرها 😤",
  "{mention} عمرك ما قلت \"سويتها\" من قلبك، دايمًا \"بسويها\" 😑",
  "يا {mention} حتى الكسل صار يستحي منك من كثر ما تجيده 😮‍💨",
  "{mention} أنا مو ضدك، بس ضد إنك تضيع نفسك كذا 😔",
  "{mention} فكّر شوي، وين بتكون بعد 5 سنين لو كملت على نفس النمط؟ 🤔",
  "{mention} الفرصة ما تدق الباب مرتين، وانت نايم ماسمعتها أول مرة 😑",
];

const command: Command = {
  name: "تسفيل",
  aliases: ["downgrade"],
  category: "ترفيه",
  description: "يسفل فيك بأسلوب أب صارم (للفرفشة بس). مثال: .تسفيل @شخص أو رد على رسالة",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const text = pickRandom(DOWNGRADES).replace("{mention}", jidToMention(target));
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `👨 ${text}`, mentions: [target] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
