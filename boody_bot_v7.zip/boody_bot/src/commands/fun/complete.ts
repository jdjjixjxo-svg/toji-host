import { Command } from "../../handlers/types";
import { QUESTION_BANKS } from "../events/questionBank";
import { pickRandom } from "../../utils/fun";
import { runMiniQuiz } from "../../utils/miniQuiz";

const command: Command = {
  name: "اكمل",
  aliases: ["complete"],
  category: "ترفيه",
  description: "أكمل المثل الشعبي",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const item = pickRandom(QUESTION_BANKS["اكمل"]);
    await runMiniQuiz(ctx, "أكمل المثل", item.question, item.answer);
  },
};

export default command;
