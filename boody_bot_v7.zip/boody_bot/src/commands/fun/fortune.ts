import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

/** 🆕 ".فأل" — فأل يومي عشوائي خفيف (للمزح فقط، بدون أي ادعاء تنبؤ حقيقي). */
const FORTUNES: string[] = [
  "اليوم يومك! افتح جوالك بثقة، الحظ معك 🍀",
  "خل بالك اليوم من كلمة تقولها بسرعة، فكر شوي زيادة",
  "فلوس بتجيك اليوم... أو تروح، النجوم مو متأكدة 😅",
  "شخص قريب راح يفكر فيك اليوم، رد عليه لو راسلك",
  "يوم ممتاز تسوي فيه قرار كنت مؤجله من زمان",
  "لا تصدق كل الي يقوله لك الفأل، جرب أنت بنفسك 😂",
  "طاقتك اليوم عالية، استغلها بشي مفيد",
  "احتمال كبير توكل شي لذيذ اليوم، ودعوة لصاحبك ما تضر",
  "يوم مناسب تصالح فيه أحد كنت زعلان منه",
  "النوم بدري الليلة راح يغير يومك بكرة، جرب",
  "فيه مفاجأة صغيرة بانتظارك اليوم",
  "اليوم مو يوم قرارات كبيرة، خله يوم راحة",
];

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const command: Command = {
  name: "فال",
  aliases: ["فأل", "fortune"],
  category: "ترفيه",
  description: "فأل يومي عشوائي خفيف للمزح فقط",
  permission: "all",
  execute: async (ctx) => {
    const mention = jidToMention(ctx.senderJid);
    const fortune = pickRandom(FORTUNES);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `${mention}\n🔮 *فألك اليوم:*\n${fortune}`, mentions: [ctx.senderJid] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
