import { Command } from "../../handlers/types";
import { jidToMention, getTargetJid } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

/**
 * أمر "غزل/دلع" — يرسل الجملة لمن تم منشنه (@) أو الرد على رسالته، ولو
 * ما فيه منشن ولا رد يرسلها على المرسل نفسه (نفس السلوك القديم كافتراضي).
 * 🔧 التغيير المطلوب: كان الأمر يتجاهل أي منشن عمدًا ويثبّت الهدف على
 * المرسل دائمًا. النصوص نفسها رومانسية لطيفة وخالية من أي طابع جنسي أو
 * إلحاح، فتبقى مناسبة للإرسال لعضو ثاني بنفس روح المجاملة العادية.
 */
const FLIRTY_LINES: string[] = [
  "{mention} يا حلو، وجودك يخلي الجو أحلى 🌹",
  "{mention} قلبك طيب وحضورك مرتاح، ما شاء الله عليك 💛",
  "{mention} فيك ذوق ما يتكرر، تستاهل كل حلو 🌸",
  "{mention} ابتسامتك وحدها تكفي تفرح ناس كثير 😊",
  "{mention} شخص يستاهل يُدلل ويُقدّر، الله يخليك 🤍",
  "{mention} حضورك دفا القلب، تستاهل كل خير 🌷",
  "{mention} كل ما تحضر يصير الجو أجمل، صدق 🌟",
  "{mention} إنسان بسيط وراقي بنفس الوقت، نادر جدًا 🌿",
  "{mention} طاقتك حلوة، الناس ترتاح لك من أول كلمة 🍃",
  "{mention} فيك دفء ما تلقاه بكل الناس، الله يحفظك 🤍",
  "{mention} تستاهل يوم حلو زي قلبك بالضبط 🌤️",
  "{mention} صدقًا من الأشخاص اللي يصعب نسيانهم 🌷",
  "{mention} وجودك بحد ذاته هدية، خلك دايمًا كذا 🎁",
  "{mention} عندك طاقة إيجابية تنتشر لكل اللي حولك 🌞",
  "{mention} شخص يستحق كل التقدير، وما راح أبخل عليك فيه 💐",
];

const command: Command = {
  name: "دلع",
  aliases: [], // 🔧 شلنا alias "غزل" (كان يتعارض مع أمر قصيدة الغزل الجديد)
  category: "ترفيه",
  description: "يدلعك بجملة غزل لطيفة — منشن شخص أو رد على رسالته ليدلّعه هو، وإلا يدلّعك إنت",
  permission: "all",
  execute: async (ctx) => {
    const targetJid = getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const text = pickRandom(FLIRTY_LINES).replace(
      "{mention}",
      jidToMention(targetJid)
    );
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `💌 ${text}`, mentions: [targetJid] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
