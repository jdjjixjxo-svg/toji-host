import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

const KISS_REPLIES: string[] = [
  "ابوس راسك انا 🌹 يا محترم",
  "ابوس طيـ...... 🙂",
  "تخليني؟ 🙂",
  "لا حرام عليك بس بوسه وحده وبس 😳🌹",
  "وربي استحيت منك 🙈🌹",
  "خلها بالخد بس، ولا يصير كلام 😅",
  "قرب شوي بس مو أكثر من كذا 😌",
  "يكفيك اللي سويته، هذي وحدة بس ولا تعودها 😏🌹",
];

const command: Command = {
  name: "بوس",
  aliases: ["kiss", "قبله", "قبلة"],
  category: "ترفيه",
  description: "يبوس شخص معيّن. مثال: .بوس @شخص أو رد على رسالته",
  permission: "all",
  execute: async (ctx) => {
    const target =
      getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const text = pickRandom(KISS_REPLIES);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `💋 ${jidToMention(target)} ${text}`, mentions: [target] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
