import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { commandRegistry } from "../../handlers/commandRegistry";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { formatUptime } from "../../utils/uptime";
import { botInfoText } from "../../utils/menuTemplates";

/**
 * قسم ".بوت" — معلومات تفصيلية عن البوت نفسه، منفصل عن ".menu" (القائمة
 * الرئيسية) بعد ما كان اسمًا بديلًا لها بالغلط. صار له الآن صورة هوية
 * خاصة (assets/sections/bot.png) وقائمة معلومات مستقلة، حسب ما طُلب.
 */
const command: Command = {
  name: "بوت",
  aliases: ["botinfo", "معلومات_البوت"],
  category: "بوت",
  description: "معلومات تفصيلية عن البوت (الإصدار، المكتبة، المطور، الأوامر...)",
  permission: "all",
  execute: async (ctx) => {
    const sentAt = Number(ctx.msg.messageTimestamp || 0) * 1000;
    const ping = sentAt ? Math.max(0, Date.now() - sentAt) : 0;
    const sectionsCount = new Set(commandRegistry.getAll().map((c) => c.category)).size;

    const text = botInfoText({
      version: CONFIG.BOT_VERSION,
      count: commandRegistry.count(),
      sections: sectionsCount,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
      speed: `السرعة ${ping}ms`,
    });

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("bot") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
