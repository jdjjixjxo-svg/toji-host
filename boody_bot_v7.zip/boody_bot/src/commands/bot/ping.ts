import { Command } from "../../handlers/types";
import { jidToMention, formatDateTime } from "../../utils/helpers";
import { commandRegistry } from "../../handlers/commandRegistry";

const command: Command = {
  name: "بنج",
  aliases: ["ping"],
  category: "بوت",
  description: "قياس سرعة استجابة البوت",
  permission: "all",
  execute: async (ctx) => {
    const start = Date.now();
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "🏓 جاري القياس..." },
      { quoted: ctx.msg }
    );
    const latency = Date.now() - start;
    const { date, time } = formatDateTime();
    const groupName = ctx.metadata?.subject || "خاص";
    await ctx.sock.sendMessage(ctx.chatId, {
      text:
        `╗══════════╔\n` +
        `║ـ🔱『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』ـ\n` +
        `╣══════════╩╔\n` +
        `║ـ${groupName}ـ\n` +
        `╣═══════════╠\n` +
        `║🪖ـ${jidToMention(ctx.senderJid)}ـ\n` +
        `║🔥*البينغ* ـ${latency}msـ\n` +
        `║🕥*الساعه* ـ${time}ـ\n` +
        `║📅*التاريخ* ـ${date}ـ\n` +
        `║🪄*عدد الوامر* ـ${commandRegistry.count()}ـ\n` +
        `╣═══════════╠\n` +
        `║ *🌹نتمنا لكم وقتاً ممتعا*\n` +
        `╣═══════════╠\n` +
        `║ *_🍃القسام فلاسفل_*\n` +
        `╝═══════════╚`,
      mentions: [ctx.senderJid],
    });
  },
};

export default command;
