import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { formatDateTime, jidToMention } from "../../utils/helpers";
import { getMenuVideoBuffer, getSectionImageBuffer } from "../../utils/media";
import { sendButtonMessage, buildSingleSelectButton, sectionButton } from "../../utils/interactive";
import { mainMenuText } from "../../utils/menuTemplates";
import { commandRegistry } from "../../handlers/commandRegistry";

const command: Command = {
  name: "menu",
  // 🔧 ملاحظة: أزلنا "بوت" من هنا لأنه صار أمرًا مستقلًا بصورة وقسم خاص به
  // (src/commands/bot/botInfo.ts) بدل ما يكون مجرد اسم بديل لهذي القائمة.
  aliases: ["اوامر", "help", "قائمة"],
  category: "بوت",
  description: "عرض القائمة الرئيسية للبوت",
  permission: "all",
  execute: async (ctx) => {
    // ملاحظة: تفاعل التأكيد بقى مركزيًا بـ messageHandler لكل الأوامر،
    // فما نحتاج نرسله يدويًا هنا بعد الحين.
    const { date, time } = formatDateTime();
    const groupName = ctx.metadata?.subject || "خاص";
    const userMention = jidToMention(ctx.senderJid);
    // استجابة فعلية: الفرق بين وقت استلام الرسالة (timestamp من واتساب) والآن
    const sentAt = Number(ctx.msg.messageTimestamp || 0) * 1000;
    const ping = sentAt ? Math.max(0, Date.now() - sentAt) : 0;

    // 🔧 (طلب صريح: استمارة منيو جديدة) — نفس المتغيرات السابقة
    // (اسم الكروب/المستخدم/التاريخ/الوقت)، بإضافة البينغ اللي كان محسوب
    // من قبل بس ما كان يُعرض بالقالب القديم.
    const menuText = mainMenuText({
      user: userMention,
      time,
      date,
      count: commandRegistry.count(),
      group: groupName,
    });

    // رسالة واحدة فقط: الفيديو/الصورة + النص + الأزرار الحقيقية مرفقين معًا
    // (بدل ما ترسل بشكل منفصل بطريقة غير احترافية). لو تعذّرت الأزرار
    // لأي سبب (بعض الأجهزة لا تدعمها) يرجع تلقائيًا لنفس الصورة/الفيديو
    // مع النص بدون أزرار — يبقى رسالة وحدة برضه، وبدون كسر أي شيء.
    const videoBuffer = getMenuVideoBuffer();
    const mainImage = videoBuffer ? undefined : getSectionImageBuffer("main");

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: menuText,
      mentions: [ctx.senderJid],
      video: videoBuffer || undefined,
      gifPlayback: true,
      image: mainImage || undefined,
      // 🆕 (طلب صريح: زر واحد بدل صف الأقسام الطويل) — كل أقسام البوت الآن
      // داخل زر واحد "📂 الأقسام" يفتح قائمة اختيار من واتساب.
      extraButtons: [
        buildSingleSelectButton("📂 الأقسام", "أقسام البوت", [
          { command: "ترفيه", label: "『 🎉 ترفيه 』", description: "〘 ألعاب • فعاليات • مرح 〙" },
          // 🆕 (طلب صريح: "لعبة الراوي تستاهل قسم وحدها") — زر مباشر
          // يشغّل .قصة فورًا (مو قائمة فرعية)، منفصل تمامًا عن ترفيه وIA.
          { command: "قصة", label: "『 📖 الراوي 』", description: "〘 مغامرة تفاعلية بالذكاء الاصطناعي 〙" },
          { command: "اوامر_جانبيه", label: "『 ✨ اوامر جانبيه 』", description: "〘 أوامر جانبية مستوردة 〙" },
          { command: "مشرفين", label: "『 👮 مشرفين 』", description: "〘 أوامر إدارة المشرفين 〙" },
          { command: "حماية", label: "『 🛡️ حماية 』", description: "〘 نظام حماية المجموعة 〙" },
          { command: "تعديل_الصور", label: "『 🖼️ تعديل الصور 』", description: "〘 فلاتر • قص • رسم • ذكاء 〙" },
          { command: "نظام_الالقاب", label: "『 🏷️ الألقاب 』", description: "〘 تسجيل وإدارة الألقاب 〙" },
          { command: "ادوات", label: "『 🛠️ أدوات 』", description: "〘 الأدوات المتاحة 〙" },
          { command: "السنه", label: "『 🤲 السنة 』", description: "〘 أذكار • أحاديث • آيات 〙" },
          { command: "بوت", label: "『 🤖 البوت 』", description: "〘 معلومات البوت والإصدار 〙" },
          { command: "اعدادات", label: "『 ⚙️ إعدادات 』", description: "〘 تفعيل وإيقاف الميزات 〙" },
          { command: "المطورين", label: "『 👑 المطورين 』", description: "〘 أرقام المطورين كأزرار • القناة • الدعم 〙" },
          { command: "IA", label: "『 🤖 IA 』", description: "〘 أسئلة الذكاء الاصطناعي 〙" },
          { command: "اوامر_المطور", label: "『 🔥 أوامر المطور 』", description: "〘 أوامر خاصة بالمطور 〙" },
          { command: "تحليل", label: "『 🔮 تحليل 』", description: "〘 تحليل وإحصائيات 〙" },
          { command: "العاب", label: "『 🎮 الألعاب 』", description: "〘 ألعاب تفاعلية فورية 〙" },
          { command: "تنصيب_قائمة", label: "『 🕸 التنصيب 』", description: "〘 تثبيت بوت فرعي جديد 〙" },
        ]),
      ],
      quickButtons: [sectionButton("اقتراح", "💡 اقتراح أمر")],
      fallbackNote: `اكتب اسم القسم مباشرة، مثال: ${CONFIG.PREFIX}ترفيه`,
    });
  },
};

export default command;