import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * ============================================================================
 * 🤖 أمر .سوال — يستخدم Google Gemini API (مجاني، بدون بطاقة ائتمان)
 * ============================================================================
 * 🔧 إصلاح (أغسطس 2026): كان الموديل المستخدم "gemini-2.5-flash"، وصار
 * يرجع خطأ 404 "This model ... is no longer available to new users" —
 * جوجل قفلت موديلات عائلة 2.5 عن أي مفتاح API جديد (تم إنشاؤه بعد منتصف
 * 2026)، حتى لو المفتاح صحيح 100%. الموديلات القديمة ما زالت شغالة بس
 * فقط للمفاتيح/المشاريع اللي كانت مستخدمتها من قبل.
 * الحل: التحويل لموديل من جيل Gemini 3 (gemini-3.1-flash-lite) وهو:
 *  - متاح لكل المفاتيح (قديمة وجديدة)
 *  - مجاني بالكامل على الـ Free Tier (Input/Output = Free of charge،
 *    مؤكد من صفحة تسعير Gemini API الرسمية بتاريخ أغسطس 2026)
 *  - سريع ورخيص، مناسب لأسئلة عامة بدون تفكير عميق
 * ============================================================================
 */

const GEMINI_MODEL = "gemini-3.1-flash-lite";

const command: Command = {
  name: "سوال",
  aliases: ["سؤال", "اسأل", "ask"],
  category: "IA",
  description: "اسأل الذكاء الاصطناعي أي سؤال ويردلك زي أي IA طبيعي. مثال: .سوال ايش عاصمة اليابان؟",
  permission: "all",
  execute: async (ctx) => {
    const question = ctx.text.trim();
    if (!question) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب سؤالك بعد الأمر. مثال: .سوال ايش عاصمة اليابان؟" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (!CONFIG.GEMINI_API_KEY) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "❌ *أمر .سوال غير مفعّل حاليًا.*\n\n" +
            "يحتاج مفتاح Gemini مجاني حتى يشتغل. خبر المطور يضيف `GEMINI_API_KEY` بملف `.env` " +
            "(يؤخذ مجانًا من https://aistudio.google.com/app/apikey).",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });

      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: [{ role: "user", parts: [{ text: question }] }],
        config: {
          systemInstruction: "أنت مساعد ذكاء اصطناعي داخل بوت واتساب عربي. رد بإيجاز ووضوح باللهجة أو الفصحى حسب سؤال المستخدم.",
          maxOutputTokens: 700,
        },
      });

      // لو جوجل حجب الرد لأسباب أمان (نادر، بس ممكن) ما يكون فيه candidates إطلاقًا
      const blockReason = response.promptFeedback?.blockReason;
      if (blockReason) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "🚫 ما قدرت أرد على هالسؤال (تصنّف كمحتوى حساس من فلاتر الأمان). جرب صياغة ثانية." },
          { quoted: ctx.msg }
        );
        return;
      }

      const answer = response.text?.trim();

      if (!answer) throw new Error("رد فارغ من الخدمة (بدون تفاصيل خطأ من Gemini)");

      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `🤖 *الذكاء الاصطناعي:*\n\n${answer}` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .سوال (IA نصي):", err);
      // نرسل التفاصيل الكاملة للمطور بالخاص، ونخلي رسالة المجموعة عامة
      // حتى ما نحرج المستخدم العادي بتفاصيل تقنية.
      await notifyOwnerOfError(ctx.sock, ".سوال", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر جلب رد الذكاء الاصطناعي حاليًا. حاول مرة ثانية بعد شوي." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
