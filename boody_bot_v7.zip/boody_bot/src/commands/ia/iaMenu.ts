import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, buildSingleSelectButton, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { iaMenuText } from "../../utils/menuTemplates";
import { AI_EXTRA_ROWS } from "../../utils/menuRows";

/**
 * ============================================================================
 * 🤖 أمر .IA — يفتح قسم الذكاء الاصطناعي (كان ناقص هذا الملف بالأساس)
 * ============================================================================
 * 🔧 إصلاح: زر "IA" بالقائمة الرئيسية (menu.ts) وكل الأقسام التانية عندها
 * ملف خاص باسم القسم نفسه (زي "ترفيه" ← funMenu.ts) يفتح القسم ويسرد
 * أوامره. قسم IA ما كان عنده هذا الملف إطلاقًا — يعني الزر أو كتابة ".IA"
 * ما كان يوصل لأي أمر مسجّل، فما كان يطلع أي رد. هذا الملف يسدّ الفجوة.
 * القائمة تُبنى ديناميكيًا من كل الأوامر المسجّلة فعليًا بفئة "IA"، فأي
 * أمر IA جديد يُضاف مستقبلًا (زي .بحث و.اخبار الآن) يظهر هنا تلقائيًا
 * بدون الحاجة نعدّل هذا الملف كل مرة.
 * ============================================================================
 */

const command: Command = {
  name: "IA",
  aliases: ["ai", "ذكاء", "ذكاء_اصطناعي", "ذكاء_صناعي"],
  category: "IA",
  description: "عرض كل أوامر الذكاء الاصطناعي: سؤال، بحث، أخبار",
  permission: "all",
  execute: async (ctx) => {
    const text = iaMenuText();

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("main") || undefined,
      extraButtons: [buildSingleSelectButton("🤖 أوامر الذكاء الاصطناعي", "الذكاء الاصطناعي", AI_EXTRA_ROWS)],
      quickButtons: [...navButtons()],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
