import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * ============================================================================
 * 📰 أمر .اخبار — يستخدم Tavily Search API (topic=news)، نفس مفتاح .بحث
 * ============================================================================
 * أي موضوع نصي يشتغل (كرة القدم، كرة السلة، سياسة، تكنولوجيا...)، ما في
 * قائمة فئات ثابتة — النص بعد الأمر هو نفسه موضوع الأخبار المطلوب.
 * ============================================================================
 */

const TAVILY_URL = "https://api.tavily.com/search";
const MAX_NEWS_RESULTS = 5;
const NEWS_DAYS_BACK = 3; // آخر 3 أيام، حتى تكون الأخبار فعلًا "حديثة"

interface TavilyNewsResult {
  title: string;
  url: string;
  content: string;
  published_date?: string;
}

interface TavilyNewsResponse {
  results: TavilyNewsResult[];
  images?: string[];
}

const command: Command = {
  name: "اخبار",
  aliases: ["أخبار", "news", "خبر"],
  category: "IA",
  description: "يجيب لك آخر الأخبار عن أي موضوع. مثال: .اخبار كرة_القدم",
  permission: "all",
  execute: async (ctx) => {
    const topic = ctx.text.trim();
    if (!topic) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "⚠️ اكتب الموضوع اللي بدك أخباره بعد الأمر.\n" +
            "أمثلة:\n  .اخبار كرة_القدم\n  .اخبار كرة_السله\n  .اخبار تكنولوجيا",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    if (!CONFIG.TAVILY_API_KEY) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "❌ *أمر .اخبار غير مفعّل حاليًا.*\n\n" +
            "يحتاج مفتاح Tavily مجاني حتى يشتغل (نفس مفتاح .بحث). خبر المطور يضيف " +
            "`TAVILY_API_KEY` بملف `.env` (يؤخذ مجانًا من https://app.tavily.com).",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    // "كرة_القدم" ← "كرة القدم" حتى يصير سؤال بحث طبيعي بدل ما يبقى بشرطة سفلية
    const searchQuery = `اخبار ${topic.replace(/_/g, " ")}`;

    try {
      const res = await fetch(TAVILY_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          api_key: CONFIG.TAVILY_API_KEY,
          query: searchQuery,
          topic: "news",
          search_depth: "basic",
          days: NEWS_DAYS_BACK,
          include_images: true,
          max_results: MAX_NEWS_RESULTS,
        }),
      });

      if (!res.ok) {
        const errBody = await res.text().catch(() => "");
        throw new Error(`Tavily رجع حالة ${res.status}: ${errBody.slice(0, 300)}`);
      }

      const data = (await res.json()) as TavilyNewsResponse;

      if (!data.results?.length) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `📰 ما لقيت أخبار حديثة عن "${topic}". جرب موضوع ثاني أو صياغة أوضح.` },
          { quoted: ctx.msg }
        );
        return;
      }

      let text = `📰 *آخر أخبار:* ${topic.replace(/_/g, " ")}\n`;
      text += "✦───────────────✦\n";

      data.results.slice(0, MAX_NEWS_RESULTS).forEach((r, i) => {
        const snippet = r.content?.trim().slice(0, 180) || "";
        const date = r.published_date ? ` (${r.published_date.slice(0, 10)})` : "";
        text += `\n${i + 1}. *${r.title}*${date}\n${snippet}${snippet.length >= 180 ? "…" : ""}\n🔗 ${r.url}\n`;
      });

      // صورة وحدة فقط (أول خبر) تكفي كغلاف، حتى ما نغرق المجموعة برسائل كتير
      const coverImage = data.images?.[0];

      if (coverImage) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { image: { url: coverImage }, caption: text.trim() },
          { quoted: ctx.msg }
        );
      } else {
        await ctx.sock.sendMessage(ctx.chatId, { text: text.trim() }, { quoted: ctx.msg });
      }
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .اخبار:", err);
      await notifyOwnerOfError(ctx.sock, ".اخبار", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر جلب الأخبار حاليًا. حاول مرة ثانية بعد شوي." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
