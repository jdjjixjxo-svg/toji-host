import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

/**
 * ============================================================================
 * 🔎 أمر .بحث — يستخدم Tavily Search API (مجاني، 1000 طلب/شهر، بدون بطاقة)
 * ============================================================================
 * تسجيل الحساب فقط بالإيميل من https://app.tavily.com، ما بيطلب أي معلومات
 * دفع إطلاقًا. الأمر يرجع ملخص نصي قصير + أهم النتائج + صور متعلقة بالبحث.
 * ============================================================================
 */

const TAVILY_URL = "https://api.tavily.com/search";
const MAX_TEXT_RESULTS = 4;
const MAX_IMAGES = 3;

interface TavilyResult {
  title: string;
  url: string;
  content: string;
}

interface TavilyResponse {
  answer?: string;
  results: TavilyResult[];
  images?: string[];
}

/** بحث احتياطي عبر ويكيبيديا (عربي ثم إنجليزي) — بدون أي مفتاح API */
async function wikiSearch(query: string): Promise<TavilyResponse> {
  const langs = /[\u0600-\u06FF]/.test(query) ? ["ar", "en"] : ["en", "ar"];
  for (const lang of langs) {
    const api =
      `https://${lang}.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}` +
      `&gsrlimit=${MAX_TEXT_RESULTS}&prop=extracts|info&exintro=1&explaintext=1&exsentences=2&inprop=url&format=json`;
    const res = await fetch(api, {
      headers: { "User-Agent": "BoodyBot/4.0 (WhatsApp bot)" },
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) throw new Error(`Wikipedia رجع حالة ${res.status}`);
    const json: any = await res.json();
    const pages: any[] = Object.values(json?.query?.pages || {});
    pages.sort((a, b) => (a.index || 0) - (b.index || 0));
    if (pages.length) {
      return {
        answer: pages[0].extract?.trim() || undefined,
        results: pages.map((p) => ({
          title: p.title,
          url: p.fullurl || `https://${lang}.wikipedia.org/?curid=${p.pageid}`,
          content: p.extract || "",
        })),
        images: [],
      };
    }
  }
  return { results: [] };
}

const command: Command = {
  name: "بحث",
  aliases: ["search", "ابحث", "دور"],
  category: "IA",
  description: "يبحث لك عن أي نص ويجيب ملخص + نتائج + صور. مثال: .بحث برج ايفل",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب اللي بدك تبحث عنه بعد الأمر. مثال: .بحث برج ايفل" },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🆕 (طلب صريح: قيود على المحتوى الجنسي)
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    // المصدر الأول: Tavily (لو المفتاح موجود). لو فشل/انتهت حصته/رجع فاضي → ويكيبيديا كخطة بديلة بدون مفتاح
    let data: TavilyResponse | null = null;
    let lastError = "";
    if (CONFIG.TAVILY_API_KEY) {
      try {
        const res = await fetch(TAVILY_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: AbortSignal.timeout(12_000),
          body: JSON.stringify({
            api_key: CONFIG.TAVILY_API_KEY,
            query,
            topic: "general",
            search_depth: "basic",
            include_answer: "basic",
            include_images: true,
            max_results: MAX_TEXT_RESULTS,
          }),
        });
        if (!res.ok) {
          const errBody = await res.text().catch(() => "");
          throw new Error(`Tavily رجع حالة ${res.status}: ${errBody.slice(0, 300)}`);
        }
        data = (await res.json()) as TavilyResponse;
      } catch (err) {
        lastError = err instanceof Error ? err.message : String(err);
        logger.warn("Tavily فشل — نجرب ويكيبيديا:", lastError);
      }
    }

    if (!data || (!data.results?.length && !data.answer)) {
      try {
        data = await wikiSearch(query);
      } catch (err) {
        lastError = lastError || (err instanceof Error ? err.message : String(err));
        logger.error("فشل أمر .بحث بكل المصادر:", err);
        await notifyOwnerOfError(ctx.sock, ".بحث", lastError, { chatId: ctx.chatId, senderJid: ctx.senderJid });
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "❌ تعذر تنفيذ البحث حاليًا. حاول مرة ثانية بعد شوي." },
          { quoted: ctx.msg }
        );
        return;
      }
    }

    try {
      if (!data.results?.length && !data.answer) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "🔎 ما لقيت نتائج لهالبحث. جرب صياغة ثانية." },
          { quoted: ctx.msg }
        );
        return;
      }

      let text = `🔎 *نتائج البحث عن:* ${query}\n`;
      text += "✦───────────────✦\n";

      if (data.answer) {
        text += `\n📌 *ملخص سريع:*\n${data.answer}\n`;
      }

      if (data.results?.length) {
        text += `\n📄 *أهم النتائج:*\n`;
        data.results.slice(0, MAX_TEXT_RESULTS).forEach((r, i) => {
          const snippet = r.content?.trim().slice(0, 150) || "";
          text += `\n${i + 1}. *${r.title}*\n${snippet}${snippet.length >= 150 ? "…" : ""}\n🔗 ${r.url}\n`;
        });
      }

      await ctx.sock.sendMessage(ctx.chatId, { text: text.trim() }, { quoted: ctx.msg });

      const images = (data.images || []).slice(0, MAX_IMAGES);
      for (const imageUrl of images) {
        try {
          await ctx.sock.sendMessage(ctx.chatId, { image: { url: imageUrl } });
        } catch (imgErr) {
          // لو صورة وحدة فشلت (رابط ميت مثلًا) نكمل الباقي بدون ما نكسر كل الأمر
          logger.warn("فشل إرسال صورة بحث وحدة:", imgErr);
        }
      }
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .بحث:", err);
      await notifyOwnerOfError(ctx.sock, ".بحث", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر تنفيذ البحث حاليًا. حاول مرة ثانية بعد شوي." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
