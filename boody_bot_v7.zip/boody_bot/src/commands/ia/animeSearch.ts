import { Command } from "../../handlers/types";
import { postJson } from "../../utils/imageSearch";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * .انمي <اسم> — يبحث عن أنمي بالاسم عبر AniList (مجاني، بدون مفتاح) ويرجع
 * اسمه الرسمي (ياباني/إنجليزي)، حالته، عدد حلقاته، تقييمه، ورابط صفحته.
 */
const QUERY = `
query ($search: String) {
  Media(search: $search, type: ANIME) {
    title { romaji english native }
    format
    status
    episodes
    averageScore
    season
    seasonYear
    genres
    siteUrl
    description(asHtml: false)
  }
}`;

function stripHtml(s: string): string {
  return s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
}

const STATUS_AR: Record<string, string> = {
  FINISHED: "مكتمل ✅",
  RELEASING: "يعرض حاليًا 🔴",
  NOT_YET_RELEASED: "لم يُعرض بعد ⏳",
  CANCELLED: "ملغي ❌",
  HIATUS: "متوقف مؤقتًا ⏸️",
};

const command: Command = {
  name: "بحث_انمي",
  aliases: ["متابعة_انمي", "انمي_بحث", "anime_search"],
  category: "IA",
  description: "يبحث عن أنمي بالاسم ويرجع معلوماته ورابطه. مثال: .بحث_انمي ون بيس",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ اكتب اسم الأنمي بعد الأمر.\nمثال: .بحث_انمي ون بيس" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const res = await postJson("https://graphql.anilist.co", { query: QUERY, variables: { search: query } });
      const media = res?.data?.Media;

      if (!media) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ ما لقيت أنمي بهذا الاسم: "${query}". جرّب الاسم بالإنجليزي.` },
          { quoted: ctx.msg }
        );
        return;
      }

      const title = media.title?.english || media.title?.romaji || media.title?.native || query;
      const altTitles = [media.title?.romaji, media.title?.native]
        .filter((t: string) => t && t !== title)
        .join(" | ");
      const status = STATUS_AR[media.status] || media.status || "غير معروف";
      const desc = media.description ? stripHtml(media.description).slice(0, 350) : "";

      const lines = [
        `🎬 *${title}*`,
        altTitles ? `(${altTitles})` : "",
        "",
        `📺 النوع: ${media.format || "-"}`,
        `📡 الحالة: ${status}`,
        media.episodes ? `🔢 الحلقات: ${media.episodes}` : "",
        media.averageScore ? `⭐ التقييم: ${media.averageScore}/100` : "",
        media.seasonYear ? `📅 الموسم: ${media.season || ""} ${media.seasonYear}`.trim() : "",
        media.genres?.length ? `🏷️ التصنيفات: ${media.genres.join("، ")}` : "",
        "",
        desc ? `📝 ${desc}${desc.length >= 350 ? "..." : ""}` : "",
        "",
        `🔗 ${media.siteUrl}`,
      ].filter(Boolean);

      await ctx.sock.sendMessage(ctx.chatId, { text: lines.join("\n") }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .انمي:", err);
      await notifyOwnerOfError(ctx.sock, ".بحث_انمي", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ صار خطأ أثناء البحث. حاول مرة ثانية." }, { quoted: ctx.msg });
    }
  },
};

export default command;
