import { Command } from "../../handlers/types";
import { startStory } from "../../handlers/storyManager";

const command: Command = {
  name: "قصة",
  aliases: ["مغامرة", "story"],
  // 🔧 (طلب صريح: "لعبة الراوي تستاهل قسم وحدها") — قبل كذا كانت تابعة
  // لقسم "IA"، الحين قسم مستقل خاص فيها بس (لها زر مباشر بالقائمة
  // الرئيسية "📖 الراوي" بدل ما تكون مدفونة بقائمة IA الفرعية).
  category: "الراوي",
  description: "مغامرة تفاعلية يرويها الذكاء الاصطناعي — يختار طريقه بأزرار (فعالية فردية)",
  permission: "all",
  execute: async (ctx) => {
    const seed = ctx.text.trim();
    await startStory(ctx.sock, ctx.chatId, ctx.senderJid, seed || undefined);
  },
};

export default command;
