import { Command } from "../../handlers/types";
import { bombManager } from "../../handlers/bombManager";

const command: Command = {
  name: "قنبلة",
  aliases: ["bomb"],
  category: "ترفيه",
  description: "لعبة القنبلة الجماعية — القنبلة تنتقل بينكم، آخر ناجي يفوز",
  permission: "all",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    await bombManager.start(ctx.sock, ctx.chatId, ctx.msg);
  },
};

export default command;
