import { Command } from "../../handlers/types";
import { TRUTHS, pickRandom, buildTruthDareTarget } from "./truthOrDareData";

const command: Command = {
  name: "صراحة",
  aliases: ["صراحه"],
  category: "ترفيه",
  description: "سؤال صراحة عشوائي (منشن اختياري لتوجيهه لشخص معيّن)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const { mention, jid } = buildTruthDareTarget(ctx);
    const question = pickRandom(TRUTHS);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🤫 *صراحة*\n${mention}\n${question}`, mentions: jid ? [jid] : [] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
