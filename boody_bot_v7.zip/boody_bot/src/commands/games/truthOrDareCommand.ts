import { Command } from "../../handlers/types";
import { TRUTHS, DARES, pickRandom, buildTruthDareTarget } from "./truthOrDareData";

const command: Command = {
  name: "جرأة_او_صراحة",
  aliases: ["صراحة_او_جرأة", "جرءة_او_صراحه"],
  category: "ترفيه",
  description: "يختار عشوائيًا بين سؤال صراحة أو تحدي جرأة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const { mention, jid } = buildTruthDareTarget(ctx);
    const isTruth = Math.random() < 0.5;
    const line = isTruth ? pickRandom(TRUTHS) : pickRandom(DARES);
    const label = isTruth ? "🤫 صراحة" : "🔥 جرأة";
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `*${label}*\n${mention}\n${line}`, mentions: jid ? [jid] : [] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
