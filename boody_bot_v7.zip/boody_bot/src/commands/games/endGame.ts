import { Command } from "../../handlers/types";
import { ticTacToeManager } from "../../handlers/ticTacToeManager";
import { game2048Manager } from "../../handlers/game2048Manager";
import { snakeManager } from "../../handlers/snakeManager";
import { eventManager } from "../../handlers/eventManager";

/**
 * 🆕 .دنهاء — ينهي أي لعبة/فعالية جارية حاليًا بهذي المجموعة (لهذا
 * البوت بالذات — نفس عزل كل الألعاب المعتمد بالمشروع)، بغض النظر عن
 * نوعها (اكس أو، 2048، الثعبان، أو فعالية عادية). طلب صريح: ماكو أمر
 * لإيقاف اكس أو/2048/الثعبان تحديدًا (بعكس .استسلم المخصص للفعاليات).
 */
const command: Command = {
  name: "انهاء",
  aliases: ["دنهاء", "ايقاف_اللعبة", "وقف_اللعبة"],
  category: "ترفيه",
  description: "ينهي أي لعبة أو فعالية جارية حاليًا بالمجموعة (اكس أو/2048/الثعبان/فعاليات)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const ended: string[] = [];

    if (ticTacToeManager.isRunning(ctx.sock, ctx.chatId)) {
      ticTacToeManager.stop(ctx.sock, ctx.chatId);
      ended.push("اكس أو");
    }
    if (game2048Manager.isRunning(ctx.sock, ctx.chatId)) {
      game2048Manager.end(ctx.sock, ctx.chatId);
      ended.push("2048");
    }
    if (snakeManager.isRunning(ctx.sock, ctx.chatId)) {
      snakeManager.end(ctx.sock, ctx.chatId);
      ended.push("الثعبان");
    }
    if (eventManager.isRunning(ctx.sock, ctx.chatId)) {
      eventManager.stop(ctx.sock, ctx.chatId);
      ended.push("فعالية");
    }

    if (!ended.length) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "ℹ️ ماكو أي لعبة أو فعالية شغالة حاليًا بهذي المجموعة." },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `✅ تم إنهاء: ${ended.join("، ")}.` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
