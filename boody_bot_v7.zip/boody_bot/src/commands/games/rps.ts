import { Command } from "../../handlers/types";
import { normalizeArabicCommand } from "../../utils/arabicNormalize";

const CHOICES = ["حجر", "ورقة", "مقص"] as const;
type Choice = (typeof CHOICES)[number];

const beats: Record<Choice, Choice> = {
  حجر: "مقص",
  ورقة: "حجر",
  مقص: "ورقة",
};

const emoji: Record<Choice, string> = { حجر: "🪨", ورقة: "📄", مقص: "✂️" };

const command: Command = {
  name: "حجر_ورقة_مقص",
  aliases: ["rps"],
  category: "ترفيه",
  description: "العب حجر ورقة مقص ضد البوت. مثال: .حجر_ورقة_مقص حجر",
  permission: "all",
  execute: async (ctx) => {
    // 🔧 إصلاح: مطابقة حرفية مباشرة كانت تفشل لو المستخدم كتب الاختيار
    // بحركة تشكيل زايدة (زي "حَجر"). الحين نقارن بعد إزالة التشكيل.
    const userChoice = CHOICES.find(
      (c) => normalizeArabicCommand(c) === normalizeArabicCommand(ctx.args[0] || "")
    );
    if (!userChoice) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `⚠️ اختر: ${CHOICES.join(" / ")}\nمثال: .حجر_ورقة_مقص حجر`,
      });
      return;
    }

    const botChoice = CHOICES[Math.floor(Math.random() * 3)];
    let result: string;
    if (botChoice === userChoice) result = "🤝 تعادل!";
    else if (beats[userChoice] === botChoice) result = "🎉 فزت!";
    else result = "😢 خسرت!";

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `أنت: ${emoji[userChoice]} ${userChoice}\nالبوت: ${emoji[botChoice]} ${botChoice}\n\n${result}`,
    });
  },
};

export default command;
