import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, bold } from "../../utils/helpers";

/** يرجع رقم عشوائي ثابت لنفس الشخص بنفس اليوم (حتى ما تتغير النسبة كل ثانية) */
function seededPercent(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 101;
}

function bar(percent: number): string {
  const filled = Math.round(percent / 10);
  return "🟩".repeat(filled) + "⬜".repeat(10 - filled);
}

const command: Command = {
  name: "تقييم",
  aliases: ["rate"],
  category: "ترفيه",
  description: "تقييم عشوائي للضحك بس 😂. مثال: .تقييم @user",
  permission: "all",
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const today = new Date().toDateString();

    const rojola = seededPercent(target + today + "rojola");
    const onootha = seededPercent(target + today + "onootha");
    const khatar = seededPercent(target + today + "khatar");

    const text =
      `📊 تقييم ${jidToMention(target)}\n\n` +
      `💪 رجولة: ${rojola}%\n${bar(rojola)}\n\n` +
      `💃 أنوثة: ${onootha}%\n${bar(onootha)}\n\n` +
      `🔥 خطورة: ${khatar}%\n${bar(khatar)}\n\n` +
      `${bold("النسب للفرفشة بس، لا تزعل منها 😆")}`;

    await ctx.sock.sendMessage(ctx.chatId, { text, mentions: [target] }, { quoted: ctx.msg });
  },
};

export default command;
