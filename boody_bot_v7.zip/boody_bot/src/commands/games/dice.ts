import { Command } from "../../handlers/types";

const command: Command = {
  name: "رمي_النرد",
  aliases: ["dice", "نرد"],
  category: "ترفيه",
  description: "رمي نرد عشوائي من 1 إلى 6",
  permission: "all",
  execute: async (ctx) => {
    const result = Math.floor(Math.random() * 6) + 1;
    const faces = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🎲 النتيجة: ${faces[result - 1]}  (${result})` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
