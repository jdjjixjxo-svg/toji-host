import { Command } from "../../handlers/types";
import { ticTacToeManager } from "../../handlers/ticTacToeManager";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { renderTicTacToeImage } from "../../utils/ticTacToeRenderer";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "إكس_أو",
  aliases: ["xo", "tictactoe", "اكسو", "اكس_او"],
  category: "ترفيه",
  description: "ابدأ لعبة إكس أو مع عضو آخر. مثال: .إكس_أو @user",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (ticTacToeManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ هناك لعبة إكس أو جارية بالفعل في هذه المجموعة.",
      });
      return;
    }

    // 🔧 إصلاح (سبب "اللعبة تبدأ بس الخصم يضغط رقم وتقوله البوت ما يرد
    // / يقول مو دورك رغم إنه فعلاً دوره"): كنا نأخذ JID الخصم الخام من
    // المنشن مباشرة (قد يوصل بصيغة "xxxx@lid" مؤقتة). لاحقًا لما الخصم
    // نفسه يرسل رقم الخانة، senderJid يوصل من messageHandler محلولًا
    // فعليًا لرقمه الحقيقي (resolveGroupJid) — فتفشل المقارنة المباشرة
    // بين الاثنين رغم إنه نفس الشخص. نستخدم getTargetJid هنا بالضبط
    // زي بقية أوامر الإشراف/الاقتصاد حتى يخزّن نفس صيغة JID الموحّدة
    // اللي راح توصل لاحقًا من senderJid.
    const opponent = getTargetJid(ctx.msg, ctx.metadata);
    if (!opponent) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ منشن الخصم لبدء اللعبة.\nمثال: .إكس_أو @user",
      });
      return;
    }


    ticTacToeManager.start(ctx.sock as any, ctx.chatId, ctx.senderJid, opponent);

    const caption =
      `🎮 بدأت لعبة إكس أو!\n` +
      `❌ ${jidToMention(ctx.senderJid)}  ضد  ⭕ ${jidToMention(opponent)}\n\n` +
      `🎯 دور ${jidToMention(ctx.senderJid)} — أرسل رقم الخانة (1-9)`;

    // 🆕 صورة 2D واضحة للوحة بدل النص القديم. لو فشل توليد الصورة لأي
    // سبب (بيئة استضافة ناقصة مثلًا)، نرجع تلقائيًا للنص القديم حتى لا
    // تنكسر اللعبة أبدًا.
    try {
      const board = await renderTicTacToeImage(["1", "2", "3", "4", "5", "6", "7", "8", "9"]);
      await ctx.sock.sendMessage(ctx.chatId, {
        image: board,
        caption,
        mentions: [ctx.senderJid, opponent],
      });
    } catch (err) {
      logger.warn("⚠️ تعذر توليد صورة لوحة إكس_أو، تم الرجوع للنص.", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `${caption}\n\n${ticTacToeManager.renderBoard(["1", "2", "3", "4", "5", "6", "7", "8", "9"])}`,
        mentions: [ctx.senderJid, opponent],
      });
    }
  },
};

export default command;
