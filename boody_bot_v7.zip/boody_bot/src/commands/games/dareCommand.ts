import { Command } from "../../handlers/types";
import { DARES, pickRandom, buildTruthDareTarget } from "./truthOrDareData";

const command: Command = {
  name: "جرأة",
  aliases: ["جراة", "جرءة"],
  category: "ترفيه",
  description: "تحدي جرأة عشوائي (منشن اختياري لتوجيهه لشخص معيّن)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const { mention, jid } = buildTruthDareTarget(ctx);
    const dare = pickRandom(DARES);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `🔥 *جرأة*\n${mention}\n${dare}`, mentions: jid ? [jid] : [] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
