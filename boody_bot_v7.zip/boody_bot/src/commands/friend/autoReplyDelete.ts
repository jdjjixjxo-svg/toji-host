import { Command } from "../../handlers/types";
import { getAutoReplies, setAutoReplies, reply } from "../../utils/friendUtils";

/** .حذف رد <الكلمة> — يحذف رد تلقائي واحد أضفته بـ .اضافة_رد */
const command: Command = {
  name: "حذف_رد",
  aliases: ["مسح_رد", "delreply"],
  category: "المطور",
  description: "يحذف رد تلقائي واحد (الكلمة المفعّلة له). مثال: .حذف رد مرحبا",
  permission: "owner",
  execute: async (ctx) => {
    const key = ctx.text.trim();
    const map = getAutoReplies();
    const keys = Object.keys(map);
    if (!key) {
      return reply(
        ctx,
        keys.length
          ? `🗑️ *حذف رد*\nاكتب: .حذف رد <الكلمة>\n\nالردود الحالية (${keys.length}):\n${keys.map((k) => `• ${k}`).join("\n")}`
          : "📭 ما فيه ردود مضافة أصلًا.\nلإضافة رد: .اضافة_رد كلمة | الرد"
      );
    }
    if (!(key in map)) return reply(ctx, `❌ ما لقيت رد بالكلمة «${key}».\nاكتب .حذف رد لعرض القائمة.`);
    delete map[key];
    setAutoReplies(map);
    await reply(ctx, `✅ انحذف الرد على «${key}».`);
  },
};
export default command;
