import { Command } from "../../handlers/types";
import { videoToSquarePtv } from "../../utils/ffmpegMedia";
import { getPtvBuffer } from "../../events/groupJoinPtv";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "نغ",
  aliases: ["ptv", "دائري"],
  category: "ادوات",
  description: "يرسل PTV (فيديو دائري) — رد على فيديو لتحويله، أو بدون رد لإرسال فيديو البوت",
  permission: "all",
  execute: async (ctx) => {
    try {
      const media = await getMedia(ctx, ["video"]);
      const buf = media ? await videoToSquarePtv(media.buffer) : await getPtvBuffer();
      if (!buf) return reply(ctx, "❌ ما فيه فيديو متاح. رد على فيديو بهذا الأمر.");
      await ctx.sock.sendMessage(ctx.chatId, { video: buf, ptv: true } as any, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر نغ:", err);
      await reply(ctx, "❌ تعذر إرسال الفيديو الدائري.");
    }
  },
};
export default command;
