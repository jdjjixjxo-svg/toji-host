import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const EXT: Record<string, string> = { image: "jpg", video: "mp4", audio: "mp3", sticker: "webp", document: "bin" };

const command: Command = {
  name: "لرابط",
  aliases: ["tourl", "رابط_ميديا"],
  category: "ادوات",
  description: "رفع الوسائط إلى سيرفرات خارجية وتحويلها لروابط",
  permission: "all",
  execute: async (ctx) => {
    try {
      const media = await getMedia(ctx, ["image", "video", "audio", "sticker", "document"]);
      if (!media) return reply(ctx, "❗ رد على صورة/فيديو/صوت/ملف بهذا الأمر.");
      if (media.buffer.length > 40 * 1024 * 1024) return reply(ctx, "❌ الملف أكبر من 40MB.");
      const form = new FormData();
      form.append("reqtype", "fileupload");
      form.append("fileToUpload", new Blob([media.buffer]), `boody.${EXT[media.kind]}`);
      const res = await fetch("https://catbox.moe/user/api.php", { method: "POST", body: form, signal: AbortSignal.timeout(90_000) });
      const url = (await res.text()).trim();
      if (!res.ok || !/^https?:\/\//.test(url)) throw new Error(`UPLOAD_FAILED ${res.status} ${url.slice(0, 80)}`);
      await reply(ctx, `🔗 *الرابط:*\n${url}`);
    } catch (err) {
      logger.error("فشل أمر لرابط:", err);
      await reply(ctx, "❌ تعذر رفع الملف حاليًا.");
    }
  },
};
export default command;
