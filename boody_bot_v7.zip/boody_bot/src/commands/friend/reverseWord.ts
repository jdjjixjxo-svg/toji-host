import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { buildEventCard } from "../../utils/miniQuiz";
import { sendWithSalawatFallback } from "../../utils/media";

const WORDS = ["مدرسة", "سيارة", "حديقة", "كمبيوتر", "طيارة", "مكتبة", "شاطئ", "قهوة", "نجمة", "صحراء", "بحيرة", "مطعم", "جامعة", "ملعب", "شجرة", "هاتف"];

const command: Command = {
  name: "اعكس_الكلمة",
  aliases: ["reverseword", "كلمة_مقلوبة"],
  category: "ترفيه",
  description: "لعبة اعكس الكلمة — احزر الكلمة من شكلها المقلوب 🔤",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم" }, { quoted: ctx.msg });
      return;
    }
    const word = WORDS[Math.floor(Math.random() * WORDS.length)];
    const reversed = word.split("").reverse().join(" ");
    eventManager.start(ctx.sock as any, ctx.chatId, "اعكس الكلمة", word, 30_000);
    const card = buildEventCard(
      ctx.metadata?.subject || "الخاص",
      "اعكس الكلمة",
      `🔄 هذي كلمة مقلوبة الحروف، اكتبها بشكلها الصحيح:\n*${reversed}*`,
      "أول شخص يكتب الكلمة الصحيحة يفوز بالنقاط.",
      "⏱️ 30 ثانية فقط!"
    );
    await sendWithSalawatFallback(ctx.sock, ctx.chatId, card);
  },
};
export default command;
