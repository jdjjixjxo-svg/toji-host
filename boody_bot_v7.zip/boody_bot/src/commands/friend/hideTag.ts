import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "مخفي",
  aliases: ["hidetag", "اخفاء_المنشن"],
  category: "مشرفين",
  description: "عمل منشن مخفي لجميع الأعضاء مع دعم الميديا (للمشرفين والنخبة)",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const mentions = (ctx.metadata?.participants || []).map((p) => p.id);
    const quotedText = ctx.quoted?.conversation || ctx.quoted?.extendedTextMessage?.text || "";
    const text = ctx.text.trim() || quotedText;
    const media = await getMedia(ctx, ["image", "video", "audio", "sticker"]).catch(() => null);

    if (media) {
      const cap = text || undefined;
      if (media.kind === "image") await ctx.sock.sendMessage(ctx.chatId, { image: media.buffer, caption: cap, mentions });
      else if (media.kind === "video") await ctx.sock.sendMessage(ctx.chatId, { video: media.buffer, caption: cap, mentions });
      else if (media.kind === "audio") await ctx.sock.sendMessage(ctx.chatId, { audio: media.buffer, mimetype: "audio/mp4", ptt: !!media.message?.ptt, mentions });
      else await ctx.sock.sendMessage(ctx.chatId, { sticker: media.buffer, mentions } as any);
      return;
    }
    if (!text) return reply(ctx, "❗ اكتب نصًا أو رد على رسالة/ميديا. مثال: .مخفي اجتماع الساعة 9");
    await ctx.sock.sendMessage(ctx.chatId, { text, mentions });
  },
};
export default command;
