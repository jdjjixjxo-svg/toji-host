import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("نعم") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_نعم",
  category: "ترفيه",
  description: "إجابة لعبة المارد: نعم",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_نعم"),
};
export default command;
