import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("لا") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_لا",
  category: "ترفيه",
  description: "إجابة لعبة المارد: لا",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_لا"),
};
export default command;
