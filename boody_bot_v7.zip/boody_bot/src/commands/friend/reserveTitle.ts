import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "حجز_لقب",
  aliases: ["reservetitle", "احجز_لقب"],
  category: "بوت",
  description: "نظام إدارة الألقاب والكنى داخل المجموعات — احجز لقبًا لنفسك",
  permission: "all",
  execute: async (ctx) => {
    const title = ctx.text.trim();
    if (!title) return reply(ctx, "❗ اكتب اللقب. مثال: .حجز_لقب ميهوك");
    if (title.length > 40) return reply(ctx, "❌ اللقب أطول من 40 حرف.");
    if (!(await ensureTitlesReady())) return reply(ctx, "❌ نظام الألقاب غير متصل حاليًا.");
    try {
      const existing = await TitleStore.findOne({ title });
      if (existing && existing.userId !== ctx.senderJid) return reply(ctx, `❌ اللقب *${title}* محجوز مسبقًا لشخص ثاني.`);
      await TitleStore.findOneAndUpdate({ userId: ctx.senderJid }, { title }, { upsert: true });
      await reply(ctx, `✅ تم حجز لقبك: *${title}*`);
    } catch (err: any) {
      await reply(ctx, err?.code === 11000 ? `❌ اللقب *${title}* محجوز مسبقًا.` : "❌ حدث خطأ أثناء حجز اللقب.");
    }
  },
};
export default command;
