import { Command } from "../../handlers/types";
import { fetchJson, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "كلمات",
  aliases: ["lyrics", "كلمات_اغنية"],
  category: "ادوات",
  description: "البحث عن كلمات الأغاني",
  permission: "all",
  execute: async (ctx) => {
    const q = ctx.text.trim();
    if (!q) return reply(ctx, "❗ اكتب اسم الأغنية. مثال: .كلمات فيروز نسم علينا الهوا");
    try {
      const list = await fetchJson<any[]>(`https://lrclib.net/api/search?q=${encodeURIComponent(q)}`);
      const hit = (list || []).find((r) => r.plainLyrics);
      if (!hit) return reply(ctx, "❌ ما لقيت كلمات لهذي الأغنية.");
      const body = String(hit.plainLyrics).slice(0, 3500);
      await reply(ctx, `🎼 *${hit.trackName}* — ${hit.artistName}\n\n${body}`);
    } catch (err) {
      logger.error("فشل أمر كلمات:", err);
      await reply(ctx, "❌ تعذر جلب الكلمات حاليًا.");
    }
  },
};
export default command;
