import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("غلط") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_غلط",
  category: "ترفيه",
  description: "إجابة لعبة المارد: غلط",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_غلط"),
};
export default command;
