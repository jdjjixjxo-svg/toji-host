import { toggleCommand } from "../../utils/friendUtils";
import { getFriendCfg, setFriendCfg } from "../../utils/friendUtils";
export default toggleCommand({
  name: "منع_الميديا",
  aliases: ["antimedia","منع_ميديا"],
  description: "تفعيل أو تعطيل الحذف التلقائي للميديا والملفات في المجموعة",
  label: "🚫 منع الميديا",
  requireBotAdmin: true,
  get: (ctx) => getFriendCfg(ctx.chatId).antiMedia,
  set: (ctx, v) => { setFriendCfg(ctx.chatId, { antiMedia: v }); },
});
