import { toggleCommand } from "../../utils/friendUtils";
import { getFriendCfg, setFriendCfg } from "../../utils/friendUtils";
export default toggleCommand({
  name: "منع_ملصقات",
  aliases: ["antisticker","منع_ملصق"],
  description: "تشغيل/تعطيل حذف الملصقات تلقائيًا داخل الجروب",
  label: "🚫 منع الملصقات",
  requireBotAdmin: true,
  get: (ctx) => getFriendCfg(ctx.chatId).antiSticker,
  set: (ctx, v) => { setFriendCfg(ctx.chatId, { antiSticker: v }); },
});
