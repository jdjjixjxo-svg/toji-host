import { Command } from "../../handlers/types";
import { getFriendCfg, setFriendCfg, parseOnOff, reply } from "../../utils/friendUtils";
import { getMentionedJids } from "../../utils/helpers";

const command: Command = {
  name: "طلبات",
  aliases: ["joinrequests", "طلبات_الانضمام"],
  category: "مشرفين",
  description: "إدارة طلبات الانضمام للجروب (عرض/قبول/رفض/قبول تلقائي)",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const sub = (ctx.args[0] || "عرض").trim();

    if (sub === "تلقائي" || sub === "auto") {
      const v = parseOnOff(ctx.args[1]);
      const next = v === undefined ? !getFriendCfg(ctx.chatId).autoAccept : v;
      setFriendCfg(ctx.chatId, { autoAccept: next });
      return reply(ctx, `⚡ القبول التلقائي: ${next ? "✅ مفعّل" : "❌ متوقف"}`);
    }

    let list: { jid: string }[] = [];
    try {
      list = (await ctx.sock.groupRequestParticipantsList(ctx.chatId)) as any;
    } catch {
      return reply(ctx, "❌ تعذر جلب الطلبات (تأكد أن البوت مشرف وأن المجموعة تتطلب موافقة).");
    }

    if (sub === "عرض" || sub === "list") {
      if (!list.length) return reply(ctx, "📭 لا توجد طلبات انضمام معلّقة.");
      const jids = list.slice(0, 40).map((r) => r.jid);
      return reply(
        ctx,
        `📥 طلبات الانضمام (${list.length}):\n${jids.map((j, i) => `${i + 1}. @${j.split("@")[0]}`).join("\n")}\n\n.طلبات قبول — قبول الكل\n.طلبات رفض — رفض الكل\n.طلبات تلقائي تشغيل|ايقاف`,
        jids
      );
    }

    if (sub === "قبول" || sub === "رفض") {
      const action = sub === "قبول" ? "approve" : "reject";
      const mentioned = getMentionedJids(ctx.msg);
      const targets = mentioned.length ? list.filter((r) => mentioned.includes(r.jid)).map((r) => r.jid) : list.map((r) => r.jid);
      if (!targets.length) return reply(ctx, "📭 لا توجد طلبات مطابقة.");
      for (let i = 0; i < targets.length; i += 20) {
        await ctx.sock.groupRequestParticipantsUpdate(ctx.chatId, targets.slice(i, i + 20), action);
      }
      return reply(ctx, `✅ تم ${sub === "قبول" ? "قبول" : "رفض"} ${targets.length} طلب.`);
    }

    await reply(ctx, ".طلبات عرض | قبول | رفض | تلقائي تشغيل|ايقاف");
  },
};
export default command;
