import { Command } from "../../handlers/types";
import { getGroupSettings, setGroupSetting } from "../../database/db";
import { getFriendCfg, setFriendCfg, parseOnOff, reply } from "../../utils/friendUtils";
import { THREE_LINK_THRESHOLD } from "../../utils/friendUtils";

/**
 * 🆕 (طلب صريح: ".3=طرد") — وضع حماية جديد، منفصل تمامًا عن .منع_الروابط
 * القديم: أي عضو (غير مشرف) يبعث 3 روابط يُطرد تلقائيًا فورًا.
 *
 * .3=طرد تشغيل  → يفعّل هذا الوضع (يتجاوز نظام .منع_الروابط القديم تلقائيًا)
 * .3=طرد ايقاف  → يرجّع نظام .منع_الروابط القديم (تحذير/حذف/طرد حسب اختياره)
 * .3=طرد        → بدون كلمة: يعرض الحالة الحالية فقط
 *
 * للمشرفين فقط (permission: "admin") — تمامًا كما طُلب.
 */
const command: Command = {
  name: "3=طرد",
  aliases: ["3=kick", "٣=طرد", "ثلاث_روابط_طرد", "طرد_3_روابط"],
  category: "مشرفين",
  description: `تفعيل/إيقاف الطرد التلقائي عند إرسال ${THREE_LINK_THRESHOLD} روابط (${"مشرفين فقط"})`,
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const word = ctx.args[0];
    const onoff = parseOnOff(word);

    if (onoff !== undefined) {
      setFriendCfg(ctx.chatId, { threeLinkKick: onoff });
      // تفعيله يحتاج نظام الحماية العام + منع الروابط شغّالين أصلًا، وإلا
      // ما توصل الرسالة لفحص الروابط من الأساس.
      if (onoff) {
        setGroupSetting(ctx.chatId, "protection", true);
        setGroupSetting(ctx.chatId, "antilink", true);
      }
    }

    const enabled = getFriendCfg(ctx.chatId).threeLinkKick;
    const oldMode = getFriendCfg(ctx.chatId).linkMode;
    const s = getGroupSettings(ctx.chatId);

    await reply(
      ctx,
      `🔗🚫 وضع "${THREE_LINK_THRESHOLD} روابط = طرد": ${enabled ? "✅ مفعّل" : "❌ متوقف"}\n` +
        (enabled
          ? `أي عضو يبعث ${THREE_LINK_THRESHOLD} روابط يُطرد تلقائيًا فورًا (بدون تحذير يدوي).`
          : `يشتغل الآن نظام .منع_الروابط القديم — الوضع الحالي: *${oldMode === "kick" ? "حذف + طرد" : oldMode === "delete" ? "حذف فقط" : "تحذير"}*.`) +
        `\n\nمنع الروابط بشكل عام: ${s.antilink ? "✅ مفعّل" : "❌ متوقف"}\n\n` +
        `.3=طرد تشغيل | ايقاف`
    );
  },
};

export default command;
