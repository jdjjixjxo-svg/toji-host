import { Command } from "../../handlers/types";
import { getTargetJid } from "../../utils/helpers";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "مراكم",
  aliases: ["tarakom"],
  category: "ترفيه",
  description: "حساب نسبة التراكم عشوائيًا لأحد أعضاء المجموعة (ترفيهي)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const pct = Math.floor(Math.random() * 101);
    const bar = "█".repeat(Math.round(pct / 10)) + "░".repeat(10 - Math.round(pct / 10));
    await reply(ctx, `📊 نسبة التراكم عند @${target.split("@")[0]}:\n${bar} *${pct}%*\n_(عشوائي للترفيه فقط)_`, [target]);
  },
};
export default command;
