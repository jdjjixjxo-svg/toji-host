import { Command } from "../../handlers/types";
import { extractAudioFromVideo } from "../../utils/ffmpegMedia";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "لصوت",
  aliases: ["toaudio", "استخراج_صوت"],
  category: "ادوات",
  description: "استخراج الصوت من الفيديو بسرعة فائقة",
  permission: "all",
  execute: async (ctx) => {
    try {
      const media = await getMedia(ctx, ["video", "audio"]);
      if (!media) return reply(ctx, "❗ رد على فيديو بهذا الأمر.");
      const mp3 = media.kind === "audio" ? media.buffer : await extractAudioFromVideo(media.buffer);
      await ctx.sock.sendMessage(ctx.chatId, { audio: mp3, mimetype: "audio/mpeg" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر لصوت:", err);
      await reply(ctx, "❌ تعذر استخراج الصوت.");
    }
  },
};
export default command;
