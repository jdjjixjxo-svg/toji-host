import { Command } from "../../handlers/types";
import { startAnimeGuess } from "../../utils/animeGuess";

const command: Command = {
  name: "احزر",
  aliases: ["guess"],
  category: "ترفيه",
  description: "لعبة تخمين الشخصية من صورتها (أي عضو في الجروب يقدر يجاوب)",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => startAnimeGuess(ctx, "full"),
};
export default command;
