import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "لقبه",
  aliases: ["hisTitle", "لقبها"],
  category: "بوت",
  description: "معرفة لقب العضو داخل المجموعة 🏷️",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) return reply(ctx, "❗ منشن العضو أو رد على رسالته. مثال: .لقبه @شخص");
    if (!(await ensureTitlesReady())) return reply(ctx, "❌ نظام الألقاب غير متصل حاليًا.");
    const t = await TitleStore.findOne({ userId: target });
    await reply(ctx, t ? `🏷️ لقب ${jidToMention(target)}: *${t.title}*` : `❌ ${jidToMention(target)} ما عنده لقب.`, [target]);
  },
};
export default command;
