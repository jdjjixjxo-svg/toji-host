import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { getChatLines, reply } from "../../utils/friendUtils";

const GEMINI_MODEL = "gemini-3.1-flash-lite"; // نفس نموذج .سوال

const command: Command = {
  name: "ملخص",
  aliases: ["summary", "لخص"],
  category: "IA",
  description: "تلخيص المحادثة بأسلوب مرح (للمشرفين فقط)",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    if (!CONFIG.GEMINI_API_KEY) return reply(ctx, "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env.");
    const lines = getChatLines(ctx.chatId);
    if (lines.length < 8) return reply(ctx, "ℹ️ ما فيه محادثة كافية للتلخيص بعد (البوت يسجّل الرسائل من لحظة تشغيله).");
    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const chat = lines.map((l) => `${l.n}: ${l.t}`).join("\n");
      const res = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: `لخّص هذه المحادثة الجماعية بأسلوب عربي مرح وكوميدي خفيف في 6 أسطر كحد أقصى، اذكر أبرز المواضيع ومن قال ماذا:\n\n${chat}`,
      });
      const out = (res as any).text || "";
      await reply(ctx, out ? `📝 *ملخص المحادثة*\n\n${out}` : "❌ لم يصل ملخص من الذكاء الاصطناعي.");
    } catch (err) {
      logger.error("فشل أمر ملخص:", err);
      await reply(ctx, "❌ تعذر التلخيص حاليًا.");
    }
  },
};
export default command;
