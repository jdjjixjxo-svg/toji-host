import fs from "fs-extra";
import { Command } from "../../handlers/types";
import { getPtvStatus, resetPtvCache, PTV_SOURCE_PATH } from "../../events/groupJoinPtv";
import { applyVideoEdit, VIDEO_EDIT_EFFECTS } from "../../utils/ffmpegMedia";
import { reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * .تعديل_تست — يعدّل *فيديو الترحيب الدائري* نفسه اللي يديره أمر .تست
 * (نفس الملف المحفوظ بـPTV_SOURCE_PATH)، بشكل دائم — التعديل يُحفظ فيصير
 * هو فيديو الترحيب الجديد من الآن فصاعدًا.
 *
 * ".تعديل_تست <تأثير>"   → يطبّق التأثير ويحفظه ويرسل معاينة.
 * ".تعديل_تست" بدون شي   → يعرض قائمة التأثيرات المتاحة + حالة الفيديو الحالي.
 * ".تعديل_تست استرجاع"  → يرجّع آخر نسخة قبل آخر تعديل (نسخة احتياطية وحيدة).
 */
const BACKUP_PATH = `${PTV_SOURCE_PATH}.bak`;

const command: Command = {
  name: "تعديل_تست",
  aliases: ["تعديل تست", "edittest", "نانو_تست"],
  category: "المطور",
  description: "يعدّل فيديو الترحيب الدائري (.تست) بتأثير ثابت ويحفظه كبديل دائم",
  permission: "owner",
  execute: async (ctx) => {
    const effect = ctx.text.trim();
    const effectsList = Object.keys(VIDEO_EDIT_EFFECTS).join(" | ");

    if (!effect) {
      const st = await getPtvStatus();
      const statusLine =
        "error" in st
          ? st.error === "NO_SOURCE"
            ? "📭 ما فيه فيديو ترحيب محفوظ حاليًا — احفظ وحدة أول بـ«.تست» (رد على فيديو)."
            : "⚠️ فيه فيديو محفوظ بس فشل تحويله حاليًا."
          : "✅ فيه فيديو ترحيب محفوظ وجاهز.";
      return reply(
        ctx,
        `${statusLine}\n\n*التأثيرات المتاحة:*\n${effectsList}\n\n` +
          `الاستخدام: «.تعديل_تست <تأثير>» — مثال: .تعديل_تست اسود_ابيض\n` +
          `للتراجع عن آخر تعديل: «.تعديل_تست استرجاع»`
      );
    }

    if (effect === "استرجاع") {
      if (!(await fs.pathExists(BACKUP_PATH))) {
        return reply(ctx, "❌ ما فيه نسخة احتياطية محفوظة للتراجع إليها.");
      }
      await fs.copy(BACKUP_PATH, PTV_SOURCE_PATH, { overwrite: true });
      resetPtvCache();
      const st = await getPtvStatus();
      if ("error" in st) return reply(ctx, "✅ تم الاسترجاع، لكن تعذّر إنشاء معاينة الآن.");
      await ctx.sock.sendMessage(ctx.chatId, { video: st.buffer, ptv: true } as any);
      return reply(ctx, "✅ رجّعنا آخر نسخة قبل التعديل.");
    }

    if (!VIDEO_EDIT_EFFECTS[effect]) {
      return reply(ctx, `❌ تأثير غير معروف: "${effect}"\n\n*المتاح:*\n${effectsList}`);
    }

    if (!(await fs.pathExists(PTV_SOURCE_PATH))) {
      return reply(ctx, "📭 ما فيه فيديو ترحيب محفوظ أصلًا. احفظ وحدة أول: رد على فيديو بـ«.تست».");
    }

    try {
      const rawBuffer = await fs.readFile(PTV_SOURCE_PATH);
      const edited = await applyVideoEdit(rawBuffer, effect);

      // نسخة احتياطية وحيدة (آخر حالة قبل هالتعديل) — تسمح بـ«.تعديل_تست استرجاع»
      await fs.copy(PTV_SOURCE_PATH, BACKUP_PATH, { overwrite: true });
      await fs.writeFile(PTV_SOURCE_PATH, edited);
      resetPtvCache();

      const st = await getPtvStatus();
      if ("error" in st) {
        return reply(ctx, `⚠️ اتحفظ التعديل، بس فشلت معاينة الفيديو الدائري.\nالسبب: ${st.error === "CONVERT_FAILED" ? st.detail : st.error}`);
      }

      await ctx.sock.sendMessage(ctx.chatId, { video: st.buffer, ptv: true } as any);
      await reply(ctx, `✅ تم تطبيق تأثير "${effect}" وحفظه كفيديو الترحيب الجديد.\n↩️ للتراجع: .تعديل_تست استرجاع`);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .تعديل_تست:", err);
      await notifyOwnerOfError(ctx.sock, ".تعديل_تست", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await reply(ctx, "❌ فشل تعديل الفيديو. الفيديو الأصلي لم يتغير.");
    }
  },
};

export default command;
