import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "متوفر",
  aliases: ["available", "لقب_متوفر"],
  category: "بوت",
  description: "فحص توفر اللقب داخل المجموعة 🔍",
  permission: "all",
  execute: async (ctx) => {
    const title = ctx.text.trim();
    if (!title) return reply(ctx, "❗ اكتب اللقب. مثال: .متوفر ميهوك");
    if (!(await ensureTitlesReady())) return reply(ctx, "❌ نظام الألقاب غير متصل حاليًا.");
    const t = await TitleStore.findOne({ title });
    await reply(ctx, t ? `❌ اللقب *${title}* محجوز مسبقًا.` : `✅ اللقب *${title}* متوفر! احجزه بـ .حجز_لقب ${title}`);
  },
};
export default command;
