import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { getFriendCfg, setFriendCfg, reply } from "../../utils/friendUtils";

const PROTECTED = new Set(["قفل_امر", "فتح_امر", "menu", "مود", "منع_بوت", "تشغيل", "ايقاف"]);

const command: Command = {
  name: "قفل_امر",
  aliases: ["lockcmd"],
  category: "مشرفين",
  description: "قفل أمر معيّن في هذه المجموعة (للمشرفين فقط)",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const word = ctx.args[0]?.replace(/^\./, "");
    if (!word) {
      const list = getFriendCfg(ctx.chatId).lockedCmds;
      return reply(ctx, `🔒 الأوامر المقفولة: ${list.length ? list.join("، ") : "لا يوجد"}\nمثال: .قفل_امر نرد`);
    }
    const cmd = commandRegistry.get(word);
    if (!cmd) return reply(ctx, `❌ ما لقيت أمر باسم "${word}".`);
    if (PROTECTED.has(cmd.name)) return reply(ctx, "❌ هذا الأمر لا يمكن قفله.");
    const list = Array.from(new Set([...getFriendCfg(ctx.chatId).lockedCmds, cmd.name]));
    setFriendCfg(ctx.chatId, { lockedCmds: list });
    await reply(ctx, `🔒 تم قفل الأمر *${cmd.name}* لغير المشرفين.`);
  },
};
export default command;
