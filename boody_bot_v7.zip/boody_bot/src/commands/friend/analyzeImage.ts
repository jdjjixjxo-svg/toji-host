import { Command } from "../../handlers/types";
import { analyzeMediaIfPresent } from "../../utils/aiVision";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "تحليل_صورة",
  aliases: ["حلل", "analyze"],
  category: "IA",
  description: "تحليل الصور والفيديوهات باستخدام الذكاء الاصطناعي",
  permission: "all",
  execute: async (ctx) => {
    if (!(await analyzeMediaIfPresent(ctx))) await reply(ctx, "❗ رد على صورة أو فيديو (واكتب سؤالك اختياريًا). مثال: .تحليل_صورة وش المكتوب هنا؟");
  },
};
export default command;
