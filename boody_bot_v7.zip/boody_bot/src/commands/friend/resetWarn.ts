import { Command } from "../../handlers/types";
import { resetWarnings } from "../../database/db";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "عيد_تحذير",
  aliases: ["تصفير_تحذير", "resetwarn"],
  category: "مشرفين",
  description: "تصفير (إرجاع) تحذيرات عضو معيّن إلى صفر - للمشرفين فقط",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) return reply(ctx, "❗ منشن العضو أو رد على رسالته. مثال: .عيد_تحذير @شخص");
    resetWarnings(ctx.chatId, target);
    await reply(ctx, `✅ تم تصفير تحذيرات ${jidToMention(target)}`, [target]);
  },
};
export default command;
