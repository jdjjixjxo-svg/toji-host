import { Command } from "../../handlers/types";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "تغيير_الاسم",
  aliases: ["setname", "اسم_المجموعة"],
  category: "مشرفين",
  description: "تغيير اسم المجموعة (للمشرفين فقط).",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const name = ctx.text.trim();
    if (!name) return reply(ctx, "❗ اكتب الاسم الجديد. مثال: .تغيير_الاسم مجموعة الأصدقاء");
    if (name.length > 100) return reply(ctx, "❌ الاسم أطول من 100 حرف.");
    await ctx.sock.groupUpdateSubject(ctx.chatId, name);
    await reply(ctx, "✅ تم تغيير اسم المجموعة.");
  },
};
export default command;
