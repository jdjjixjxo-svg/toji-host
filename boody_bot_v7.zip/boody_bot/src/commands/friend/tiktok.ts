import { Command } from "../../handlers/types";
import { detectPlatform, resolveVideo, searchTikTokVideo, downloadBuffer } from "../../utils/downloader";
import { logger } from "../../utils/logger";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "تيك",
  aliases: ["tiktok", "tt"],
  category: "ادوات",
  description: "تحميل فيديوهات تيك توك بدون علامة مائية، أو البحث بكلمة",
  permission: "all",
  execute: async (ctx) => {
    const q = ctx.text.trim();
    if (!q) return reply(ctx, "❗ اكتب رابط تيك توك أو كلمة بحث. مثال: .تيك ون بيس");
    try {
      let videoUrl: string | undefined;
      if (/^https?:\/\//i.test(q) && detectPlatform(q) === "tiktok") {
        videoUrl = (await resolveVideo(q, "tiktok")).videoUrl;
      } else {
        videoUrl = (await searchTikTokVideo(q))?.videoUrl;
      }
      if (!videoUrl) return reply(ctx, "❌ ما لقيت فيديو.");
      const buf = await downloadBuffer(videoUrl, () => undefined, "tiktok");
      await ctx.sock.sendMessage(ctx.chatId, { video: buf, caption: "✅ تيك توك - 𝑩𝑶𝑶𝑫𝒀" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر تيك:", err);
      await reply(ctx, "❌ تعذر تحميل الفيديو حاليًا.");
    }
  },
};
export default command;
