import sharp from "sharp";
import { Command } from "../../handlers/types";
import { reply } from "../../utils/friendUtils";

const GRADS: [string, string][] = [["#ff512f", "#f09819"], ["#00c6ff", "#0072ff"], ["#f953c6", "#b91d73"], ["#11998e", "#38ef7d"], ["#8e2de2", "#4a00e0"]];
const esc = (s: string) => s.replace(/[<>&"']/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" }[c] as string));

const command: Command = {
  name: "تأثير",
  aliases: ["effect", "نص_ملصق"],
  category: "ادوات",
  description: "إنشاء ملصق نصي بتأثيرات ألوان (تدرّج + ظل) مباشرة",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim().slice(0, 40);
    if (!text) return reply(ctx, "❗ اكتب النص. مثال: .تأثير بودي");
    const [a, b] = GRADS[Math.floor(Math.random() * GRADS.length)];
    const size = text.length > 18 ? 56 : text.length > 9 ? 84 : 120;
    const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>
      <filter id="s"><feDropShadow dx="4" dy="6" stdDeviation="5" flood-color="#000" flood-opacity="0.6"/></filter></defs>
      <text x="256" y="290" font-size="${size}" font-weight="bold" font-family="sans-serif" text-anchor="middle" fill="url(#g)" stroke="#fff" stroke-width="3" filter="url(#s)">${esc(text)}</text></svg>`;
    const webp = await sharp(Buffer.from(svg)).resize(512, 512).webp().toBuffer();
    await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
  },
};
export default command;
