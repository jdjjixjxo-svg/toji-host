import { Command } from "../../handlers/types";
import { searchTikTokVideo, downloadBuffer } from "../../utils/downloader";
import { extractAudioFromVideo } from "../../utils/ffmpegMedia";
import { logger } from "../../utils/logger";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "غ",
  aliases: ["sound", "صوت_تيك"],
  category: "ادوات",
  description: "البحث عن صوت من تيك توك وتحويله إلى MP3",
  permission: "all",
  execute: async (ctx) => {
    const q = ctx.text.trim();
    if (!q) return reply(ctx, "❗ اكتب اسم الصوت. مثال: .غ اغنية حماسية");
    try {
      const v = await searchTikTokVideo(q);
      if (!v) return reply(ctx, "❌ ما لقيت شيء.");
      const video = await downloadBuffer(v.videoUrl, () => undefined, "tiktok");
      const mp3 = await extractAudioFromVideo(video);
      await ctx.sock.sendMessage(ctx.chatId, { audio: mp3, mimetype: "audio/mpeg" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر غ:", err);
      await reply(ctx, "❌ تعذر جلب الصوت حاليًا.");
    }
  },
};
export default command;
