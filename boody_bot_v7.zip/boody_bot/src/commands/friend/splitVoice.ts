import { Command } from "../../handlers/types";
import { runVocalSplit } from "../../utils/vocalSplit";

const command: Command = {
  name: "فصل_صوت",
  aliases: ["splitvoice", "فصل_الصوت"],
  category: "ادوات",
  description: "فصل الصوت البشري عن الموسيقى (تقريبي) من رابط/اسم أغنية أو رد على فيديو/صوت",
  permission: "all",
  execute: (ctx) => runVocalSplit(ctx, true),
};
export default command;
