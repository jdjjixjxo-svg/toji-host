import { Command } from "../../handlers/types";
import { runVocalSplit } from "../../utils/vocalSplit";

const command: Command = {
  name: "عزل",
  aliases: ["isolate"],
  category: "ادوات",
  description: "فصل الصوت عن الموسيقى (تقريبي) — رد على صوت أو فيديو",
  permission: "all",
  execute: (ctx) => runVocalSplit(ctx, false),
};
export default command;
