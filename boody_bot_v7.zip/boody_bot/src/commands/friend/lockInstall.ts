import { toggleCommand } from "../../utils/friendUtils";
import { getGroupSettings, setGroupSetting } from "../../database/db";
export default toggleCommand({
  name: "قفل_تنصيب",
  aliases: ["lockinstall"],
  description: "تشغيل/تعطيل قفل أمر التنصيب داخل الجروب",
  label: "🔒 قفل أمر التنصيب",
  requireBotAdmin: false,
  get: (ctx) => !getGroupSettings(ctx.chatId).installEnabled,
  set: (ctx, v) => { setGroupSetting(ctx.chatId, "installEnabled", !v); },
});
