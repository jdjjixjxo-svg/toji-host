import { Command } from "../../handlers/types";
import { uninstallSubBot } from "../../handlers/subBotManager";
import { isOwner } from "../../middlewares/permissions";
import { digitsOnly } from "../../utils/helpers";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "الغاء_تنصيب",
  aliases: ["uninstall", "إلغاء_تنصيب"],
  category: "تنصيب",
  description: "إيقاف وحذف البوت الفرعي (رقمك، أو رقم آخر للمطور)",
  permission: "all",
  execute: async (ctx) => {
    let phone = digitsOnly(ctx.senderJid);
    const other = (ctx.args[0] || "").replace(/\D/g, "");
    if (other && other !== phone) {
      if (!isOwner(ctx.senderJid, ctx.metadata || undefined, ctx.sock)) return reply(ctx, "🚫 فقط المطور يقدر يلغي تنصيب رقم غير رقمه.");
      phone = other;
    }
    const existed = await uninstallSubBot(phone);
    await reply(ctx, existed ? `🗑️ تم إيقاف وحذف البوت الفرعي للرقم ${phone}.` : "ℹ️ ما فيه بوت فرعي منصّب لهذا الرقم.");
  },
};
export default command;
