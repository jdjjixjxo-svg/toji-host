import { Command } from "../../handlers/types";
import { getFriendCfg, setFriendCfg, reply, fetchBuffer } from "../../utils/friendUtils";

const command: Command = {
  name: "نسخ",
  aliases: ["copygroup", "نسخ_المجموعة"],
  category: "مشرفين",
  description: "نسخ إعدادات الجروب (الاسم، الوصف، الصورة، الإعدادات) واستعادتها وازالتها",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const sub = (ctx.args[0] || "").trim();
    const snap = getFriendCfg(ctx.chatId).snapshot;

    if (sub === "استعادة" || sub === "استعاده" || sub === "restore") {
      if (!snap) return reply(ctx, "❌ ما فيه نسخة محفوظة. اكتب .نسخ أولًا.");
      const steps: string[] = [];
      try { await ctx.sock.groupUpdateSubject(ctx.chatId, snap.subject); steps.push("الاسم"); } catch { /* تجاهل */ }
      try { await ctx.sock.groupUpdateDescription(ctx.chatId, snap.desc); steps.push("الوصف"); } catch { /* تجاهل */ }
      if (snap.pic) {
        try { await ctx.sock.updateProfilePicture(ctx.chatId, Buffer.from(snap.pic, "base64")); steps.push("الصورة"); } catch { /* تجاهل */ }
      }
      try { await ctx.sock.groupSettingUpdate(ctx.chatId, snap.announce ? "announcement" : "not_announcement"); steps.push("قفل الرسائل"); } catch { /* تجاهل */ }
      try { await ctx.sock.groupSettingUpdate(ctx.chatId, snap.restrict ? "locked" : "unlocked"); steps.push("قفل المعلومات"); } catch { /* تجاهل */ }
      return reply(ctx, `♻️ تمت الاستعادة: ${steps.join("، ") || "لا شيء (تحقق من صلاحيات البوت)"}`);
    }
    if (sub === "ازالة" || sub === "إزالة" || sub === "حذف" || sub === "remove") {
      setFriendCfg(ctx.chatId, { snapshot: undefined });
      return reply(ctx, "🗑️ تم حذف النسخة المحفوظة.");
    }
    if (sub === "عرض" || sub === "show") {
      if (!snap) return reply(ctx, "📭 لا توجد نسخة محفوظة.");
      return reply(ctx, `📦 النسخة المحفوظة:\n• الاسم: ${snap.subject}\n• الوصف: ${snap.desc ? snap.desc.slice(0, 120) : "—"}\n• الصورة: ${snap.pic ? "نعم" : "لا"}`);
    }

    const md = await ctx.sock.groupMetadata(ctx.chatId);
    let pic: string | undefined;
    try {
      const url = await ctx.sock.profilePictureUrl(ctx.chatId, "image");
      if (url) pic = (await fetchBuffer(url, 3 * 1024 * 1024)).toString("base64");
    } catch { /* المجموعة بدون صورة */ }
    setFriendCfg(ctx.chatId, {
      snapshot: { subject: md.subject, desc: md.desc || "", pic, announce: !!md.announce, restrict: !!md.restrict, at: Date.now() },
    });
    await reply(ctx, "📦 تم حفظ نسخة من إعدادات المجموعة.\n.نسخ استعادة — لاستعادتها\n.نسخ ازالة — لحذفها\n.نسخ عرض — لعرضها");
  },
};
export default command;
