import { Command } from "../../handlers/types";
import { getActivity, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "احصائيات-المجموعة",
  aliases: ["احصائيات_المجموعة", "احصائيات", "groupstats"],
  category: "مشرفين",
  description: "عرض لوحة شرف لجميع الأعضاء مرتبة حسب التفاعل (للمشرفين فقط)",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const act = getActivity(ctx.chatId);
    const rows = Object.entries(act).sort((a, b) => b[1] - a[1]).slice(0, 15);
    if (!rows.length) return reply(ctx, "📭 لا توجد إحصائيات بعد (يبدأ العدّ من لحظة تشغيل هذا التحديث).");
    const medals = ["🥇", "🥈", "🥉"];
    const total = Object.values(act).reduce((a, b) => a + b, 0);
    const text =
      `🏆 *لوحة شرف المجموعة*\n\n` +
      rows.map(([jid, n], i) => `${medals[i] || `${i + 1}.`} @${jid.split("@")[0]} — ${n} رسالة`).join("\n") +
      `\n\n📊 إجمالي الرسائل المسجّلة: ${total}`;
    await reply(ctx, text, rows.map(([j]) => j));
  },
};
export default command;
