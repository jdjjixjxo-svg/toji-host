import fs from "fs-extra";
import { Command } from "../../handlers/types";
import { getPtvStatus, resetPtvCache, PTV_SOURCE_PATH } from "../../events/groupJoinPtv";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

/**
 * .تست — فيديو الترحيب الدائري الذي يرسله البوت عند دخوله أي مجموعة.
 *  • «.تست» فقط        → يرسل الفيديو الحالي كتجربة.
 *  • رد على فيديو بـ «.تست» → يحفظه كفيديو الترحيب الجديد ويرسله كتجربة.
 * رسائل واضحة لكل حالة (ما فيه فيديو / الرد على صورة مو فيديو / فشل التحويل).
 */
const command: Command = {
  name: "تست",
  aliases: ["test", "تجربة"],
  category: "المطور",
  description: "يجرّب/يغيّر فيديو الترحيب الدائري — «.تست» يرسله، ورد على فيديو بـ «.تست» يحفظه كبديل",
  permission: "owner",
  execute: async (ctx) => {
    try {
      const repliedNonVideo = !!(ctx.quoted?.imageMessage || ctx.quoted?.stickerMessage || ctx.quoted?.audioMessage || ctx.quoted?.documentMessage);
      const media = await getMedia(ctx, ["video"]);

      if (!media && repliedNonVideo) {
        return reply(ctx, "⚠️ هذا الأمر يقبل *فيديو* فقط.\nرد على فيديو بـ «.تست» لحفظه كفيديو الترحيب.");
      }

      let saved = false;
      if (media) {
        await fs.ensureDir(PTV_SOURCE_PATH.replace(/[^/\\]+$/, ""));
        await fs.writeFile(PTV_SOURCE_PATH, media.buffer);
        resetPtvCache();
        saved = true;
      }

      const st = await getPtvStatus();
      if ("error" in st) {
        if (st.error === "NO_SOURCE") {
          return reply(ctx, "📭 ما فيه فيديو ترحيب محفوظ.\nرد على فيديو بـ «.تست» لحفظه.");
        }
        return reply(ctx, `❌ الفيديو موجود لكن فشل تحويله لشكل دائري.\nالسبب: ${st.detail || "خطأ ffmpeg"}\nجرّب فيديو أقصر (أقل من 30 ثانية) وحجم أصغر.`);
      }

      await ctx.sock.sendMessage(ctx.chatId, { video: st.buffer, ptv: true } as any);
      if (saved) await reply(ctx, "✅ تم حفظ هذا الفيديو كفيديو الترحيب. سيُرسل عند دخول البوت أي مجموعة جديدة.");
    } catch (err) {
      logger.error("فشل أمر تست:", err);
      await reply(ctx, `❌ فشل التنفيذ: ${err instanceof Error ? err.message : String(err)}`);
    }
  },
};
export default command;
