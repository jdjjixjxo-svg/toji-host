import { Command } from "../../handlers/types";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "عشوائي",
  aliases: ["random", "اختار_عضو", "زنجي"],
  category: "ترفيه",
  description: "اختيار عشوائي لأحد أعضاء المجموعة (الفلتة اليوم 😂)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const ids = (ctx.metadata?.participants || []).map((p) => p.id).filter((id) => id !== ctx.sock.user?.id);
    if (!ids.length) return reply(ctx, "❌ ما قدرت أجلب الأعضاء.");
    const pick = ids[Math.floor(Math.random() * ids.length)];
    await reply(ctx, `🎭 الفلتة اليوم هو @${pick.split("@")[0]} — يا فلتة 😂${ctx.text ? `\n📝 ${ctx.text}` : ""}`, [pick]);
  },
};
export default command;
