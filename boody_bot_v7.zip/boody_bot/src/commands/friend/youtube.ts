import ytSearch from "yt-search";
import { withTimeout } from "../../utils/timeout";
import { Command } from "../../handlers/types";
import { downloadYouTubeBuffer } from "../../utils/downloader";
import { logger } from "../../utils/logger";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "يوتيوب",
  aliases: ["youtube", "yt"],
  category: "ادوات",
  description: "تحميل فيديو من يوتيوب (جودة منخفضة لتوفير الحجم) بالرابط أو بالبحث",
  permission: "all",
  execute: async (ctx) => {
    const q = ctx.text.trim();
    if (!q) return reply(ctx, "❗ اكتب رابط يوتيوب أو اسم الفيديو. مثال: .يوتيوب سورة الكهف");
    try {
      let url = q;
      let title = "";
      if (!/^https?:\/\//i.test(q)) {
        const r = await withTimeout(ytSearch(q), 12_000, "YT_SEARCH_TIMEOUT");
        const v = r.videos?.[0];
        if (!v) return reply(ctx, "❌ ما لقيت نتيجة.");
        if (v.seconds > 15 * 60) return reply(ctx, "❌ أول نتيجة أطول من 15 دقيقة — جرّب اسمًا أدق.");
        url = v.url;
        title = v.title;
      }
      await reply(ctx, "⏳ جاري التحميل...");
      const buf = await downloadYouTubeBuffer(url);
      if (buf.length > 60 * 1024 * 1024) return reply(ctx, "❌ الفيديو كبير جدًا للإرسال.");
      await ctx.sock.sendMessage(ctx.chatId, { video: buf, caption: title ? `✅ ${title}` : "✅ يوتيوب - 𝑩𝑶𝑶𝑫𝒀", mimetype: "video/mp4" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر يوتيوب:", err);
      await reply(ctx, "❌ تعذر تحميل الفيديو حاليًا (يوتيوب يحجب بعض الاستضافات أحيانًا).");
    }
  },
};
export default command;
