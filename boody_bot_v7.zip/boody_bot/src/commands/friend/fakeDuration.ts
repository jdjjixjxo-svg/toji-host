import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "تزييف",
  aliases: ["fakeduration", "مدة_وهمية"],
  category: "ادوات",
  description: "تزييف مدة الفيديو أو الريكورد لثواني وهمية (رد + عدد الثواني)",
  permission: "all",
  execute: async (ctx) => {
    const secs = parseInt(ctx.args[0] || "", 10);
    if (!secs || secs < 1 || secs > 86400) return reply(ctx, "❗ اكتب عدد الثواني. مثال: رد على فيديو أو ريكورد ثم .تزييف 600");
    try {
      const media = await getMedia(ctx, ["video", "audio"]);
      if (!media) return reply(ctx, "❗ رد على فيديو أو رسالة صوتية.");
      if (media.kind === "video") {
        await ctx.sock.sendMessage(ctx.chatId, { video: media.buffer, seconds: secs, mimetype: "video/mp4" } as any, { quoted: ctx.msg });
      } else {
        await ctx.sock.sendMessage(ctx.chatId, { audio: media.buffer, seconds: secs, ptt: !!media.message?.ptt, mimetype: media.message?.mimetype || "audio/ogg; codecs=opus" } as any, { quoted: ctx.msg });
      }
    } catch (err) {
      logger.error("فشل أمر تزييف:", err);
      await reply(ctx, "❌ تعذر التنفيذ.");
    }
  },
};
export default command;
