import { toggleCommand } from "../../utils/friendUtils";
import { getFriendCfg, setFriendCfg } from "../../utils/friendUtils";
export default toggleCommand({
  name: "مود",
  aliases: ["mode","وضع_المشرفين"],
  description: "قفل البوت للمشرفين فقط (الأعضاء العاديون لا تعمل أوامرهم)",
  label: "🔐 وضع المشرفين فقط",
  requireBotAdmin: false,
  get: (ctx) => getFriendCfg(ctx.chatId).adminOnly,
  set: (ctx, v) => { setFriendCfg(ctx.chatId, { adminOnly: v }); },
});
