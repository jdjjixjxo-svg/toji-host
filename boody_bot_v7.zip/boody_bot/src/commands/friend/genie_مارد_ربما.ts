import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("ربما") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_ربما",
  category: "ترفيه",
  description: "إجابة لعبة المارد: ربما",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_ربما"),
};
export default command;
