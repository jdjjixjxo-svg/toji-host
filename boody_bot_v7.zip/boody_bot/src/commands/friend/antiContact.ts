import { toggleCommand } from "../../utils/friendUtils";
import { getGroupSettings, setGroupSetting } from "../../database/db";
export default toggleCommand({
  name: "منع_بطاقة",
  aliases: ["منع_بطاقه","anticontact"],
  description: "نظام منع إرسال بطاقات الاتصال في الجروب",
  label: "🚫 منع بطاقات الاتصال",
  requireBotAdmin: true,
  get: (ctx) => getGroupSettings(ctx.chatId).antiContact,
  set: (ctx, v) => { setGroupSetting(ctx.chatId, "antiContact", v); if (v) setGroupSetting(ctx.chatId, "protection", true); },
});
