import { Command } from "../../handlers/types";
import { fetchBuffer, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "ميديا",
  aliases: ["mediafire", "ميديافاير"],
  category: "ادوات",
  description: "تحميل الملفات المباشرة من موقع MediaFire",
  permission: "all",
  execute: async (ctx) => {
    const link = ctx.text.trim();
    if (!/^https?:\/\/(www\.)?mediafire\.com\//i.test(link)) return reply(ctx, "❗ ارسل رابط MediaFire. مثال: .ميديا https://www.mediafire.com/file/...");
    try {
      const html = (await fetchBuffer(link, 3 * 1024 * 1024)).toString("utf8");
      let direct =
        html.match(/href="(https?:\/\/download[^"]*mediafire\.com[^"]+)"/i)?.[1] ||
        html.match(/id="downloadButton"[^>]*href="(https?:[^"]+)"/i)?.[1];
      const scrambled = html.match(/data-scrambled-url="([^"]+)"/i)?.[1];
      if (!direct && scrambled) direct = Buffer.from(scrambled, "base64").toString("utf8");
      if (!direct) return reply(ctx, "❌ ما قدرت أستخرج رابط التحميل (الملف محذوف أو الموقع غيّر شكله).");
      const fileName = decodeURIComponent(direct.split("/").pop()?.split("?")[0] || "file");
      await reply(ctx, `⏳ جاري تحميل *${fileName}* ...`);
      const buf = await fetchBuffer(direct);
      await ctx.sock.sendMessage(ctx.chatId, { document: buf, fileName, mimetype: "application/octet-stream" }, { quoted: ctx.msg });
    } catch (err: any) {
      logger.error("فشل أمر ميديا:", err);
      await reply(ctx, err?.message === "FILE_TOO_LARGE" ? "❌ الملف أكبر من 45MB (حد الذاكرة بالاستضافة)." : "❌ تعذر تحميل الملف.");
    }
  },
};
export default command;
