import { Command } from "../../handlers/types";
import { boostAudio } from "../../utils/ffmpegMedia";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "صاخب",
  aliases: ["loud", "تضخيم"],
  category: "ادوات",
  description: "تضخيم وزيادة مستوى الصوت للرسائل الصوتية",
  permission: "all",
  execute: async (ctx) => {
    try {
      const media = await getMedia(ctx, ["audio", "video"]);
      if (!media) return reply(ctx, "❗ رد على رسالة صوتية بهذا الأمر.");
      const factor = Math.min(15, Math.max(2, parseInt(ctx.args[0] || "6", 10) || 6));
      const out = await boostAudio(media.buffer, factor);
      await ctx.sock.sendMessage(ctx.chatId, { audio: out, mimetype: "audio/mpeg" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر صاخب:", err);
      await reply(ctx, "❌ تعذر تضخيم الصوت.");
    }
  },
};
export default command;
