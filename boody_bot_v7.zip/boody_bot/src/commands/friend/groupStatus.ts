import { jidNormalizedUser } from "@whiskeysockets/baileys";
import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const COLORS = ["#1a237e", "#004d40", "#880e4f", "#3e2723", "#311b92", "#b71c1c"];

/**
 * 🔧 إصلاح (سبب «.ستوري ما يشتغل»):
 *  1) النص كان يمرّ على sock المموّه (createBrandedSock) اللي يحوّل أي رسالة نصية
 *     لرسالة أزرار — فيُرسل «زر» لـ status@broadcast بدل ستوري حقيقي. الحين
 *     نضيف __skipBrand فيرسل ستوري نصي فعلي.
 *  2) قائمة الجمهور كانت تستخدم p.id اللي صار معرّف @lid بمجموعات كثيرة؛ ستوريات
 *     واتساب تحتاج أرقام هواتف حقيقية (p.jid). الحين نأخذ الرقم الحقيقي فقط.
 *  3) نضيف رقم البوت نفسه للجمهور (شرط ظهور الستوري عند غيره).
 */
function buildAudience(ctx: Parameters<Command["execute"]>[0]): string[] {
  const set = new Set<string>();
  for (const p of ctx.metadata?.participants || []) {
    const real = (p as any).jid || (p.id.endsWith("@s.whatsapp.net") ? p.id : "");
    if (real && real.endsWith("@s.whatsapp.net")) set.add(jidNormalizedUser(real));
  }
  const me = ctx.sock.user?.id;
  if (me) set.add(jidNormalizedUser(me));
  return [...set];
}

const command: Command = {
  name: "ستوري",
  aliases: ["ستوري_المجموعة", "status"],
  category: "مشرفين",
  description: "ينشر ستوري (نص/صورة/فيديو) من حساب البوت لأعضاء المجموعة — للمشرفين",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const audience = buildAudience(ctx);
    if (audience.length < 2) {
      return reply(ctx, "❌ ما قدرت أجلب أرقام أعضاء المجموعة.\nواتساب يخفي بعض الأرقام بالمجموعات الجديدة — جرّب بعد شوي أو بمجموعة ثانية.");
    }
    try {
      const media = await getMedia(ctx, ["image", "video"]).catch(() => null);
      const text = ctx.text.trim() || ctx.quoted?.conversation || ctx.quoted?.extendedTextMessage?.text || "";
      if (media?.kind === "image") {
        await ctx.sock.sendMessage("status@broadcast", { image: media.buffer, caption: text || undefined }, { statusJidList: audience });
      } else if (media?.kind === "video") {
        await ctx.sock.sendMessage("status@broadcast", { video: media.buffer, caption: text || undefined }, { statusJidList: audience });
      } else if (text) {
        await ctx.sock.sendMessage(
          "status@broadcast",
          { text, __skipBrand: true } as any,
          { statusJidList: audience, backgroundColor: COLORS[Math.floor(Math.random() * COLORS.length)], font: Math.floor(Math.random() * 5) } as any
        );
      } else {
        return reply(
          ctx,
          "📸 *نشر ستوري*\n\nاكتب النص بعد الأمر:\n.ستوري اجتماع اليوم الساعة 9\n\nأو رد على صورة/فيديو بكلمة:\n.ستوري"
        );
      }
      await reply(
        ctx,
        `✅ تم نشر الستوري من حساب البوت.\n👥 موجّه لـ ${audience.length - 1} عضو.\nℹ️ يظهر فقط لمن حافظ رقم البوت بجهات اتصاله.`
      );
    } catch (err) {
      logger.error("فشل أمر ستوري:", err);
      await reply(ctx, `❌ تعذر نشر الستوري.\nالسبب: ${err instanceof Error ? err.message : String(err)}`);
    }
  },
};
export default command;
