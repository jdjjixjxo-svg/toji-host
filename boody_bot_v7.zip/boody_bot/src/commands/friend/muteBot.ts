import { toggleCommand } from "../../utils/friendUtils";
import { getFriendCfg, setFriendCfg } from "../../utils/friendUtils";
export default toggleCommand({
  name: "منع_بوت",
  aliases: ["mutebot"],
  description: "إيقاف/تشغيل استجابة البوت في المجموعة (للمشرفين والمطورين فقط)",
  label: "🔇 إيقاف استجابة البوت",
  requireBotAdmin: false,
  get: (ctx) => getFriendCfg(ctx.chatId).botMuted,
  set: (ctx, v) => { setFriendCfg(ctx.chatId, { botMuted: v }); },
});
