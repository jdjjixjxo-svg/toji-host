import { Command } from "../../handlers/types";
import { startAnimeGuess } from "../../utils/animeGuess";

const command: Command = {
  name: "عين",
  aliases: ["eye"],
  category: "ترفيه",
  description: "لعبة التخمين: خمن اسم الشخصية من صورة العين",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => startAnimeGuess(ctx, "eye"),
};
export default command;
