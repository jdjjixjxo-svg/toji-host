import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const MODEL = "gemini-3.1-flash-lite";

const command: Command = {
  name: "تعرف",
  aliases: ["shazam", "اسم_الاغنية", "recognize"],
  category: "IA",
  description: "التعرف على الأغاني والمقاطع الصوتية من ملف (محاولة ذكية بالذكاء الاصطناعي)",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.GEMINI_API_KEY) return reply(ctx, "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env.");
    try {
      const media = await getMedia(ctx, ["audio", "video"]);
      if (!media) return reply(ctx, "❗ رد على مقطع صوتي أو فيديو فيه أغنية.");
      if (media.buffer.length > 18 * 1024 * 1024) return reply(ctx, "❌ الملف كبير جدًا (الحد ~18MB).");
      await reply(ctx, "🎧 جاري الاستماع...");
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const res = await ai.models.generateContent({
        model: MODEL,
        contents: [
          { text: "استمع لهذا المقطع وحاول تحديد اسم الأغنية والفنان واللغة. إن كنت غير متأكد فقل ذلك بصراحة ولا تخترع. اكتب الجواب بالعربية في 3 أسطر كحد أقصى." },
          { inlineData: { mimeType: media.kind === "video" ? "video/mp4" : media.message?.mimetype?.split(";")[0] || "audio/ogg", data: media.buffer.toString("base64") } },
        ],
      });
      const out = (res as any).text || "";
      await reply(ctx, out ? `🎵 *النتيجة:*\n${out}\n\n_⚠️ تخمين بالذكاء الاصطناعي، مو دقيق 100%_` : "❌ ما قدرت أتعرف على المقطع.");
    } catch (err) {
      logger.error("فشل أمر تعرف:", err);
      await reply(ctx, "❌ تعذر التعرف حاليًا.");
    }
  },
};
export default command;
