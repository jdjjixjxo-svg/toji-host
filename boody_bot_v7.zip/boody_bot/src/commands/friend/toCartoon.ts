import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const IMAGE_MODEL = "gemini-2.5-flash-image";

const command: Command = {
  name: "لكرتون",
  aliases: ["tocartoon", "لانمي"],
  category: "IA",
  description: "تحويل الصورة إلى أنمي باستخدام الذكاء الاصطناعي",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.GEMINI_API_KEY) return reply(ctx, "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env.");
    try {
      const media = await getMedia(ctx, ["image"]);
      if (!media) return reply(ctx, "❗ رد على صورة بهذا الأمر.");
      await reply(ctx, "🎨 جاري التحويل لأنمي...");
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const res = await ai.models.generateContent({
        model: IMAGE_MODEL,
        contents: [
          { text: "Redraw this photo as a high quality anime illustration. Keep the same person, pose, and composition." },
          { inlineData: { mimeType: "image/jpeg", data: media.buffer.toString("base64") } },
        ],
      });
      const part = (res.candidates?.[0]?.content?.parts ?? []).find((p: any) => p.inlineData);
      if (!part?.inlineData?.data) throw new Error("NO_IMAGE_RETURNED");
      await ctx.sock.sendMessage(ctx.chatId, { image: Buffer.from(part.inlineData.data, "base64"), caption: "🎨 أنمي - 𝑩𝑶𝑶𝑫𝒀" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر لكرتون:", err);
      await reply(ctx, "❌ تعذر التحويل حاليًا.");
    }
  },
};
export default command;
