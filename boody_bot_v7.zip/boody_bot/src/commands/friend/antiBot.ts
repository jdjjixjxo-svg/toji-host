import { toggleCommand } from "../../utils/friendUtils";
import { getFriendCfg, setFriendCfg } from "../../utils/friendUtils";
export default toggleCommand({
  name: "مضاد_البوتات",
  aliases: ["antibot"],
  description: "اكتشاف وطرد البوتات الأجنبية تلقائيًا من المجموعة (كشف تقريبي)",
  label: "🤖 مضاد البوتات",
  requireBotAdmin: true,
  get: (ctx) => getFriendCfg(ctx.chatId).antiBot,
  set: (ctx, v) => { setFriendCfg(ctx.chatId, { antiBot: v }); },
});
