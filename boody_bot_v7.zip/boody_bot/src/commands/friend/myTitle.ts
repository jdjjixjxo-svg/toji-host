import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "لقبي",
  aliases: ["mytitle"],
  category: "بوت",
  description: "معرفة لقبك الشخصي داخل المجموعة 🏷️",
  permission: "all",
  execute: async (ctx) => {
    if (!(await ensureTitlesReady())) return reply(ctx, "❌ نظام الألقاب غير متصل حاليًا.");
    const t = await TitleStore.findOne({ userId: ctx.senderJid });
    await reply(ctx, t ? `🏷️ لقبك: *${t.title}*` : "❌ ما عندك لقب مسجّل. سجّل لقبك بـ .حجز_لقب <لقب>");
  },
};
export default command;
