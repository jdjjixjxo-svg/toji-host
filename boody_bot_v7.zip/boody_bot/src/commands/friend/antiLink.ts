import { Command } from "../../handlers/types";
import { getGroupSettings, setGroupSetting } from "../../database/db";
import { getFriendCfg, setFriendCfg, parseOnOff, reply } from "../../utils/friendUtils";
import { normalizeArabicCommand } from "../../utils/arabicNormalize";

const MODES: Record<string, "warn" | "delete" | "kick"> = { تحذير: "warn", حذف: "delete", طرد: "kick" };
const MODE_LABEL = { warn: "حذف + تحذير", delete: "حذف فقط", kick: "حذف + طرد" };

const command: Command = {
  name: "منع_الروابط",
  aliases: ["antilink", "منع_رابط"],
  category: "مشرفين",
  description: "تشغيل أو إيقاف منع الروابط مع أوضاع: تحذير، طرد، حذف فقط.",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const s = getGroupSettings(ctx.chatId);
    const cfg = getFriendCfg(ctx.chatId);
    const word = ctx.args[0];
    const onoff = parseOnOff(word);
    const mode = word ? MODES[normalizeArabicCommand(word)] || MODES[word] : undefined;

    if (onoff !== undefined) {
      setGroupSetting(ctx.chatId, "antilink", onoff);
      if (onoff) setGroupSetting(ctx.chatId, "protection", true);
    } else if (mode) {
      setFriendCfg(ctx.chatId, { linkMode: mode });
      setGroupSetting(ctx.chatId, "antilink", true);
      setGroupSetting(ctx.chatId, "protection", true);
    }
    const now = getGroupSettings(ctx.chatId).antilink;
    const m = getFriendCfg(ctx.chatId).linkMode;
    await reply(
      ctx,
      `🔗 منع الروابط: ${now ? "✅ مفعّل" : "❌ متوقف"}\nالوضع: *${MODE_LABEL[m]}*\n\n` +
        `.منع_الروابط تشغيل | ايقاف\n.منع_الروابط تحذير | حذف | طرد`
    );
    void s; void cfg;
  },
};
export default command;
