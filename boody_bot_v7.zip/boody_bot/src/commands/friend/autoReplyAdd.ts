import { Command } from "../../handlers/types";
import { getAutoReplies, setAutoReplies, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "اضافة_رد",
  aliases: ["addreply", "إضافة_رد", "اضف_رد"],
  category: "المطور",
  description: "إدارة نظام الردود التلقائية العالمية على كلمات وجمل محددة",
  permission: "owner",
  execute: async (ctx) => {
    const raw = ctx.text.trim();
    const map = getAutoReplies();

    if (!raw || raw === "قائمة") {
      const keys = Object.keys(map);
      return reply(ctx, keys.length ? `📋 الردود التلقائية (${keys.length}):\n${keys.map((k) => `• ${k} ← ${map[k].slice(0, 40)}`).join("\n")}` : "📭 لا توجد ردود.\nمثال: .اضافة_رد مرحبا | اهلا وسهلا");
    }
    if (raw.startsWith("حذف ")) {
      const key = raw.slice(4).trim();
      if (!(key in map)) return reply(ctx, "❌ الكلمة غير موجودة.");
      delete map[key];
      setAutoReplies(map);
      return reply(ctx, "✅ تم حذف الرد.");
    }
    const [trigger, ...rest] = raw.split("|");
    const answer = rest.join("|").trim();
    if (!trigger.trim() || !answer) return reply(ctx, "❗ الصيغة: .اضافة_رد الكلمة | الرد\n.اضافة_رد حذف الكلمة\n.اضافة_رد قائمة");
    if (Object.keys(map).length >= 300) return reply(ctx, "❌ وصلت للحد الأقصى (300 رد).");
    map[trigger.trim()] = answer;
    setAutoReplies(map);
    await reply(ctx, `✅ إذا كتب أحد "${trigger.trim()}" سأرد: ${answer.slice(0, 60)}`);
  },
};
export default command;
