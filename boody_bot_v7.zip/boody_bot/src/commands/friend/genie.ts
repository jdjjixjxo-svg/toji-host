import { Command } from "../../handlers/types";
import { genieStart } from "../../utils/genieGame";

const command: Command = {
  name: "مارد",
  aliases: ["akinator", "المارد"],
  category: "ترفيه",
  description: "لعبة المارد الأزرق (Akinator) لتخمين الشخصيات باستخدام الأزرار",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieStart(ctx),
};
export default command;
