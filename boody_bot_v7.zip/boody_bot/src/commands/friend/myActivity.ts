import { Command } from "../../handlers/types";
import { getActivity, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "نشاطي",
  aliases: ["myactivity", "تفاعلي"],
  category: "بوت",
  description: "عرض إحصائيات نشاطك في المجموعة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const act = getActivity(ctx.chatId);
    const mine = act[ctx.senderJid] || 0;
    const sorted = Object.entries(act).sort((a, b) => b[1] - a[1]);
    const rank = sorted.findIndex(([j]) => j === ctx.senderJid) + 1;
    if (!mine) return reply(ctx, "📭 ما سجّلت لك أي نشاط بعد.");
    await reply(ctx, `📈 *نشاطك*\n\n💬 رسائلك: ${mine}\n🏅 ترتيبك: ${rank} من ${sorted.length}`);
  },
};
export default command;
