import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("لا أعرف") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_لا_اعرف",
  category: "ترفيه",
  description: "إجابة لعبة المارد: لا أعرف",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_لا_اعرف"),
};
export default command;
