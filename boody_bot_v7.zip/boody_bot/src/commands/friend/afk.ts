import { Command } from "../../handlers/types";
import { setAfk, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "اختفاء",
  aliases: ["afk", "غياب"],
  category: "بوت",
  description: "تسجيل الغياب مع سبب في المجموعات، والعودة التلقائية عند الإرسال",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const reason = ctx.text.trim() || "بدون سبب";
    setAfk(ctx.chatId, ctx.senderJid, reason.slice(0, 150));
    await reply(ctx, `💤 تم تسجيل غيابك.\n📝 السبب: ${reason.slice(0, 150)}\nترجع تلقائيًا أول ما ترسل رسالة.`);
  },
};
export default command;
