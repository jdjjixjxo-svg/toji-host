import { Command } from "../../handlers/types";
import { getFriendCfg, setFriendCfg, parseOnOff, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "منع_كلمات",
  aliases: ["badwords", "كلمات_ممنوعة"],
  category: "مشرفين",
  description: "تشغيل أو إيقاف منع الكلمات الممنوعة مع أوضاع الحذف أو الطرد.",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const cfg = getFriendCfg(ctx.chatId);
    const sub = (ctx.args[0] || "").trim();
    const rest = ctx.args.slice(1).join(" ").trim();

    if (sub === "اضافة" || sub === "إضافة" || sub === "add") {
      if (!rest) return reply(ctx, "❗ اكتب الكلمة. مثال: .منع_كلمات اضافة كلمة");
      const list = Array.from(new Set([...cfg.badWords, rest])).slice(0, 200);
      setFriendCfg(ctx.chatId, { badWords: list, badWordsOn: true });
      return reply(ctx, `✅ أُضيفت الكلمة (المجموع ${list.length}) والمنع مفعّل.`);
    }
    if (sub === "حذف" || sub === "ازالة" || sub === "remove") {
      const list = cfg.badWords.filter((w) => w !== rest);
      setFriendCfg(ctx.chatId, { badWords: list });
      return reply(ctx, list.length < cfg.badWords.length ? "✅ حُذفت الكلمة." : "❌ الكلمة غير موجودة بالقائمة.");
    }
    if (sub === "قائمة" || sub === "list") {
      return reply(ctx, cfg.badWords.length ? `📋 الكلمات الممنوعة:\n${cfg.badWords.map((w) => `• ${w}`).join("\n")}` : "📭 لا توجد كلمات ممنوعة.");
    }
    if (sub === "طرد" || sub === "kick") {
      setFriendCfg(ctx.chatId, { badWordsMode: "kick", badWordsOn: true });
      return reply(ctx, "✅ الوضع: حذف الرسالة + طرد المرسل.");
    }
    if (sub === "حذف_فقط" || sub === "delete") {
      setFriendCfg(ctx.chatId, { badWordsMode: "delete", badWordsOn: true });
      return reply(ctx, "✅ الوضع: حذف الرسالة فقط.");
    }
    const onoff = parseOnOff(sub);
    if (onoff !== undefined) setFriendCfg(ctx.chatId, { badWordsOn: onoff });
    const now = getFriendCfg(ctx.chatId);
    await reply(
      ctx,
      `🚫 منع الكلمات: ${now.badWordsOn ? "✅ مفعّل" : "❌ متوقف"}\nالوضع: *${now.badWordsMode === "kick" ? "حذف + طرد" : "حذف فقط"}* — عدد الكلمات: ${now.badWords.length}\n\n` +
        `.منع_كلمات تشغيل | ايقاف\n.منع_كلمات اضافة <كلمة>\n.منع_كلمات حذف <كلمة>\n.منع_كلمات قائمة\n.منع_كلمات طرد | حذف_فقط`
    );
  },
};
export default command;
