import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { getFriendCfg, setFriendCfg, reply } from "../../utils/friendUtils";

const command: Command = {
  name: "فتح_امر",
  aliases: ["unlockcmd"],
  category: "مشرفين",
  description: "فتح (إلغاء قفل) أمر معيّن في هذه المجموعة - للمشرفين فقط",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const word = ctx.args[0]?.replace(/^\./, "");
    if (!word) return reply(ctx, "❗ اكتب اسم الأمر. مثال: .فتح_امر نرد");
    const cmd = commandRegistry.get(word);
    const name = cmd?.name || word;
    const cur = getFriendCfg(ctx.chatId).lockedCmds;
    if (!cur.includes(name)) return reply(ctx, "ℹ️ هذا الأمر غير مقفول أصلًا.");
    setFriendCfg(ctx.chatId, { lockedCmds: cur.filter((c) => c !== name) });
    await reply(ctx, `🔓 تم فتح الأمر *${name}*.`);
  },
};
export default command;
