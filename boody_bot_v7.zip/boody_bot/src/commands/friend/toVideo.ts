import { Command } from "../../handlers/types";
import { animatedWebpToMp4 } from "../../utils/ffmpegMedia";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "لفيديو",
  aliases: ["tovideo", "ملصق_لفيديو"],
  category: "ادوات",
  description: "تحويل الاستيكر (المتحرك) إلى فيديو",
  permission: "all",
  execute: async (ctx) => {
    try {
      const media = await getMedia(ctx, ["sticker"]);
      if (!media) return reply(ctx, "❗ رد على ملصق متحرك بهذا الأمر.");
      if (!media.message?.isAnimated) return reply(ctx, "ℹ️ هذا ملصق ثابت — استخدم .لصورة لتحويله لصورة.");
      const mp4 = await animatedWebpToMp4(media.buffer);
      await ctx.sock.sendMessage(ctx.chatId, { video: mp4, mimetype: "video/mp4", gifPlayback: true }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر لفيديو:", err);
      await reply(ctx, "❌ تعذر التحويل.");
    }
  },
};
export default command;
