import { Command } from "../../handlers/types";
import { getAutoReplies, setAutoReplies, reply } from "../../utils/friendUtils";

/** .حذف الردود — يمسح كل الردود التلقائية المضافة يدويًا (بـ .اضافة_رد) */
const command: Command = {
  name: "حذف_الردود",
  aliases: ["مسح_الردود", "حذف_كل_الردود", "clearreplies"],
  category: "المطور",
  description: "يمسح كل الردود التلقائية المضافة يدويًا دفعة وحدة",
  permission: "owner",
  execute: async (ctx) => {
    const n = Object.keys(getAutoReplies()).length;
    setAutoReplies({});
    await reply(ctx, n ? `🧹 تم حذف كل الردود المضافة (${n}).` : "📭 ما كان فيه ردود مضافة.");
  },
};
export default command;
