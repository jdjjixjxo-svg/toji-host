import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "حذف_الألقاب",
  aliases: ["حذف_الالقاب", "deletetitles"],
  category: "مشرفين",
  description: "حذف لقب عضو معين أو جميع الألقاب دفعة واحدة",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    if (!(await ensureTitlesReady())) return reply(ctx, "❌ نظام الألقاب غير متصل حاليًا.");
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (target) {
      const r = await TitleStore.findOneAndDelete({ userId: target });
      return reply(ctx, r ? `✅ تم حذف لقب ${jidToMention(target)}` : "❌ هذا العضو ما عنده لقب.", [target]);
    }
    if (ctx.args[0] === "الكل" || ctx.args[0] === "all") {
      const r = await TitleStore.deleteMany({});
      return reply(ctx, `🗑️ تم حذف ${r.deletedCount} لقب.`);
    }
    await reply(ctx, "❗ منشن عضو لحذف لقبه، أو اكتب: .حذف_الألقاب الكل");
  },
};
export default command;
