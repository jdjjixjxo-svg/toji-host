import { Command } from "../../handlers/types";
import { genieAnswer } from "../../utils/genieGame";

// زر إجابة للعبة المارد ("صح") — يُستخدم من أزرار .مارد
const command: Command = {
  name: "مارد_صح",
  category: "ترفيه",
  description: "إجابة لعبة المارد: صح",
  permission: "all",
  groupOnly: true,
  execute: (ctx) => genieAnswer(ctx, "مارد_صح"),
};
export default command;
