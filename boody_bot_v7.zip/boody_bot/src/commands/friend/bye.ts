import { toggleCommand } from "../../utils/friendUtils";
import { getGroupSettings, setGroupSetting } from "../../database/db";
export default toggleCommand({
  name: "bye",
  aliases: ["وداع","goodbye"],
  description: "التحكم بنظام الوداع التلقائي للمغادرين",
  label: "👋 الوداع التلقائي",
  requireBotAdmin: false,
  get: (ctx) => getGroupSettings(ctx.chatId).goodbye,
  set: (ctx, v) => { setGroupSetting(ctx.chatId, "goodbye", v); },
});
