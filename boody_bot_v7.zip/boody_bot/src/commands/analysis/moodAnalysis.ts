import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, numberToJid } from "../../utils/helpers";

function seededNumber(seed: string, max: number): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % max;
}

const MOODS: { emoji: string; label: string; note: string }[] = [
  { emoji: "😄", label: "مبسوط", note: "يومك حلو، استغله!" },
  { emoji: "😴", label: "كسلان", note: "خذلك قسط راحة اليوم." },
  { emoji: "🔥", label: "حماسي", note: "طاقتك عالية، إنجز شي مهم." },
  { emoji: "😌", label: "هادئ", note: "أعصابك رايقة اليوم." },
  { emoji: "🤔", label: "مفكر", note: "بالك مشغول بشي، خذ وقتك." },
  { emoji: "😅", label: "متوتر", note: "خذ نفس عميق وريح بالك شوي." },
  { emoji: "🥳", label: "احتفالي", note: "جو حلو حواليك، استمتع!" },
  { emoji: "🙂", label: "عادي", note: "يوم طبيعي، ولا شي مميز." },
];

const command: Command = {
  name: "تحليل_المزاج",
  aliases: ["مزاجي", "mood"],
  category: "تحليل",
  description: "بطاقة مزاج عشوائية لليوم. مثال: .تحليل_المزاج @شخص",
  permission: "all",
  execute: async (ctx) => {
    const rawNumber = ctx.args[0]?.replace(/[^0-9]/g, "");
    const target =
      getTargetJid(ctx.msg, ctx.metadata) ||
      (rawNumber ? numberToJid(rawNumber) : undefined) ||
      ctx.senderJid;

    const today = new Date().toDateString();
    const seed = `${target}-${today}-mood`;
    const mood = MOODS[seededNumber(seed, MOODS.length)];
    const energy = 40 + seededNumber(`${seed}-energy`, 61); // 40-100
    const social = 20 + seededNumber(`${seed}-social`, 81); // 20-100

    const divider = "━━━━━━━━━━━━━━━";
    const text =
      `*『 🌈 تحليل المزاج 』*\n${divider}\n` +
      `👤 العضو: ${jidToMention(target)}\n${divider}\n\n` +
      `${mood.emoji} *الحالة:* ${mood.label}\n` +
      `⚡ *الطاقة:* ${energy}%\n` +
      `🗣️ *الرغبة بالكلام:* ${social}%\n\n` +
      `💭 _${mood.note}_\n${divider}\n` +
      `🎲 _النتائج عشوائية للترفيه فقط_ 😄`;

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text, mentions: [target] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
