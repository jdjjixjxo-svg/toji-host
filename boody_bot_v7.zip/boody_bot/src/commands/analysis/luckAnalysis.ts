/**
 * 🆕 (طلب صريح: "ضيف أشياء جديدة من عندك") — بطاقة "تحليل الحظ"، نفس فكرة
 * .تحليل_الشخصية و.تحليل_المزاج بالضبط (نتيجة ثابتة لنفس الشخص بنفس اليوم)
 * بس بمظهر مختلف شوي (بطاقة تاروت/حظ) حتى تكون إضافة مميزة عن الموجود.
 */
import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, numberToJid } from "../../utils/helpers";

function seededNumber(seed: string, max: number): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % max;
}

const LUCK_CARDS: { emoji: string; title: string; note: string }[] = [
  { emoji: "🍀", title: "البرسيم الرابح", note: "يوم مليان فرص، اقتنصها بسرعة" },
  { emoji: "🌕", title: "قمر مكتمل", note: "نيتك صافية وحظك يتماشى معك" },
  { emoji: "⚡", title: "شرارة مفاجئة", note: "خبر يفرحك يوصلك اليوم أو بكرة" },
  { emoji: "🕯️", title: "شمعة هادئة", note: "يوم للراحة أكثر من المجازفة" },
  { emoji: "🗝️", title: "مفتاح مخفي", note: "فرصة قديمة ترجع لك من باب ثاني" },
  { emoji: "🌊", title: "موجة عابرة", note: "تحدي بسيط، بس تعبره بسهولة" },
  { emoji: "🌵", title: "صبر الصحراء", note: "الصبر اليوم أقوى سلاح عندك" },
  { emoji: "🎯", title: "تصويب دقيق", note: "قرار تاخذه اليوم يطلع صح 100%" },
];

const command: Command = {
  name: "تحليل_الحظ",
  aliases: ["حظي", "luck", "تحليل_حظ"],
  category: "تحليل",
  description: "بطاقة حظ اليوم العشوائية (تاروت/حظ) — ثابتة لنفس اليوم لنفس الشخص. مثال: .تحليل_الحظ @شخص",
  permission: "all",
  execute: async (ctx) => {
    const rawNumber = ctx.args[0]?.replace(/[^0-9]/g, "");
    const target =
      getTargetJid(ctx.msg, ctx.metadata) ||
      (rawNumber ? numberToJid(rawNumber) : undefined) ||
      ctx.senderJid;

    const today = new Date().toDateString();
    const seed = `${target}-${today}-hazz`;
    const card = LUCK_CARDS[seededNumber(seed, LUCK_CARDS.length)];
    const percent = 40 + seededNumber(`${seed}-percent`, 60); // 40-99%

    const divider = "━━━━━━━━━━━━━━━";
    const text =
      `*『 🔮 تحليل الحظ 』*\n${divider}\n` +
      `👤 العضو: ${jidToMention(target)}\n${divider}\n\n` +
      `${card.emoji} *${card.title}*\n_${card.note}_\n\n` +
      `📊 *نسبة الحظ اليوم:* *${percent}%*\n${divider}\n` +
      `🎲 _النتيجة عشوائية للترفيه فقط، ثابتة لنفس اليوم_ 😄`;

    try {
      const url = await ctx.sock.profilePictureUrl(target, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");
      await ctx.sock.sendMessage(ctx.chatId, { image: { url }, caption: text, mentions: [target] }, { quoted: ctx.msg });
    } catch {
      await ctx.sock.sendMessage(ctx.chatId, { text, mentions: [target] }, { quoted: ctx.msg });
    }
  },
};

export default command;
