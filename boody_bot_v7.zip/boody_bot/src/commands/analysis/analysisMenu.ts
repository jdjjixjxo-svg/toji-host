import { analyzeMediaIfPresent } from "../../utils/aiVision";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";

/**
 * ============================================================================
 * 🆕 قسم "تحليل" — بطاقات عشوائية للترفيه (شخصية / مزاج)
 * ============================================================================
 * نفس نمط قسم "تحرش" بالضبط (اتبعنا نفس الملاحظة اللي تركها المطور السابق):
 *   1) هنا: name: "تحليل"
 *   2) src/handlers/types.ts → داخل نوع category (موجودة بالفعل: "تحليل")
 *   3) src/commands/bot/menu.ts → sectionButton("تحليل", ...)
 * ============================================================================
 */
const command: Command = {
  name: "تحليل",
  aliases: ["analysis", "تحليلات"],
  category: "تحليل",
  description: "قائمة بطاقات التحليل العشوائية (شخصية / مزاج) للترفيه فقط",
  permission: "all",
  execute: async (ctx) => {
    // 🆕 لو المستخدم رد على صورة/فيديو (أو أرفقها) → تحليل بالذكاء الاصطناعي بدل القائمة
    if (await analyzeMediaIfPresent(ctx)) return;
    const p = CONFIG.PREFIX;

    const text =
      `✦ ───────── ✦\n      🔮 *تحليل* 🔮\n✦ ───────── ✦\n\n` +
      `🃏 *بطاقات عشوائية للترفيه فقط:*\n\n` +
      `  ${p}تحليل_الشخصية @شخص\n` +
      `  ${p}تحليل_المزاج @شخص\n` +
      `  ${p}تحليل_الحظ @شخص\n\n` +
      `✦ ──────── ✦`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      quickButtons: [
        sectionButton("تحليل_الشخصية", "🔮 تحليل الشخصية"),
        sectionButton("تحليل_المزاج", "🌈 تحليل المزاج"),
        sectionButton("تحليل_الحظ", "🍀 تحليل الحظ"),
        ...navButtons(),
      ],
      fallbackNote: `اكتب الأمر مباشرة مع منشن @شخص، مثال: ${p}تحليل_الشخصية @شخص`,
    });
  },
};

export default command;
