import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, numberToJid } from "../../utils/helpers";

/** رقم عشوائي ثابت لنفس الشخص بنفس اليوم (حتى ما تتغير النتيجة كل مرة يكتب الأمر) */
function seededNumber(seed: string, max: number): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % max;
}

function seededPercent(seed: string, min = 55, max = 99): number {
  return min + (seededNumber(seed, max - min + 1));
}

/** شريط تقدّم بـ 10 خانات بنفس شكل ▰▰▰▰▰▰▰▱▱▱ */
function bar(percent: number): string {
  const filled = Math.min(10, Math.max(0, Math.round(percent / 10)));
  return "▰".repeat(filled) + "▱".repeat(10 - filled);
}

/** مسبح صفات — يُختار منها 5 عشوائيًا لكل شخص حتى تختلف البطاقة من شخص لآخر */
const TRAITS: { emoji: string; label: string }[] = [
  { emoji: "📚", label: "حكيم" },
  { emoji: "🧠", label: "ذكي" },
  { emoji: "🚀", label: "نشيط" },
  { emoji: "🛡️", label: "وفيّ" },
  { emoji: "😎", label: "كاريزما" },
  { emoji: "🎨", label: "مبدع" },
  { emoji: "💬", label: "اجتماعي" },
  { emoji: "🕊️", label: "هادئ" },
  { emoji: "🔥", label: "عنيد" },
  { emoji: "🤝", label: "كريم" },
];

/** يختار 5 صفات ثابتة لنفس الشخص بنفس اليوم (بدون تكرار) */
function pickTraits(seed: string): { emoji: string; label: string }[] {
  const pool = [...TRAITS];
  const picked: { emoji: string; label: string }[] = [];
  for (let i = 0; i < 5 && pool.length > 0; i++) {
    const idx = seededNumber(`${seed}-pick${i}`, pool.length);
    picked.push(pool.splice(idx, 1)[0]);
  }
  return picked;
}

const command: Command = {
  name: "تحليل_الشخصية",
  aliases: ["تحليل_شخصية", "personality", "شخصيتي"],
  category: "تحليل",
  description: "بطاقة تحليل شخصية عشوائية مع صورة البروفايل. مثال: .تحليل_الشخصية @شخص",
  permission: "all",
  execute: async (ctx) => {
    const rawNumber = ctx.args[0]?.replace(/[^0-9]/g, "");
    const target =
      getTargetJid(ctx.msg, ctx.metadata) ||
      (rawNumber ? numberToJid(rawNumber) : undefined) ||
      ctx.senderJid;

    const today = new Date().toDateString();
    const seedBase = `${target}-${today}-shakhsiya`;

    const traits = pickTraits(seedBase);
    const scores = traits.map((t) => seededPercent(`${seedBase}-${t.label}`));
    const finalScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);

    const traitsBlock = traits
      .map((t, i) => `${t.emoji} ${t.label}\n${bar(scores[i])} *${scores[i]}%*`)
      .join("\n\n");

    const divider = "━━━━━━━━━━━━━━━";
    const text =
      `*『 🔮 تحليل الشخصية 』*\n${divider}\n` +
      `👤 العضو: ${jidToMention(target)}\n${divider}\n\n` +
      `${traitsBlock}\n\n${divider}\n` +
      `🏆 *التقييم النهائي:* *${finalScore}%*\n` +
      `🎲 _النتائج عشوائية للترفيه فقط_ 😄`;

    try {
      const url = await ctx.sock.profilePictureUrl(target, "image");
      if (!url) throw new Error("NO_PROFILE_PICTURE");
      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: { url }, caption: text, mentions: [target] },
        { quoted: ctx.msg }
      );
    } catch {
      // ما فيه صورة بروفايل (مخفية بالخصوصية أو غير موجودة) — نرسل نفس
      // البطاقة كنص عادي بدون ما ينكسر الأمر.
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text, mentions: [target] },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
