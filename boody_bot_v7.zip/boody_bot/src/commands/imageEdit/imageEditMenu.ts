import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { imageEditMenuText } from "../../utils/menuTemplates";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";

/**
 * 🆕 قسم تعديل الصور — نافذة منبثقة (قائمة اختيار واتساب الأصلية) بدل نص
 * عادي، نفس أسلوب القائمة الرئيسية. لو الأجهزة ما دعمت الأزرار، يرجع
 * تلقائيًا نص عادي (fallbackNote).
 */
const command: Command = {
  name: "تعديل_الصور",
  aliases: ["قسم_الصور", "imageedit"],
  category: "تعديل_الصور",
  description: "كل أدوات تعديل الصور بالبوت بمكان واحد (نافذة اختيار)",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: imageEditMenuText(),
      mentions: [ctx.senderJid],
      quoted: ctx.msg,
      extraButtons: [
        buildSingleSelectButton("🖼️ الأدوات", "تعديل الصور", [
          { command: "نانو", label: "🤖 نانو (ذكاء)", description: "تعديل صورة حسب وصفك" },
          { command: "ارسم", label: "🎨 ارسم", description: "ارسم صورة من وصف نصي" },
          { command: "فلتر", label: "🧪 فلتر", description: "فلاتر فورية على الصورة" },
          { command: "قص_شكل", label: "✂️ قص شكل", description: "قص مربع أو دائري" },
          { command: "قص", label: "📐 قص نسبة", description: "قص نسبة من الأطراف" },
          { command: "ملصق", label: "🩹 ملصق", description: "تحويل لملصق" },
        ]),
      ],
      fallbackNote: `اكتب الأمر مباشرة، مثال: ${p}فلتر رمادي`,
    });
  },
};

export default command;
