import Jimp from "jimp";
import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

/**
 * .قص_شكل مربع | دائري — رد على صورة. جزء من قسم تعديل_الصور الجديد.
 */
const command: Command = {
  name: "قص_شكل",
  aliases: ["cropshape", "قص_مربع"],
  category: "تعديل_الصور",
  description: "يقص الصورة مربّعة أو دائرية (رد على صورة). مثال: .قص_شكل مربع",
  permission: "all",
  execute: async (ctx) => {
    const mode = ctx.args[0]?.trim();
    if (!mode || !["مربع", "دائري", "square", "circle"].includes(mode)) {
      await reply(ctx, "❗ رد على صورة واكتب: .قص_شكل مربع  أو  .قص_شكل دائري");
      return;
    }

    const media = await getMedia(ctx, ["image"]);
    if (!media) {
      await reply(ctx, "❗ رد على صورة بنفس رسالة الأمر.");
      return;
    }

    try {
      const img = await Jimp.read(media.buffer);
      const side = Math.min(img.getWidth(), img.getHeight());
      img.crop((img.getWidth() - side) / 2, (img.getHeight() - side) / 2, side, side);
      if (mode === "دائري" || mode === "circle") img.circle();
      const outBuffer = await img.getBufferAsync(Jimp.MIME_PNG);
      await ctx.sock.sendMessage(ctx.chatId, { image: outBuffer, caption: "✅ تم القص" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر .قص_شكل:", err);
      await reply(ctx, "❌ فشل قص الصورة، جرّب صورة ثانية.");
    }
  },
};

export default command;
