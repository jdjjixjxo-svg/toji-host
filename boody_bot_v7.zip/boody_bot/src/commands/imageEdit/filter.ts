import Jimp from "jimp";
import { Command } from "../../handlers/types";
import { getMedia, reply } from "../../utils/friendUtils";
import { logger } from "../../utils/logger";

/**
 * 🆕 (طلب صريح: "قسم تعديل صور... تلوين قص تعديل...") — أول أمر بقسم
 * تعديل الصور الجديد. فلاتر فورية (بدون أي API خارجي، Jimp فقط، نفس
 * المكتبة المستخدمة أصلًا بالمشروع لرسوم الألعاب) — رد على صورة بالأمر.
 *
 * .فلتر رمادي | عكس | ضبابي | بكسل | فاتح | غامق | تباين | بوستر
 *
 * (للتعديل بالذكاء الاصطناعي حسب وصف حر، الأمر .نانو موجود مسبقًا ويغطي
 * هذا الجزء بالفعل — يحتاج GEMINI_API_KEY بـ.env.)
 */
const FILTERS: Record<string, (img: Jimp) => Jimp | Promise<Jimp>> = {
  رمادي: (img) => img.greyscale(),
  grayscale: (img) => img.greyscale(),
  عكس: (img) => img.invert(),
  invert: (img) => img.invert(),
  ضبابي: (img) => img.blur(6),
  blur: (img) => img.blur(6),
  بكسل: (img) => img.pixelate(10),
  pixelate: (img) => img.pixelate(10),
  فاتح: (img) => img.brightness(0.3),
  غامق: (img) => img.brightness(-0.3),
  تباين: (img) => img.contrast(0.4),
  بوستر: (img) => img.posterize(4),
};

const command: Command = {
  name: "فلتر",
  aliases: ["filter"],
  category: "تعديل_الصور",
  description: `فلاتر فورية على صورة (رد عليها). الأنواع: ${Object.keys(FILTERS).filter((k) => /[ا-ي]/.test(k)).join(" | ")}`,
  permission: "all",
  execute: async (ctx) => {
    const type = ctx.args[0]?.trim();
    if (!type || !FILTERS[type]) {
      await reply(
        ctx,
        `❗ رد على صورة واكتب نوع الفلتر.\nمثال: .فلتر رمادي\n\nالأنواع المتاحة: ${Object.keys(FILTERS)
          .filter((k) => /[ا-ي]/.test(k))
          .join(" | ")}`
      );
      return;
    }

    const media = await getMedia(ctx, ["image"]);
    if (!media) {
      await reply(ctx, "❗ رد على صورة بنفس رسالة الأمر.");
      return;
    }

    try {
      const img = await Jimp.read(media.buffer);
      await FILTERS[type](img);
      const outBuffer = await img.getBufferAsync(Jimp.MIME_JPEG);
      await ctx.sock.sendMessage(ctx.chatId, { image: outBuffer, caption: `✅ فلتر: ${type}` }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر .فلتر:", err);
      await reply(ctx, "❌ فشل تعديل الصورة، جرّب صورة ثانية.");
    }
  },
};

export default command;
