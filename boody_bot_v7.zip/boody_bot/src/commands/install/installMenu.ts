import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";
import { installMenuText } from "../../utils/menuTemplates";

/**
 * قسم "🕸التنصيب" — شرح كيف تعمل الميزة قبل استخدامها (طلب صريح: أول ما
 * تدخل الزر يعطيك معلومات عن كيف يعمل وكيف يشتغل). راجع install.ts لتنفيذ
 * الأمر الفعلي و enableInstall.ts/disableInstall.ts لتفعيل/تعطيل الميزة
 * بمجموعة معينة (المطور فقط).
 */
const command: Command = {
  name: "تنصيب_قائمة",
  aliases: ["قائمة_تنصيب", "installmenu"],
  category: "تنصيب",
  description: "شرح ميزة التنصيب (ربط رقمك ببوت فرعي) قبل استخدام أمر .تنصيب",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;

    const text = installMenuText();

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      quickButtons: [sectionButton("تنصيب", "🕸 ابدأ التنصيب الآن"), sectionButton("الغاء_تنصيب", "🗑️ إلغاء التنصيب"), ...navButtons()],
      fallbackNote: `اكتب الأمر مباشرة: ${p}تنصيب`,
    });
  },
};

export default command;
