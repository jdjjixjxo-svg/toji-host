import { Command } from "../../handlers/types";
import { setGroupSetting } from "../../database/db";

/**
 * .تفعيل_بوت — يعيد تشغيل البوتات الفرعية بهذي المجموعة بعد تعطيلها
 * بأمر .تعطيل_بوت. راجع disableSubBots.ts للتفاصيل الكاملة.
 */
const command: Command = {
  name: "تفعيل_بوت",
  aliases: ["تشغيل_بوت"],
  category: "تنصيب",
  description: "يعيد تشغيل البوتات الفرعية المنصّبة بهذه المجموعة بعد تعطيلها بـ .تعطيل_بوت",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    if (ctx.isSubBot) return; // التحكم عبر البوت الرئيسي فقط

    setGroupSetting(ctx.chatId, "subBotsEnabled", true);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "✅ تم إعادة تفعيل البوتات الفرعية بهذه المجموعة." },
      { quoted: ctx.msg }
    );
  },
};

export default command;
