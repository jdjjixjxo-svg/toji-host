import { Command } from "../../handlers/types";
import { installCodeText } from "../../utils/menuTemplates";
import { digitsOnly, resolveRealPhoneJid, parseManualPhoneNumber, jidToMention } from "../../utils/helpers";
import { sendButtonMessage, buildCopyCodeButton } from "../../utils/interactive";
import { requestInstallCode } from "../../handlers/subBotManager";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";

/**
 * ============================================================================
 * .تنصيب — يربط رقم المستخدم كـ"جهاز مرتبط" ليشتغل عنده بوت فرعي كامل
 * ============================================================================
 * لا يعمل تلقائيًا بأي مجموعة أبدًا — لازم المطور يفعّله يدويًا بكل مجموعة
 * تحديدًا عبر ".تفعيل_تنصيب" (راجع src/commands/owner/enableInstall.ts).
 *
 * لا يعرض رقم المستخدم إطلاقًا داخل الرسالة (فقط منشن + كود اقتران).
 * ============================================================================
 */
const command: Command = {
  name: "تنصيب",
  category: "تنصيب",
  description: "يربط رقمك كجهاز مرتبط ليشتغل عندك بوت فرعي كامل (يحتاج تفعيل من المطور أولًا بهذي المجموعة)",
  permission: "all",
  requireBotAdmin: false,
  execute: async (ctx) => {
    // 🔧 (طلب صريح: "خلي التنصيب يشتغل بكل البوتات الفرعية") — شلنا القيد
    // اللي كان يمنع تشغيل .تنصيب من داخل بوت فرعي. الآن أي بوت (رئيسي أو
    // فرعي) يقدر ينصّب بوتات فرعية جديدة بنفس الطريقة.

    // 🔧 (طلب صريح) .تنصيب يعمل بالخاص والمجموعات معًا.

    // 🔧 إصلاح Username/@lid: لا نخمّن رقم الهاتف أبدًا من معرّف مؤقت.
    // نحاول أولًا نجيب رقم الهاتف الحقيقي الموثوق من بيانات المجموعة
    // (resolveRealPhoneJid لا ترجع إلا رقمًا حقيقيًا فعليًا، وإلا null
    // صراحة — بعكس resolveGroupJid العامة المستخدمة بأماكن أخرى بالمشروع
    // واللي قد ترجع معرّف @lid كـfallback، وهو مناسب هناك لكن غير مقبول
    // هنا). لو تعذّر، نطلب من المستخدم يكتب رقمه يدويًا صراحة.
    const resolvedJid = resolveRealPhoneJid(ctx.senderJid, ctx.metadata);
    let phone: string | null = resolvedJid ? digitsOnly(resolvedJid) : null;

    if (!phone) {
      const manualInput = ctx.text.trim(); // كل شي بعد ".تنصيب" كما كتبه المستخدم
      if (!manualInput) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          {
            text:
              `⚠️ ما قدرنا نتعرّف تلقائيًا على رقمك الحقيقي (يبدو إنك تظهر بمعرّف مؤقت/Username وليس رقم هاتف).\n\n` +
              `اكتب رقمك يدويًا بهذي الصيغة:\n` +
              `${CONFIG.PREFIX}تنصيب <رقمك مع رمز الدولة>\n\n` +
              `مثال:\n${CONFIG.PREFIX}تنصيب +44 7453 388374`,
          },
          { quoted: ctx.msg }
        );
        return;
      }

      const parsed = parseManualPhoneNumber(manualInput);
      if (!parsed) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          {
            text:
              `❌ الرقم اللي كتبته غير صالح.\n` +
              `تأكد إنه رقم هاتف صحيح مع رمز الدولة، مثال:\n${CONFIG.PREFIX}تنصيب +44 7453 388374`,
          },
          { quoted: ctx.msg }
        );
        return;
      }
      phone = parsed;
    }

    if (!phone || phone.length < 7) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذّر التعرف على رقمك الحقيقي حاليًا. حاول مرة ثانية بعد قليل." },
        { quoted: ctx.msg }
      );
      return;
    }

    let code: string;
    try {
      const result = await requestInstallCode(phone);
      code = result.code;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);

      if (message === "ALREADY_ACTIVE") {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "✅ عندك أصلًا بوت فرعي شغّال ومربوط برقمك. ما تحتاج تنصيب من جديد." },
          { quoted: ctx.msg }
        );
        return;
      }
      if (message === "ALREADY_PENDING") {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "⏳ فيه كود سابق لسا بانتظار إدخالك — تفقّد الخاص، أو انتظر شوي قبل ما تطلب كود جديد." },
          { quoted: ctx.msg }
        );
        return;
      }
      if (message.startsWith("COOLDOWN:")) {
        const seconds = message.split(":")[1];
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `⏳ لازم تنتظر ${seconds} ثانية قبل ما تطلب كود تنصيب جديد لنفس رقمك.` },
          { quoted: ctx.msg }
        );
        return;
      }

      logger.error("فشل طلب كود تنصيب:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ صار خطأ أثناء توليد كود التنصيب. حاول مرة ثانية بعد قليل." },
        { quoted: ctx.msg }
      );
      return;
    }

    const mention = jidToMention(ctx.senderJid);
    const text = installCodeText({ user: mention, code });

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      mentions: [ctx.senderJid],
      extraButtons: [buildCopyCodeButton(code)],
      fallbackNote: "انسخ الكود يدويًا من أعلى وحطه بواتساب ← الأجهزة المرتبطة ← ربط جهاز ← استخدام رقم الهاتف.",
    });
  },
};

export default command;
