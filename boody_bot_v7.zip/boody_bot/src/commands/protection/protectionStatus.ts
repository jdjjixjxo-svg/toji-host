import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getGroupSettings } from "../../database/db";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { protectionMenuText } from "../../utils/menuTemplates";
import { getSectionImageBuffer } from "../../utils/media";

const onOff = (v: boolean) => (v ? "✅ مفعّل" : "❌ متوقف");

const command: Command = {
  name: "حماية",
  aliases: ["protection"],
  category: "حماية",
  description: "عرض حالة نظام الحماية في المجموعة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const s = getGroupSettings(ctx.chatId);
    const text = protectionMenuText({
      general: onOff(s.protection),
      links: onOff(s.antilink),
      spam: onOff(s.antispam),
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
    });

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("protection") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
