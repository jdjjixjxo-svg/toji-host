import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getSupabase, isSupabaseConfigured } from "../../database/supabaseClient";

/**
 * 🆕 ".فحص_قاعدة_البيانات" (خلف "mongocheck" القديم) — تشخيص حي لاتصال
 * Supabase على هذا السيرفر تحديدًا: يتأكد إن SUPABASE_URL/SUPABASE_KEY
 * موجودين، ثم يعمل كتابة وقراءة فعليتين على جدول bot_backup (نفس الجدول
 * اللي يستخدمه النسخ الاحتياطي) للتأكد إن البوت "يقرأ ويكتب صح" فعليًا،
 * لا مجرد فحص شكلي للنص. يخفي المفتاح دائمًا، ما يطلعه إطلاقًا بأي حال.
 */
function maskKey(raw: string): string {
  if (raw.length <= 8) return "••••";
  return `${raw.slice(0, 6)}••••${raw.slice(-4)}`;
}

const command: Command = {
  name: "فحص_قاعدة_البيانات",
  aliases: ["mongocheck", "فحص_مونجو", "فحص_مونقو", "فحص_supabase", "supabasecheck"],
  category: "المطور",
  description: "يفحص إعدادات Supabase الفعلية على هذا السيرفر ويجرّب قراءة/كتابة حقيقية (بدون إظهار المفتاح)",
  permission: "owner",
  execute: async (ctx) => {
    const url = (CONFIG.SUPABASE_URL || "").trim();
    const key = (CONFIG.SUPABASE_KEY || "").trim();

    if (!url || !key) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `❌ Supabase مو مضبوط بالكامل على هذا السيرفر:\n` +
            `SUPABASE_URL: ${url ? "✅ موجود" : "❌ فاضي"}\n` +
            `SUPABASE_KEY: ${key ? "✅ موجود" : "❌ فاضي"}\n\n` +
            `تأكد أضفتهم بـ.env (أو متغيرات البيئة بالاستضافة) وأعدت تشغيل البوت.`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const problems: string[] = [];
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(url)) {
      problems.push("⚠️ SUPABASE_URL ما يطابق الشكل المتوقع (https://xxxx.supabase.co) — تأكد نسخته كامل بدون مسار إضافي.");
    }
    if (key.startsWith("sb_publishable_")) {
      problems.push(
        "ℹ️ هذا مفتاح publishable (anon) — يحترم صلاحيات RLS. لو القراءة/الكتابة بالأسفل فشلت، إما فعّل سياسة RLS تسمح بالوصول لجدولي bot_backup/titles، أو استخدم مفتاح secret (service_role) بدلًا منه لأن هذا بوت خلفي موثوق مو تطبيق متصفح عام."
      );
    }

    let readWriteResult = "";
    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error("تعذر إنشاء عميل Supabase.");

      const probeValue = { pingedAt: Date.now(), from: "فحص_قاعدة_البيانات" };
      const { error: writeErr } = await supabase
        .from("bot_backup")
        .upsert({ id: "__healthcheck__", data: probeValue, updated_at: new Date().toISOString() });
      if (writeErr) throw writeErr;

      const { data, error: readErr } = await supabase
        .from("bot_backup")
        .select("data")
        .eq("id", "__healthcheck__")
        .maybeSingle();
      if (readErr) throw readErr;

      const roundTripOk = (data as any)?.data?.pingedAt === probeValue.pingedAt;
      readWriteResult = roundTripOk
        ? "✅ نجحت الكتابة والقراءة فعليًا على جدول bot_backup — الاتصال سليم بالكامل."
        : "⚠️ الكتابة نجحت لكن القراءة رجّعت قيمة مختلفة — تحقق من الجدول يدويًا.";
    } catch (err: any) {
      const msg = err?.message || String(err);
      const isMissingTable = /relation .* does not exist|not found|42P01/i.test(msg);
      readWriteResult =
        `❌ فشلت الكتابة/القراءة الفعلية: ${msg}\n` +
        (isMissingTable
          ? "👈 السبب الأرجح: جدول bot_backup غير منشأ بعد — نفّذ SQL إنشاء الجدول من README مرة واحدة بلوحة تحكم Supabase."
          : "👈 لو الجدول موجود فعلًا، تأكد سياسات RLS تسمح لهذا المفتاح بالقراءة/الكتابة، أو استخدم مفتاح secret.");
    }

    const text =
      `🔍 *فحص Supabase (السيرفر الحالي):*\n\n` +
      `الرابط: \`${url}\`\n` +
      `المفتاح: \`${maskKey(key)}\`\n\n` +
      (problems.length ? `${problems.join("\n\n")}\n\n` : "") +
      readWriteResult;

    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
