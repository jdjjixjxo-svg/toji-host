import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { commandRegistry } from "../../handlers/commandRegistry";
import { devMenuText } from "../../utils/menuTemplates";

const command: Command = {
  name: "اوامر_المطور",
  aliases: ["اوامرالمطور", "المطور_اوامر", "ownercommands", "devcommands", "🔥اوامر_المطور"],
  category: "المطور",
  description: "عرض كل أوامر المطور بدون أي استثناء",
  permission: "owner",
  execute: async (ctx) => {
    // 📋 القائمة تُبنى ديناميكيًا من كل الأوامر المسجّلة فعليًا بفئة
    // "المطور" — مو قائمة مكتوبة يدويًا. هذا يضمن ظهور "كل" أوامر المطور
    // بدون استثناء، وحتى أي أمر مطور جديد يُضاف مستقبلًا يظهر هنا تلقائيًا
    // بدون الحاجة نعدّل هالملف كل مرة.
    const devCommands = commandRegistry
      .getAll()
      .filter((c) => c.category === "المطور")
      .sort((a, b) => a.name.localeCompare(b.name, "ar"));

    if (!devCommands.length) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ ما فيه أوامر مسجّلة بفئة المطور حاليًا." },
        { quoted: ctx.msg }
      );
      return;
    }

    const text = devMenuText(devCommands.map((c) => ({ name: c.name, description: c.description })));

    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
