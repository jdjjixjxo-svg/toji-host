import { Command } from "../../handlers/types";
import { db } from "../../database/db";
import { sleep } from "../../utils/helpers";

const command: Command = {
  name: "اذاعة",
  aliases: ["broadcast", "بث", "إذاعة"],
  category: "المطور",
  description: "إرسال رسالة لجميع المجموعات التي يوجد بها البوت",
  permission: "owner",
  execute: async (ctx) => {
    if (!ctx.text) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ اكتب نص الرسالة بعد الأمر." });
      return;
    }

    const groupIds = Object.keys(db.get("groups").value() || {});
    let success = 0;

    for (const gid of groupIds) {
      try {
        await ctx.sock.sendMessage(gid, {
          text: `📢 *إذاعة من المطور*\n\n${ctx.text}`,
        });
        success++;
        await sleep(700); // تجنب الإغراق السريع بالرسائل
      } catch {
        // تجاهل المجموعات التي فشل الإرسال إليها ومتابعة الباقي
      }
    }

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `✅ تم إرسال الإذاعة إلى ${success} من أصل ${groupIds.length} مجموعة.`,
    });
  },
};

export default command;
