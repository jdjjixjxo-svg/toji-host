import { Command } from "../../handlers/types";
import { db } from "../../database/db";

const command: Command = {
  name: "وضع_عام",
  aliases: ["public"],
  category: "المطور",
  description: "البوت يستجيب للجميع",
  permission: "owner",
  execute: async (ctx) => {
    db.set("bot.publicMode", true).write();
    await ctx.sock.sendMessage(ctx.chatId, {
      text: "🌐 تم تفعيل الوضع العام — البوت يستجيب للجميع الآن.",
    });
  },
};

export default command;
