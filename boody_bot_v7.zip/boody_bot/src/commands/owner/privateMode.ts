import { Command } from "../../handlers/types";
import { db } from "../../database/db";

const command: Command = {
  name: "وضع_خاص",
  aliases: ["private"],
  category: "المطور",
  description: "البوت يستجيب للمالك فقط",
  permission: "owner",
  execute: async (ctx) => {
    db.set("bot.publicMode", false).write();
    await ctx.sock.sendMessage(ctx.chatId, {
      text: "🔒 تم تفعيل الوضع الخاص — البوت يستجيب للمالك فقط الآن.",
    });
  },
};

export default command;
