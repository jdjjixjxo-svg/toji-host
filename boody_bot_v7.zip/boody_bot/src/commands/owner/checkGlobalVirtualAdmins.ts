import { Command } from "../../handlers/types";
import { db } from "../../database/db";
import { jidToMention } from "../../utils/helpers";

/**
 * 🆕 (طلب صريح: "رفع_مالك يقلي تم رفعه لكن ما يعطيه أي صلاحية") — أمر
 * تشخيصي بحت يعرض *بالضبط* القيم المخزَّنة حاليًا بقائمة الأدمن الوهمي
 * العام (bot.globalVirtualAdmins) من قاعدة البيانات مباشرة، بدون أي
 * تعديل أو تفسير. يساعد يحدد فورًا هل السبب:
 *   1) القائمة فاضية تمامًا رغم تنفيذ .رفع_مالك سابقًا → أرجح سبب:
 *      الاستضافة لا تحفظ db.json بشكل دائم بين كل إعادة تشغيل (مشكلة
 *      استضافة، مو كود).
 *   2) القائمة فيها JID لكن بصيغة غريبة (مثلًا تنتهي بـ @lid) → المقارنة
 *      وقت التحقق من الصلاحية غالبًا تفشل رغم التخزين الصحيح ظاهريًا.
 */
const command: Command = {
  name: "فحص_مالك",
  aliases: ["فحص_مالك_وهمي"],
  category: "المطور",
  description: "يعرض قائمة الأعضاء المرفوعين عبر .رفع_مالك كما هي مخزّنة فعليًا (تشخيص). للمطور فقط.",
  permission: "owner",
  requireBotAdmin: false,
  execute: async (ctx) => {
    const list: string[] = db.get("bot.globalVirtualAdmins").value() || [];

    if (!list.length) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "📋 القائمة فاضية حاليًا (ما فيه أي عضو مرفوع عبر .رفع_مالك).\n\n" +
            "⚠️ لو أنت متأكد إنك رفعت أحد قبل شوي وطلع فاضي، هذا دليل قوي إن " +
            "الاستضافة ما تحفظ ملفات المشروع (db.json) بشكل دائم بين كل إعادة تشغيل — " +
            "مشكلة استضافة، مو كود البوت.",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🔧 (عزل البوتات الفرعية) — الإدخالات صارت بصيغة "botId|jid" (راجع
    // db.ts). ندعم كمان الصيغة القديمة (jid خام بدون فاصل، معناها كانت
    // مرفوعة على البوت الرئيسي قبل هذا الإصلاح) بعرضها بوضوح.
    const parsed = list.map((entry) => {
      const sep = entry.indexOf("|");
      return sep === -1
        ? { botId: "(رئيسي — منح قديم قبل التحديث)", jid: entry }
        : { botId: entry.slice(0, sep), jid: entry.slice(sep + 1) };
    });

    const jids = parsed.map((p) => p.jid);
    const lines = parsed
      .map((p, i) => `${i + 1}. ${jidToMention(p.jid)} — بوت: ${p.botId} — (JID خام: ${p.jid})`)
      .join("\n");
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `📋 الأعضاء المرفوعين عبر .رفع_مالك حاليًا (بكل البوتات):\n\n${lines}`,
        mentions: jids,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
