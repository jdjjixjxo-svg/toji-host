import { Command } from "../../handlers/types";
import { setGroupSetting } from "../../database/db";

/**
 * 🆕 يفعّل أمر ".تنصيب" بهذي المجموعة تحديدًا فقط. مطفي افتراضيًا بكل
 * مجموعة ولا يعمل تلقائيًا أبدًا — المطور لازم يفعّله يدويًا بكل مجموعة
 * على حدة (طلب صريح). راجع src/commands/install/install.ts.
 */
const command: Command = {
  name: "تفعيل_تنصيب",
  category: "المطور",
  description: "يفعّل أمر .تنصيب داخل هذه المجموعة تحديدًا",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    setGroupSetting(ctx.chatId, "installEnabled", true);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "✅ تم تفعيل أمر .تنصيب بهذه المجموعة." },
      { quoted: ctx.msg }
    );
  },
};

export default command;
