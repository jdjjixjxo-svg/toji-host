import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, getBotScopeId } from "../../utils/helpers";
import { grantVirtualAdmin } from "../../database/db";
import { isOwner } from "../../middlewares/permissions";
import { logger } from "../../utils/logger";
import { updateParticipant, isBotAdminLive } from "../../utils/groupAdmin";

/**
 * .رفع_ادمن (تُكتب أيضًا «.رفع ادمن» بمسافة، أو «.رفع») — يرفع العضو أدمن.
 *
 * يسوي شيئين (حسب من كتب الأمر وحالة البوت):
 *  1) 🤖 أدمن داخل البوت (للمطور فقط): العضو يقدر ينفذ كل أوامر المشرفين بهذي
 *     المجموعة حتى لو مو مشرف بواتساب.
 *  2) 👑 ترقية حقيقية بواتساب (لأي مشرف): تنجح فقط لو البوت نفسه مشرف بالمجموعة.
 *
 * ⚠️ الأدمن الوهمي نفسه ما يقدر يرفع غيره (allowVirtualAdmin: false).
 * ⚠️ ما يشتغل على أوامر المطور، وردود «انا مطورك» تبقى للمطور الحقيقي فقط.
 */
const command: Command = {
  name: "رفع_ادمن",
  aliases: ["رفع", "رفع_ادمن_وهمي", "رفع_مشرف"],
  category: "مشرفين",
  description: "يرفع العضو أدمن: ترقية حقيقية بواتساب (لو البوت مشرف) + صلاحية أوامر المشرفين داخل البوت (للمطور).",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  allowVirtualAdmin: false,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ حدّد الشخص: منشنه أو رد على رسالته.\nمثال: .رفع ادمن @الشخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    const owner = isOwner(ctx.senderJid, ctx.metadata || undefined, ctx.sock);
    const lines: string[] = [];

    if (owner) {
      grantVirtualAdmin(getBotScopeId(ctx.sock), ctx.chatId, target);
      lines.push("✅ صار يقدر ينفذ أوامر المشرفين داخل البوت بهذي المجموعة.");
    }

    const res = await updateParticipant(ctx.sock, ctx.chatId, "promote", target, ctx.metadata);
    const realOk = res.ok;
    if (res.ok) lines.push("✅ تمت ترقيته مشرف بواتساب.");
    else {
      const botAdmin = await isBotAdminLive(ctx.sock, ctx.chatId);
      logger.warn(`تعذرت الترقية الحقيقية (status=${res.status}): ${res.reason}`);
      const why = botAdmin === false ? "البوت نفسه مو مشرف بهذي المجموعة" : res.reason;
      lines.push(owner ? `ℹ️ ما تمت الترقية بواتساب: ${why}` : `❌ فشلت الترقية: ${why}`);
    }

    const head = owner || realOk ? `👑 *رفع أدمن* — ${jidToMention(target)}` : `⚠️ *رفع أدمن* — ${jidToMention(target)}`;
    await ctx.sock.sendMessage(ctx.chatId, { text: `${head}\n\n${lines.join("\n")}`, mentions: [target] }, { quoted: ctx.msg });
  },
};

export default command;
