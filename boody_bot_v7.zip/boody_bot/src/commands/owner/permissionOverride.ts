import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import {
  setPermissionOverride,
  getPermissionOverride,
  listPermissionOverrides,
  PermissionOverrideLevel,
} from "../../database/db";

/**
 * 🆕 (طلب صريح: "المطور يقدر يخلي أمر بس للمشرفين، أو بس للمطورين") —
 * تغيير صلاحية أي أمر من داخل واتساب بدون تعديل كود.
 *
 * .صلاحية <أمر> مشرفين   → المشرفون فقط
 * .صلاحية <أمر> مطور     → المطورون فقط (على هذا البوت بالذات: الرئيسي
 *                           → مطوريه الرئيسيين، بوت فرعي → صاحب رقمه)
 * .صلاحية <أمر> الكل     → الجميع
 * .صلاحية <أمر> افتراضي  → يرجّع الصلاحية الأصلية للأمر
 * .صلاحية                → يعرض كل التجاوزات الحالية
 *
 * الإعداد محفوظ لكل بوت لحاله (كل بوت فرعي له db محلي خاص فيه).
 */
const LEVELS: Record<string, PermissionOverrideLevel | null> = {
  الكل: "all",
  all: "all",
  مشرفين: "admin",
  المشرفين: "admin",
  admin: "admin",
  مطور: "owner",
  المطور: "owner",
  مطورين: "owner",
  المطورين: "owner",
  owner: "owner",
  افتراضي: null,
  reset: null,
};

const LABEL: Record<PermissionOverrideLevel, string> = { all: "الجميع", admin: "المشرفين فقط", owner: "المطورين فقط" };

const command: Command = {
  name: "صلاحية",
  aliases: ["صلاحيه", "perm"],
  category: "المطور",
  description: "يغيّر صلاحية أي أمر: .صلاحية <أمر> <الكل|مشرفين|مطور|افتراضي>",
  permission: "owner",
  execute: async (ctx) => {
    const reply = (text: string) => ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });

    if (!ctx.args.length) {
      const all = listPermissionOverrides();
      const rows = Object.entries(all).map(([n, l]) => `• ${n} → ${LABEL[l as PermissionOverrideLevel] ?? l}`);
      await reply(
        rows.length
          ? `🔐 *تجاوزات الصلاحيات الحالية:*\n${rows.join("\n")}`
          : "🔐 ما فيه تجاوزات — كل الأوامر على صلاحياتها الأصلية.\n\nمثال: .صلاحية طرد مشرفين"
      );
      return;
    }

    const cmdName = ctx.args[0].replace(/^\./, "");
    const levelWord = ctx.args[1];
    const target = commandRegistry.get(cmdName);
    if (!target) {
      await reply(`❌ ما لقيت أمر باسم "${cmdName}".`);
      return;
    }
    if (target.name === "صلاحية") {
      await reply("🚫 أمر .صلاحية نفسه ما ينغيّر (حماية من قفل التحكم).");
      return;
    }

    if (!levelWord || !(levelWord in LEVELS)) {
      const cur = getPermissionOverride(target.name);
      await reply(
        `🔐 .${target.name}\nالأصلية: ${target.permission}\nالحالية: ${cur ? LABEL[cur] : "أصلية (بدون تجاوز)"}\n\n` +
          `اكتب: .صلاحية ${target.name} <الكل | مشرفين | مطور | افتراضي>`
      );
      return;
    }

    const level = LEVELS[levelWord];
    setPermissionOverride(target.name, level);
    await reply(
      level
        ? `✅ صار أمر .${target.name} لـ ${LABEL[level]}.`
        : `✅ رجّعت أمر .${target.name} لصلاحيته الأصلية (${target.permission}).`
    );
  },
};

export default command;
