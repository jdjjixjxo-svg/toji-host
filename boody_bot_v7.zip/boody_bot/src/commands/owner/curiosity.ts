import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { isOwner } from "../../middlewares/permissions";
import { isVirtualAdmin } from "../../database/db";
import { buildQuotedMessage, getBotScopeId } from "../../utils/helpers";
import { logger } from "../../utils/logger";

/**
 * 🆕 .فضول — أمر مخصص فقط للمطور و"الأدمن الوهمي" (اللي منحه المطور
 * صلاحيته عبر .رفع_ادمن بهذي المجموعة بالذات)، وليس لمشرفي واتساب
 * الحقيقيين. لهذا السبب permission هنا "all" (حتى ما يمر بفحص الصلاحية
 * المركزي اللي يسمح تلقائيًا لأي مشرف حقيقي)، ونعمل الفحص يدويًا بالأسفل:
 * إما المطور نفسه (isOwner) أو أدمن وهمي بهذي المجموعة (isVirtualAdmin).
 * أي شخص ثاني: نتجاهله بصمت تمامًا (بدون أي رد بالمجموعة) — الأمر أصلًا
 * مصمم يكون خفي (لا رد، لا رسالة خطأ) حتى ما يلفت الانتباه له.
 *
 * الشرط: يعمل فقط لما يكون الأمر ردًا (Reply) فعليًا على رسالة وسائط
 * (صورة/فيديو/رسالة صوتية) — مو منشن ومو كابشن مباشر. لو ما فيه رد على
 * وسائط، نتجاهل الأمر بصمت (بدون أي رد بالمجموعة كذلك).
 *
 * عند التنفيذ: نحمّل الوسائط ونرسلها فقط بالخاص (DM) لنفس الشخص اللي كتب
 * الأمر، بدون أي رد أو أثر داخل المجموعة نفسها. بعدها نرسل تأكيد نجاح/فشل
 * بنفس الخاص فقط.
 */
const command: Command = {
  name: "فضول",
  aliases: ["fdool"],
  category: "المطور",
  description: "يرسل الوسائط المردود عليها للخاص بصمت. للمطور والأدمن الوهمي فقط (رد فقط، وليس منشن).",
  permission: "all",
  requireBotAdmin: false,
  execute: async (ctx) => {
    // ===== فحص الصلاحية اليدوي: المطور أو أدمن وهمي بهذي المجموعة فقط =====
    const authorized =
      isOwner(ctx.senderJid, ctx.metadata || undefined) ||
      (ctx.isGroup && isVirtualAdmin(getBotScopeId(ctx.sock), ctx.chatId, ctx.senderJid));

    if (!authorized) return; // صمت تام — بدون أي رد

    // ===== لازم يكون الأمر ردًا فعليًا على وسائط (مو منشن ومو كابشن مباشر) =====
    const quoted = ctx.quoted;
    if (!quoted) return;

    const imageMsg = quoted.imageMessage;
    const videoMsg = quoted.videoMessage;
    const audioMsg = quoted.audioMessage;

    if (!imageMsg && !videoMsg && !audioMsg) return;

    const target = ctx.senderJid;

    try {
      const source = buildQuotedMessage(ctx.msg);
      if (!source) throw new Error("NO_QUOTED_SOURCE");

      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      if (imageMsg) {
        await ctx.sock.sendMessage(target, {
          image: buffer,
          caption: imageMsg.caption || undefined,
        });
      } else if (videoMsg) {
        await ctx.sock.sendMessage(target, {
          video: buffer,
          mimetype: videoMsg.mimetype || "video/mp4",
          caption: videoMsg.caption || undefined,
        });
      } else if (audioMsg) {
        await ctx.sock.sendMessage(target, {
          audio: buffer,
          mimetype: audioMsg.mimetype || "audio/ogg; codecs=opus",
          ptt: !!audioMsg.ptt,
        });
      }

      await ctx.sock.sendMessage(target, { text: "✅ تم نجاح الامر" });
    } catch (err) {
      logger.error("فشل أمر .فضول:", err);
      try {
        await ctx.sock.sendMessage(target, { text: "❌ فشل الامر 🙂" });
      } catch {
        /* حتى لو فشل إرسال رسالة الفشل نفسها، ما نكسر شي ولا نرد بالمجموعة */
      }
    }
  },
};

export default command;
