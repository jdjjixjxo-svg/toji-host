import { Command } from "../../handlers/types";
import { setBotEnabledInGroup } from "../../database/db";
import { getBotScopeId } from "../../utils/helpers";

const command: Command = {
  name: "ايقاف",
  aliases: ["إيقاف", "off", "ايقاف_هنا"],
  category: "المطور",
  description: "يوقف هذا البوت (بالذات) داخل هذه المجموعة",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 (طلب صريح: "لو 3 بواتات بكروب واحد كتب .ايقاف ما يوقفن 3 بس
    // بوته") — كان هذا الأمر يوقف كل البوتات بهذي المجموعة معًا (رئيسي +
    // كل الفرعيين) لأنه يكتب على حقل "enabled" مشترك. الآن يوقف بوته هو
    // بالذات فقط (getBotScopeId(ctx.sock) = رقمه الفعلي)، بدون أي تأثير
    // على بقية البوتات المنصّبة بنفس المجموعة.
    setBotEnabledInGroup(ctx.chatId, getBotScopeId(ctx.sock), false);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "🛑 تم إيقاف هذا البوت بهذه المجموعة. اكتب .تشغيل لإعادة تفعيله." },
      { quoted: ctx.msg }
    );
  },
};

export default command;
