import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, getBotScopeId } from "../../utils/helpers";
import { grantGlobalVirtualAdmin } from "../../database/db";
import { logger } from "../../utils/logger";

/**
 * 🆕 .رفع_مالك — نفس فكرة .رفع_ادمن بالضبط (يعطي عضو صلاحية تنفيذ كل
 * أوامر المشرفين permission: "admin" بدون ترقية واتساب حقيقية)، لكن
 * الفرق الجوهري: .رفع_ادمن تحصر الصلاحية بمجموعة واحدة بس (اللي
 * استُخدم فيها الأمر)، بينما .رفع_مالك تعطيه الصلاحية بكل مجموعة البوت
 * موجود فيها حاليًا أو ينضم لها مستقبلًا — بدون أي حاجة لتكرار الأمر
 * بكل مجموعة على حدة.
 *
 * ⚠️ يمكن استخدامه داخل مجموعة (منشن/رد) أو بالخاص (منشن فقط، عبر
 * getTargetJid بدون metadata) — نفس شرط .رفع_ادمن ما ينطبق هنا لأن هذا
 * الأمر مو groupOnly أصلًا.
 *
 * ⚠️ ما يشتغل على:
 *   - أوامر permission: "owner" (تبقى للمطور فقط دائمًا).
 *   - فحوصات isOwner() المباشرة (زي "انا مطورك") — لا علاقة لها بنظام
 *     الأدمن الوهمي إطلاقًا، عام كان أو محصور بمجموعة.
 */
const command: Command = {
  name: "رفع_مالك",
  aliases: ["رفع_مالك_وهمي", "ادمن_عام"],
  category: "المطور",
  description:
    "يعطي عضو صلاحية أوامر المشرفين بكل مجموعات البوت (مو مجموعة وحدة فقط). للمطور فقط.",
  permission: "owner",
  requireBotAdmin: false,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ منشن الشخص أو رد على رسالته! مثال: .رفع_مالك @شخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    grantGlobalVirtualAdmin(getBotScopeId(ctx.sock), target);

    // 🩺 تشخيص (طلب صريح: "يقلي تم رفعه لكن ما يعطيه أي صلاحية") — نطبع
    // الـ JID المخزَّن *بالضبط* بالـ logs، حتى نقدر نتأكد لاحقًا هل المشكلة
    // بتخزين JID غلط (مثلاً @lid بدل الرقم الحقيقي) أو بشي ثاني تمامًا
    // (مثلاً قاعدة البيانات تُصفَّر بين كل إعادة تشغيل بسبب استضافة لا
    // تحفظ الملفات بشكل دائم). راجع أيضًا أمر .فحص_مالك الجديد بالأسفل.
    logger.info(`🩺 .رفع_مالك: تم تخزين JID التالي بقائمة الأدمن الوهمي العام: "${target}"`);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `👑 تم رفع ${jidToMention(target)} لصلاحية "أدمن" بكل مجموعات البوت (مو مجموعة وحدة بس).`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
