import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { digitsOnly, buildQuotedMessage } from "../../utils/helpers";
import { getPtvStatus } from "../../events/groupJoinPtv";
import { logger } from "../../utils/logger";

/**
 * 🆕 (طلب صريح: ".فنشهم") — لصاحب البوت (OWNER_NUMBER/OWNER_NUMBER_2) أو
 * رقم البوت نفسه حصرًا. يسوي 3 خطوات بالترتيب:
 *   1) يغيّر صورة المجموعة (رد على صورة بنفس رسالة الأمر)
 *   2) يغيّر اسم المجموعة للاسم الجديد
 *   3) يبعث فيديو الترحيب الدائري المحفوظ (نفس فيديو .تست)
 *
 * ⚠️ ملاحظة صريحة: الخطوة الرابعة المطلوبة أصلًا ("طرد الكل دفعة وحدة")
 * ما انبنت عمدًا — تفريغ مجموعة من كل أعضائها دفعة وحدة فيه احتمال ضرر
 * كبير لأشخاص فعليين بضغطة وحدة بدون رجعة. راجع رد المحادثة للتفصيل.
 */
const command: Command = {
  name: "فنشهم",
  category: "المطور",
  description: "يغيّر صورة واسم المجموعة ويبعث فيديو الترحيب — لصاحب البوت فقط (رد على صورة بنفس رسالة الأمر)",
  permission: "owner",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const senderDigits = digitsOnly(ctx.senderJid);
    const primaryOwners = [CONFIG.OWNER_NUMBER, CONFIG.OWNER_NUMBER_2, CONFIG.OWNER_NUMBER_3].filter(Boolean).map(digitsOnly);
    if (!primaryOwners.includes(senderDigits)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "🚫 هذا الأمر لصاحب البوت فقط." }, { quoted: ctx.msg });
      return;
    }

    const NEW_NAME = "『 𝑩𝑶𝑶𝑫𝒀┆ 🌑 ┆𝒀𝑼𝑴𝑹』";

    try {
      // 1) الصورة (لو فيه رد على صورة بنفس الرسالة)
      if (ctx.quoted?.imageMessage) {
        const source = buildQuotedMessage(ctx.msg) ?? ({ message: ctx.quoted, key: ctx.msg.key } as any);
        const buffer = (await downloadMediaMessage(source, "buffer", {}, {
          logger: logger as any,
          reuploadRequest: ctx.sock.updateMediaMessage,
        })) as Buffer;
        await ctx.sock.updateProfilePicture(ctx.chatId, buffer);
      }

      // 2) الاسم
      await ctx.sock.groupUpdateSubject(ctx.chatId, NEW_NAME);

      // 3) فيديو الترحيب (نفس مصدر .تست)
      const st = await getPtvStatus();
      if (!("error" in st)) {
        await ctx.sock.sendMessage(ctx.chatId, { video: st.buffer, ptv: true } as any);
      }

      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          `✅ تم:\n` +
          `${ctx.quoted?.imageMessage ? "🖼️ الصورة\n" : "⏭️ ما فيه صورة بالرد، تخطّيناها\n"}` +
          `📝 الاسم → ${NEW_NAME}\n` +
          `${"error" in st ? "⏭️ ما فيه فيديو ترحيب محفوظ، تخطّيناه\n" : "🎬 الفيديو\n"}` +
          `\n⚠️ خطوة طرد كل الأعضاء ما اتنفذت (متوقفة عمدًا — راجع المحادثة).`,
      });
    } catch (err) {
      logger.error("فشل أمر .فنشهم:", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `❌ صار خطأ أثناء التنفيذ: ${err instanceof Error ? err.message : String(err)}`,
      });
    }
  },
};

export default command;
