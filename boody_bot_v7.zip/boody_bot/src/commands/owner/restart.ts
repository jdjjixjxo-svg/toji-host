import { Command } from "../../handlers/types";

const command: Command = {
  name: "اعادة_تشغيل",
  aliases: ["restart", "إعادة_تشغيل"],
  category: "المطور",
  description: "إعادة تشغيل البوت",
  permission: "owner",
  execute: async (ctx) => {
    await ctx.sock.sendMessage(ctx.chatId, { text: "🔄 جاري إعادة تشغيل البوت..." });
    // ملاحظة: على Katabump/PM2 يُفضّل أن تكون العملية تحت مدير عمليات يعيد تشغيلها تلقائيًا
    process.exit(0);
  },
};

export default command;
