import { Command } from "../../handlers/types";
import { setGroupSetting } from "../../database/db";

/**
 * 🆕 يعطّل أمر ".تنصيب" بهذي المجموعة تحديدًا فقط. راجع enableInstall.ts.
 */
const command: Command = {
  name: "تعطيل_تنصيب",
  category: "المطور",
  description: "يعطّل أمر .تنصيب داخل هذه المجموعة تحديدًا",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    setGroupSetting(ctx.chatId, "installEnabled", false);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "🚫 تم تعطيل أمر .تنصيب بهذه المجموعة." },
      { quoted: ctx.msg }
    );
  },
};

export default command;
