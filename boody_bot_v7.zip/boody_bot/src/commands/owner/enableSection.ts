import { Command } from "../../handlers/types";
import { setSectionDisabled, isSectionDisabled } from "../../database/db";
import { resolveSectionName, ALL_SECTIONS, PROTECTED_SECTION } from "../../utils/sections";

/**
 * 🆕 .تفعيل <القسم> — عكس .تعطيل بالضبط: يعيد تشغيل قسم أوقفه المطور
 * سابقًا. نفس صلاحية .تعطيل (owner فقط: المطور + رقم البوت نفسه).
 *
 * ⚠️ ملاحظة: هذا الاسم ".تفعيل" كان سابقًا اسمًا بديلًا (alias) لأمر
 * .تشغيل (تشغيل/إيقاف البوت داخل مجموعة معينة — src/commands/owner/enable.ts).
 * تم نقله لهذا الأمر الجديد بناءً على طلب صريح، وأمر .تشغيل بقى يعمل
 * بنفس وظيفته القديمة عبر اسمه الأساسي ".تشغيل" (أو ".on").
 */
const command: Command = {
  name: "تفعيل",
  aliases: ["تفعيل_قسم", "enable_section", "on_section"],
  category: "المطور",
  description: "يعيد تشغيل قسم أوقفه المطور بأمر .تعطيل. مثال: .تفعيل ترفيه",
  permission: "owner",
  execute: async (ctx) => {
    const raw = ctx.text.trim();
    if (!raw) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ اكتب اسم القسم اللي تبي تفعله.\nمثال: .تفعيل ترفيه\n\n` +
            `📋 الأقسام المتاحة: ${ALL_SECTIONS.filter((s) => s !== PROTECTED_SECTION).join(" / ")}`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const section = resolveSectionName(raw);
    if (!section) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `❌ ما قدرت أتعرف على قسم اسمه "${raw}".\n\n` +
            `📋 الأقسام المتاحة: ${ALL_SECTIONS.filter((s) => s !== PROTECTED_SECTION).join(" / ")}`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    if (!isSectionDisabled(section)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `✅ قسم *${section}* مفعّل ويعمل بشكل طبيعي أصلًا.` },
        { quoted: ctx.msg }
      );
      return;
    }

    setSectionDisabled(section, false);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `✅ تم تفعيل قسم *${section}* بنجاح، رجعت كل أوامره تشتغل عادي بكل المجموعات.` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
