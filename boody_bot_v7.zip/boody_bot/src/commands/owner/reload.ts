import { Command } from "../../handlers/types";
import path from "path";
import { commandRegistry } from "../../handlers/commandRegistry";

const command: Command = {
  name: "تحديث",
  aliases: ["reload"],
  category: "المطور",
  description: "إعادة تحميل الأوامر بدون إعادة تشغيل كاملة للبوت",
  permission: "owner",
  execute: async (ctx) => {
    const before = commandRegistry.count();
    commandRegistry.clear();
    commandRegistry.loadAll(path.join(__dirname, "..")); // مجلد commands بالكامل
    const after = commandRegistry.count();

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🔄 تم تحديث الأوامر بنجاح.\nقبل: ${before} | بعد: ${after}`,
    });
  },
};

export default command;
