import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention } from "../../utils/helpers";
import { pickRandom } from "../../utils/fun";

/**
 * 🆕 .كسر — أمر تنمّر أقوى من .روست العادي، خاص بالمطور الرئيسي فقط
 * (طلب صريح). يعمل بمنشن أو رد على رسالة الشخص، نفس أسلوب .روست
 * بالضبط بس بجرعة أقوى.
 */
const LINES: string[] = [
  "{mention} حتى الفشل تعب منه وطلب نقل 😂💀",
  "{mention} لو الغباء مسابقة، كان اعتزل عشان يعطي غيره فرصة 🏆😂",
  "{mention} نسخة مسودة ما حد راجعها قبل ما تنشر 📄💀",
  "{mention} كل ما يفتح فمه، يثبت النظرية من جديد 🎤😂",
  "{mention} حتى غوغل تعب يدور له جواب 🔍💀",
  "{mention} شخص لو طلع من الكروب محد يلاحظ، ولو رجع نفس الشي 👋😂",
  "{mention} إنجازه الوحيد إنه لسا صامد لهسا 🏅💀",
  "{mention} لو فيه كأس عالمي للتفاهة، كان رفع الكأس بثقة 🏆😂",
];

const command: Command = {
  name: "كسر",
  category: "المطور",
  description: "تنمّر أقوى (منشن أو رد) — للمطور الرئيسي فقط",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ منشن الشخص أو رد على رسالته.\nمثال: .كسر @شخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    const line = pickRandom(LINES).replace("{mention}", jidToMention(target));
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: line, mentions: [target] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
