import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "رقيني",
  aliases: ["ترقيني", "رقني"],
  category: "المطور",
  description: "يرقّي المطور نفسه لمشرف بالمجموعة مباشرة (يتطلب أن يكون البوت مشرفًا)",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    try {
      await ctx.sock.groupParticipantsUpdate(ctx.chatId, [ctx.senderJid], "promote");
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `👑 تم ترقية ${jidToMention(ctx.senderJid)} إلى مشرف.`, mentions: [ctx.senderJid] },
        { quoted: ctx.msg }
      );
    } catch (err) {
      logger.error("فشل أمر .رقيني:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `❌ فشلت الترقية. السبب الفعلي: ${err instanceof Error ? err.message : String(err)}` },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
