import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, getBotScopeId } from "../../utils/helpers";
import { revokeGlobalVirtualAdmin } from "../../database/db";

/** 🆕 .تنزيل_مالك — يسحب صلاحية "الأدمن الوهمي العام" اللي أعطاها .رفع_مالك. */
const command: Command = {
  name: "تنزيل_مالك",
  aliases: ["تنزيل_مالك_وهمي"],
  category: "المطور",
  description: "يسحب صلاحية أوامر المشرفين العامة اللي أعطاها .رفع_مالك. للمطور فقط.",
  permission: "owner",
  requireBotAdmin: false,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);

    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ منشن الشخص أو رد على رسالته! مثال: .تنزيل_مالك @شخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    revokeGlobalVirtualAdmin(getBotScopeId(ctx.sock), target);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `⬇️ تم سحب صلاحية "الأدمن الوهمي العام" من ${jidToMention(target)}.`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
