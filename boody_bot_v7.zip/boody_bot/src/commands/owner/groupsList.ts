import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";

/**
 * .كروبات — للمطور فقط، بالخاص فقط. يعرض كل المجموعات اللي هذا البوت
 * (اللي كُتب فيه الأمر بالذات — رئيسي أو فرعي، كل واحد يعرض مجموعاته
 * هو فقط) عضو فيها حاليًا، مع رابط كل مجموعة لو أمكن.
 *
 * ⚠️ صراحة: رابط الدعوة (groupInviteCode) يتطلب أن يكون البوت أدمن
 * بتلك المجموعة تحديدًا — لو مو أدمن، نعرض المجموعة بدون رابط بدل ما
 * نفشل الأمر كله.
 */
const command: Command = {
  name: "كروبات",
  aliases: ["مجموعاتي", "groups"],
  category: "المطور",
  description: "يعرض كل المجموعات اللي البوت فيها + روابطها (للمطور، بالخاص فقط)",
  permission: "owner",
  groupOnly: false,
  execute: async (ctx) => {
    if (ctx.isGroup) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ هذا الأمر يعمل بالخاص فقط.",
      });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: "⏳ يجمع قائمة المجموعات..." });

    try {
      const groups = await ctx.sock.groupFetchAllParticipating();
      const entries = Object.values(groups);

      if (!entries.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "📭 هذا البوت مو عضو بأي مجموعة حاليًا." });
        return;
      }

      const lines: string[] = [];
      let index = 1;
      for (const g of entries) {
        let link = "— (البوت مو أدمن، ما قدر يجيب رابط)";
        try {
          const code = await ctx.sock.groupInviteCode(g.id);
          if (code) link = `🔗 https://chat.whatsapp.com/${code}`;
        } catch {
          /* البوت مو أدمن بهذي المجموعة — نعرضها بدون رابط بدل ما نفشل الكل */
        }
        lines.push(`${index}. *${g.subject || "(بدون اسم)"}*\n${link}`);
        index++;
      }

      // 🔧 رسائل واتساب لها حد أقصى لطول النص — لو عدد المجموعات كبير
      // جدًا، نقسّمها لأكثر من رسالة بدل ما تفشل الرسالة كلها بصمت.
      const chunks: string[] = [];
      let current = "";
      for (const line of lines) {
        if ((current + "\n\n" + line).length > 3500) {
          chunks.push(current);
          current = line;
        } else {
          current = current ? `${current}\n\n${line}` : line;
        }
      }
      if (current) chunks.push(current);

      for (const chunk of chunks) {
        await ctx.sock.sendMessage(ctx.chatId, { text: chunk });
      }
    } catch (err) {
      logger.error("فشل أمر .كروبات:", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ فشل جلب قائمة المجموعات. جرّب مرة ثانية بعد شوي.",
      });
    }
  },
};

export default command;
