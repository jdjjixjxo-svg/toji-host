import { Command } from "../../handlers/types";
import path from "path";
import fs from "fs-extra";

const command: Command = {
  name: "نسخ_احتياطي",
  aliases: ["backup"],
  category: "المطور",
  description: "إرسال نسخة احتياطية من قاعدة بيانات البوت",
  permission: "owner",
  execute: async (ctx) => {
    const dbPath = path.resolve(process.cwd(), "database", "db.json");
    if (!(await fs.pathExists(dbPath))) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ لا توجد بيانات لعمل نسخة احتياطية بعد." });
      return;
    }

    const buffer = await fs.readFile(dbPath);
    // 🔧 إصلاح (سبب "الملف يوصل بس ما يفتح"): كنا نرسله بامتداد .json —
    // أغلب الهواتف ما عندها تطبيق افتراضي مرتبط بامتداد json فما يفتح
    // عند الضغط عليه رغم وصوله كامل وسليم. الحل: نفس المحتوى بالضبط، بس
    // بامتداد .txt (يفتحه أي هاتف بمفكرة/متصفح افتراضيًا بدون أي تطبيق إضافي).
    await ctx.sock.sendMessage(ctx.chatId, {
      document: buffer,
      mimetype: "text/plain",
      fileName: `backup-${Date.now()}.txt`,
      caption: "📦 نسخة احتياطية من قاعدة البيانات (بصيغة JSON داخل ملف نصي .txt حتى يفتح على أي جهاز).",
    });
  },
};

export default command;
