import { Command } from "../../handlers/types";
import { setBotEnabledInGroup } from "../../database/db";
import { getBotScopeId } from "../../utils/helpers";

const command: Command = {
  name: "تشغيل",
  // 🔧 إصلاح تعارض أسماء: "تفعيل" كانت اسمًا بديلًا لهذا الأمر (تشغيل
  // البوت بمجموعة معينة)، لكنها الآن أمر مستقل بالكامل (تفعيل *قسم*
  // أوامر موقوف — راجع src/commands/owner/enableSection.ts) بناءً على
  // طلب صريح. أزلناها من هنا لتفادي التعارض؛ هذا الأمر يبقى شغّال
  // بنفس وظيفته القديمة عبر ".تشغيل" أو ".on".
  aliases: ["on"],
  category: "المطور",
  description: "يشغّل هذا البوت (بالذات) داخل هذه المجموعة (بعد إيقافه بـ .ايقاف)",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 نفس إصلاح disable.ts — يشغّل بوته هو بالذات فقط.
    setBotEnabledInGroup(ctx.chatId, getBotScopeId(ctx.sock), true);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "✅ تم تشغيل هذا البوت بهذه المجموعة." },
      { quoted: ctx.msg }
    );
  },
};

export default command;
