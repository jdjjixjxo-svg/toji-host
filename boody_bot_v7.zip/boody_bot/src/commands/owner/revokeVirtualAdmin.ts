import { Command } from "../../handlers/types";
import { getTargetJid, jidToMention, getBotScopeId } from "../../utils/helpers";
import { revokeVirtualAdmin } from "../../database/db";
import { isOwner } from "../../middlewares/permissions";
import { logger } from "../../utils/logger";
import { updateParticipant, isBotAdminLive } from "../../utils/groupAdmin";

/** .تنزيل_ادمن (تُكتب أيضًا «.تنزيل ادمن» بمسافة) — عكس .رفع_ادمن: يسحب الصلاحيتين. */
const command: Command = {
  name: "تنزيل_ادمن",
  aliases: ["تنزيل_ادمن_وهمي", "تنزيل_مشرف"],
  category: "مشرفين",
  description: "ينزّل الأدمن: يسحب ترقية واتساب (لو البوت مشرف) + صلاحية أوامر المشرفين داخل البوت.",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: false,
  allowVirtualAdmin: false,
  execute: async (ctx) => {
    const target = getTargetJid(ctx.msg, ctx.metadata);
    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "✏️ حدّد الشخص: منشنه أو رد على رسالته.\nمثال: .تنزيل ادمن @الشخص" },
        { quoted: ctx.msg }
      );
      return;
    }

    const owner = isOwner(ctx.senderJid, ctx.metadata || undefined, ctx.sock);
    const lines: string[] = [];

    if (owner) {
      revokeVirtualAdmin(getBotScopeId(ctx.sock), ctx.chatId, target);
      lines.push("✅ انسحبت منه صلاحية أوامر المشرفين داخل البوت.");
    }

    const res = await updateParticipant(ctx.sock, ctx.chatId, "demote", target, ctx.metadata);
    const realOk = res.ok;
    if (res.ok) lines.push("✅ تم تنزيله من الإشراف بواتساب.");
    else {
      const botAdmin = await isBotAdminLive(ctx.sock, ctx.chatId);
      logger.warn(`تعذر التنزيل الحقيقي (status=${res.status}): ${res.reason}`);
      const why = botAdmin === false ? "البوت نفسه مو مشرف بهذي المجموعة" : res.reason;
      lines.push(owner ? `ℹ️ ما تم التنزيل بواتساب: ${why}` : `❌ فشل التنزيل: ${why}`);
    }

    const head = owner || realOk ? `⬇️ *تنزيل أدمن* — ${jidToMention(target)}` : `⚠️ *تنزيل أدمن* — ${jidToMention(target)}`;
    await ctx.sock.sendMessage(ctx.chatId, { text: `${head}\n\n${lines.join("\n")}`, mentions: [target] }, { quoted: ctx.msg });
  },
};

export default command;
