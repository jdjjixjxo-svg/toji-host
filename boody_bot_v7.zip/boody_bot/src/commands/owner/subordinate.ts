import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { digitsOnly } from "../../utils/helpers";
import { getBotSelfNumber } from "../../utils/botIdentity";
import { getInstalledSubBotNumbers } from "../../handlers/subBotManager";
import { setBotEnabledInGroup, isBotEnabledInGroup } from "../../database/db";

/**
 * 🆕 (طلب صريح: ".اخضاع" — للمطورين الرئيسيين الـ2 فقط، لا للبوتات
 * الفرعية) — يوقف كل البوتات الفرعية المنصّبة *داخل هذه المجموعة بالذات
 * فقط* (ما يلمس أي مجموعة ثانية ولا البوت الرئيسي).
 *
 * ⚠️ عمدًا permission هنا "owner" لكن بفحص إضافي أشد يدويًا بالأسفل:
 * بعد التحديث الأخير (راجع developerIdentity.ts) أي رقم نصّب بوت فرعي
 * صار "مطورًا" لأغراض عامة — لكن هذا الأمر بالذات يستثنيهم عمدًا ويقبل
 * فقط CONFIG.OWNER_NUMBER / OWNER_NUMBER_2 الحقيقيين، بالضبط زي ما طُلب
 * ("فقط للمطورين الرئيسيين... مش كل بوت فرعي").
 *
 * .اخضاع            → يوقف كل البوتات الفرعية بهذه المجموعة
 * .اخضاع تشغيل      → يرجّعهم كلهم شغّالين بهذه المجموعة
 */
const command: Command = {
  name: "اخضاع",
  aliases: ["اخضاع_البوتات"],
  category: "المطور",
  description: "يوقف/يشغّل كل البوتات الفرعية بهذه المجموعة فقط (للمطورين الرئيسيين حصرًا)",
  permission: "owner",
  groupOnly: true,
  execute: async (ctx) => {
    const senderDigits = digitsOnly(ctx.senderJid);
    const primaryOwners = [CONFIG.OWNER_NUMBER, CONFIG.OWNER_NUMBER_2, CONFIG.OWNER_NUMBER_3].filter(Boolean).map(digitsOnly);
    if (!primaryOwners.includes(senderDigits)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "🚫 هذا الأمر للمطورين الرئيسيين فقط، حتى لو عندك بوت فرعي منصّب." },
        { quoted: ctx.msg }
      );
      return;
    }

    const mainBotNumber = getBotSelfNumber();
    const subBotNumbers = getInstalledSubBotNumbers().filter((n) => n !== mainBotNumber);

    if (!subBotNumbers.length) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "ℹ️ ما فيه بوتات فرعية منصّبة أصلًا." }, { quoted: ctx.msg });
      return;
    }

    const turnOn = ctx.args[0] === "تشغيل" || ctx.args[0] === "رجع";
    for (const num of subBotNumbers) {
      setBotEnabledInGroup(ctx.chatId, num, turnOn);
    }

    const stillOn = subBotNumbers.filter((n) => isBotEnabledInGroup(ctx.chatId, n));
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: turnOn
          ? `✅ رجّعت تشغيل ${subBotNumbers.length} بوت فرعي بهذه المجموعة.`
          : `🚫 أوقفت ${subBotNumbers.length - stillOn.length}/${subBotNumbers.length} بوت فرعي بهذه المجموعة (البوت الرئيسي غير متأثر).\n\n.اخضاع تشغيل — لإرجاعهم كلهم هنا.`,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
