import fs from "fs";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { commandRegistry } from "../../handlers/commandRegistry";
import { db } from "../../database/db";
import { isBotAdmin } from "../../middlewares/permissions";
import { bold, digitsOnly } from "../../utils/helpers";
import { MENU_VIDEO_PATH } from "../../utils/media";
import { getBotSelfNumber, getOwnerLid } from "../../utils/botIdentity";

const command: Command = {
  name: "تشخيص",
  aliases: ["diag", "حالة"],
  category: "المطور",
  description: "تقرير سريع لتشخيص سبب توقف الأوامر (خاص بالمطور)",
  permission: "owner",
  execute: async (ctx) => {
    const publicMode = db.get("bot.publicMode").value();
    const botAdmin =
      ctx.isGroup && ctx.metadata
        ? isBotAdmin(ctx.metadata, ctx.sock.user?.id || "")
        : null;
    const uptimeMin = Math.floor(process.uptime() / 60);

    const lines = [
      `🩺 ${bold("تشخيص " + CONFIG.BOT_NAME)}`,
      `━━━━━━━━━━━━━━━`,
      `📜 عدد الأوامر المحمّلة: ${commandRegistry.count()}`,
      `🌐 الوضع العام (publicMode): ${publicMode ? "مفعّل ✅ (يرد على الجميع)" : "معطّل ⚠️ (يرد على المالك بس)"}`,
      ctx.isGroup
        ? `👮 البوت مشرف بهالكروب: ${botAdmin ? "نعم ✅" : "غير مؤكد ⚠️ (قد يكون مشرف فعليًا، الفحص المحلي غير دقيق 100% بسبب خصوصية lid)"}`
        : `👮 البوت مشرف: (خارج كروب، تجاهل)`,
      `⏱️ مدة التشغيل من آخر إقلاع: ${uptimeMin} دقيقة`,
      `🎬 فيديو المنيو موجود: ${fs.existsSync(MENU_VIDEO_PATH) ? "نعم ✅" : "لا ❌ (تحقق من assets/menu.mp4)"}`,
      `🔑 SELF_COMMANDS: ${CONFIG.SELF_COMMANDS ? "مفعّل" : "معطّل"}`,
      `━━━━━━━━━━━━━━━`,
      // 🆕 (v1.1.4) الهويتان مستقلتان تمامًا الآن — كل منهما مطور بكامل
      // الصلاحيات بغض النظر عن تطابقهما. هذا السطر يساعدك تتأكد إنهما
      // مسجّلتين صح بعد أي عملية ربط جديدة للبوت.
      `👤 رقم البوت الحالي (مطور تلقائيًا): ${getBotSelfNumber() || "غير معروف بعد"}`,
      `👑 رقم المالك (من .env): ${digitsOnly(CONFIG.OWNER_NUMBER) || "غير محدد"}`,
      `🪪 lid المالك المكتشف: ${getOwnerLid() || "لسا ما انحل (طبيعي لو الحساب مو مفعّل عليه خصوصية lid)"}`,
    ];

    // ⚠️ لو publicMode معطّل أو البوت مو مشرف، هذا أكثر سبب شائع لـ"الأوامر ما ترد"
    if (!publicMode) {
      lines.push(
        "",
        `💡 لو تبي البوت يرد على الجميع مو بس أنت، فعّل الوضع العام بأمر: ${CONFIG.PREFIX}وضع_عام`
      );
    }
    if (ctx.isGroup && botAdmin === false) {
      lines.push(
        "",
        "💡 لو أوامر الإدارة (طرد/كتم/نذار...) فعليًا ما تشتغل: ارفع البوت مشرف بهالكروب. لو هو مشرف فعليًا وطلعت هذي الرسالة غلط، تجاهلها — نفس الفحص هذا بس تقريبي."
      );
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: lines.join("\n") }, { quoted: ctx.msg });
  },
};

export default command;
