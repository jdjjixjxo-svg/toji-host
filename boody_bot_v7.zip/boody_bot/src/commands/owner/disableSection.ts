import { Command } from "../../handlers/types";
import { setSectionDisabled, isSectionDisabled } from "../../database/db";
import { resolveSectionName, PROTECTED_SECTION, ALL_SECTIONS } from "../../utils/sections";

/**
 * 🆕 .تعطيل <القسم> — يوقف قسم كامل من الأوامر عبر كل البوت (كل
 * المجموعات + الخاص) بأمر واحد فقط، مخصص لرقم المطور ورقم البوت نفسه
 * (permission: "owner" — يشمل الاثنين تلقائيًا، راجع isOwner بملف
 * middlewares/permissions.ts). القسم الموقوف: لا يعمل أي أمر منه لأي
 * أحد (حتى فتح قائمة القسم نفسها)، ويُرفض برسالة واضحة — راجع الفحص
 * بـ handlers/messageHandler.ts. المطور/رقم البوت نفسهما يبقيان
 * معفيّين من هذا الإيقاف حتى يقدروا يجربوا القسم قبل ما يعيدوا تفعيله.
 */
const command: Command = {
  name: "تعطيل",
  aliases: ["تعطيل_قسم", "disable_section", "off_section"],
  category: "المطور",
  description: "يوقف قسم أوامر كامل عن العمل بكل البوت. مثال: .تعطيل ترفيه",
  permission: "owner",
  execute: async (ctx) => {
    const raw = ctx.text.trim();
    if (!raw) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ اكتب اسم القسم اللي تبي توقفه.\nمثال: .تعطيل ترفيه\n\n` +
            `📋 الأقسام المتاحة: ${ALL_SECTIONS.filter((s) => s !== PROTECTED_SECTION).join(" / ")}`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const section = resolveSectionName(raw);
    if (!section) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `❌ ما قدرت أتعرف على قسم اسمه "${raw}".\n\n` +
            `📋 الأقسام المتاحة: ${ALL_SECTIONS.filter((s) => s !== PROTECTED_SECTION).join(" / ")}`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    if (section === PROTECTED_SECTION) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "🔒 لا يمكن تعطيل قسم المطور نفسه (فيه أوامر التحكم بالأقسام)." },
        { quoted: ctx.msg }
      );
      return;
    }

    if (isSectionDisabled(section)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `⚠️ قسم *${section}* معطّل بالفعل.` },
        { quoted: ctx.msg }
      );
      return;
    }

    setSectionDisabled(section, true);
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `🚫 تم تعطيل قسم *${section}* بنجاح.\nكل أوامره (وحتى قائمة القسم نفسها) متوقفة الآن بكل المجموعات، إلا لرقم المطور/رقم البوت.\nلإعادة تفعيله: .تفعيل ${section}`,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
