import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { FOOTER_DIVIDER } from "../../utils/theme";
import { getSectionImageBuffer } from "../../utils/media";
import { isOwner } from "../../middlewares/permissions";

const command: Command = {
  name: "المطور",
  aliases: ["owner", "دولير", "مطور", "مطوري"],
  category: "المطور",
  description: "عرض بطاقة معلومات مطور البوت",
  permission: "all",
  execute: async (ctx) => {
    // 🔧 (طلب صريح) لا نرسل بطاقة جهة اتصال (vcard) إطلاقًا — إرسال جهات اتصال
    // لأرقام غير محفوظة يعرّض رقم البوت للحظر. نعرض المعلومات كنص فقط.
    const text =
      `ـ⌬┋ *بطاقة المطور*\n` +
      `ـ⌬┋ الاسم ﹘ ${CONFIG.OWNER_NAME}\n` +
      `ـ⌬┋ البوت ﹘ 『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』\n\n` +
      `ـ⌬┋ للتواصل مع المطورين اكتب: ${CONFIG.PREFIX}تواصل`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("developer") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });

    // قائمة أوامر المطور المرتبة — تظهر للمطور بس، حتى ما تنكشف لبقية الأعضاء
    if (isOwner(ctx.senderJid, ctx.metadata || undefined)) {
      const ownerCommandsText =
        `${FOOTER_DIVIDER}\n      🔐 *أوامر المطور* 🔐\n${FOOTER_DIVIDER}\n\n` +
        `📢 *تحكم عام:*\n` +
        `  ${CONFIG.PREFIX}اذاعة <نص> — رسالة لكل المجموعات\n` +
        `  ${CONFIG.PREFIX}وضع_عام — البوت يستجيب للجميع\n` +
        `  ${CONFIG.PREFIX}وضع_خاص — البوت يستجيب للمالك فقط\n\n` +
        `${FOOTER_DIVIDER}\n\n` +
        `🎛️ *تحكم بمجموعة محددة:*\n` +
        `  ${CONFIG.PREFIX}تشغيل — يشغّل البوت بهذي المجموعة\n` +
        `  ${CONFIG.PREFIX}ايقاف — يوقف البوت بهذي المجموعة\n` +
        `  ${CONFIG.PREFIX}رقيني — يرقّيك مشرف مباشرة\n\n` +
        `${FOOTER_DIVIDER}\n\n` +
        `🛠️ *صيانة البوت:*\n` +
        `  ${CONFIG.PREFIX}تشخيص — تقرير أسباب توقف الأوامر\n` +
        `  ${CONFIG.PREFIX}تحديث — إعادة تحميل الأوامر بدون ريستارت\n` +
        `  ${CONFIG.PREFIX}اعادة_تشغيل — إعادة تشغيل البوت بالكامل\n` +
        `  ${CONFIG.PREFIX}نسخ_احتياطي — نسخة احتياطية من قاعدة البيانات\n\n` +
        `${FOOTER_DIVIDER}`;

      await ctx.sock.sendMessage(ctx.chatId, { text: ownerCommandsText }, { quoted: ctx.msg });
    }
  },
};

export default command;
