import { Command } from "../../handlers/types";
import sharp from "sharp";

const SVG = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <text x="256" y="260" font-size="180" text-anchor="middle">🤫</text>
  <text x="256" y="400" font-size="48" fill="#2c3e50" text-anchor="middle" font-family="sans-serif" font-weight="bold">اسكت!</text>
</svg>`;

const command: Command = {
  name: "اسكت",
  category: "اوامر_جانبيه",
  description: "ملصق اسكت كرد على رسالة",
  permission: "all",
  execute: async (ctx) => {
    const webp = await sharp(Buffer.from(SVG)).resize(512, 512).webp().toBuffer();
    await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
  },
};

export default command;
