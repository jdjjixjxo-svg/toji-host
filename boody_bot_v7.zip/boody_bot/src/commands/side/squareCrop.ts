import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

// 🔧 الأصل كان يستدعي ffmpeg عبر exec() بأمر shell (خطر حقن أوامر لو
// دخلت أي قيمة غير متوقعة بالمسار). استبدلناها بـsharp (نفس مكتبة .ملصق
// الموجودة أصلًا، بدون أي shell على الإطلاق).
const command: Command = {
  name: "مربع",
  category: "اوامر_جانبيه",
  description: "يقص صورة لشكل مربع. رد بها على صورة مع الأمر",
  permission: "all",
  execute: async (ctx) => {
    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    if (!imageMsg) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رد بهذا الأمر على صورة." }, { quoted: ctx.msg });
      return;
    }

    try {
      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const metadata = await sharp(buffer).metadata();
      const size = Math.min(metadata.width || 512, metadata.height || 512);
      const squared = await sharp(buffer)
        .resize(size, size, { fit: "cover", position: "center" })
        .jpeg()
        .toBuffer();

      await ctx.sock.sendMessage(ctx.chatId, { image: squared, caption: "⬛ تم القص لمربع" }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر مربع:", err);
      await notifyOwnerOfError(ctx.sock, ".مربع", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل قص الصورة." }, { quoted: ctx.msg });
    }
  },
};

export default command;
