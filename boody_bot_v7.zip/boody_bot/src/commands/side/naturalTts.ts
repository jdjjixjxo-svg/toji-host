import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

// 🔧 تكملة لأمر .صوت الموجود أصلًا (Google Translate TTS مجاني بس صوته
// آلي وروبوتي). هذا أمر إضافي بصوت طبيعي أقرب للبشري (ElevenLabs)،
// يحتاج مفتاح — لو ما فيه مفتاح، يقترح يستخدم .صوت المجاني بدله.
const DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"; // "Rachel" الصوت الافتراضي بـElevenLabs

const command: Command = {
  name: "قول",
  category: "اوامر_جانبيه",
  description: "يحوّل نص لصوت طبيعي ويرسله كبصمة صوتية (PTT). مثال: .قول مرحبا",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim();
    if (!text) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب النص بعد الأمر. مثال: .قول مرحبا كيف حالك" }, { quoted: ctx.msg });
      return;
    }

    if (!CONFIG.ELEVENLABS_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          "❌ هذا الأمر يحتاج مفتاح بملف .env (ELEVENLABS_API_KEY) لصوت طبيعي.\n" +
          "خذ مفتاح من: https://elevenlabs.io → Profile → API Keys\n\n" +
          "💡 بالانتظار، جرّب أمر .صوت (نفس الفكرة بصوت آلي مجاني بالكامل).",
      });
      return;
    }

    try {
      const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${DEFAULT_VOICE_ID}`, {
        method: "POST",
        headers: {
          "xi-api-key": CONFIG.ELEVENLABS_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text.slice(0, 500),
          model_id: "eleven_multilingual_v2",
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`ELEVENLABS_${res.status}: ${errText.slice(0, 200)}`);
      }

      const buffer = Buffer.from(await res.arrayBuffer());
      await ctx.sock.sendMessage(ctx.chatId, {
        audio: buffer,
        mimetype: "audio/mpeg",
        ptt: true,
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر قول:", err);
      await notifyOwnerOfError(ctx.sock, ".قول", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل توليد الصوت. تأكد إن المفتاح صحيح وله رصيد." }, { quoted: ctx.msg });
    }
  },
};

export default command;
