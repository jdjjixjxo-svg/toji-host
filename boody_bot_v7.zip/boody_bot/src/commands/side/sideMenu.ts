import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";
import { getMenuVideoBuffer, getSectionImageBuffer } from "../../utils/media";
import { jidToMention } from "../../utils/helpers";
import { SIDE_EXTRA_ROWS } from "../../utils/menuRows";

/**
 * 🆕 (طلب صريح) قسم "اوامر جانبيه" — أوامر مستوردة من ملف خارجي جهّزه
 * صاحب البوت، أُعيدت كتابتها بالكامل (مو نسخ-لصق) لأنها كانت بـ3 أطر
 * عمل مختلفة تمامًا عن معمارية هذا المشروع. راجع رسالة الرد الكاملة
 * لتفاصيل أي أوامر استُبعدت والسبب (تكرار/غير آمن/يحتاج ملف ناقص).
 */
const command: Command = {
  name: "اوامر_جانبيه",
  aliases: ["جانبيه", "sidecommands"],
  category: "اوامر_جانبيه",
  description: "قسم الأوامر الجانبية المستوردة",
  permission: "all",
  execute: async (ctx) => {
    const groupName = ctx.metadata?.subject || "خاص";
    const userMention = jidToMention(ctx.senderJid);

    const cardText = `ـ𐐘💥╾━╤デ╦︻ඞاـ
*${groupName}*
ـֶָِ. ..𓂃 ࣪ ֶָِ🪽་༘࿐ ( -_•))
*🫟اوامر جانبيه*
> *لم يتم تاكد من انها تعمل دون مشاكل بعد*
*ـ꧁ᬊᬁ『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』ᬊ᭄꧂ـ*
*\`↓آلَقۣۗہسۣۗہآمۣۗہ تۣۗہحۣۗہتۣۗہ↓\`*`;

    const rows = [
      { command: "ذكوره", label: "🧔 ذكوره" },
      { command: "تجديد", label: "🔗 تجديد لينك الكروب" },
      { command: "لينك", label: "🔗 لينك الكروب الحالي" },
      { command: "مثل", label: "🗣️ مثل شعبي" },
      { command: "شاتي", label: "💬 شاتي (رابط شات)" },
      { command: "شكوى", label: "📢 شكوى للمطورين" },
      { command: "سؤال_شخصي", label: "❓ سؤال شخصي عشوائي" },
      { command: "مؤقت", label: "⏳ مؤقت عد تنازلي" },
      { command: "صور", label: "🖼️ بحث عن صور" },
      { command: "زوجه", label: "💍 زوّج شخصين عشوائي" },
      { command: "معلومات", label: "📛 معلومات الكروب" },
      { command: "حكمه", label: "🖋️ بيت شعر حكمة" },
      { command: "غزل", label: "💖 بيت غزل" },
      { command: "لو_خيروك", label: "🤔 لو خيروك" },
      { command: "صراحه", label: "🗯️ سؤال صراحة" },
      { command: "فيديو", label: "📹 بحث فيديو يوتيوب" },
      { command: "شات قفل", label: "🔒 قفل/فتح الكروب مؤقتًا" },
      { command: "مضاد_الاشراف", label: "🛡️ مضاد الإشراف (تشغيل/إيقاف)" },
      { command: "مربع", label: "⬛ قص صورة لمربع" },
      { command: "قص", label: "✂️ قص نسبة من الصورة" },
      { command: "حقوق_ستكر", label: "©️ حقوق على ملصق" },
      { command: "روايه_قصيره", label: "📖 قصة قصيرة بالذكاء الاصطناعي" },
      { command: "تحداني", label: "🔥 تحداني (جرأة)" },
      { command: "بوابه", label: "🌀 بوابة الواقع الغامضة" },
      { command: "رتب", label: "🔤 رتب الحروف" },
      { command: "قلوب", label: "❤️ لعبة القلوب" },
      { command: "طقس", label: "🌤️ طقس مدينة" },
      { command: "هل", label: "🔮 هل...؟ (إجابة عشوائية)" },
      { command: "مين_اكثر", label: "👀 مين أكثر واحد..." },
      { command: "يشبهني", label: "🪞 يشبهني" },
      { command: "مهمة_اضف", label: "📌 أضف مهمة شخصية" },
      { command: "مهامي", label: "📋 مهامي" },
      { command: "طقس", label: "🌤️ طقس مدينة" },
      { command: "هل", label: "🔮 هل...؟" },
      { command: "مين_اكثر", label: "👀 مين أكثر واحد..." },
      { command: "يشبهني", label: "🪞 يشبهني" },
      { command: "تسجيل_لقب", label: "🏷️ تسجيل لقب" },
      { command: "اللقاب", label: "📋 كل الألقاب" },
      { command: "نرد", label: "🎲 نرد" },
      { command: "ايدي", label: "🆔 ايدي (JID)" },
      { command: "امر", label: "📊 إحصائية الأوامر" },
      { command: "لصورة", label: "🖼️ ملصق → صورة" },
      { command: "ترجم", label: "🌐 ترجم نص" },
      { command: "صفع", label: "👋 صفع" },
      { command: "اسكت", label: "🤫 اسكت" },
      { command: "المشنقة", label: "🪢 لعبة المشنقة" },
      { command: "ز1", label: "✨ زخرفة إنجليزي (11 نمط: ز1-ز11)" },
      { command: "رقم_سري", label: "🔢 رقم سري" },
      { command: "من_الاسرع", label: "⚡ من الأسرع" },
      { command: "ضد_الكلمة", label: "🔄 ضد الكلمة" },
      { command: "سباق_الشخصيات", label: "🏁 سباق الشخصيات" },
      { command: "مبارزة", label: "⚔️ مبارزة @شخص" },
      { command: "سلسلة", label: "🔗 سلسلة الحروف" },
      { command: "كلمة_السر", label: "🕵️ كلمة السر" },
      { command: "dino", label: "🦖 Dino Runner" },
      { command: "fps", label: "🪖 FPS War Zone" },
      { command: "race", label: "🏎️ Speed Rival (سباق)" },
      { command: "kuro", label: "🥷 KURO SLASH (قتال)" },
      { command: "ازالة_خلفية", label: "🖼️ إزالة خلفية (يحتاج مفتاح)" },
      { command: "تحسين", label: "📈 تحسين جودة الصورة (يحتاج مفتاح)" },
      { command: "قول", label: "🎙️ صوت طبيعي PTT (يحتاج مفتاح)" },
      { command: "tg_pack", label: "📦 حزمة ملصقات تليجرام (يحتاج مفتاح)" },
      { command: "ارسم", label: "🎨 رسم صورة بالذكاء الاصطناعي" },
      { command: "نانو", label: "🍌 تعديل صورة بالذكاء الاصطناعي" },
      { command: "مانجا", label: "📖 مانجا (PDF)" },
      { command: "مانهوا", label: "📖 مانهوا (PDF)" },
      { command: "سبوتيفاي", label: "🎵 سبوتيفاي/ساوند (أغنية)" },
      ...SIDE_EXTRA_ROWS,
    ];

    // 🆕 (طلب صريح: "زر لحاله + زر واحد يفتح قائمة الأوامر") زر القائمة
    const listButton = buildSingleSelectButton("📜 عرض الأوامر", "الأوامر الجانبية", rows);

    // 🆕 (طلب صريح: "زر المطورين") — نفس رابط الدعم المستخدم بزر
    // "🔱الــتــنــصــيــب🔱" بالمنيو الرئيسي (ما عندنا رابط منفصل مخصص
    // "للمطورين" بالإعدادات، فاستخدمنا نفس الرابط الوحيد المتوفر. لو عندك
    // رابط/رقم مطورين مختلف قولّي أضبطه بمكان مخصص بملف .env).
    const devButton = {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "👨‍💻 المطورين",
        url: CONFIG.SUPPORT_GROUP_LINK,
      }),
    };

    const videoBuffer = getMenuVideoBuffer();
    const image = videoBuffer ? undefined : getSectionImageBuffer("main");

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: cardText,
      mentions: [ctx.senderJid],
      video: videoBuffer || undefined,
      image: image || undefined,
      extraButtons: [listButton, devButton],
    });
  },
};

export default command;
