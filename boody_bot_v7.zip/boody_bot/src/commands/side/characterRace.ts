import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";

const CHARACTERS = [
  "مونكي دي لوفي", "ناروتو اوزوماكي", "ساسكي اوتشيها", "ايرين ييغر",
  "تانجيرو كامادو", "ايزوكو ميدوريا", "سايتاما", "غوكو", "ليفاي اكرمان",
  "كيلوا زولديك", "غون فريكس", "اش كيتشوم",
];

const command: Command = {
  name: "سباق_الشخصيات",
  category: "ترفيه",
  description: "سباق كتابة — اكتب اسم الشخصية بالظبط أول واحد يفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم" },
        { quoted: ctx.msg }
      );
      return;
    }

    const name = CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)];
    eventManager.start(ctx.sock as any, ctx.chatId, "سباق الشخصيات", name, 25_000);

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🏁 *سباق كتابة!*\n\nاكتبوا هذا الاسم بالظبط، أول واحد يكتبه صح يفوز:\n\n📝 *${name}*\n\n⏱️ 25 ثانية!`,
    });
  },
};

export default command;
