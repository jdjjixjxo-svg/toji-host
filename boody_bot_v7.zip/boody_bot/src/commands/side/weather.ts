import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";

// 🔧 (طلب صريح: "حط مكان الأيبي بملف .env مع رابط مباشر") — الأصل كان
// فيه مفتاح OpenWeatherMap شخصي لصاحب الملف مكتوب حرفيًا بالكود، ما
// نقدر نستخدمه (حساب غيرنا). الحين المفتاح يُقرأ من .env (WEATHER_API_KEY)
// — راجع التعليق جنبه بملف .env.example للرابط المباشر للتسجيل.
const command: Command = {
  name: "طقس",
  aliases: ["الطقس"],
  category: "اوامر_جانبيه",
  description: "حالة الطقس الحالية لأي مدينة. مثال: .طقس الرياض",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.WEATHER_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          "❌ هذا الأمر يحتاج مفتاح طقس بملف .env (WEATHER_API_KEY).\n" +
          "خذ مفتاح مجاني من: https://openweathermap.org/api",
      });
      return;
    }

    const city = ctx.text.trim();
    if (!city) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ اكتب اسم المدينة. مثال: .طقس الرياض" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
        city
      )}&units=metric&lang=ar&appid=${CONFIG.WEATHER_API_KEY}`;
      const res = await fetch(url);
      const data: any = await res.json();

      if (data.cod !== 200) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ ما لقيت مدينة بهذا الاسم: "${city}"` },
          { quoted: ctx.msg }
        );
        return;
      }

      const text =
        `🌤️ *طقس ${data.name}*\n\n` +
        `🌡️ الحرارة: ${Math.round(data.main.temp)}°م (تحس وكأنها ${Math.round(data.main.feels_like)}°م)\n` +
        `☁️ الحالة: ${data.weather[0]?.description || "-"}\n` +
        `💧 الرطوبة: ${data.main.humidity}%\n` +
        `💨 سرعة الرياح: ${data.wind.speed} م/ث`;

      await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء جلب الطقس." }, { quoted: ctx.msg });
    }
  },
};

export default command;
