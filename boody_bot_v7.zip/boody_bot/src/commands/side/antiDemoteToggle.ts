import { Command } from "../../handlers/types";
import { getGroupSettings, setGroupSetting } from "../../database/db";

// 🔧 (طلب صريح: أمر "مضاد الاشراف" من ملف خارجي) — الأصل كان مسجّل
// كمستمع أحداث منفصل بالكامل (conn.ev.on خاص فيه)، ورقم "المطور" المعفى
// من الحظر مكتوب حرفيًا بالكود (رقم حقيقي لشخص أجنبي — صاحب البوت
// الأصلي، مو صاحب بوتنا!). أعدنا بناءها: هذا الأمر يبدّل إعداد بقاعدة
// البيانات فقط، والمنطق الفعلي مدمج بالحدث المركزي الموجود أصلًا
// (src/events/groupParticipants.ts)، والمعفى الوحيد هو owner الحقيقي
// لهذا البوت (CONFIG.OWNER_JID عبر isOwner، نفس فحص بقية المشروع).
const command: Command = {
  name: "مضاد_الاشراف",
  category: "اوامر_جانبيه",
  description: "تشغيل/إيقاف تنزيل تلقائي لأي مشرف يسحب إشراف مشرف آخر",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const state = ctx.text.trim();
    if (state !== "فتح" && state !== "غلق") {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            "استخدم الأمر بهذا الشكل:\n\n" +
            "- .مضاد_الاشراف فتح (لتفعيل الحماية)\n" +
            "- .مضاد_الاشراف غلق (لإيقافها)",
        },
        { quoted: ctx.msg }
      );
      return;
    }

    const enabled = state === "فتح";
    setGroupSetting(ctx.chatId, "antiDemoteAbuse", enabled);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: enabled
          ? "✅ تم تفعيل مضاد الإشراف — أي مشرف يسحب إشراف مشرف ثاني سيُنزَّل تلقائيًا."
          : "❌ تم إيقاف مضاد الإشراف.",
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
