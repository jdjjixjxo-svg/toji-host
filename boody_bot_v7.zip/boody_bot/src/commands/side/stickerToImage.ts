import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

const command: Command = {
  name: "لصورة",
  category: "اوامر_جانبيه",
  description: "يحوّل ملصق (ثابت) إلى صورة عادية. رد على الملصق بالأمر",
  permission: "all",
  execute: async (ctx) => {
    const quotedSticker = ctx.quoted?.stickerMessage;
    const directSticker = ctx.msg.message?.stickerMessage;
    const stickerMsg = quotedSticker || directSticker;

    if (!stickerMsg) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رد بهذا الأمر على ملصق." }, { quoted: ctx.msg });
      return;
    }
    if (stickerMsg.isAnimated) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ هذا الأمر يدعم الملصقات الثابتة فقط (مو المتحركة)." },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const source = quotedSticker ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const jpeg = await sharp(buffer).flatten({ background: "#ffffff" }).jpeg().toBuffer();
      await ctx.sock.sendMessage(ctx.chatId, { image: jpeg }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر لصورة:", err);
      await notifyOwnerOfError(ctx.sock, ".لصورة", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل تحويل الملصق." }, { quoted: ctx.msg });
    }
  },
};

export default command;
