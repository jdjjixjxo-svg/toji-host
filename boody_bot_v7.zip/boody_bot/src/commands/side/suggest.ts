import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { expectSuggestion, submitSuggestion } from "../../handlers/suggestManager";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "اقتراح",
  aliases: ["اقتراح_امر", "اقتراح_أمر", "اقترح", "suggest"],
  category: "اوامر_جانبيه",
  description: "💡 اقترح أمر أو ميزة جديدة — تصل للمطور مباشرة على الخاص",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim();
    if (!text) {
      expectSuggestion(ctx.sock, ctx.chatId, ctx.senderJid);
      return reply(
        ctx,
        "💡 *اقتراح أمر*\n\nاكتب اقتراحك الآن في *رسالتك التالية* (خلال دقيقتين) وأنا أوصله للمطور مباشرة.\n\n" +
          "مثال: «أبغى أمر يترجم النص للإنجليزي»\n" +
          `أو اكتبه دفعة وحدة: ${CONFIG.PREFIX}اقتراح أمر يترجم النص`
      );
    }
    const res = await submitSuggestion(
      ctx.sock,
      {
        chatId: ctx.chatId,
        sender: ctx.senderJid,
        pushName: ctx.msg.pushName || undefined,
        groupName: ctx.isGroup ? ctx.metadata?.subject : undefined,
        isSubBot: ctx.isSubBot,
      },
      text
    );
    await reply(ctx, res.ok ? "✅ وصل اقتراحك للمطور. شكرًا لك، هالأفكار هي اللي تكبّر البوت 🚀" : `⚠️ ${res.reason}`);
  },
};

export default command;
