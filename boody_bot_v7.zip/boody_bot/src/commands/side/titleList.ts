import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "اللقاب",
  aliases: ["الألقاب","القاب"],
  category: "اوامر_جانبيه",
  description: "يعرض كل الألقاب المسجّلة",
  permission: "all",
  execute: async (ctx) => {
    const ready = await ensureTitlesReady();
    if (!ready) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ نظام الألقاب غير متصل حاليًا." });
      return;
    }

    try {
      const all = await TitleStore.find({});
      if (!all.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "📭 ما فيه أي ألقاب مسجّلة لحد الآن." }, { quoted: ctx.msg });
        return;
      }

      const mentions = all.map((t) => t.userId);
      const list = all.map((t) => `🏷️ ${jidToMention(t.userId)} ← *${t.title}*`).join("\n");
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `📋 *كل الألقاب المسجّلة:*\n\n${list}`, mentions },
        { quoted: ctx.msg }
      );
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء جلب الألقاب." }, { quoted: ctx.msg });
    }
  },
};

export default command;
