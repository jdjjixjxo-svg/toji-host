import { GoogleGenAI } from "@google/genai";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

const IMAGE_MODEL = "gemini-2.5-flash-image";

const command: Command = {
  name: "نانو",
  category: "اوامر_جانبيه",
  description: "يعدّل صورة بالذكاء الاصطناعي حسب طلبك. رد على صورة واكتب التعديل",
  permission: "all",
  execute: async (ctx) => {
    const instruction = ctx.text.trim();
    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    if (!imageMsg || !instruction) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ رد على صورة واكتب التعديل اللي تبيه. مثال: .نانو خلي الخلفية بحر" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (isExplicitQuery(instruction)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    if (!CONFIG.GEMINI_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env." });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: "🍌 يعدّل الصورة..." });

    try {
      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: IMAGE_MODEL,
        contents: [
          { text: instruction },
          { inlineData: { mimeType: "image/jpeg", data: buffer.toString("base64") } },
        ],
      });

      const parts = response.candidates?.[0]?.content?.parts ?? [];
      const imagePart = parts.find((p: any) => p.inlineData);

      if (!imagePart?.inlineData?.data) {
        throw new Error("NO_IMAGE_RETURNED");
      }

      const resultBuffer = Buffer.from(imagePart.inlineData.data, "base64");
      await ctx.sock.sendMessage(ctx.chatId, { image: resultBuffer, caption: `🍌 ${instruction}` }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر نانو:", err);
      await notifyOwnerOfError(ctx.sock, ".نانو", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ تعذر تعديل الصورة حاليًا." }, { quoted: ctx.msg });
    }
  },
};

export default command;
