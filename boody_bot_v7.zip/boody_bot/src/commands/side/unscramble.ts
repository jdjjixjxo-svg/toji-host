import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";
import { buildEventCard } from "../../utils/miniQuiz";
import { sendWithSalawatFallback } from "../../utils/media";

// 🔧 الأصل كان يسجّل مستمع "sock.ev.on('messages.upsert', ...)" منفصل
// بكل استدعاء للأمر — نفس مشكلة تسريب الذاكرة اللي لقيناها بلعبة القنبلة
// بالضبط (كل جولة رتب تسجّل مستمع جديد ما ينحذف). وكان عنده ملف نقاط
// منفصل خاص فيه (data/ranks.json)، موازي لنظام النقاط الحقيقي بالبوت.
// استبدلنا الاثنين: نفس نظام الفعاليات الموجود أصلًا بالمشروع
// (eventManager — نفس المستخدم بـ.فعالية)، فتستفيد تلقائيًا من: البنك
// الحقيقي، وأمر .استسلم لإنهائها، وحماية "فعالية جارية بالفعل".
const WORDS = [
  "ناروتو", "ساسكي", "كيوبي", "ميكاسا", "إيرين", "لوفي", "زورو",
  "تشوبر", "غوكو", "فيجيتا", "غون", "كيلوا", "هيسوكا", "تانجيرو", "نيزوكو",
  "سايتاما", "جينوس", "دراجون", "نيجي", "هيناتا", "شينوبو", "يوتا",
];

const command: Command = {
  name: "رتب",
  aliases: ["رتب_الحروف"],
  category: "ترفيه",
  description: "لعبة ترتيب الحروف — رتّب الحروف المبعثرة لتكوّن الكلمة الصحيحة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم" },
        { quoted: ctx.msg }
      );
      return;
    }

    const word = WORDS[Math.floor(Math.random() * WORDS.length)];
    const shuffled = word
      .split("")
      .sort(() => Math.random() - 0.5)
      .join(" ");

    eventManager.start(ctx.sock as any, ctx.chatId, "رتب الحروف", word, 30_000);

    const groupName = ctx.metadata?.subject || "الخاص";
    const card = buildEventCard(
      groupName,
      "رتب الحروف",
      `🔤 رتب الحروف التالية لتكون كلمة صحيحة:\n*${shuffled}*`,
      "أول شخص يكتب الكلمة الصحيحة يفوز بالنقاط.",
      "⏱️ 30 ثانية فقط!"
    );

    await sendWithSalawatFallback(ctx.sock, ctx.chatId, card);
  },
};

export default command;
