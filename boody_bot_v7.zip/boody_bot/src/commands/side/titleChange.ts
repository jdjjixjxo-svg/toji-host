import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { jidToMention, getTargetJid } from "../../utils/helpers";

const command: Command = {
  name: "تغير_لقب",
  aliases: ["تغيير_لقب"],
  category: "اوامر_جانبيه",
  description: "يغيّر لقب شخص مسجّل مسبقًا. مثال: .تغير_لقب @شخص لقب_جديد",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 نوحّد JID الهدف (رقم حقيقي بدل @lid) ليتطابق مع .لقبي/.لقبه
    const targetJid = getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    const newTitle = ctx.text.replace(/@\d+/g, "").trim();

    if (!newTitle) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب اللقب الجديد بعد المنشن. مثال: .تغير_لقب @شخص لقب_جديد" },
        { quoted: ctx.msg }
      );
      return;
    }

    const ready = await ensureTitlesReady();
    if (!ready) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ نظام الألقاب غير متصل حاليًا." });
      return;
    }

    try {
      const current = await TitleStore.findOne({ userId: targetJid });
      if (!current) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "❌ هذا الشخص ما عنده لقب مسجّل أصلًا. سجّله أول بـ.تسجيل_لقب" },
          { quoted: ctx.msg }
        );
        return;
      }

      const clash = await TitleStore.findOne({ title: newTitle });
      if (clash && clash.userId !== targetJid) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ اللقب "${newTitle}" مستخدم لشخص ثاني.` },
          { quoted: ctx.msg }
        );
        return;
      }

      const oldTitle = current.title;
      current.title = newTitle;
      await current.save();

      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text: `✅ تم تغيير لقب ${jidToMention(targetJid)} من "${oldTitle}" إلى *${newTitle}*`,
          mentions: [targetJid],
        },
        { quoted: ctx.msg }
      );
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء تغيير اللقب." }, { quoted: ctx.msg });
    }
  },
};

export default command;
