import { Command } from "../../handlers/types";
import { start } from "../../handlers/raceManager";

const command: Command = {
  name: "race",
  aliases: ["سباق"],
  category: "ترفيه",
  description: "لعبة سباق سيارات — بادل بين المسارات وتفادى العوائق",
  permission: "all",
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId, ctx.senderJid);
  },
};

export default command;
