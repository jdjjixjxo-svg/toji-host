import { Command } from "../../handlers/types";

const PROVERBS = [
  "🗣️ إللي اختشوا ماتوا.",
  "🗣️ الباب اللي يجي لك منه الريح سده واستريح.",
  "🗣️ امشي سنة ولا تخطي قَناة.",
  "🗣️ إللي بيته من إزاز ما يحدفش الناس بالطوب.",
  "🗣️ المال السايب يعلم السرقة.",
  "🗣️ إن كان حبيبك عسل ما تلحسوش كله.",
  "🗣️ عصفور في اليد ولا عشرة على الشجرة.",
  "🗣️ كل تأخيرة وفيها خيرة.",
  "🗣️ ما يحكّ ظهرك غير ظفرك.",
  "🗣️ اللي على راسه بطحة يحسس عليها.",
  "🗣️ الحلو ما يكملش.",
  "🗣️ القرد في عين أمه غزال.",
  "🗣️ العلم في الراس مش في الكراس.",
  "🗣️ قليل البخت يلاقي العضم في الكرشة.",
];

const command: Command = {
  name: "مثل",
  category: "اوامر_جانبيه",
  description: "مثل شعبي عشوائي",
  permission: "all",
  execute: async (ctx) => {
    const proverb = PROVERBS[Math.floor(Math.random() * PROVERBS.length)];
    await ctx.sock.sendMessage(ctx.chatId, { text: proverb }, { quoted: ctx.msg });
  },
};

export default command;
