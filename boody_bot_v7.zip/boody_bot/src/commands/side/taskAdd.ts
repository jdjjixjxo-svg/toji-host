import { Command } from "../../handlers/types";
import { addTask } from "../../database/db";

// 🔧 الأصل كان يخزّن المهام بملف JSON منفصل تمامًا (data/tasks.json) عن
// قاعدة البيانات الحقيقية بالمشروع. استبدلناها بتخزين حقيقي بنفس db.json
// (نفس مكان النقاط والإعدادات)، ونظام واحد فقط لكل بيانات البوت.
// كمان الأصل ما كان فيه أي طريقة تشوف أو تحذف مهامك بعد إضافتها (أمر
// إضافة بس بلا فايدة عملية) — أضفنا .مهامي لعرضها.
const command: Command = {
  name: "مهمة_اضف",
  aliases: ["اضف_مهمة"],
  category: "اوامر_جانبيه",
  description: "يضيف مهمة لقائمتك الشخصية. مثال: .مهمة_اضف حل واجب الرياضيات",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim();
    if (!text) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب نص المهمة بعد الأمر.\nمثال: .مهمة_اضف حل واجب الرياضيات" },
        { quoted: ctx.msg }
      );
      return;
    }

    const task = addTask(ctx.senderJid, text);
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `✅ تمت إضافة المهمة:\n📌 ${text}\n🆔 ${task.id}\n\nشوف كل مهامك بأمر .مهامي` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
