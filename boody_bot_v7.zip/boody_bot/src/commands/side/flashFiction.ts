import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

// 🔧 الأصل كان يستخدم API خارجي مجهول (api.siputzx.my.id) بلا أي ضمان
// استمرارية أو خصوصية. بما إن المشروع أصلًا عنده وصول موثوق لـGemini
// (نفس مفتاح .سوال و.قصة)، أعدنا بناء هذا الأمر ليستخدمه بدل الاعتماد
// على خدمة عامة غير معروفة الجهة.
const GEMINI_MODEL = "gemini-3.1-flash-lite";

const command: Command = {
  name: "روايه_قصيره",
  aliases: ["قصه_قصيره"],
  category: "اوامر_جانبيه",
  description: "يكتب قصة قصيرة (فلاش فيكشن) عن أي فكرة تعطيه إياها",
  permission: "all",
  execute: async (ctx) => {
    const idea = ctx.text.trim();
    if (!idea) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب فكرة القصة بعد الأمر. مثال: .روايه_قصيره رجل نسي كيف يحلم" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (!CONFIG.GEMINI_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env." });
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: `اكتب قصة قصيرة جدًا (فلاش فيكشن، فقرة إلى فقرتين بالعربية) عن: ${idea}`,
        config: {
          systemInstruction: "أنت كاتب قصص قصيرة عربي محترف. اكتب قصة مكثفة ومؤثرة بأسلوب أدبي بدون مقدمات.",
          maxOutputTokens: 500,
        },
      });

      const text = response.text?.trim();
      if (!text) throw new Error("EMPTY_RESPONSE");

      await ctx.sock.sendMessage(ctx.chatId, { text: `📖 *${text}*` }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر روايه_قصيره:", err);
      await notifyOwnerOfError(ctx.sock, ".روايه_قصيره", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ تعذر توليد القصة حاليًا. حاول مرة ثانية بعد شوي." });
    }
  },
};

export default command;
