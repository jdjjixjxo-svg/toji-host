import { Command } from "../../handlers/types";

const GHAZAL = [
  "عيناك يا حبيبي بحر من الشوق ✦ وقلبك عندي أغلى من كل شيء",
  "يا حبيبي أنت القمر بين النجوم ✦ وأنت النور في ظلمة ليالي",
  "حبك في قلبي مثل النبض ✦ لا يسكن ولا يهدأ ولا ينتهي",
  "عيونك سحر ونظراتك غزل ✦ وقلبك عندي دنياي وما فيها",
  "أنت القصيدة التي أعجز عن كتابتها ✦ وأنت الحلم الذي لا أريد أن أصحو منه",
  "حبي لك كالسماء واسع ✦ وكالبحر عميق وكالنجوم لا يحصى",
  "لو كل الناس تنسى حبك ✦ أنا آخر واحد سيتذكر",
];

const command: Command = {
  name: "غزل",
  category: "اوامر_جانبيه",
  description: "بيت غزل عشوائي",
  permission: "all",
  execute: async (ctx) => {
    const poem = GHAZAL[Math.floor(Math.random() * GHAZAL.length)];
    await ctx.sock.sendMessage(ctx.chatId, { text: `💖 *كلمات غزل:*\n\n${poem}` }, { quoted: ctx.msg });
  },
};

export default command;
