import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

// 🔧 (تجنّب ازدواجية) — الأصل كان يخزن "زيجات" بملف JSON منفصل خاص فيه،
// بالتوازي مع نظام الزواج الحقيقي الموجود أصلًا بالمشروع (.زواج/.طلاق) —
// لو نقلناه بحاله كان راح يصير عندنا مصدرين مختلفين لـ"مين متزوج مين"
// يتناقضون مع بعض. حولناها لمزحة لحظية بدون أي تخزين (نفس روح ".تشبيه").
const MAHR_LIST = [
  "مهره 10 قلوب حب ❤️",
  "مهره 5 كيلو شوكولاتة 🍫",
  "مهره 100 كرتونة بيبسي 🥤",
  "مهره جولة في كوكب الناميك 🌌",
  "مهره كوفي يومي لمدة شهر ☕",
  "مهره لايكات يومية لمدة سنة 👍",
  "مهره 100 وردة من الحب الحقيقي 🌹",
];

const command: Command = {
  name: "زوجه",
  category: "اوامر_جانبيه",
  description: "يزوّج شخصين عشوائيين من الكروب (مزحة، بدون أي تخزين فعلي)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const metadata = ctx.metadata;
    if (!metadata) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يعمل فقط بالكروبات." }, { quoted: ctx.msg });
      return;
    }

    const candidates = metadata.participants
      .map((p) => p.id)
      .filter((id) => id !== ctx.senderJid);

    if (candidates.length < 2) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ ما فيه أعضاء كفاية بالكروب عشان نسوي زواج 😅" },
        { quoted: ctx.msg }
      );
      return;
    }

    const shuffled = [...candidates].sort(() => 0.5 - Math.random());
    const [partner1, partner2] = shuffled;
    const mahr = MAHR_LIST[Math.floor(Math.random() * MAHR_LIST.length)];

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `💍 *تم تزويج شخصين بالقرعة العشوائية* 😂\n\n` +
          `👰 الطرف الأول: ${jidToMention(partner1)}\n` +
          `🤵 الطرف الثاني: ${jidToMention(partner2)}\n\n` +
          `🎁 المهر: ${mahr}\n\n` +
          `🎊 ألف مبروك للزوجين! (مزحة، بدون أي تسجيل فعلي)`,
        mentions: [partner1, partner2],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
