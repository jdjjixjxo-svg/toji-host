import { Command } from "../../handlers/types";

// 🔧 إصلاحات عن الأصل:
// 1) الأصل كان مقيّد بقائمة "نخبة" (isElite) من ملف غير موجود بالزيب
//    أصلًا (../haykala/elite.js) — كان سيتعطل البوت فورًا عند استيراده.
//    حذفنا القيد، متاح للجميع (أمر بسيط بلا أي خطورة).
// 2) الأصل كان يعدّل الرسالة كل ثانية (setInterval كل 1000ms) — لمؤقت
//    طويل هذا مئات الطلبات المتتالية لواتساب، خطر حظر/تقييد حقيقي.
//    استبدلناها برسالة بداية + رسالة نهاية فقط (بدون تحديث مباشر)،
//    وحددنا حدًا أقصى معقول للمدة.
const MAX_SECONDS = 600; // 10 دقائق كحد أقصى

const command: Command = {
  name: "مؤقت",
  category: "اوامر_جانبيه",
  description: "عد تنازلي بسيط (حتى 10 دقائق)",
  permission: "all",
  execute: async (ctx) => {
    const totalSeconds = parseInt(ctx.text.trim(), 10);
    if (isNaN(totalSeconds) || totalSeconds <= 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ اكتب عدد الثواني. مثال: .مؤقت 60" },
        { quoted: ctx.msg }
      );
      return;
    }
    const seconds = Math.min(totalSeconds, MAX_SECONDS);
    const format = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `⏳ بدأ العد التنازلي: ${format(seconds)}${
          totalSeconds > MAX_SECONDS ? "\n(الحد الأقصى 10 دقائق)" : ""
        }`,
      },
      { quoted: ctx.msg }
    );

    setTimeout(() => {
      ctx.sock.sendMessage(ctx.chatId, { text: "✅ انتهى الوقت!" }).catch(() => {});
    }, seconds * 1000);
  },
};

export default command;
