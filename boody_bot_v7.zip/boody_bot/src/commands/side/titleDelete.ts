import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";

// حسب طلبك بالضبط: الحذف بنص اللقب نفسه (".حذف_لقب ميهوك")، مو بالمنشن.
const command: Command = {
  name: "حذف_لقب",
  aliases: ["حذف_اللقب"],
  category: "اوامر_جانبيه",
  description: "يحذف لقب بالاسم. مثال: .حذف_لقب ميهوك",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const title = ctx.text.trim();
    if (!title) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب اللقب اللي تبي تحذفه. مثال: .حذف_لقب ميهوك" },
        { quoted: ctx.msg }
      );
      return;
    }

    const ready = await ensureTitlesReady();
    if (!ready) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ نظام الألقاب غير متصل حاليًا." });
      return;
    }

    try {
      const result = await TitleStore.findOneAndDelete({ title });
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: result ? `✅ تم حذف اللقب "${title}"` : `❌ ما لقيت لقب بهذا الاسم: "${title}"` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء حذف اللقب." }, { quoted: ctx.msg });
    }
  },
};

export default command;
