import { Command } from "../../handlers/types";
import { start } from "../../handlers/mazeManager";
import { hasWebGames, sendWebGameCard } from "../../utils/webGame";

const command: Command = {
  name: "متاهة",
  aliases: ["maze", "maze3d", "متاهة_3D"],
  category: "العاب2D",
  description: "متاهة 3D بمنظور الشخص الأول — دوّر على الباب الأخضر",
  permission: "all",
  execute: async (ctx) => {
    if (hasWebGames()) {
      await sendWebGameCard(ctx.sock, ctx.chatId, ctx.senderJid, {
        title: "🧊 *متاهة 3D*",
        blurb: "متاهة بمنظور الشخص الأول — دوّر على الباب الأخضر وسجّل أسرع وقت.",
        mode: "maze",
      });
      return;
    }
    await start(ctx.sock, ctx.chatId, ctx.senderJid);
  },
};
export default command;
