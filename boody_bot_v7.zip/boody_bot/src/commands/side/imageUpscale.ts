import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

const command: Command = {
  name: "تحسين",
  category: "اوامر_جانبيه",
  description: "يحسّن/يكبّر جودة الصورة (Upscale). رد على صورة بالأمر",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.DEEPAI_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ هذا الأمر يحتاج مفتاح بملف .env (DEEPAI_API_KEY).\nخذ مفتاح مجاني من: https://deepai.org/dashboard/profile",
      });
      return;
    }

    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    if (!imageMsg) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رد بهذا الأمر على صورة." }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: "🔄 يحسّن الصورة..." });

    try {
      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const form = new FormData();
      form.append("image", new Blob([buffer]), "image.png");

      const res = await fetch("https://api.deepai.org/api/torch-srgan", {
        method: "POST",
        headers: { "api-key": CONFIG.DEEPAI_API_KEY },
        body: form,
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`DEEPAI_${res.status}: ${errText.slice(0, 200)}`);
      }

      const data: any = await res.json();
      const resultUrl = data.output_url;
      if (!resultUrl) throw new Error("NO_OUTPUT_URL");

      const imgRes = await fetch(resultUrl);
      const resultBuffer = Buffer.from(await imgRes.arrayBuffer());

      await ctx.sock.sendMessage(ctx.chatId, { image: resultBuffer, caption: "✅ تم تحسين الصورة" }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر تحسين:", err);
      await notifyOwnerOfError(ctx.sock, ".تحسين", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل تحسين الصورة. تأكد إن المفتاح صحيح وله رصيد." }, { quoted: ctx.msg });
    }
  },
};

export default command;
