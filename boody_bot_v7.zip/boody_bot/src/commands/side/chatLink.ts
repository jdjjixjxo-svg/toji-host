import { Command } from "../../handlers/types";

// 🔧 (طلب صريح: "خليها ملكية لبوتنا") — الأصل كان فيه اسم/علامة بوت ثاني
// ("𝑨𝑺𝑯𝑼𝑹𝑨") مطبوعة بالرسالة، حذفناها بالكامل. وبسّطنا الرسالة لنص
// عادي (الأصل كان يحاول يرفق صورة بروفايل الكروب كـ"صورة إعلان" بمكان
// غير مناسب لمحادثة خاصة أو كروب بدون صورة).
const command: Command = {
  name: "شاتي",
  category: "اوامر_جانبيه",
  description: "ينشئ رابط شات واتساب لرقمك، مع رسالة تلقائية اختيارية",
  permission: "all",
  execute: async (ctx) => {
    const senderNumber = ctx.senderJid.split("@")[0];
    const text = ctx.text.trim();
    const chatLink = `https://wa.me/${senderNumber}${text ? `?text=${encodeURIComponent(text)}` : ""}`;

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `🔗 *لينك شاتك:*\n${chatLink}\n\n` +
          `💡 لو تبي تضيف رسالة تلقائية مع اللينك، اكتب: .شاتي <الرسالة>`,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
