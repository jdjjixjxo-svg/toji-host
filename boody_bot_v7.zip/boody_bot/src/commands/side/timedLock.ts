import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { checkPermission } from "../../middlewares/permissions";

// 🔧 إصلاحات عن الأصل:
// 1) الأصل كان يعتمد على "isElite" من ملف غير موجود بالزيب (سيتعطل
//    البوت فورًا) — استبدلناها بـpermission: "admin" العادية بالمشروع.
// 2) الأصل كان يعدّل رسالة العداد كل ثانية (تحميل زائد حقيقي على واتساب
//    لمدد طويلة) — اكتفينا برسالة بداية + رسالة نهاية.
// 3) الأصل كان يقرأ صورة محلية ثابتة (image.jpeg) غير موجودة بمشروعنا —
//    حذفناها، رسالة نصية بس.
const MAX_MINUTES = 180; // 3 ساعات كحد أقصى

const command: Command = {
  name: "شات",
  category: "اوامر_جانبيه",
  aliases: ["chat"],
  description: "مساعد الذكاء الاصطناعي: .شات <سؤالك> — وللمشرفين: قفل/فتح الكروب مؤقتًا (.شات قفل 2 أو .شات فتح 3)",
  // 🆕 صلاحية "الجميع" لأن .شات عند صديقك مساعد AI للكل؛ قفل/فتح الكروب يفحص صلاحية المشرف داخليًا.
  permission: "all",
  groupOnly: false,
  requireBotAdmin: false,
  execute: async (ctx) => {
    const args = ctx.text.trim().split(/\s+/);
    const action = args[0];
    const minutes = parseInt(args[1], 10);

    // ليس أمر قفل/فتح → مساعد الذكاء الاصطناعي (نفس .سوال)
    if (!["قفل", "فتح"].includes(action)) {
      const ask = commandRegistry.get("سوال");
      if (ask) return ask.execute(ctx);
    }

    if (!ctx.metadata) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ قفل/فتح الكروب يعمل داخل المجموعات فقط." }, { quoted: ctx.msg });
      return;
    }
    if (!(await checkPermission(ctx.sock, ctx.chatId, ctx.senderJid, "admin", ctx.metadata, true))) return;

    if (!["قفل", "فتح"].includes(action) || isNaN(minutes) || minutes <= 0) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ الصيغة: .شات قفل 2  أو  .شات فتح 3 (المدة بالدقائق)" },
        { quoted: ctx.msg }
      );
      return;
    }

    const cappedMinutes = Math.min(minutes, MAX_MINUTES);
    const isLock = action === "قفل";

    try {
      await ctx.sock.groupSettingUpdate(ctx.chatId, isLock ? "announcement" : "not_announcement");
    } catch (err) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر تغيير إعدادات الكروب. تأكد إن البوت مشرف." },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `${isLock ? "🔒 تم قفل الكروب" : "✅ تم فتح الكروب"} لمدة ${cappedMinutes} دقيقة${
          minutes > MAX_MINUTES ? ` (الحد الأقصى ${MAX_MINUTES} دقيقة)` : ""
        }.`,
      },
      { quoted: ctx.msg }
    );

    setTimeout(async () => {
      try {
        await ctx.sock.groupSettingUpdate(ctx.chatId, isLock ? "not_announcement" : "announcement");
        await ctx.sock.sendMessage(ctx.chatId, {
          text: isLock ? "✅ تم فتح الكروب تلقائيًا." : "🔒 تم قفل الكروب تلقائيًا.",
        });
      } catch {
        // تجاهل بصمت — ممكن البوت يكون فقد صلاحية الإشراف بالفترة
      }
    }, cappedMinutes * 60 * 1000);
  },
};

export default command;
