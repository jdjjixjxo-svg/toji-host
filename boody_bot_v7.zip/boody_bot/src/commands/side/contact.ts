import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, navButtons, waLinkButton } from "../../utils/interactive";
import { developersMenuText } from "../../utils/menuTemplates";

/**
 * 👑 قسم المطورين — بنفس ستايل باقي الأقسام، وأرقامنا كأزرار حقيقية تفتح
 * واتساب مباشرة (wa.me) بدل إرسال بطاقة جهة اتصال (vCard)، لأن إرسال جهة
 * اتصال لرقم غير محفوظ يعرّض رقم البوت للحظر عند تكراره.
 */
const command: Command = {
  name: "المطورين",
  aliases: ["مطورين", "تواصل", "التواصل", "مراسلة", "مراسله", "contact", "دعم"],
  category: "بوت",
  description: "قسم المطورين — أرقامهم كأزرار مباشرة + القناة وكروب الدعم",
  permission: "all",
  execute: async (ctx) => {
    const devs = [
      { name: CONFIG.OWNER_NAME, number: CONFIG.OWNER_NUMBER },
      { name: CONFIG.OWNER_NAME_2, number: CONFIG.OWNER_NUMBER_2 },
      { name: CONFIG.OWNER_NAME_3, number: CONFIG.OWNER_NUMBER_3 },
    ].filter((d) => d.number);

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: developersMenuText({ devs, channel: CONFIG.CHANNEL_LINK || undefined, support: CONFIG.SUPPORT_GROUP_LINK || undefined }),
      quickButtons: navButtons(),
      extraButtons: devs.map((d) => waLinkButton(`💬 ${d.name}`, d.number)),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
