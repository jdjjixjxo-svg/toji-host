import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

const command: Command = {
  name: "ازالة_خلفية",
  aliases: ["ازالة-خلفية"],
  category: "اوامر_جانبيه",
  description: "يزيل خلفية الصورة. رد على صورة بالأمر",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.REMOVEBG_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ هذا الأمر يحتاج مفتاح بملف .env (REMOVEBG_API_KEY).\nخذ مفتاح مجاني من: https://www.remove.bg/api",
      });
      return;
    }

    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    if (!imageMsg) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ رد بهذا الأمر على صورة." }, { quoted: ctx.msg });
      return;
    }

    try {
      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const form = new FormData();
      form.append("image_file", new Blob([buffer]), "image.png");
      form.append("size", "auto");

      const res = await fetch("https://api.remove.bg/v1.0/removebg", {
        method: "POST",
        headers: { "X-Api-Key": CONFIG.REMOVEBG_API_KEY },
        body: form,
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`REMOVEBG_${res.status}: ${errText.slice(0, 200)}`);
      }

      const resultBuffer = Buffer.from(await res.arrayBuffer());
      await ctx.sock.sendMessage(ctx.chatId, { image: resultBuffer, caption: "✅ تمت إزالة الخلفية" }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر ازالة_خلفية:", err);
      await notifyOwnerOfError(ctx.sock, ".ازالة_خلفية", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشلت إزالة الخلفية. تأكد إن المفتاح صحيح وله رصيد." }, { quoted: ctx.msg });
    }
  },
};

export default command;
