import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

const command: Command = {
  name: "قص",
  category: "اوامر_جانبيه",
  description: "يقص نسبة مئوية من أطراف الصورة. مثال: رد على صورة بـ.قص 20",
  permission: "all",
  execute: async (ctx) => {
    const quotedImage = ctx.quoted?.imageMessage;
    const directImage = ctx.msg.message?.imageMessage;
    const imageMsg = quotedImage || directImage;

    if (!imageMsg) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ رد بهذا الأمر على صورة، مع نسبة القص. مثال: .قص 20" },
        { quoted: ctx.msg }
      );
      return;
    }

    const percent = Math.min(Math.max(parseInt(ctx.text.trim(), 10) || 10, 1), 45);

    try {
      const source = quotedImage ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const metadata = await sharp(buffer).metadata();
      const width = metadata.width || 512;
      const height = metadata.height || 512;
      const cutW = Math.floor((width * percent) / 100);
      const cutH = Math.floor((height * percent) / 100);

      const cropped = await sharp(buffer)
        .extract({
          left: cutW,
          top: cutH,
          width: Math.max(width - cutW * 2, 1),
          height: Math.max(height - cutH * 2, 1),
        })
        .jpeg()
        .toBuffer();

      await ctx.sock.sendMessage(
        ctx.chatId,
        { image: cropped, caption: `✂️ تم قص ${percent}% من الأطراف` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر قص:", err);
      await notifyOwnerOfError(ctx.sock, ".قص", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل قص الصورة." }, { quoted: ctx.msg });
    }
  },
};

export default command;
