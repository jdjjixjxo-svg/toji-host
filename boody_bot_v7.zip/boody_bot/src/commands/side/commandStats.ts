import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { CONFIG } from "../../config/config";

const command: Command = {
  name: "امر",
  aliases: ["احصائية_الاوامر"],
  category: "اوامر_جانبيه",
  description: "إحصائية عدد الأوامر المسجّلة بالبوت",
  permission: "all",
  execute: async (ctx) => {
    const all = commandRegistry.getAll();
    const byCategory = new Map<string, number>();
    for (const c of all) {
      byCategory.set(c.category, (byCategory.get(c.category) || 0) + 1);
    }
    const breakdown = [...byCategory.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([cat, count]) => `  • ${cat}: ${count}`)
      .join("\n");

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `🤖 *${CONFIG.BOT_NAME}*\n\n📊 *إجمالي الأوامر:* ${all.length}\n\n${breakdown}`,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
