import { Command } from "../../handlers/types";

const QUESTIONS = [
  "😂 مين أكثر شخص يضحك على أي شيء؟",
  "😈 مين أكثر شخص دايم يطقطق على الناس؟",
  "🕒 مين أكثر شخص دايم يتأخر؟",
  "📱 مين أكثر واحد دايم ماسك الجوال؟",
  "💤 مين أكثر شخص ينام بدري؟",
  "💬 مين أكثر واحد يحب يفضفض؟",
  "🎉 مين أكثر شخص يحب الفلة والوناسة؟",
  "🧠 مين أكثر شخص ذكي بالجروب؟",
  "🫣 مين أكثر شخص يخاف بسرعة؟",
  "🍔 مين أكثر واحد دايم ياكل؟",
  "🤡 مين أكثر واحد يحب يسوي مقالب؟",
  "🗣️ مين أكثر شخص يتكلم كثير؟",
  "😎 مين أكثر شخص واثق من نفسه؟",
  "🥷 مين أكثر واحد غامض؟",
  "❤️ مين أكثر واحد محبوب؟",
];

const command: Command = {
  name: "مين_اكثر",
  category: "ترفيه",
  description: "سؤال 'مين أكثر واحد...' عشوائي للجروب",
  permission: "all",
  execute: async (ctx) => {
    const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    await ctx.sock.sendMessage(ctx.chatId, { text: `👀 ${q}` }, { quoted: ctx.msg });
  },
};

export default command;
