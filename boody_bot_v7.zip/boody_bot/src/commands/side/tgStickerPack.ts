import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, sleep } from "../../utils/helpers";

const command: Command = {
  name: "tg_pack",
  aliases: ["حزمة_تليجرام"],
  category: "اوامر_جانبيه",
  description: "يحمّل حزمة ملصقات من تليجرام. مثال: .tg_pack AnimeStickers",
  permission: "all",
  execute: async (ctx) => {
    if (!CONFIG.TELEGRAM_BOT_TOKEN) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          "❌ هذا الأمر يحتاج توكن بملف .env (TELEGRAM_BOT_TOKEN)، مجاني بالكامل.\n" +
          "افتح تطبيق تليجرام → ابحث @BotFather → أرسل /newbot واتبع التعليمات.",
      });
      return;
    }

    const packName = ctx.text.trim();
    if (!packName) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب اسم حزمة الملصقات من رابط تليجرام.\nمثال: .tg_pack AnimeStickers" },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: `🔎 يجهّز حزمة "${packName}" من تليجرام...` });

    try {
      const base = `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}`;
      const setRes = await fetch(`${base}/getStickerSet?name=${encodeURIComponent(packName)}`);
      const setData: any = await setRes.json();

      if (!setData.ok) {
        throw new Error(`TG_SET_${setData.error_code}: ${setData.description}`);
      }

      const stickers = setData.result.stickers as any[];
      const staticStickers = stickers.filter((s) => !s.is_animated && !s.is_video);

      if (!staticStickers.length) {
        await ctx.sock.sendMessage(ctx.chatId, {
          text: "❌ هذي الحزمة كلها ملصقات متحركة (Lottie)، ما ندعم تحويلها حاليًا.",
        });
        return;
      }

      let sent = 0;
      for (const sticker of staticStickers.slice(0, 30)) {
        try {
          const fileRes = await fetch(`${base}/getFile?file_id=${sticker.file_id}`);
          const fileData: any = await fileRes.json();
          if (!fileData.ok) continue;

          const fileUrl = `https://api.telegram.org/file/bot${CONFIG.TELEGRAM_BOT_TOKEN}/${fileData.result.file_path}`;
          const imgRes = await fetch(fileUrl);
          const buffer = Buffer.from(await imgRes.arrayBuffer());

          await ctx.sock.sendMessage(ctx.chatId, { sticker: buffer });
          sent++;
          await sleep(500);
        } catch {
          continue; // ملصق وحد فشل، نكمل الباقي
        }
      }

      if (!sent) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما قدرت أحمّل ولا ملصق من هذي الحزمة." });
        return;
      }

      await ctx.sock.sendMessage(ctx.chatId, { text: `✅ تم إرسال ${sent} ملصق من حزمة "${packName}".` });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر tg_pack:", err);
      await notifyOwnerOfError(ctx.sock, ".tg_pack", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ ما لقيت حزمة بهذا الاسم. تأكد إن الاسم مطابق تمامًا لرابط تليجرام.",
      });
    }
  },
};

export default command;
