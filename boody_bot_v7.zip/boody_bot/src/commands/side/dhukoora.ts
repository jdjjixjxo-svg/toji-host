import { Command } from "../../handlers/types";
import { jidToMention } from "../../utils/helpers";

// مُعاد بناؤه بالكامل من ملف خارجي (اوامر_جانبيه.zip) ليشتغل بمعمارية
// هذا المشروع. الأصل كان يفحص contextInfo.mentionedJid يدويًا — استبدلناها
// بمنطق مطابق لباقي أوامر المشروع.
const command: Command = {
  name: "ذكوره",
  category: "اوامر_جانبيه",
  description: "نسبة الذكورة لك أو لشخص تمنشنه (عشوائية بالكامل، للمزح فقط)",
  permission: "all",
  execute: async (ctx) => {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const targetJid = mentioned || ctx.senderJid;
    const percentage = Math.floor(Math.random() * 101);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `🧔‍♂️ نسبة الذكورة لـ ${jidToMention(targetJid)}: *${percentage}%*\n\n💪 الرجولة على أصولها ولا لأ؟`,
        mentions: [targetJid],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
