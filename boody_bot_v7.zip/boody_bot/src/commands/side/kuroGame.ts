import { Command } from "../../handlers/types";
import { start } from "../../handlers/kuroManager";

const command: Command = {
  name: "kuro",
  aliases: ["مبارزة_دموية"],
  category: "ترفيه",
  description: "لعبة قتال خفيف — هجوم/هجوم قوي/دفاع ضد خصم",
  permission: "all",
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId, ctx.senderJid);
  },
};

export default command;
