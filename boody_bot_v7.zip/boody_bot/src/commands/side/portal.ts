import { Command } from "../../handlers/types";
import { startPortal, beginPortalSession } from "../../handlers/portalManager";

const command: Command = {
  name: "بوابه",
  category: "ترفيه",
  description: "لعبة بوابة الواقع الغامضة — قصة قصيرة متفرعة، لعبة فردية",
  permission: "all",
  execute: async (ctx) => {
    beginPortalSession(ctx.chatId, ctx.senderJid);
    const { text } = startPortal();
    await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
  },
};

export default command;
