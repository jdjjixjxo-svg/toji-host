import { Command } from "../../handlers/types";
import { decrease } from "../../handlers/heartsManager";
import { jidToMention, getMentionedJids, getQuotedParticipant } from "../../utils/helpers";

// 🔧 الأصل كان يقبل الرد (reply) فقط لتحديد اللاعب. أضفنا كمان المنشن @
// كطريقة بديلة (نفس تحسين لعبة القنبلة)، عشان يشتغل بأي طريقة يستخدمها
// اللاعب.
const command: Command = {
  name: "انقاص",
  category: "ترفيه",
  description: "ينقص قلب لاعب بلعبة القلوب (رد على رسالته أو امنشنه) — لصاحب اللعبة فقط",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const target = getMentionedJids(ctx.msg)[0] || getQuotedParticipant(ctx.msg);
    if (!target) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ منشن اللاعب أو رد على رسالته لتنقص قلبه." },
        { quoted: ctx.msg }
      );
      return;
    }

    const result = decrease(ctx.sock, ctx.chatId, ctx.senderJid, target);
    if (!result) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ لا توجد لعبة قلوب نشطة حاليًا." }, { quoted: ctx.msg });
      return;
    }
    if (!result.allowed) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ فقط الشخص اللي بدأ اللعبة يقدر ينقص قلوب اللاعبين." },
        { quoted: ctx.msg }
      );
      return;
    }
    if (result.eliminated === undefined) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الشخص مو مشارك باللعبة." }, { quoted: ctx.msg });
      return;
    }

    if (result.winner) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `🏆 اللعبة انتهت! الفائز هو ${jidToMention(result.winner)} (+1 نقطة)`, mentions: [result.winner] },
        { quoted: ctx.msg }
      );
      return;
    }

    if (result.eliminated) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `💔 خرج من اللعبة ${jidToMention(target)}`, mentions: [target] },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text: `💔 تم تقليل قلب من ${jidToMention(target)}. القلوب المتبقية: ${result.icon?.repeat(result.heartsLeft || 0)}`,
        mentions: [target],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
