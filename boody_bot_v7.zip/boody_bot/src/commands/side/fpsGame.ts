import { Command } from "../../handlers/types";
import { start } from "../../handlers/fpsManager";
import { hasWebGames, sendWebGameCard } from "../../utils/webGame";

const command: Command = {
  name: "fps",
  aliases: ["حرب"],
  category: "ترفيه",
  description: "لعبة إطلاق نار وحرب — صفّي الأعداء قبل ما تخلص صحتك",
  permission: "all",
  execute: async (ctx) => {
    if (hasWebGames()) {
      await sendWebGameCard(ctx.sock, ctx.chatId, ctx.senderJid, {
        title: "🪖 *WAR ZONE 3D*",
        blurb: "حرب بمنظور الشخص الأول: موجات أعداء، تصويب، تلقيم، وحركة فورية.",
        mode: "war",
      });
      return;
    }
    await start(ctx.sock, ctx.chatId, ctx.senderJid);
  },
};

export default command;
