import { Command } from "../../handlers/types";
import { start } from "../../handlers/wordChainManager";

const command: Command = {
  name: "سلسلة",
  category: "ترفيه",
  description: "لعبة سلسلة الحروف — كل كلمة تبدأ بآخر حرف من اللي قبلها",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId);
  },
};

export default command;
