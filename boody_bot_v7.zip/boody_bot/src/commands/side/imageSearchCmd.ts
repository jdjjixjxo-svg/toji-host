import { Command } from "../../handlers/types";
import { searchImages, downloadImageBuffer } from "../../utils/imageSearch";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

// 🔧 (سبب فعلي حقيقي لـ ".صور مش شغال") — كنا نمرر رابط الصورة الخام
// مباشرة لواتساب ({ image: { url } })، ونخلي سيرفرات واتساب نفسها تجيب
// الصورة. كثير من روابط نتائج البحث (DuckDuckGo/Bing) محمية ضد
// hotlinking — لازم User-Agent يشبه متصفح حقيقي (بالضبط زي اللي نسويه
// إحنا بـdownloadImageBuffer)، وسيرفرات واتساب ما ترسل هذا الهيدر فتفشل
// الصورة بصمت أو توصل فاضية. الحل: نحمّل الصورة إحنا (نفس طريقة .حزمة
// الشغالة أصلًا)، ثم نرفعها كـbuffer جاهز بدل رابط خام.
const MAX_IMAGES = 5;

const command: Command = {
  name: "صور",
  category: "اوامر_جانبيه",
  description: "بحث عن صور بأي كلمة. مثال: .صور قطط",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ اكتب كلمة بحث بعد الأمر. مثال: .صور قطط" },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🆕 (طلب صريح: قيود على المحتوى الجنسي)
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    try {
      const urls = await searchImages(query, 15); // نطلب أكثر من MAX_IMAGES لأن بعضها بيفشل بالتحميل
      if (!urls.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما لقيت صور لهالكلمة." }, { quoted: ctx.msg });
        return;
      }

      let sent = 0;
      const failures: string[] = [];
      for (const url of urls) {
        if (sent >= MAX_IMAGES) break;
        try {
          const buffer = await downloadImageBuffer(url);
          await ctx.sock.sendMessage(ctx.chatId, { image: buffer, caption: `🖼️ ${query}` });
          sent++;
        } catch (err) {
          failures.push(err instanceof Error ? err.message : String(err));
        }
      }

      if (!sent) {
        logger.warn(`⚠️ فشلت كل صور .صور لـ "${query}":`, failures.join(" | "));
        await notifyOwnerOfError(ctx.sock, ".صور", `كل الصور فشلت لـ"${query}": ${failures.slice(0, 3).join(" | ")}`, {
          chatId: ctx.chatId,
          senderJid: ctx.senderJid,
        });
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ لقيت صور بس ما قدرت أحمّل ولا وحدة. جرّب كلمة ثانية." }, { quoted: ctx.msg });
      }
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء البحث." }, { quoted: ctx.msg });
    }
  },
};

export default command;

