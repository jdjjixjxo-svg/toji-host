import { Command } from "../../handlers/types";
import { start } from "../../handlers/secretNumberManager";

const command: Command = {
  name: "رقم_سري",
  category: "ترفيه",
  description: "لعبة تخمين رقم سري جماعية (1-100)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId);
  },
};

export default command;
