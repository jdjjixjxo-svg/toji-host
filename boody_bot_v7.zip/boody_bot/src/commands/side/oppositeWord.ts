import { Command } from "../../handlers/types";
import { eventManager } from "../../handlers/eventManager";

// نفس نمط .فعالية/.حزورة (eventManager)، بس نص عادي بدون صورة — تجنّبًا
// لنفس مشكلة "يرسل صورة بس" اللي واجهناها بأمر محذوف سابقًا.
const PAIRS: [string, string][] = [
  ["كبير", "صغير"], ["طويل", "قصير"], ["سريع", "بطيء"], ["قوي", "ضعيف"],
  ["حار", "بارد"], ["فرح", "حزين"], ["نهار", "ليل"], ["غني", "فقير"],
  ["جديد", "قديم"], ["نظيف", "وسخ"], ["سهل", "صعب"], ["مفتوح", "مغلق"],
  ["ثقيل", "خفيف"], ["واسع", "ضيق"], ["حلو", "مر"], ["قريب", "بعيد"],
];

const command: Command = {
  name: "ضد_الكلمة",
  category: "اوامر_جانبيه",
  description: "فعالية عكس الكلمة — أول شخص يكتب عكس الكلمة يفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    if (eventManager.isRunning(ctx.sock as any, ctx.chatId)) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ هناك فعالية جارية بالفعل! انتظر انتهاءها أو استخدم .استسلم" },
        { quoted: ctx.msg }
      );
      return;
    }

    const [word, opposite] = PAIRS[Math.floor(Math.random() * PAIRS.length)];
    eventManager.start(ctx.sock as any, ctx.chatId, "ضد الكلمة", opposite, 30_000);

    await ctx.sock.sendMessage(ctx.chatId, {
      text: `🔄 *فعالية ضد الكلمة!*\n\nإيش عكس كلمة: *${word}*؟\n\n⏱️ أول إجابة صحيحة تفوز! (30 ثانية)`,
    });
  },
};

export default command;
