import { Command } from "../../handlers/types";
import { withTimeout } from "../../utils/timeout";
import ytSearch from "yt-search";
import ytdl from "@distube/ytdl-core";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

// 🔧 صراحة مهمة: سبوتيفاي ما يوفر تحميل صوت فعلي عبر API عام (بس
// معلومات/معاينة 30 ثانية). أي بوت "يحمّل من سبوتيفاي" فعليًا يبحث عن
// نفس الأغنية بمكان ثاني (عادة يوتيوب) ويحمّلها من هناك. سويناها
// بوضوح: نبحث اسم الأغنية بيوتيوب (نفس مصدر .ايديت الموثوق) ونرسلها،
// بدل ما نتظاهر إنها "من سبوتيفاي" فعليًا.
const command: Command = {
  name: "سبوتيفاي",
  aliases: ["ساوند"], // 🔧 نفس الآلية بالضبط (SoundCloud كمان ما يوفر تحميل مباشر رسمي) — بدل ملف مكرر بنفس الكود تمامًا
  category: "اوامر_جانبيه",
  description: "يبحث عن أغنية ويرسلها بصوت (المصدر الفعلي: يوتيوب، سبوتيفاي ما يسمح بتحميل مباشر)",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب اسم الأغنية. مثال: .سبوتيفاي شاي حلال" }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: `🔎 يدور "${query}"...` });

    try {
      const results = await withTimeout(ytSearch(query), 12_000, "YT_SEARCH_TIMEOUT");
      const video = results?.videos?.[0];
      if (!video?.url) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما لقيت الأغنية." }, { quoted: ctx.msg });
        return;
      }

      const stream = ytdl(video.url, { quality: "highestaudio", filter: "audioonly" });
      const chunks: Buffer[] = [];
      const buffer = await new Promise<Buffer>((resolve, reject) => {
        stream.on("data", (c: Buffer) => chunks.push(c));
        stream.on("end", () => resolve(Buffer.concat(chunks)));
        stream.on("error", reject);
      });

      await ctx.sock.sendMessage(ctx.chatId, {
        audio: buffer,
        mimetype: "audio/mpeg",
        fileName: `${video.title}.mp3`,
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر سبوتيفاي:", err);
      await notifyOwnerOfError(ctx.sock, ".سبوتيفاي", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل تحميل الأغنية. جرّب اسم ثاني." }, { quoted: ctx.msg });
    }
  },
};

export default command;
