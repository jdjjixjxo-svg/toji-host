import { Command } from "../../handlers/types";

const command: Command = {
  name: "معلومات_الكروب",
  aliases: ["معلومات"],
  category: "اوامر_جانبيه",
  description: "يعرض اسم ووصف وصورة الكروب الحالي",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const metadata = ctx.metadata;
    if (!metadata) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يعمل فقط بالكروبات." }, { quoted: ctx.msg });
      return;
    }

    const name = metadata.subject || "بدون اسم";
    const description = metadata.desc || "لا يوجد وصف.";

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `📛 *اسم الكروب:* ${name}\n📄 *الوصف:* ${description}` },
      { quoted: ctx.msg }
    );

    try {
      const url = await ctx.sock.profilePictureUrl(ctx.chatId, "image");
      if (url) {
        await ctx.sock.sendMessage(ctx.chatId, { image: { url }, caption: "🖼️ صورة الكروب" });
      }
    } catch {
      // ما فيه صورة، تجاهل بصمت
    }
  },
};

export default command;
