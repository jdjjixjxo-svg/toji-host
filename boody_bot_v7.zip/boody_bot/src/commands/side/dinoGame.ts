import { Command } from "../../handlers/types";
import { start } from "../../handlers/dinoManager";

const command: Command = {
  name: "dino",
  aliases: ["دينو"],
  category: "ترفيه",
  description: "لعبة الديناصور — اقفز فوق الصبار قبل ما يوصلك",
  permission: "all",
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId, ctx.senderJid);
  },
};

export default command;
