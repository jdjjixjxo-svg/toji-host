import { Command } from "../../handlers/types";
import { start } from "../../handlers/speedReactionManager";

const command: Command = {
  name: "من_الاسرع",
  category: "ترفيه",
  description: "لعبة رد فعل سريع — أول شخص يكتب بعد إشارة البدء يفوز",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId);
  },
};

export default command;
