import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

const GEMINI_MODEL = "gemini-3.1-flash-lite";

const command: Command = {
  name: "ترجم",
  category: "اوامر_جانبيه",
  description: "يترجم نص لأي لغة. مثال: .ترجم انجليزي مرحبا كيف حالك",
  permission: "all",
  execute: async (ctx) => {
    const raw = (ctx.text || "").trim();
    const quotedText =
      ctx.quoted?.conversation || ctx.quoted?.extendedTextMessage?.text || "";
    const [lang, ...rest] = raw.split(/\s+/);
    const text = rest.join(" ") || quotedText;

    if (!lang || !text) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ الصيغة: .ترجم <اللغة> <النص>\nمثال: .ترجم انجليزي مرحبا كيف حالك" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (!CONFIG.GEMINI_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env." });
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: `ترجم النص التالي للغة "${lang}" فقط، بدون أي شرح أو مقدمة، رد بالترجمة فقط:\n\n${text}`,
        config: { maxOutputTokens: 500 },
      });

      const translated = response.text?.trim();
      if (!translated) throw new Error("EMPTY_RESPONSE");

      await ctx.sock.sendMessage(ctx.chatId, { text: `🌐 *الترجمة (${lang}):*\n${translated}` }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر ترجم:", err);
      await notifyOwnerOfError(ctx.sock, ".ترجم", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ تعذرت الترجمة حاليًا." }, { quoted: ctx.msg });
    }
  },
};

export default command;
