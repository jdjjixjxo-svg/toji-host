import { Command } from "../../handlers/types";
import { ensureTitlesReady, TitleStore } from "../../database/supabaseTitles";
import { jidToMention, getTargetJid } from "../../utils/helpers";

// 🔧 (تجنّب تصادم حقيقي) — طلبت الصيغة ".تسجيل لقب @شخص X" (كلمتين
// منفصلتين)، لكن ".حذف" مستخدم أصلًا بالمشروع لحذف الرسائل — ".حذف لقب"
// كان سيصطدم به فورًا (البوت يقرأ أول كلمة بس كاسم الأمر). استخدمنا
// "تسجيل_لقب"/"تغير_لقب"/"حذف_لقب" (كلمة وحدة بشرطة سفلية) بدل المسافة،
// بنفس تنسيق بقية أوامر المشروع (صح_او_خطا، حجر_ورقة_مقص...).
const command: Command = {
  name: "تسجيل_لقب",
  aliases: ["تلقيب","تسجيل_لقب_لعضو"],
  category: "اوامر_جانبيه",
  description: "يسجّل لقب لشخص. مثال: .تسجيل_لقب @شخص ميهوك",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    // 🔧 نوحّد JID الهدف (رقم حقيقي بدل @lid) ليتطابق مع .لقبي/.لقبه
    const targetJid = getTargetJid(ctx.msg, ctx.metadata) || ctx.senderJid;
    // نشيل المنشن (@xxxxx) من النص، الباقي هو اللقب
    const title = ctx.text.replace(/@\d+/g, "").trim();

    if (!title) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب اللقب بعد المنشن. مثال: .تسجيل_لقب @شخص ميهوك" },
        { quoted: ctx.msg }
      );
      return;
    }

    const ready = await ensureTitlesReady();
    if (!ready) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ نظام الألقاب غير متصل حاليًا (MONGODB_URI ناقص أو غلط بملف .env).",
      });
      return;
    }

    try {
      // 🔧 (طلب صريح: "ما أبيها تتكرر") — نتأكد الاسم مو مسجّل لشخص ثاني
      const existing = await TitleStore.findOne({ title });
      if (existing && existing.userId !== targetJid) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ اللقب "${title}" مسجّل مسبقًا لشخص ثاني. اختر لقب مختلف.` },
          { quoted: ctx.msg }
        );
        return;
      }

      await TitleStore.findOneAndUpdate(
        { userId: targetJid },
        { title },
        { upsert: true }
      );

      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `✅ تم تسجيل لقب ${jidToMention(targetJid)}: *${title}*`, mentions: [targetJid] },
        { quoted: ctx.msg }
      );
    } catch (err: any) {
      // خطأ فريد (duplicate key) لو حصل تعارض بنفس اللحظة من طلبين متزامنين
      if (err?.code === 11000) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `❌ اللقب "${title}" مسجّل مسبقًا لشخص ثاني.` },
          { quoted: ctx.msg }
        );
        return;
      }
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء تسجيل اللقب." }, { quoted: ctx.msg });
    }
  },
};

export default command;
