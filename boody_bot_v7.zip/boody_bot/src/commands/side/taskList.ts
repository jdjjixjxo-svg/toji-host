import { Command } from "../../handlers/types";
import { getTasks, removeTask } from "../../database/db";

const command: Command = {
  name: "مهامي",
  category: "اوامر_جانبيه",
  description: "يعرض مهامك الشخصية، أو احذف وحدة بـ.مهامي حذف <الكود>",
  permission: "all",
  execute: async (ctx) => {
    const args = ctx.text.trim().split(/\s+/);

    if (args[0] === "حذف" && args[1]) {
      const removed = removeTask(ctx.senderJid, args[1]);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: removed ? `✅ تم حذف المهمة ${args[1]}` : "❌ ما لقيت مهمة بهذا الكود." },
        { quoted: ctx.msg }
      );
      return;
    }

    const tasks = getTasks(ctx.senderJid);
    if (!tasks.length) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "📭 ما عندك أي مهام. أضف وحدة بـ.مهمة_اضف <النص>" },
        { quoted: ctx.msg }
      );
      return;
    }

    const list = tasks.map((t) => `📌 ${t.text}\n🆔 ${t.id}`).join("\n\n");
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `📋 *مهامك:*\n\n${list}\n\n🗑️ للحذف: .مهامي حذف <الكود>` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
