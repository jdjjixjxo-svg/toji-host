import { Command } from "../../handlers/types";

const DARES = [
  "غيّر صورة بروفايلك لمدة ساعة لصورة مضحكة.",
  "أرسل آخر صورة بجهازك بدون ما تشوفها قبل.",
  "اكتب اسم أول شخص فكرت فيه اليوم.",
  "اتكلم بصوت مضحك بأول رسالة صوتية ترسلها.",
  "أرسل ايموجي واحد يعبر عن يومك.",
  "اكتب أكذوبة بيضاء قلتها هالأسبوع.",
  "غيّر اسمك بالكروب لمدة ساعة لاسم غريب.",
  "أرسل آخر أغنية سمعتها.",
  "اعترف بأكثر شي محرج صار لك هالشهر.",
  "قلّد شخص بالكروب بدون ما تذكر اسمه.",
];

const command: Command = {
  name: "تحداني",
  category: "ترفيه",
  description: "تحدي عشوائي (جرأة)",
  permission: "all",
  execute: async (ctx) => {
    const dare = DARES[Math.floor(Math.random() * DARES.length)];
    await ctx.sock.sendMessage(ctx.chatId, { text: `🔥 *تحداك:*\n\n${dare}` }, { quoted: ctx.msg });
  },
};

export default command;
