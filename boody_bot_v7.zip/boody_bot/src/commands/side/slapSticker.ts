import { Command } from "../../handlers/types";
import sharp from "sharp";
import { jidToMention } from "../../utils/helpers";

const SVG = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <rect width="512" height="512" fill="#fff5f5" opacity="0"/>
  <text x="256" y="230" font-size="150" text-anchor="middle">👋</text>
  <text x="256" y="330" font-size="70" text-anchor="middle">💥</text>
  <text x="256" y="420" font-size="42" fill="#c0392b" text-anchor="middle" font-family="sans-serif" font-weight="bold">صفعة!</text>
</svg>`;

const command: Command = {
  name: "صفع",
  category: "اوامر_جانبيه",
  description: "ملصق صفع لشخص (منشن أو رد على رسالته)",
  permission: "all",
  execute: async (ctx) => {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const target = mentioned || ctx.senderJid;

    const webp = await sharp(Buffer.from(SVG)).resize(512, 512).webp().toBuffer();
    await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
    if (mentioned) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `👋 صفعة لـ ${jidToMention(target)}!`,
        mentions: [target],
      });
    }
  },
};

export default command;
