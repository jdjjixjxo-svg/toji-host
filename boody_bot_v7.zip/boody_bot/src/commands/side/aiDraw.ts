import { GoogleGenAI } from "@google/genai";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

// 🔧 يستخدم نفس GEMINI_API_KEY الموجود أصلًا (نفس خدمة .سوال/.قصة) —
// ما يحتاج مفتاح إضافي. الموديل "gemini-2.5-flash-image" (اسمه الشائع
// "Nano Banana") هو نموذج توليد الصور الرسمي من جوجل، موثّق بشكل ثابت
// بمصادر متعددة (تحقّقت منه بالبحث قبل الكتابة).
const IMAGE_MODEL = "gemini-2.5-flash-image";

const command: Command = {
  name: "ارسم",
  category: "اوامر_جانبيه",
  description: "يرسم صورة بالذكاء الاصطناعي من وصف نصي. مثال: .ارسم قطة تلبس نظارة",
  permission: "all",
  execute: async (ctx) => {
    const prompt = ctx.text.trim();
    if (!prompt) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب وصف الصورة بعد الأمر. مثال: .ارسم قطة تلبس نظارة شمس" },
        { quoted: ctx.msg }
      );
      return;
    }

    if (isExplicitQuery(prompt)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    if (!CONFIG.GEMINI_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ هذا الأمر يحتاج GEMINI_API_KEY بملف .env." });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: "🎨 يرسم..." });

    try {
      const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: IMAGE_MODEL,
        contents: prompt,
      });

      const parts = response.candidates?.[0]?.content?.parts ?? [];
      const imagePart = parts.find((p: any) => p.inlineData);

      if (!imagePart?.inlineData?.data) {
        throw new Error("NO_IMAGE_RETURNED");
      }

      const buffer = Buffer.from(imagePart.inlineData.data, "base64");
      await ctx.sock.sendMessage(ctx.chatId, { image: buffer, caption: `🎨 ${prompt}` }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر ارسم:", err);
      await notifyOwnerOfError(ctx.sock, ".ارسم", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ تعذر رسم الصورة حاليًا. حاول بوصف مختلف." }, { quoted: ctx.msg });
    }
  },
};

export default command;
