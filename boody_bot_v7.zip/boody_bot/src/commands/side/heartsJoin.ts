import { Command } from "../../handlers/types";
import { join } from "../../handlers/heartsManager";
import { jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "مشاركة",
  category: "ترفيه",
  description: "ينضم للعبة القلوب الجارية",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const result = join(ctx.sock, ctx.chatId, ctx.senderJid);
    if (!result.ok) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ لا توجد لعبة قلوب نشطة حاليًا. اكتب .قلوب لبدء واحدة." }, { quoted: ctx.msg });
      return;
    }
    if (result.already) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ أنت مشارك بالفعل." }, { quoted: ctx.msg });
      return;
    }
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `✅ تمت إضافتك باللعبة، عندك 5 قلوب ${result.icon}`, mentions: [ctx.senderJid] },
      { quoted: ctx.msg }
    );
  },
};

export default command;
