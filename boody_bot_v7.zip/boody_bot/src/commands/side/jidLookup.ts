import { Command } from "../../handlers/types";
import { getQuotedParticipant } from "../../utils/helpers";

const command: Command = {
  name: "ايدي",
  aliases: ["jid"],
  category: "اوامر_جانبيه",
  description: "يجيب الـJID الخاص فيك أو بشخص عملت عليه رد/منشن",
  permission: "all",
  execute: async (ctx) => {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const replied = getQuotedParticipant(ctx.msg);
    const target = mentioned || replied || ctx.senderJid;

    await ctx.sock.sendMessage(ctx.chatId, { text: `🆔 *JID:*\n\`\`\`${target}\`\`\`` }, { quoted: ctx.msg });
  },
};

export default command;
