import { Command } from "../../handlers/types";

const ANSWERS = [
  "احتمال قليل", "نعم بالتأكيد", "لا أعتقد", "مستحيل", "جداً أكيد",
  "ممكن", "نسبة ضعيفة", "عندك حظ", "كان ممكن", "خيالك واسع",
  "نص نص", "الفرصة موجودة", "شكله صعب", "نسبة ضئيلة", "خارج الحسابات",
  "تماماً لا", "نعم جداً", "لا أصلاً", "محتمل", "على الأغلب",
  "بكل أسف لا", "ربما قريباً", "قول يارب", "انسى", "عندك أمل", "مع الوقت",
];

const command: Command = {
  name: "هل",
  category: "ترفيه",
  description: "اسأل أي سؤال بـ'هل' ويعطيك إجابة عشوائية طريفة",
  permission: "all",
  execute: async (ctx) => {
    const question = ctx.text.trim();
    if (!question) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❗ اكتب سؤالك بعد الأمر. مثال: .هل بكرة بيصير مطر؟" },
        { quoted: ctx.msg }
      );
      return;
    }
    const answer = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `*السؤال:* هل ${question}\n\n*الإجابة:* ${answer}` },
      { quoted: ctx.msg }
    );
  },
};

export default command;
