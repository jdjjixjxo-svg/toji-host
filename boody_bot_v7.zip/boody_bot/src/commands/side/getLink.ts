import { Command } from "../../handlers/types";

const command: Command = {
  name: "لينك",
  aliases: ["رابط_الكروب"],
  category: "اوامر_جانبيه",
  description: "يعطي رابط دعوة الكروب الحالي",
  permission: "admin", // 🔧 خليناها للمشرفين فقط (الأصل كان مفتوح للكل، وهذا يسرّب رابط الكروب لأي عضو)
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    try {
      const inviteCode = await ctx.sock.groupInviteCode(ctx.chatId);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `🔗 رابط دعوة الكروب:\nhttps://chat.whatsapp.com/${inviteCode}` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر جلب الرابط. تأكد إن البوت مشرف بالكروب." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
