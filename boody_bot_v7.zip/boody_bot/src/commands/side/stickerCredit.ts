import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";

// 🔧 الأصل كان يستخدم ffmpeg drawtext عبر exec() (نفس خطر حقن الأوامر).
// استبدلناها بتركيب SVG نصي فوق الملصق عبر sharp composite — بدون أي
// shell، ونفس مكتبة .ملصق الأساسية بالمشروع.
const command: Command = {
  name: "حقوق_ستكر",
  category: "اوامر_جانبيه",
  description: "يضيف اسمك كحقوق على ملصق. رد على ملصق بـ.حقوق_ستكر <النص>",
  permission: "all",
  execute: async (ctx) => {
    const quotedSticker = ctx.quoted?.stickerMessage;
    const directSticker = ctx.msg.message?.stickerMessage;
    const stickerMsg = quotedSticker || directSticker;
    const label = ctx.text.trim();

    if (!stickerMsg || !label) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ رد بهذا الأمر على ملصق، مع النص. مثال: .حقوق_ستكر بودي" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const source = quotedSticker ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const safeLabel = label.replace(/[<>&]/g, "").slice(0, 30);
      const svg = `<svg width="512" height="512">
        <rect x="0" y="440" width="512" height="72" fill="black" fill-opacity="0.55" />
        <text x="256" y="486" font-size="34" fill="white" text-anchor="middle" font-family="sans-serif">${safeLabel}</text>
      </svg>`;

      const webp = await sharp(buffer)
        .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .composite([{ input: Buffer.from(svg), top: 0, left: 0 }])
        .webp()
        .toBuffer();

      await ctx.sock.sendMessage(ctx.chatId, { sticker: webp }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر حقوق_ستكر:", err);
      await notifyOwnerOfError(ctx.sock, ".حقوق_ستكر", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل إضافة الحقوق." }, { quoted: ctx.msg });
    }
  },
};

export default command;
