import { Command } from "../../handlers/types";
import { applyDecorationStyle } from "../../utils/decorationStyles";

const command: Command = {
  name: "ز6",
  category: "اوامر_جانبيه",
  description: "يزخرف نص إنجليزي بالنمط رقم 6",
  permission: "all",
  execute: async (ctx) => {
    const input = ctx.text.trim();
    if (!input) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب نص بعد الأمر. مثال: .ز6 hello" }, { quoted: ctx.msg });
      return;
    }
    const decorated = applyDecorationStyle(input, 5);
    await ctx.sock.sendMessage(ctx.chatId, { text: decorated }, { quoted: ctx.msg });
  },
};

export default command;
