import { Command } from "../../handlers/types";
import { jidToMention, getQuotedParticipant } from "../../utils/helpers";
import { addPoint } from "../../database/db";

const MOVES = [
  "🗡️ ضربة سيف حاسمة", "🔥 كرة نار ضخمة", "⚡ صاعقة برق", "🛡️ درع دفاعي مثالي",
  "🌪️ إعصار قوي", "💥 لكمة ساحقة", "❄️ نفس متجمد", "🌊 موجة عملاقة",
];

const command: Command = {
  name: "مبارزة",
  category: "ترفيه",
  description: "مبارزة عشوائية بينك وبين شخص (منشن أو رد على رسالته)",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const replied = getQuotedParticipant(ctx.msg);
    const opponent = mentioned || replied;

    if (!opponent) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ منشن شخص أو رد على رسالته عشان تبارزه." },
        { quoted: ctx.msg }
      );
      return;
    }
    if (opponent === ctx.senderJid) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما تقدر تبارز نفسك!" }, { quoted: ctx.msg });
      return;
    }

    const rounds = 3;
    let p1Score = 0;
    let p2Score = 0;
    const log: string[] = [];

    for (let i = 1; i <= rounds; i++) {
      const m1 = MOVES[Math.floor(Math.random() * MOVES.length)];
      const m2 = MOVES[Math.floor(Math.random() * MOVES.length)];
      const p1Roll = Math.random();
      const p2Roll = Math.random();
      if (p1Roll > p2Roll) {
        p1Score++;
        log.push(`الجولة ${i}: ${m1} 🆚 ${m2} — نقطة للاعب الأول`);
      } else {
        p2Score++;
        log.push(`الجولة ${i}: ${m1} 🆚 ${m2} — نقطة للاعب الثاني`);
      }
    }

    const winner = p1Score > p2Score ? ctx.senderJid : opponent;
    if (p1Score !== p2Score) addPoint(ctx.chatId, winner, 1);

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `⚔️ *مبارزة!* ${jidToMention(ctx.senderJid)} 🆚 ${jidToMention(opponent)}\n\n` +
          `${log.join("\n")}\n\n` +
          `📊 النتيجة: ${p1Score} - ${p2Score}\n` +
          (p1Score === p2Score
            ? "🤝 تعادل!"
            : `🏆 الفائز: ${jidToMention(winner)} (+1 نقطة)`),
        mentions: [ctx.senderJid, opponent],
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
