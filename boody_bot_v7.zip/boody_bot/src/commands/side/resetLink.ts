import { Command } from "../../handlers/types";

// مُعاد بناؤه من ملفَين مكررين بالزيب الأصلي (تجديد.js و رستر.js) —
// دمجناهم بأمر واحد، وحذفنا اسم "رستر" كبديل لتجنّب تصادمه مع معنى
// "رستر = إعادة تشغيل البوت" المستخدم بملف آخر بنفس الزيب.
const command: Command = {
  name: "تجديد",
  aliases: ["تجديد_اللينك", "resetlink"],
  category: "اوامر_جانبيه",
  description: "يغيّر رابط دعوة الكروب الحالي ويبطل القديم",
  permission: "admin",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    try {
      const newCode = await ctx.sock.groupRevokeInvite(ctx.chatId);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: `🔗 *تم تجديد رابط الكروب.*\n\nالرابط الجديد:\nhttps://chat.whatsapp.com/${newCode}` },
        { quoted: ctx.msg }
      );
    } catch (err) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذر تجديد الرابط. تأكد إن البوت مشرف بالكروب." },
        { quoted: ctx.msg }
      );
    }
  },
};

export default command;
