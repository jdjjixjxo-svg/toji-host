import { Command } from "../../handlers/types";
import { start } from "../../handlers/passwordGameManager";

const command: Command = {
  name: "كلمة_السر",
  category: "ترفيه",
  description: "لعبة كلمة السر — خمّن الكلمة من التلميح بأقل محاولات",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId);
  },
};

export default command;
