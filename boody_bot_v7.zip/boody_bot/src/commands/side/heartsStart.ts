import { Command } from "../../handlers/types";
import { start as startHearts } from "../../handlers/heartsManager";

const command: Command = {
  name: "قلوب",
  category: "ترفيه",
  description: "يبدأ لعبة القلوب الجماعية",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const started = startHearts(ctx.sock, ctx.chatId, ctx.senderJid);
    if (!started) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ اللعبة شغالة حاليًا بهذا الكروب." }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          "❤️ *لقد بدأت لعبة القلوب!*\n\n" +
          "١. اكتب *.مشاركة* لتنضم وتحصل على 5 قلوب.\n" +
          "٢. صاحب اللعبة يستخدم *.انقاص* (بالرد على رسالة اللاعب) لتقليل قلب أحدهم.\n" +
          "٣. اكتب *.نتيجه* لعرض حالة اللاعبين.\n" +
          "٤. اكتب *.استسلم* لإنهاء اللعبة.",
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
