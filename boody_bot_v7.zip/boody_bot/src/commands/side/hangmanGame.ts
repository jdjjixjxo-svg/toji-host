import { Command } from "../../handlers/types";
import { start } from "../../handlers/hangmanManager";

const command: Command = {
  name: "المشنقة",
  category: "ترفيه",
  description: "لعبة المشنقة الجماعية — خمّنوا الكلمة حرفًا بحرف",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    await start(ctx.sock, ctx.chatId);
  },
};

export default command;
