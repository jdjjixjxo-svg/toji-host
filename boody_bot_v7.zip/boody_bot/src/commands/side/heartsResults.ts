import { Command } from "../../handlers/types";
import { getResults } from "../../handlers/heartsManager";
import { jidToMention } from "../../utils/helpers";

const command: Command = {
  name: "نتيجه",
  category: "ترفيه",
  description: "يعرض حالة اللاعبين بلعبة القلوب الجارية",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const results = getResults(ctx.sock, ctx.chatId);
    if (!results) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ لا توجد لعبة قلوب نشطة حاليًا." }, { quoted: ctx.msg });
      return;
    }
    if (!results.alive.length) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "لا يوجد لاعبون بعد. اكتب .مشاركة للانضمام." }, { quoted: ctx.msg });
      return;
    }

    const mentions: string[] = [];
    const lines = results.alive.map((line) => {
      const [jid, rest] = line.split(" - ");
      mentions.push(jid);
      return `${jidToMention(jid)} - ${rest}`;
    });

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: `*نتائج اللعبة*\n\n${lines.join("\n")}`, mentions },
      { quoted: ctx.msg }
    );
  },
};

export default command;
