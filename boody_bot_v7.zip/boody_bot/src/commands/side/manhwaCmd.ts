import { Command } from "../../handlers/types";
import { searchManga, getLatestChapter, downloadChapterAsPdf } from "../../utils/mangaDex";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

// نفس منطق .مانجا بالضبط — MangaDex كتالوج واحد للمانجا والمانهوا معًا،
// ما فيه API منفصل. أمر مستقل بس عشان يطابق تسمية قائمة صاحبك.
const command: Command = {
  name: "مانهوا",
  category: "اوامر_جانبيه",
  description: "يبحث عن مانهوا ويحمّل آخر فصل كـPDF. مثال: .مانهوا solo leveling",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب اسم المانهوا. مثال: .مانهوا solo leveling" }, { quoted: ctx.msg });
      return;
    }
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    try {
      const manga = await searchManga(query);
      if (!manga) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما لقيت مانهوا بهذا الاسم." }, { quoted: ctx.msg });
        return;
      }

      const chapter = await getLatestChapter(manga.id);
      if (!chapter) {
        await ctx.sock.sendMessage(ctx.chatId, { text: `❌ لقيت "${manga.title}" بس ما فيها فصول متاحة حاليًا.` }, { quoted: ctx.msg });
        return;
      }

      await ctx.sock.sendMessage(ctx.chatId, { text: `📖 يجهّز "${manga.title}" — الفصل ${chapter.chapter}...` });

      const pdf = await downloadChapterAsPdf(chapter.id);
      await ctx.sock.sendMessage(ctx.chatId, {
        document: pdf,
        fileName: `${manga.title} - ${chapter.chapter}.pdf`,
        mimetype: "application/pdf",
        caption: `📖 ${manga.title} — الفصل ${chapter.chapter}`,
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر مانهوا:", err);
      await notifyOwnerOfError(ctx.sock, ".مانهوا", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء تجهيز المانهوا." }, { quoted: ctx.msg });
    }
  },
};

export default command;
