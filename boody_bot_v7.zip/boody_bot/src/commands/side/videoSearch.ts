import { Command } from "../../handlers/types";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";

// يرسل روابط فقط (بحث نصي عن معرّفات فيديوهات بصفحة نتائج يوتيوب) —
// بدون أي تحميل فعلي، فلا مخاوف حقوق نشر (زي .اغنيه بالضبط، فقط روابط/
// معاينة رسمية).
const command: Command = {
  name: "فيديو",
  category: "اوامر_جانبيه",
  description: "يبحث عن فيديو يوتيوب ويرسل روابطه. مثال: .فيديو ون بيس",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ اكتب اسم الفيديو. مثال: .فيديو ون بيس" },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🆕 (طلب صريح: قيود على المحتوى الجنسي)
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    try {
      const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
      const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
      const html = await res.text();
      const ids = [...html.matchAll(/"videoId":"(.*?)"/g)].map((m) => m[1]);
      const seen = new Set<string>();
      const unique = ids.filter((id) => !seen.has(id) && seen.add(id)).slice(0, 3);

      if (!unique.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما لقيت نتايج." }, { quoted: ctx.msg });
        return;
      }

      const text = unique.map((id) => `📹 https://www.youtube.com/watch?v=${id}`).join("\n");
      await ctx.sock.sendMessage(ctx.chatId, { text }, { quoted: ctx.msg });
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ حدث خطأ أثناء البحث." }, { quoted: ctx.msg });
    }
  },
};

export default command;
