import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";

// 🔧 (إصلاح أمان مهم) — الأصل كان فيه رقم واتساب أجنبي مكتوب حرفيًا
// بالكود ('212700764714@s.whatsapp.net' — رقم مطور البوت الأصلي اللي
// اشتُري منه الملف)، فكل شكوى كانت بترسل لصاحب البوت الأصلي، مو لكم!
// استبدلناه بـCONFIG.OWNER_JID (رقم مالك هذا البوت من .env).
const command: Command = {
  name: "شكوى",
  category: "اوامر_جانبيه",
  description: "إرسال شكوى لصاحب البوت مباشرة",
  permission: "all",
  execute: async (ctx) => {
    const complaint = ctx.text.trim();
    if (!complaint) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "📢 اكتب شكواك بعد الأمر.\nمثال: .شكوى في عضو بيسبم بالكروب" },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: "✅ شكواك تم تسجيلها وإرسالها للمطور.\n📌 شكرًا لتعاونك!" },
      { quoted: ctx.msg }
    );

    let groupName = "";
    if (ctx.chatId.endsWith("@g.us")) {
      groupName = ctx.metadata?.subject || "كروب غير معروف";
    }

    await ctx.sock.sendMessage(CONFIG.OWNER_JID, {
      text:
        `📩 *شكوى جديدة*\n\n` +
        `📬 من: wa.me/${ctx.senderJid.split("@")[0]}\n` +
        (groupName ? `👥 الكروب: ${groupName}\n` : "") +
        `📢 الشكوى:\n${complaint}`,
    });
  },
};

export default command;
