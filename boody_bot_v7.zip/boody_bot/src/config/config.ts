import "dotenv/config";

/**
 * ⚙️ ملف الإعدادات المركزي
 * كل ما يخص هوية البوت والمطور والسلوك العام موجود هنا فقط.
 * غيّر القيم من ملف .env — لا حاجة لتعديل أي كود آخر.
 */
export const CONFIG = {
  // ===== هوية البوت =====
  BOT_NAME: process.env.BOT_NAME || "『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆\n𝑩𝑶𝑻 』",
  PREFIX: process.env.PREFIX || ".",
  BOT_VERSION: "4.0",

  // ===== معلومات المطور (مكان واحد فقط للتعديل) =====
  OWNER_NAME: process.env.OWNER_NAME || "👑 𝑴𝑰𝑯𝑨𝑾𝑲 | 𒉭 ميهوك",
  // 🔧 إصلاح جذري: نطهّر الرقم من أي رمز غير رقمي (+، مسافات، شرطات...)
  // فور قراءته من .env. قبل هذا الإصلاح، isOwner() في permissions.ts كانت
  // تقارن target (رقم منظّف بالكامل عبر digitsOnly) مباشرة مع CONFIG.OWNER_NUMBER
  // الخام كما كُتب في .env — فلو المطور كتب رقمه بصيغة "+964xxxxxxxxx" أو
  // "964 xxx xxx xxxx" (وهو أشيع شكل ينسخه الناس من واتساب فعليًا)، المقارنة
  // تفشل دائمًا لأن الطرفين مختلفين شكليًا حتى لو نفس الرقم فعليًا. هذا يفسر
  // بالضبط مشكلة "متأكد من رقمي بس البوت يعاملني كعضو عادي مو المطور".
  OWNER_NUMBER: (process.env.OWNER_NUMBER || "905382160878").replace(/[^0-9]/g, ""),
  get OWNER_JID() {
    return `${this.OWNER_NUMBER}@s.whatsapp.net`;
  },

  // 🆕 المطور الثاني (اختياري) — هوية مستقلة كاملة الصلاحيات مثل المطور
  // الأساسي تمامًا (راجع isOwner بـ middlewares/permissions.ts)، تُقرأ من
  // .env فقط بدون أي رقم مكتوب بالكود. لو تُركت فارغة، زر "🤍 المطور
  // الثاني" لا يُضاف إطلاقًا ولا يُعامل أي رقم كمطور ثانٍ.
  // ⚠️ هذا رقم عام (owner-level) بنفس منطق CONFIG.OWNER_NUMBER الحالي —
  // ما له علاقة بأي بوت فرعي محدد، فلا يكسر عزل الـsub-bots عن بعضها.
  OWNER_NUMBER_2: (process.env.OWNER_NUMBER_2 || "").replace(/[^0-9]/g, ""),
  OWNER_NAME_2: process.env.OWNER_NAME_2 || "🤍 المطور الثاني",

  // 🆕 المطور الثالث (رئيسي) — صلاحيات مطابقة تمامًا للمطور الأساسي والثاني
  OWNER_NUMBER_3: (process.env.OWNER_NUMBER_3 || "201282291403").replace(/[^0-9]/g, ""),
  OWNER_NAME_3: process.env.OWNER_NAME_3 || "🖤 المطور الثالث",

  // 🆕 رابط قناة واتساب (يظهر كزر "📢 عرض القناة" تلقائيًا بآخر كل رسالة
  // أزرار بأي قسم — بنفس فكرة زر "💬 مراسلة المطور" بالضبط، راجع
  // buildNativeFlowButtons بـ utils/interactive.ts). لو تُرك فارغًا، الزر
  // لا يُضاف إطلاقًا (بدل زر مكسور برابط فارغ). غيّره من .env فقط.
  CHANNEL_LINK: process.env.CHANNEL_LINK || "",
  // 🎮 رابط صفحة ألعاب 3D الفورية (assets/games/index.html بعد رفعها على أي استضافة ثابتة).
  // لو فاضي: ترجع الألعاب لنسخة الصور داخل الشات.
  // 🧹 الردود التلقائية القديمة (بوتي/ملل/جيت/هاي/شتائم/انا مطورك...) موقوفة افتراضيًا. لتشغيلها: LEGACY_AUTO_REPLIES=1
  LEGACY_REPLIES: process.env.LEGACY_AUTO_REPLIES === "1",
  GAMES_URL: (process.env.GAMES_URL || "https://moazfree43-hue.github.io/games/").trim(), // افتراضي جاهز (لتعطيله ضع GAMES_URL=off)

  // 🆕 رابط كروب الدعم — يظهر كزر "⚜️𝑴𝑹 𝑩𝒐𝒕𝒔 𝑺𝒖𝒑𝒑𝒐𝒓𝒕⚜️" بآخر كل رسالة
  // أزرار، قبل زر "📢 عرض القناة" مباشرة. نفس منطق CHANNEL_LINK بالضبط —
  // لو تُرك فارغًا، الزر لا يُضاف إطلاقًا.
  SUPPORT_GROUP_LINK:
    process.env.SUPPORT_GROUP_LINK ||
    "https://chat.whatsapp.com/Db3ZW74EWIAH5zdTalrsIQ?s=cl&p=a&mlu=4",

  // 🆕 (بند 5 من الطلب) — الاسم الأزرق القابل للضغط اللي يطلع فوق كل رسالة
  // زي بوت "itadori" اللي أرسلت صورته (تاغ أخضر "معاد توجيهها" + اسم القناة
  // بالأزرق يفتح القناة مباشرة). هذا مو أزرار واتساب العادية — هو خدعة
  // بروتوكول (forwardedNewsletterMessageInfo) تخلي الرسالة "تتنكر" وكأنها
  // مُعاد توجيهها من قناة واتساب حقيقية.
  //
  // ⚠️ يحتاج CHANNEL_JID (مو CHANNEL_LINK) — وهو معرّف القناة الداخلي بصيغة
  // "xxxxxxxxxxxxxxxxx@newsletter"، مختلف تمامًا عن رابط الدعوة العادي.
  // طريقة الحصول عليه: افتح قناتك بواتساب ← ⋮ ← معلومات القناة ← انسخ الرابط،
  // ثم مرر نفس الرابط لدالة sock.newsletterMetadata("invite", الكود) وقت
  // التشغيل (أو استخدم أي أداة مطوّرين تقرأ newsletter jid من رابط القناة)
  // واحفظ الناتج هنا. لو تُرك فارغًا، هذي الخاصية لا تُفعَّل إطلاقًا ولا
  // تُغيّر أي شي بشكل الرسائل العادية (بدون أي كسر).
  //
  // 🔧 ملاحظة صراحة: هذا استخدام غير موثّق رسميًا من واتساب (نفس فلسفة كل
  // الأزرار التفاعلية بـ interactive.ts) — "أفضل محاولة"، قد يتوقف أو يتغير
  // بأي وقت بدون إشعار، ولم يُختبر فعليًا على حساب حقيقي (البيئة اللي كُتب
  // فيها هذا الكود بلا اتصال إنترنت/واتساب). جرّبه واطلع لي بأي خطأ يصير.
  CHANNEL_JID: process.env.CHANNEL_JID || "",

  // ===== الجلسة =====
  SESSION_ID: process.env.SESSION_ID || "",
  SESSION_DIR: process.env.SESSION_DIR || "session",

  // ===== الذكاء الاصطناعي (.رسم / .سوال) =====
  // مزود Google Gemini — مجاني فعليًا بدون بطاقة ائتمان (حد يومي سخي)،
  // وفيه فلاتر أمان مدمجة من جوجل نفسها (يمنع نفس مشكلة الصور الغير لائقة
  // اللي صارت قبل مع مصدر مجاني بلا رقابة). خذ مفتاحك مجانًا من
  // https://aistudio.google.com/app/apikey (تسجيل دخول بحساب جوجل فقط،
  // بدون أي معلومات دفع) وحطه بـ.env — بدون هذا المفتاح، أوامر قسم IA
  // تتوقف برسالة توضيحية بدل ما تحاول.
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || "",
  // 🆕 أمر .طقس (اوامر جانبيه) — https://openweathermap.org/api
  WEATHER_API_KEY: process.env.WEATHER_API_KEY || "",
  // 🆕 قاعدة البيانات السحابية (Supabase) — تُستخدم لأمرين فقط:
  //  1) نظام الألقاب (.تسجيل_لقب...) — كان سابقًا على MongoDB.
  //  2) نسخة احتياطية سحابية دورية لكامل db.json المحلي (كانت سابقًا على MongoDB أيضًا).
  // خذ القيمتين من: لوحة تحكم مشروعك على supabase.com → Project Settings → API.
  SUPABASE_URL: process.env.SUPABASE_URL || "",
  SUPABASE_KEY: process.env.SUPABASE_KEY || "",
  // 🆕 مفاتيح لأوامر مؤجّلة (لسا ما بُنيت) — جاهزة بالكونفيج عشان تُستخدم
  // فور ما تُبنى الأوامر المرتبطة فيها
  ELEVENLABS_API_KEY: process.env.ELEVENLABS_API_KEY || "",
  REMOVEBG_API_KEY: process.env.REMOVEBG_API_KEY || "",
  DEEPAI_API_KEY: process.env.DEEPAI_API_KEY || "",
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || "",

  // ===== البحث والأخبار (.بحث / .اخبار) =====
  // مزود Tavily — مجاني بالكامل بدون بطاقة ائتمان (1000 طلب/شهر، تسجيل
  // بالإيميل فقط). خذ مفتاحك من https://app.tavily.com (Get API Key من
  // لوحة التحكم بعد التسجيل، يبدأ بـ "tvly-") وحطه بـ.env — بدون هذا
  // المفتاح، أوامر البحث والأخبار تتوقف برسالة توضيحية بدل ما تحاول.
  TAVILY_API_KEY: process.env.TAVILY_API_KEY || "",

  // ===== أوامر ذاتية =====
  // يسمح للمالك بإرسال أوامر من نفس رقم البوت نفسه (مفيد جدًا إن كان
  // الرقم المرتبط بالبوت هو رقمك الشخصي ولا تملك رقمًا آخر للاختبار).
  // اجعلها "false" في .env لتعطيلها إن أردت.
  SELF_COMMANDS: (process.env.SELF_COMMANDS ?? "true") !== "false",

  // ===== رسائل عامة =====
  WELCOME_MESSAGE:
    process.env.WELCOME_MESSAGE ||
    "🎉 أهلًا وسهلًا @user في مجموعة *{group}*!\nنتمنى لك وقتًا ممتعًا 🌟",
  GOODBYE_MESSAGE:
    process.env.GOODBYE_MESSAGE || "👋 وداعًا @user، نتمنى لك التوفيق!",

  // ===== نظام الحماية (قيم افتراضية، قابلة للتغيير لكل مجموعة عبر .اعدادات) =====
  MAX_WARNINGS: Number(process.env.MAX_WARNINGS || 3),

  // ===== الأداء =====
  ANTISPAM_WINDOW_MS: 8000, // النافذة الزمنية لرصد السبام
  ANTISPAM_MAX_MSGS: 6, // عدد الرسائل المسموح خلال النافذة

  // 🆕 حماية من "طرد جماعي سريع" (مشرف يطرد أعضاء بسرعة غير طبيعية) —
  // لو مشرف واحد نفّذ عدد الطردات هذا خلال النافذة الزمنية هذي، البوت
  // ينزّله من الإشراف تلقائيًا ويرسل تحذير بالمجموعة. راجع
  // src/events/groupParticipants.ts للتفاصيل الكاملة.
  ANTINUKE_MAX_KICKS: 3,
  ANTINUKE_WINDOW_MS: 30_000,
};

export type BotConfig = typeof CONFIG;
