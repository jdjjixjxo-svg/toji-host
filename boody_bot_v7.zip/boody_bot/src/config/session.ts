import fs from "fs-extra";
import path from "path";
import { CONFIG } from "./config";
import { logger } from "../utils/logger";

/**
 * 🔐 نظام استرجاع/تصدير الجلسة عبر SESSION_ID (Base64)
 * ==========================================================
 * ⚠️ ملاحظة مهمة جدًا (كانت سبب مشاكل "Bad MAC" السابقة):
 * لا يكفي حفظ ملف creds.json فقط! فمكتبة Baileys تعتمد على بروتوكول Signal،
 * الذي يخزّن أيضًا مفاتيح الجلسات لكل محادثة (session-*.json) ومفاتيح ما قبل
 * المشاركة (pre-key-*.json) وغيرها داخل مجلد الجلسة. عند استعادة creds.json
 * فقط دون بقية الملفات، يظن الهاتف أن جلسة تشفير قديمة ما زالت قائمة بينما
 * البوت فقد كل حالة التشفير المرتبطة بها، فتفشل عملية فك التشفير بخطأ
 * "Bad MAC" فور استلام أي رسالة. لذلك أصبح SESSION_ID الآن يمثّل **مجلد
 * الجلسة كاملًا** (كل الملفات) وليس ملفًا واحدًا فقط.
 *
 * طريقة توليد SESSION_ID:
 *   1) شغّل البوت مرة واحدة محليًا بدون SESSION_ID → سيطلب مسح QR.
 *   2) بعد نجاح الاتصال وتبادل بعض الرسائل (حتى تستقر الجلسة)، شغّل:
 *        npm run export-session
 *   3) انسخ القيمة الناتجة وضعها في SESSION_ID داخل .env أو إعدادات الاستضافة.
 */

interface SerializedSession {
  [fileName: string]: string;
}

/**
 * 🆕 حارس أخطاء إملائية شائعة باسم "creds.json" (مثال حقيقي واجهناه:
 * ملف بالاسم "crads.json" بدل "creds.json" — حرفين متبدّلين بالغلط عند
 * رفع/تسمية الملف يدويًا على استضافة). لو الاسم الصحيح غير موجود لكن
 * وجدنا نسخة بأحد الأخطاء الشائعة هذي، نعيد تسميتها تلقائيًا بدل ما
 * يظل البوت "يظن" إنه ما فيه جلسة أصلًا (ويطلب QR من جديد رغم وجود
 * الملف فعليًا، بس باسم غلط ما يتعرف عليه أي كود Baileys).
 *
 * ⚠️ هذا يصلّح فقط مشكلة "الاسم غلط فما نلقاه" — لا يضمن أن محتوى
 * الملف نفسه جلسة مكتملة وناجحة فعليًا (لو كان الملف أصلًا نسخة جزئية/
 * قبل إتمام الربط، البوت سيطلب QR برضه بعد إعادة التسمية، وهذا سلوك
 * صحيح ومتوقع تمامًا، مو خطأ).
 */
const COMMON_CREDS_FILENAME_TYPOS = ["crads.json", "craeds.json", "cred.json", "creads.json"];

async function fixCommonCredsFilenameTypo(sessionDir: string, credsPath: string): Promise<void> {
  if (await fs.pathExists(credsPath)) return;
  for (const typo of COMMON_CREDS_FILENAME_TYPOS) {
    const typoPath = path.join(sessionDir, typo);
    if (await fs.pathExists(typoPath)) {
      logger.warn(
        `⚠️ لقينا ملف اسمه "${typo}" داخل مجلد الجلسة بدل "creds.json" الصحيح — جاري إعادة تسميته تلقائيًا الآن.`
      );
      try {
        await fs.move(typoPath, credsPath);
        logger.success(`✅ تمت إعادة التسمية إلى "creds.json" بنجاح.`);
      } catch (err) {
        logger.warn(
          `تعذّر إعادة التسمية تلقائيًا — أعد تسمية الملف يدويًا من "${typo}" إلى "creds.json" ثم أعد التشغيل.`,
          err
        );
      }
      return;
    }
  }
}

export async function restoreSessionFromEnv(): Promise<void> {
  const sessionDir = path.resolve(process.cwd(), CONFIG.SESSION_DIR);
  const credsPath = path.join(sessionDir, "creds.json");

  await fs.ensureDir(sessionDir);
  await fixCommonCredsFilenameTypo(sessionDir, credsPath);

  // لو الجلسة موجودة أصلاً على القرص (تشغيل محلي أو Volume دائم) لا داعي لإعادة الكتابة
  if (await fs.pathExists(credsPath)) {
    // 🔧 (طلب صريح — سبب لبس شائع): وجود ملف "creds.json" فعليًا لا يعني
    // تلقائيًا أنه جلسة ربط مكتملة وناجحة! Baileys يُنشئ ملف creds.json
    // "فارغ"/أولي (noiseKey + signedIdentityKey فقط، بدون "registered":true)
    // تلقائيًا حتى *قبل* أي مسح QR — فقط أول مرة يُستدعى فيها الكود. لو
    // الملف الحالي من هذا النوع (لم يكتمل ربطه فعليًا بواتساب من قبل)،
    // البوت *سيطلب QR* رغم وجود الملف — وهذا سلوك صحيح ومتوقع تمامًا،
    // وليس خطأ بالكود. نتحقق هنا من الحقل الحقيقي ونوضح أيهما بالضبط
    // بدل رسالة عامة قد تسبب انطباع خاطئ إن "الجلسة جاهزة" وهي ليست كذلك.
    try {
      const raw = JSON.parse(await fs.readFile(credsPath, "utf-8"));
      if (raw?.registered === true) {
        logger.info("📂 تم العثور على جلسة مكتملة ومسجّلة مسبقًا على القرص — سيربط تلقائيًا بدون QR.");
      } else {
        logger.warn(
          "📂 يوجد ملف creds.json لكنه غير مكتمل الربط بعد (لم يُمسح QR بنجاح من خلاله من قبل) — " +
            "سيُطلب منك مسح QR الآن كخطوة أولى وأخيرة، وبعدها يُحفظ تلقائيًا ويربط بدون QR بكل مرة قادمة."
        );
      }
    } catch {
      logger.warn("📂 يوجد ملف creds.json لكن تعذّرت قراءته/فهمه — سيُطلب QR كإجراء احتياطي آمن.");
    }
    return;
  }

  if (!CONFIG.SESSION_ID) {
    logger.warn(
      "⚠️ لا يوجد SESSION_ID في متغيرات البيئة. سيتم طلب مسح QR عند الاتصال."
    );
    return;
  }

  try {
    const decoded = Buffer.from(CONFIG.SESSION_ID, "base64").toString("utf-8");
    const parsed: SerializedSession | Record<string, unknown> = JSON.parse(decoded);

    // توافق مع الصيغة القديمة (نسخ سابقة كانت تخزن creds.json فقط كـ JSON مباشر)
    const looksLikeSingleCreds =
      typeof parsed === "object" &&
      parsed !== null &&
      ("noiseKey" in parsed || "me" in parsed) &&
      !("creds.json" in parsed);

    if (looksLikeSingleCreds) {
      logger.warn(
        "⚠️ SESSION_ID الحالي بالصيغة القديمة (creds.json فقط). هذا هو سبب أخطاء " +
          "Bad MAC عند إعادة التشغيل غالبًا. يُفضّل بشدة إعادة ربط البوت من جديد " +
          "(QR) ثم توليد SESSION_ID جديد عبر: npm run export-session"
      );
      await fs.writeFile(credsPath, JSON.stringify(parsed), "utf-8");
      return;
    }

    const files = parsed as SerializedSession;
    const entries = Object.entries(files);
    if (entries.length === 0) {
      throw new Error("SESSION_ID لا يحتوي على أي ملفات جلسة صالحة.");
    }

    for (const [fileName, content] of entries) {
      // حماية بسيطة من مسارات خبيثة (Path Traversal)
      const safeName = path.basename(fileName);
      await fs.writeFile(path.join(sessionDir, safeName), content, "utf-8");
    }

    logger.info(
      `✅ تم استرجاع جلسة الاتصال كاملة من SESSION_ID بنجاح (${entries.length} ملف).`
    );
  } catch (err) {
    logger.error(
      "❌ فشل فك تشفير SESSION_ID. تأكد أنه Base64 صالح تم توليده عبر npm run export-session.",
      err
    );
  }
}

/**
 * 📦 يجمع كل ملفات مجلد الجلسة الحالي ويحوّلها إلى قيمة SESSION_ID واحدة (Base64).
 * يُستخدم عبر الأمر: npm run export-session
 */
/**
 * 🆕 (ميزة .تنصيب) — أصبحت تقبل مسار مجلد جلسة اختياري بدل ما تفترض دائمًا
 * مجلد جلسة البوت الرئيسي (CONFIG.SESSION_DIR). تُستخدم أيضًا من
 * subBotManager.ts لتصدير نسخة احتياطية من جلسة أي بوت فرعي رُبط عبر
 * ".تنصيب" وإرسالها لصاحب الرقم على الخاص. السلوك القديم (بدون تمرير أي
 * وسيط) يبقى تمامًا كما هو.
 */
export async function exportSessionToBase64(sessionDirOverride?: string): Promise<string> {
  const sessionDir = sessionDirOverride
    ? path.resolve(sessionDirOverride)
    : path.resolve(process.cwd(), CONFIG.SESSION_DIR);
  const credsPath = path.join(sessionDir, "creds.json");

  if (!(await fs.pathExists(credsPath))) {
    throw new Error(
      "لا يوجد session/creds.json — شغّل البوت أولاً وامسح رمز QR قبل التصدير."
    );
  }

  const fileNames = (await fs.readdir(sessionDir)).filter((f) =>
    f.endsWith(".json")
  );

  const files: SerializedSession = {};
  for (const fileName of fileNames) {
    files[fileName] = await fs.readFile(path.join(sessionDir, fileName), "utf-8");
  }

  return Buffer.from(JSON.stringify(files)).toString("base64");
}
