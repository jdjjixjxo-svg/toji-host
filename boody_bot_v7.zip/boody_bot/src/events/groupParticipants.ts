import { WASocket } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { getGroupSettings, isBotEnabledInGroup } from "../database/db";
import { jidToMention, digitsOnly, getBotScopeId } from "../utils/helpers";
import { buildWelcomeCard, buildGoodbyeCard } from "../utils/welcomeCard";
import { getBotSelfNumber } from "../utils/botIdentity";
import { isOwner } from "../middlewares/permissions";
import { logger } from "../utils/logger";

/**
 * 🆕 (طلب صريح: "اذا حد من المشرفين بدا يطرد اعضاء بسرعه ووصل لـ 3
 * اعضاء البوت ينزله من الإشراف ويبعت رسالة تحذير") — تتبّع بسيط بالذاكرة
 * لعدد الطردات اللي نفّذها كل مشرف بكل مجموعة خلال نافذة زمنية قصيرة
 * (CONFIG.ANTINUKE_WINDOW_MS). لو وصل العدد لـ CONFIG.ANTINUKE_MAX_KICKS
 * يُنزّل تلقائيًا من الإشراف (بشرط أن يكون البوت نفسه مشرفًا).
 * المفتاح: `${chatId}:${digitsOnly(actorJid)}`.
 */
const kickTracker = new Map<string, { count: number; firstTs: number }>();

export function registerGroupParticipantsEvent(
  sock: WASocket,
  // 🆕 يُمرَّر true فقط عند التسجيل لمقبس بوت فرعي (راجع subBotManager.ts).
  // يجعل هذا الحدث يحترم .تعطيل_بوت بنفس منطق handleIncomingMessage
  // تمامًا (لا يوقف البوت الرئيسي أبدًا، ولا يؤثر على مجموعات أخرى).
  options?: { subBot?: boolean }
) {
  sock.ev.on("group-participants.update", async (update) => {
    try {
      const { id: chatId, participants, action } = update;
      const settings = getGroupSettings(chatId);

      // 🔧 إصلاح: هذا الحدث منفصل تمامًا عن handleIncomingMessage (يُسجَّل
      // على sock.ev مباشرة)، فكان لا يتحقق أبدًا من إعداد "ايقاف/تشغيل"
      // الخاص بالمجموعة (.ايقاف يوقف الرسائل والأوامر بس، ويضل البوت
      // يودّع ويرحب ويرقّي...). الحين لو هذا البوت بالذات موقوف بهذي
      // المجموعة نتجاهل كل شي هنا أيضًا (نفس سلوك بقية البوت تمامًا لما
      // تكون .ايقاف مفعّلة) — 🔧 (عزل البوتات) مرتبط بهوية البوت الحالي
      // فقط (isBotEnabledInGroup)، فإيقاف بوت واحد ما يسكت ترحيب/وداع
      // بقية البوتات الأخرى المنصّبة بنفس المجموعة.
      if (!isBotEnabledInGroup(chatId, getBotScopeId(sock))) return;
      // 🆕 (.تعطيل_بوت) — لو هذا مقبس بوت فرعي وهذي المجموعة معطّلة له
      // تحديدًا، لا يرحب/يودّع/يعلّق على ترقية إشراف — بنفس استقلالية
      // الفحص الموجود أصلًا بـmessageHandler.ts (لا يؤثر على البوت
      // الرئيسي ولا على أي مجموعة أخرى).
      if (options?.subBot && settings.subBotsEnabled === false) return;

      let metadata;
      try {
        metadata = await sock.groupMetadata(chatId);
      } catch {
        return;
      }

      // 👤 مين نفّذ العملية (رفع/تنزيل إشراف). بعض إصدارات Baileys ترجع هالحقل
      // ضمن الحدث (author)، وبعضها لأ — لهيك نتعامل معه بشكل مرن وما نفشل
      // إذا كان غير متوفر، ونعرض "غير معروف" بدل ما نكسر الميزة كاملة.
      const actorJid: string | undefined = (update as any).author;
      const actorMention = actorJid ? jidToMention(actorJid) : "غير معروف 🤷";

      // ===== 🆕 حماية من الطرد الجماعي السريع (إساءة استخدام صلاحية إشراف) =====
      if (action === "remove" && actorJid) {
        const actorDigits = digitsOnly(actorJid);
        const botDigits = getBotSelfNumber();
        const isBotItself = !!botDigits && actorDigits === botDigits;
        // المطور/المالك معفى دائمًا — قد يحتاج يطرد عدة أعضاء دفعة وحدة فعليًا
        const isOwnerActor = isOwner(actorJid, metadata, sock);

        if (!isBotItself && !isOwnerActor && actorDigits) {
          // 🔧 (عزل البوتات الفرعية) — نفس حدث الطرد الحقيقي بواتساب يوصل
          // بشكل منفصل لكل بوت مسجّل بهذي المجموعة (رئيسي + فرعي/فرعيين،
          // كل واحد له اتصاله الخاص). كان العداد "kickTracker" مشتركًا بلا
          // أي تمييز، فيتضاعف عدّه بعدد البوتات الموجودة (نفس الطرد
          // الواحد يُحتسب مرة لكل بوت) ويشغّل الحماية أسرع بكثير من الحد
          // المضبوط فعليًا. أضفنا هوية البوت بالمفتاح حتى يحسب كل بوت
          // الطردات الحقيقية بمعدلها الصحيح تمامًا.
          const key = `${getBotScopeId(sock)}:${chatId}:${actorDigits}`;
          const now = Date.now();
          const existing = kickTracker.get(key);
          const entry =
            existing && now - existing.firstTs < CONFIG.ANTINUKE_WINDOW_MS
              ? existing
              : { count: 0, firstTs: now };
          entry.count += participants.length;
          kickTracker.set(key, entry);

          if (entry.count >= CONFIG.ANTINUKE_MAX_KICKS) {
            kickTracker.delete(key);
            try {
              await sock.groupParticipantsUpdate(chatId, [actorJid], "demote");
              await sock.sendMessage(chatId, {
                text:
                  `🚨 تم تنزيل ${actorMention} من الإشراف تلقائيًا — طرد ${entry.count} أعضاء خلال وقت قصير جدًا (حماية ضد إساءة استخدام صلاحية الإشراف).\n` +
                  `لو هذا غير مقصود، يقدر المطور يرفعه إشراف من جديد يدويًا.`,
                mentions: [actorJid],
              });
            } catch (err) {
              logger.error("فشل تنزيل مشرف تلقائيًا بعد رصد طرد جماعي سريع:", err);
            }
          }
        }
      }

      // ===== 🆕 (طلب صريح) مضاد الإشراف — تنزيل فوري لأي مشرف يسحب إشراف
      // مشرف آخر، لو الإعداد مفعّل بهذي المجموعة (.مضاد_الاشراف فتح) =====
      if (action === "demote" && actorJid && settings.antiDemoteAbuse) {
        const actorDigits = digitsOnly(actorJid);
        const botDigits = getBotSelfNumber();
        const isBotItself = !!botDigits && actorDigits === botDigits;
        const isOwnerActor = isOwner(actorJid, metadata, sock);
        // demote ذاتي (شخص نزّل نفسه هو) مو إساءة استخدام — نستثنيه
        const isSelfDemote = participants.some((p) => digitsOnly(p) === actorDigits);

        if (!isBotItself && !isOwnerActor && !isSelfDemote && actorDigits) {
          try {
            await sock.groupParticipantsUpdate(chatId, [actorJid], "demote");
            await sock.sendMessage(chatId, {
              text: `🚨 تم تنزيل ${actorMention} من الإشراف تلقائيًا — نزّل إشراف مشرف آخر (مضاد الإشراف مفعّل بهذه المجموعة).`,
              mentions: [actorJid],
            });
          } catch (err) {
            logger.error("فشل تنزيل مشرف تلقائيًا بعد رصد إساءة استخدام (مضاد الإشراف):", err);
          }
        }
      }

      for (const jid of participants) {
        const mention = jidToMention(jid);

        if (action === "add" && settings.welcome) {
          const card = buildWelcomeCard(metadata.subject, mention);
          try {
            const url = await sock.profilePictureUrl(jid, "image");
            if (!url) throw new Error("NO_PROFILE_PICTURE");
            await sock.sendMessage(chatId, { image: { url }, caption: card, mentions: [jid] });
          } catch {
            await sock.sendMessage(chatId, { text: card, mentions: [jid] });
          }
        }

        if (action === "remove" && settings.goodbye) {
          // 🔧 (طلب صريح: قالب وداع جديد + صورة بروفايل) — نفس أسلوب
          // الترحيب بالضبط: نحاول جلب صورة بروفايل العضو المغادر ونرسلها
          // مع البطاقة كابشن، ولو ما عنده صورة (أو تعذر الجلب) نرسل نص فقط.
          const card = buildGoodbyeCard(metadata.subject, mention);
          try {
            const url = await sock.profilePictureUrl(jid, "image");
            if (!url) throw new Error("NO_PROFILE_PICTURE");
            await sock.sendMessage(chatId, { image: { url }, caption: card, mentions: [jid] });
          } catch {
            await sock.sendMessage(chatId, { text: card, mentions: [jid] });
          }
        }

        if (action === "promote") {
          await sock.sendMessage(chatId, {
            text: `⬆️ مبروك! ${mention} صار مشرف جديد بالكروب 🎉\n👤 اللي رفعه: ${actorMention}`,
            mentions: actorJid ? [jid, actorJid] : [jid],
          });
        }

        if (action === "demote") {
          await sock.sendMessage(chatId, {
            text: `⬇️ ${mention} انسحب منه الإشراف.\n👤 اللي نزّله: ${actorMention}`,
            mentions: actorJid ? [jid, actorJid] : [jid],
          });
        }
      }
    } catch (err) {
      logger.error("خطأ في معالجة حدث انضمام/مغادرة/ترقية الأعضاء:", err);
    }
  });
}
