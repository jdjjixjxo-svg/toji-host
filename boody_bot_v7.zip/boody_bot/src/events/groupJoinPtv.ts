/**
 * 🆕 (طلب صريح) — يرسل فيديو دائري (PTV) لكل مجموعة ينضم لها البوت
 * لأول مرة. مُعالَج مرة وحدة (مربّع + مضغوط) ومُخزَّن مؤقتًا بالذاكرة،
 * فما نعيد معالجة الفيديو الأصلي بكل مرة ينضم فيها لمجموعة جديدة.
 */
import path from "path";
import fs from "fs-extra";
import { WASocket } from "@whiskeysockets/baileys";
import { videoToSquarePtv } from "../utils/ffmpegMedia";
import { logger } from "../utils/logger";

const SOURCE_PATH = path.join(process.cwd(), "assets", "welcome-ptv-source.mp4");
let cachedPtv: Buffer | null = null;

export type PtvStatus = { buffer: Buffer } | { error: "NO_SOURCE" | "CONVERT_FAILED"; detail?: string };

/** نفس getPtvBuffer لكن يوضّح سبب الفشل (ما فيه فيديو أصلًا / فشل تحويل ffmpeg) */
export async function getPtvStatus(): Promise<PtvStatus> {
  if (cachedPtv) return { buffer: cachedPtv };
  if (!fs.existsSync(SOURCE_PATH)) return { error: "NO_SOURCE" };
  try {
    const raw = await fs.readFile(SOURCE_PATH);
    cachedPtv = await videoToSquarePtv(raw);
    return { buffer: cachedPtv };
  } catch (err) {
    logger.error("فشل تجهيز فيديو الترحيب الدائري (PTV):", err);
    return { error: "CONVERT_FAILED", detail: err instanceof Error ? err.message : String(err) };
  }
}

export async function getPtvBuffer(): Promise<Buffer | null> {
  const st = await getPtvStatus();
  return "buffer" in st ? st.buffer : null;
}

/** يمسح النسخة المخزنة مؤقتًا (بعد تغيير الفيديو المصدر بأمر .تست) */
export function resetPtvCache(): void {
  cachedPtv = null;
}

export const PTV_SOURCE_PATH = SOURCE_PATH;

export function registerGroupJoinPtvEvent(sock: WASocket): void {
  sock.ev.on("groups.upsert", async (groups) => {
    for (const group of groups) {
      try {
        const buffer = await getPtvBuffer();
        if (!buffer) return;
        await sock.sendMessage(group.id, {
          video: buffer,
          ptv: true,
        } as any);
      } catch (err) {
        logger.error(`فشل إرسال فيديو الترحيب الدائري بمجموعة ${group.id}:`, err);
      }
    }
  });
}
