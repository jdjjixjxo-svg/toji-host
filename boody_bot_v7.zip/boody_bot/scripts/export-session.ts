/**
 * 🧰 سكربت مساعد: يولّد قيمة SESSION_ID من مجلد الجلسة المحلي بعد الربط بنجاح.
 * الاستخدام:
 *   1) شغّل البوت محليًا وامسح رمز QR (npm run dev أو npm start بدون SESSION_ID).
 *   2) انتظر حتى يستقر الاتصال وتصلك رسالة "تم تشغيل البوت بنجاح".
 *   3) شغّل: npm run export-session
 *   4) انسخ القيمة المطبوعة وضعها في SESSION_ID (.env أو إعدادات الاستضافة).
 */
import { exportSessionToBase64 } from "../src/config/session";

exportSessionToBase64()
  .then((value) => {
    console.log("\n✅ انسخ القيمة التالية بالكامل وضعها في متغير SESSION_ID:\n");
    console.log(value);
    console.log(
      "\n⚠️ هذه القيمة تعطي تحكمًا كاملاً بحساب واتساب المرتبط — لا تشاركها مع أحد.\n"
    );
  })
  .catch((err) => {
    console.error("❌ فشل التصدير:", err.message || err);
    process.exit(1);
  });
