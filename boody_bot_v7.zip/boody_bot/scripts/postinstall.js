#!/usr/bin/env node
/**
 * postinstall — خفيف جدًا عمدًا.
 *
 * ⚠️ سبب انهيار "JavaScript heap out of memory" على Katabump (308MB رام):
 * الملف القديم كان يشغّل tsc (البناء) أثناء "npm install". قياس فعلي لبناء
 * هذا المشروع: ذروة الرام ~450MB — أكثر من ضعف ما تسمح به الخطة. فأي تشغيل
 * لـ tsc على السيرفر = انهيار مضمون، سواء كان dist جاهزًا أو لا.
 * الفحص القديم "هل src أحدث من dist؟" بالتواريخ غير موثوق: عند رفع/فك
 * الملفات على الاستضافة تتغير تواريخ التعديل عشوائيًا، فكان يظن أن الكود
 * تغيّر ويعيد البناء.
 *
 * الحل: dist/ يُبنى على جهازك فقط. هنا نطبّق باتش baileys ونتوقف —
 * ولا نبني إلا لو dist/index.js مفقود تمامًا (ولا نحاول ذلك إن كان
 * typescript غير مثبت، لأن الاستضافة تثبّت الإنتاج فقط).
 */
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const distEntry = path.join(ROOT, "dist", "index.js");
const tscBin = path.join(ROOT, "node_modules", "typescript", "bin", "tsc");

try {
  console.log("▶️  تصحيح باكيج baileys...");
  execSync("node scripts/patch-baileys-passive.js", { stdio: "inherit", cwd: ROOT });
} catch {
  console.warn("⚠️ تعذّر تطبيق باتش baileys — نكمل بدونه.");
}

if (fs.existsSync(distEntry)) {
  console.log("✅ dist/ موجود — لن يتم أي بناء على السيرفر (توفير الذاكرة).");
} else if (fs.existsSync(tscBin)) {
  console.warn("⚠️ dist/ مفقود — بناء اضطراري (يحتاج ~450MB رام؛ قد ينهار على الخطط الصغيرة).");
  try {
    execSync(`node --max-old-space-size=450 "${tscBin}"`, { stdio: "inherit", cwd: ROOT, timeout: 10 * 60 * 1000 });
  } catch {
    console.warn("⚠️ فشل البناء الاضطراري. ابنِ على جهازك (npm run build) وارفع dist/.");
  }
} else {
  console.warn("❌ dist/ مفقود ولا يوجد typescript على السيرفر. ابنِ على جهازك (npm i && npm run build) وارفع dist/.");
}
