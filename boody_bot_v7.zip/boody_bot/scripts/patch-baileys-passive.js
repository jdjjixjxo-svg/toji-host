#!/usr/bin/env node
/**
 * ============================================================================
 * 🔧 تصحيح تلقائي لخلل تسجيل/اقتران Baileys (passive: true)
 * ============================================================================
 * بعض إصدارات مكتبة Baileys (خصوصًا فروع 7.x الحديثة، وأحيانًا يوصل نفس
 * السلوك لنسخ 6.x عبر تحديثات فرعية) ترسل الحقل `passive: true` ضمن
 * رسالة تسجيل الدخول الأولى (generateLoginNode). في حالات معينة من
 * بروتوكول واتساب الحديث، هذا يخلي سيرفرات واتساب تتعامل مع الاتصال
 * كـ"مستمع سلبي" وتقفله فجأة (أو ما تكمل عملية الاقتران بشكل صحيح)
 * بدل ما تعامله كطلب اقتران/تسجيل فعلي.
 *
 * هذا السكربت يشتغل تلقائيًا بعد كل `npm install` (عبر postinstall)،
 * يفحص ملفات المكتبة المثبتة فعليًا (بغض النظر عن الإصدار أو المسار
 * الداخلي بالضبط)، ويستبدل `passive: true` بـ `passive: false` أينما
 * وجدها ضمن ملفات التسجيل/الاتصال فقط. آمن تمامًا: لو ما لقى شي، ما يغيّر
 * ولا حرف ولا يفشل التثبيت.
 * ============================================================================
 */

const fs = require("fs");
const path = require("path");

const BAILEYS_ROOT = path.join(__dirname, "..", "node_modules", "@whiskeysockets", "baileys", "lib");

// نفحص فقط الملفات المتعلقة بالتسجيل/الاتصال (تجنبًا لأي تعديل عشوائي
// بملفات ثانية قد يكون فيها `passive: true` بسياق مختلف تمامًا).
const TARGET_FILE_HINTS = ["validate-connection", "socket", "generate-login"];

/** يبحث بشكل تعاودي عن كل ملفات .js داخل مجلد lib */
function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full, out);
    } else if (entry.isFile() && entry.name.endsWith(".js")) {
      out.push(full);
    }
  }
  return out;
}

function main() {
  const allFiles = walk(BAILEYS_ROOT);
  const targets = allFiles.filter((f) =>
    TARGET_FILE_HINTS.some((hint) => path.basename(f).toLowerCase().includes(hint))
  );

  if (targets.length === 0) {
    console.log("ℹ️  [patch-baileys-passive] ما لقيت ملفات Baileys متوقعة (تجاهل — التثبيت يكمل عادي).");
    return;
  }

  let patchedCount = 0;

  for (const file of targets) {
    let content;
    try {
      content = fs.readFileSync(file, "utf8");
    } catch {
      continue;
    }

    // نطابق فقط النمط الدقيق `passive: true` أو `passive:true` أو
    // `passive: !0` (بعض أدوات bundling تحول true لـ !0) — تحسبًا.
    const patterns = [/passive\s*:\s*true/g, /passive\s*:\s*!0(?![\w])/g];

    let changed = false;
    let newContent = content;
    for (const pattern of patterns) {
      if (pattern.test(newContent)) {
        newContent = newContent.replace(pattern, "passive: false");
        changed = true;
      }
    }

    if (changed) {
      try {
        fs.writeFileSync(file, newContent, "utf8");
        patchedCount += 1;
        console.log(`✅ [patch-baileys-passive] تم تصحيح: ${path.relative(process.cwd(), file)}`);
      } catch (err) {
        console.warn(`⚠️  [patch-baileys-passive] تعذر الكتابة بالملف ${file}:`, err.message);
      }
    }
  }

  if (patchedCount === 0) {
    console.log("ℹ️  [patch-baileys-passive] ما لقيت `passive: true` بأي ملف (يمكن النسخة المثبتة ما فيها هذا الخلل أصلًا).");
  } else {
    console.log(`🖤 [patch-baileys-passive] تم تصحيح ${patchedCount} ملف/ملفات بنجاح.`);
  }
}

try {
  main();
} catch (err) {
  // لا نفشّل التثبيت كامل بسبب هذا التصحيح الاختياري لو صار خطأ غير متوقع
  console.warn("⚠️  [patch-baileys-passive] خطأ غير متوقع أثناء محاولة التصحيح (تم تجاهله):", err?.message || err);
}
