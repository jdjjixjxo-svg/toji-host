/**
 * ملف مدخل احتياطي (Shim) في جذر المشروع.
 * بعض منصات الاستضافة (مثل Katabump) تبحث افتراضيًا عن "index.js" في الجذر
 * كنقطة انطلاق، بينما ملفنا الفعلي بعد البناء موجود في dist/index.js.
 *
 * هذا الملف أيضًا شبكة أمان: لو نسيت المنصة تشغيل "npm install" (وبالتالي
 * postinstall الذي يبني المشروع)، أو حذفت مجلد dist بالخطأ، سيقوم هذا
 * الملف بتثبيت المكتبات (npm install) والبناء (tsc) تلقائيًا قبل التشغيل —
 * لا حاجة لأي تدخل يدوي حتى لو المنصة ما شغّلت أي خطوة تثبيت أصلًا.
 *
 * ⚠️ مهم: لا نبني المشروع (tsc) في كل مرة يُشغَّل فيها هذا الملف — فقط لو
 * كان dist/index.js غير موجود، أو لو فيه ملف مصدر (src/**) أحدث من آخر
 * بناء. فحص "هل يوجد ملف أحدث؟" خفيف جدًا (فقط قراءة تواريخ التعديل)
 * ولا يقارن بالبناء الكامل. هذا يمنع استهلاك الذاكرة والوقت في كل إعادة
 * تشغيل على استضافة محدودة الموارد (مثل Katabump بخطتها المجانية 308 ميجا
 * رام)، وبنفس الوقت يضمن أن أي تعديل جديد بالكود يُبنى تلقائيًا.
 */
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const distEntry = path.join(__dirname, "dist", "index.js");
const srcDir = path.join(__dirname, "src");

function getLatestMtime(dir) {
  let latest = 0;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return latest;
  }
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      latest = Math.max(latest, getLatestMtime(fullPath));
    } else {
      try {
        const mtime = fs.statSync(fullPath).mtimeMs;
        if (mtime > latest) latest = mtime;
      } catch {
        /* تجاهل */
      }
    }
  }
  return latest;
}

// ⚠️ لا نقارن تواريخ src/dist أبدًا: تواريخ الملفات تتغير عند الرفع/الفك على
// الاستضافة فكان يُشغَّل tsc (~450MB رام) ويسبب "heap out of memory" على 308MB.
// البناء يتم على جهازك فقط؛ هنا نبني فقط لو dist/index.js مفقود تمامًا.
function needsBuild() {
  return !fs.existsSync(distEntry);
}

/**
 * 🆕 شبكة أمان أهم من البناء نفسه: لو أي مكتبة من "dependencies" بملف
 * package.json غير مثبتة فعليًا بمجلد node_modules — نثبت كل المكتبات
 * من جديد هنا تلقائيًا قبل أي محاولة بناء أو تشغيل، بدل ما يفشل كل شي
 * بصمت أو بخطأ غامض "Cannot find module ...".
 *
 * 🔧 (سبب "أضفت مكتبة جديدة بـ package.json بس ما انثبتت لحالها"):
 * قبل كذا كنا نتحقق من مكتبة واحدة بس (baileys) كمؤشر عام على إن
 * التثبيت سليم — فلو node_modules أصلًا موجود من تثبيت سابق و *بعدين*
 * ضفنا مكتبة جديدة لـ package.json (متل jimp)، الفحص القديم يعتبر كل
 * شي تمام لأن baileys موجودة، ويتجاهل إن المكتبة الجديدة تحديدًا ناقصة.
 * الحل: نتحقق من *كل* مكتبة مذكورة بـ package.json وحدة وحدة (بما فيها
 * الحزم المسبوقة بـ @scope متل @whiskeysockets/baileys)، ولو أي وحدة
 * منها ناقصة نعيد "npm install" الكامل — هذا يشتغل تلقائيًا لأي مكتبة
 * تُضاف مستقبلًا بدون ما نحتاج نعدّل هذا الملف كل مرة.
 */
function getMissingDependencies() {
  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8"));
  } catch {
    return [];
  }
  const deps = Object.keys(pkg.dependencies || {});
  const missing = [];
  for (const dep of deps) {
    const depMarker = path.join(__dirname, "node_modules", ...dep.split("/"), "package.json");
    if (!fs.existsSync(depMarker)) missing.push(dep);
  }
  return missing;
}

function ensureDependenciesInstalled() {
  const missing = getMissingDependencies();
  if (missing.length === 0) return;

  console.log(`📦 مكتبات ناقصة (${missing.join("، ")}) — جاري تثبيت كل المكتبات تلقائيًا (npm install)...`);
  console.log("   ⏳ قد يأخذ هذا دقيقة أو دقيقتين حسب سرعة الاستضافة، الرجاء الانتظار...");
  try {
    execSync("npm install --omit=dev --no-audit --no-fund --no-progress", { stdio: "inherit", cwd: __dirname });
    console.log("✅ تم تثبيت المكتبات بنجاح.");
  } catch (err) {
    console.error(
      "❌ فشل تثبيت المكتبات تلقائيًا. جرّب تشغيل \"npm install\" يدويًا من طرفية الاستضافة (Console/Terminal) ثم أعد تشغيل البوت."
    );
    process.exit(1);
  }
}

ensureDependenciesInstalled();

if (needsBuild()) {
  console.error(
    "❌ dist/index.js غير موجود. البناء على هذي الاستضافة مستحيل (tsc يحتاج ~450MB رام).\n" +
      "   ابنِ على جهازك: npm install ثم npm run build، وارفع مجلد dist/ مع باقي الملفات."
  );
  process.exit(1);
}

console.log("✅ dist/ جاهز — تشغيل مباشر بدون بناء.");
require(distEntry);
